#!/usr/bin/env python3
r"""
regression_fixtures.py — generator behavior regression (the QC-sweep fixture).

Runs BOTH interior generators (generate_book.js kdp_paperback + generate_kindle.js)
over a tiny synthetic book engineered to hit every historically-defective input,
then unzips the DOCX output and asserts the RENDERED text is right. These are the
defects that were invisible under default configs and shipped silently:

  1. currency  — "$14.99 ... $24.99" on one line stays literal prose (dollars
                 kept), never a Cambria-Math run (nonfiction book, math ON).
  2. real math — \rightarrow / \cdots / \bigcup convert to → ⋯ ⋃ (the strippers
                 and the longest-first table hold).
  3. deep headings — an "#### H4" renders as a subsection heading, never body
                 text with literal hashes.
  4. bold+code — **`--config`** renders without orphaned literal ** runs.
  5. dashes    — zero U+2014/2013/2015/2012/2212 anywhere in the rendered text
                 (epigraph attribution included) under no_em_dashes.
  6. even/odd  — with interior.page_number_align="outer", settings.xml carries
                 an ENABLED <w:evenAndOddHeaders/> (not w:val="false").
  7. [IMAGE    — a prose line starting "[IMAGES were everywhere]" is NOT eaten.
  8. midflow   — a standalone "![alt](images/x.png)" line: kindle EMBEDS the
                 original, print EMBEDS too (2026-07-27, the figure-program
                 feature) and must prefer the grayscale "x_print.png" sibling
                 when present, build_epub embeds it as <figure class="midflow">
                 — and the literal markdown never reaches any rendered artifact.

EBOOK LEG (2026-09-24, the across_borders ebook QC): a second synthetic book
(labels, CJK, captioned figures, config free text with *italics*) built with
generate_kindle.js + build_epub.py only. Every case below FAILED on the
pre-fix generators:
  9. alt text: "![alt](path)" alt reaches EPUB <img alt> (escaped, markup
                 stripped) and the Kindle docPr descr/title (name = file name).
 10. CJK: CJK is never italic. DOCX CJK runs in italic contexts carry
                 italics OFF (Latin beside them stays italic) and an East Asian
                 w:lang (ja-JP for kana, else zh-CN); EPUB CJK runs sit in
                 <span class="cjk lang-xx" lang xml:lang> (upright via CSS,
                 plus a CJK font stack).
 11. captions: an italic caption line under an image. EPUB <figure> with
                 <img> + <figcaption>; Kindle image paragraph keepNext + a
                 centered caption paragraph right after it.
 12. labels: quote lines separated by blank lines or a bare ">" are ONE
                 block (one <blockquote>; DOCX tight inner spacing), and a bare
                 ">" never prints.
 13. headings: Kindle H1 text in real case with caps FORMATTING; About the
                 Author is a Heading 1 (and in the EPUB nav as an h1).
 14. metadata: Kindle core.xml title/creator = the book's; EPUB OPF title/
                 creator; EPUB copyright page carries strings.copyright_line +
                 strings.first_edition_line ("First edition" by default).
 15. config text: dedication / epigraph / attribution / About the Author
                 parse *italic* (no literal asterisk) in both ebooks.
 16. EPUB nav: a landmarks nav (cover, bodymatter; toc only when the nav is
                 in the spine); the in-book Contents (nav in the spine) only
                 with kindle_include_toc: true (LESSONS_LEDGER §16.4).

PRINT LEG (2026-09-24, KITP-A, the across_borders final render QC): a third
synthetic book built with generate_book.js kdp_paperback only (print_leg). Every
P case FAILED on the pre-fix generator:
 P1 config text: About the Author / dedication / epigraph / reader's note parse
                 *italic* (no literal asterisk); About is justified.
 P2 CJK never italic in print; the Latin beside it keeps its italics.
 P3 East Asian w:lang on every CJK run (ja-JP for kana, else zh-CN); a Latin book
                 carrying CJK gets docDefaults w:eastAsia + overflowPunct=0 (Word
                 kinsoku on, hanging punctuation off). Guard: a Latin-only book
                 gets neither (latin_book_untouched).
 P4 figures: interior.figure_max_h_in caps the height; with the OPT-IN
                 interior.min_image_ppi (300 here) no raster prints below it.
                 Guard: without that knob the historical sizing is kept
                 (figure_no_floor_without_knob).
 P5 captions: the caption after a figure keeps its lines (image keepNext); a
                 long plain paragraph after a figure is not bound.
 P6 TOC1/TOC2 styles in the book font with a hanging turnover indent.
 P7 interior.body_space_after_pt sets the body paragraph space after.
 P8 folio footer distance 540 twips (0.375 in from the trim).
 P9 DOCX core properties: title / subject / creator / lastModifiedBy.

KIT2-OTHER LEG (2026-09-24, the across_borders final render QC round 2): EPUB,
Kindle DOCX, digital PDF and cover compositor (kit2o_leg; its own synthetic
books). Every K case FAILED on the pre-fix tools:
 K1 EPUB figure/figcaption display:block (MuPDF no longer hoists a figure above
                 its chapter title)       K2 EPUB quote lines ragged-right
 K3 EPUB copyright page centered          K4 EPUB OPF role/file-as, dc:date,
                 dc:rights, schema.org accessibility metadata
 K5 Kindle label text in the body colour (ornaments keep their grey)
 K6 digital PDF digital_pdf.back_cover_last   K7 digital PDF /PageLabels = the
                 printed folios (roman front matter, named covers)
 K8 hardcover back laid out like the paperback back; a blurb line whose glyphs
                 end above the barcode keep-out keeps the full width
 K9 Kindle cover title/subtitle width cap (cover.kindle_text_width_frac)
 Guards (hold on both): default_back_cover_page_2, default_kindle_text_width.

KIT2-PRINT LEG (2026-09-24, the across_borders final render QC round 2):
generate_book.js only (kit2p_leg; its own synthetic book). Every R case FAILED
on the pre-round-2 generator:
 R1 interior.label_keep_max_lines: a run of quote lines is one label block
                 (keepNext down the run, keepLines); a run over the cap keeps only
                 its ends; a bare ">" never prints
 R2 Latin book with CJK: autoSpaceDE/DN off, compressed CJK punctuation
 R3 interior.hyphenate: settings in schema order; display text exempt
 R4 interior.caption          R5 title_lines (a mismatch fails the build)
 R6 TOC1/TOC2 right indent; interior.part_title_break ("Part One:" / title)
 R7 print figure alt text     R8 interior.label_cjk_nobreak_max (U+200D)
 R9 header distance 0.3 in    R10 part-page label note shares the label indent
 Guards (hold on both): guard_latin_book_no_cjk_spacing,
                 guard_no_hyphenation_without_knob,
                 guard_default_caption_title_heading, guard_no_joiners_without_knob,
                 guard_label_keep_off_by_default.

Workspace is a fresh temp dir (config-parent rooted — nothing in the repo is
touched). Needs node + the vendored _tools/node_modules; exits 2 SKIP without
(the epub leg is pure Python and runs regardless).

Usage:  python _tools/regression_fixtures.py [--json]
Exit:   0 all assertions hold · 1 regression · 2 environment missing
"""
from __future__ import annotations
import html
import json
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
ROOT = TOOLS.parent

MASTER = """# Chapter One

The book is $14.99 in paperback and $24.99 hardcover; the audiobook waits.

As $x \\rightarrow \\infty$ the series $a_1, \\cdots, a_n$ collects into $\\bigcup_{i=1}^{n} A_i$.

Run **`--config`** before anything else. *Steady now.*

- **The brain (`d3`), honestly labeled.** A cell can become one.

#### A Deep Subsection

[IMAGES were everywhere] and the crowd still would not look away.

![test photo](images/mf_test.png)

A caption line under the photo.

Body continues, plain and unhurried, with enough words to look like prose.
"""

CONFIG = {
    "title": "Regression Fixture",
    "subtitle": "The Defect Gauntlet",
    "author": "BOOKSMITH QC",
    "slug": "_regfix",
    "is_fiction": False,
    "formats": ["kdp_paperback", "kindle"],
    "min_pages": 1,
    "epigraph": {"text": "Every gate earns its keep.", "attribution": "The Ledger"},
    "front_matter": [{"type": "half_title"}, {"type": "title"},
                     {"type": "copyright"}, {"type": "epigraph"}],
    "interior": {"page_number_align": "outer"},
    "voice": {"unit_noun": "chapter", "no_em_dashes": True, "blacklist": []},
    "units": [{"id": "ch_01", "title": "Chapter One", "class": "C", "target_words": 80}],
}

DASHES = "—–―‒−"

# ---- the EBOOK LEG fixture (cases 9-16; kindle + epub generators only) -------
EBOOK_MASTER = """# Part One: The Setup

> Translation Notes

> 3-21-2024

> 萧百中 Xiao Bai-Zhong

*The first entry in the notes, 第一天.*

# Chapter One

A local name is marked 土名 on the label, and *the earth name 土名 is a small poem* in italics.

> BRIT610941 Calophanoides chinensis
>
> 李明红， 萧百中; [Li Minghong, Xiao Bai-Zhong]
>
> ヨーロッパ原産 [Native to Europe]

A paragraph between two labels.

> A single-line label 单行

![A test figure with "quotes" & an ampersand, plus *emphasis*.](images/fig_alt.png)

*A caption under the figure, with 中文 inside.*

Body after the caption, plain and unhurried.

![Second figure, no caption.](images/fig_nocap.png)

Body after the uncaptioned figure.
"""

EBOOK_CONFIG = {
    "title": "Ebook Fixture",
    "subtitle": "Labels and Figures 标本",
    "author": "Fixture Author",
    "slug": "_regebook",
    "is_fiction": False,
    "language": "en",
    "formats": ["kindle", "epub"],
    "kindle_include_toc": True,
    "dedication": "For *everyone* who reads 标签.",
    "epigraph": {"text": "Small *white* flowers 小白花.",
                 "attribution": "From *a label*, 1957."},
    "about_the_author": "Fixture Author wrote *The First Book* and then this one.",
    "strings": {"copyright_line": "Copyright © 2026 Fixture Author. All rights reserved.",
                "first_edition_line": "First edition, 2026. Fixture printing."},
    "voice": {"unit_noun": "chapter", "no_em_dashes": True, "blacklist": []},
    "units": [{"id": "part_one", "title": "Part One: The Setup", "class": "C", "target_words": 20},
              {"id": "ch_01", "title": "Chapter One", "class": "C", "target_words": 80}],
}

# independent of the generators' own tables: the CJK the fixture uses
CJK_RE = re.compile("[\U00003000-\U0000303F\U00003040-\U000030FF\U00003400-\U00004DBF"
                    "\U00004E00-\U00009FFF\U0000FF00-\U0000FFEF]")


def docx_paragraphs(doc_xml: str):
    """[(pPr, [(rPr, text)], text, raw)] for every w:p, in document order."""
    out = []
    for p in re.findall(r"<w:p[ >].*?</w:p>", doc_xml, re.S):
        ppr = re.search(r"<w:pPr>(.*?)</w:pPr>", p, re.S)
        runs = []
        for r in re.findall(r"<w:r>(.*?)</w:r>", p, re.S):
            rpr = re.search(r"<w:rPr>(.*?)</w:rPr>", r, re.S)
            t = "".join(re.findall(r"<w:t[^>]*>([^<]*)</w:t>", r))
            runs.append((rpr.group(1) if rpr else "", html.unescape(t)))
        out.append((ppr.group(1) if ppr else "", runs, "".join(t for _, t in runs), p))
    return out


def italic_on(rpr: str) -> bool:
    return re.search(r'<w:i(?:\s+w:val="(?:true|1|on)")?\s*/>', rpr) is not None


def spacing_of(ppr: str):
    m = re.search(r"<w:spacing\b([^>]*)/>", ppr)
    attrs = dict(re.findall(r'w:(\w+)="([^"]*)"', m.group(1))) if m else {}
    return int(attrs.get("before", 0)), int(attrs.get("after", 0))


def xhtml_body(x: str) -> str:
    m = re.search(r"<body[^>]*>(.*)</body>", x, re.S)
    return m.group(1) if m else x


def docx_text_and_settings(docx: Path):
    with zipfile.ZipFile(docx) as z:
        doc = z.read("word/document.xml").decode("utf-8", "replace")
        try:
            settings = z.read("word/settings.xml").decode("utf-8", "replace")
        except KeyError:
            settings = ""
        media = [n for n in z.namelist() if n.startswith("word/media/")]
        media_bytes = [z.read(n) for n in media]
    runs = re.findall(r"<w:t[^>]*>([^<]*)</w:t>", doc)
    # content assertions join with NO separator: adjacent runs in one paragraph
    # render adjacent ("$" + "24.99" is "$24.99" on the page)
    return runs, "".join(runs), settings, media, media_bytes


def tiny_png(path: Path, w=8, h=6, rgb=(180, 40, 40)):
    """Write a minimal valid RGB PNG (stdlib only) for image-embed fixtures."""
    import struct
    import zlib

    def chunk(tag, data):
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    raw = b"".join(b"\x00" + bytes(rgb) * w for _ in range(h))
    png = (b"\x89PNG\r\n\x1a\n"
           + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw))
           + chunk(b"IEND", b""))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(png)


def ebook_leg(checks: list, fails: list) -> None:
    """Cases 9-16: build EBOOK_MASTER with generate_kindle.js + build_epub.py in
    a fresh temp workspace and assert the rendered artifacts."""
    ws = Path(tempfile.mkdtemp(prefix="bs_regebook_"))

    def chk(target, name, ok, detail=""):
        checks.append({"target": target, "check": name, "pass": bool(ok), "detail": detail})
        if not ok:
            fails.append(f"{target}/{name}: {detail}")

    try:
        (ws / "outputs" / "markdown").mkdir(parents=True)
        (ws / "book_config.json").write_text(
            json.dumps(EBOOK_CONFIG, indent=2, ensure_ascii=False), encoding="utf-8")
        (ws / "outputs" / "markdown" / "_regebook_v1.md").write_text(EBOOK_MASTER, encoding="utf-8")
        tiny_png(ws / "images" / "fig_alt.png", w=12, h=9, rgb=(40, 120, 60))
        tiny_png(ws / "images" / "fig_nocap.png", w=9, h=12, rgb=(40, 60, 160))
        tiny_png(ws / "cover_art" / "_regebook_src.png")
        cfg_path = str(ws / "book_config.json")

        # ---------------- Kindle DOCX ----------------
        r = subprocess.run(["node", str(TOOLS / "generate_kindle.js"), "--config", cfg_path],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=180)
        if r.returncode != 0:
            fails.append(f"ebook generate_kindle.js rc={r.returncode}: "
                         f"{(r.stderr or r.stdout).strip()[-200:]}")
        docx = ws / "outputs" / "kindle" / "_regebook_KINDLE.docx"
        if docx.exists():
            with zipfile.ZipFile(docx) as z:
                doc = z.read("word/document.xml").decode("utf-8", "replace")
                core = z.read("docProps/core.xml").decode("utf-8", "replace")
            paras = docx_paragraphs(doc)

            # 9. alt text -> docPr descr + title, name = the image file name
            docprs = [dict(re.findall(r'(\w+)="([^"]*)"', a))
                      for a in re.findall(r"<wp:docPr\b([^>]*)/>", doc)]
            alt1 = 'A test figure with "quotes" & an ampersand, plus emphasis.'
            d1 = [d for d in docprs if html.unescape(d.get("descr", "")) == alt1]
            chk("kindle", "alt_text_in_docPr",
                len(d1) == 1 and html.unescape(d1[0].get("title", "")) == alt1
                and d1[0].get("name") == "fig_alt.png"
                and any(html.unescape(d.get("descr", "")) == "Second figure, no caption."
                        for d in docprs),
                f"docPr attributes: {docprs}")

            # 10. CJK never italic (Latin beside it keeps its italics) + w:lang
            cjk_runs = [(rpr, t) for _, runs, _, _ in paras for rpr, t in runs
                        if CJK_RE.search(t)]
            italic_cjk = [t for rpr, t in cjk_runs if italic_on(rpr)]
            upright = [t for rpr, t in cjk_runs if '<w:i w:val="false"/>' in rpr]
            latin_kept = any(t.strip() == "Xiao Bai-Zhong" and italic_on(rpr)
                             for _, runs, _, _ in paras for rpr, t in runs)
            chk("kindle", "cjk_never_italic",
                cjk_runs and not italic_cjk and len(upright) >= 8 and latin_kept,
                f"{len(cjk_runs)} CJK runs; italic CJK={italic_cjk[:6]}; "
                f"upright-in-italic-context={len(upright)}; Latin label italic={latin_kept}")
            def ea_lang(rpr):     # w:lang's eastAsia (NOT w:rFonts' eastAsia font)
                m = re.search(r'<w:lang\b[^>]*\bw:eastAsia="([^"]*)"', rpr)
                return m.group(1) if m else None
            untagged = [t for rpr, t in cjk_runs if ea_lang(rpr) is None]
            chk("kindle", "cjk_east_asian_lang",
                cjk_runs and not untagged
                and any("ヨーロッパ原産" in t and ea_lang(rpr) == "ja-JP" for rpr, t in cjk_runs)
                and any(t == "萧百中" and ea_lang(rpr) == "zh-CN" for rpr, t in cjk_runs),
                f"CJK runs without an East Asian w:lang: {untagged[:6]}")

            # 11. the italic caption line stays with its figure
            imgs = [k for k, p in enumerate(paras) if "<w:drawing>" in p[3]]
            cap_ok, detail = False, f"{len(imgs)} image paragraphs (want 2)"
            if len(imgs) == 2 and imgs[1] + 1 < len(paras):
                a, b = imgs
                nxt = paras[a + 1]
                cap_ok = ("<w:keepNext/>" in paras[a][0]
                          and nxt[2] == "A caption under the figure, with 中文 inside."
                          and '<w:jc w:val="center"/>' in nxt[0]
                          and "w:firstLine" not in nxt[0]
                          and "<w:keepNext/>" not in paras[b][0]
                          and paras[b + 1][2] == "Body after the uncaptioned figure.")
                detail = (f"captioned image pPr={paras[a][0][:90]!r}; next={nxt[2]!r} "
                          f"pPr={nxt[0][:90]!r}; uncaptioned image pPr={paras[b][0][:90]!r}")
            chk("kindle", "caption_bound_to_figure", cap_ok, detail)

            # 12. a run of quote lines is ONE block (tight inside); bare ">" silent
            want = {"Translation Notes": (120, 40), "3-21-2024": (0, 40),
                    "萧百中 Xiao Bai-Zhong": (0, 200),
                    "BRIT610941 Calophanoides chinensis": (120, 40),
                    "李明红， 萧百中; [Li Minghong, Xiao Bai-Zhong]": (0, 40),
                    "ヨーロッパ原産 [Native to Europe]": (0, 200),
                    "A single-line label 单行": (120, 200)}
            got = {}
            for t in want:
                p = next((p for p in paras if p[2] == t), None)
                got[t] = spacing_of(p[0]) if p else None
            literal_gt = [p[2] for p in paras if p[2].strip().startswith(">")]
            chk("kindle", "label_run_one_block", got == want and not literal_gt,
                f"(before, after) per label line={got}; literal '>' paragraphs={literal_gt}")

            # 13. H1 text in real case (caps FORMATTING) + About the Author is H1
            h1 = [(p[2], p[1]) for p in paras if '<w:pStyle w:val="Heading1"/>' in p[0]]
            h1_texts = [t for t, _ in h1]
            chk("kindle", "h1_real_case_caps_format",
                h1_texts[:2] == ["Part One: The Setup", "Chapter One"]
                and all(any("<w:caps/>" in rpr for rpr, _ in runs) for _, runs in h1),
                f"Heading 1 texts={h1_texts}")
            chk("kindle", "about_author_is_heading1", "About the Author" in h1_texts,
                f"Heading 1 texts={h1_texts}")

            # 14. core properties carry the book's title + author
            ct = re.search(r"<dc:title>([^<]*)</dc:title>", core)
            cc = re.search(r"<dc:creator>([^<]*)</dc:creator>", core)
            chk("kindle", "core_props_title_creator",
                ct is not None and ct.group(1) == "Ebook Fixture"
                and cc is not None and cc.group(1) == "Fixture Author" and "Un-named" not in core,
                f"core.xml tail={core[-300:]!r}")

            # 15. config free text takes the body's inline markup
            def para_with(sub):
                return next((p for p in paras if sub in p[2]), None)
            ded, epi, att, about = (para_with(s) for s in ("who reads", "flowers", "1957", "wrote"))
            conf_ok = all(p is not None and "*" not in p[2] for p in (ded, epi, att, about))
            conf_ok = conf_ok and any(t == "everyone" and italic_on(rp) for rp, t in ded[1]) \
                and any(t == "The First Book" and italic_on(rp) for rp, t in about[1])
            chk("kindle", "config_text_inline_markup", conf_ok,
                "dedication/epigraph/attribution/about: "
                + " | ".join(repr(p[2]) if p else "MISSING" for p in (ded, epi, att, about)))
        else:
            fails.append(f"ebook kindle: DOCX not produced at {docx}")

        # ---------------- EPUB ----------------
        r = subprocess.run([sys.executable, str(TOOLS / "build_epub.py"), "--config", cfg_path],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=180)
        if r.returncode != 0:
            fails.append(f"ebook build_epub rc={r.returncode}: "
                         f"{(r.stderr or r.stdout).strip()[-300:]}")
        epub = ws / "outputs" / "epub" / "_regebook.epub"
        if epub.exists():
            with zipfile.ZipFile(epub) as z:
                nm = z.namelist()
                rd = lambda n: z.read(n).decode("utf-8", "replace") if n in nm else ""  # noqa: E731
                texts = {n: rd(n) for n in nm if n.startswith("OEBPS/text/")}
                nav, opf, css = rd("OEBPS/nav.xhtml"), rd("OEBPS/content.opf"), rd("OEBPS/css/style.css")
            t = lambda name: texts.get(f"OEBPS/text/{name}", "")  # noqa: E731
            ch1, p1 = t("ch_01.xhtml"), t("part_one.xhtml")

            # 9. alt text, escaped, markup stripped
            chk("epub", "alt_text_in_img",
                'alt="A test figure with &quot;quotes&quot; &amp; an ampersand, plus emphasis."' in ch1
                and 'alt="Second figure, no caption."' in ch1,
                "figure <img alt> does not carry the markdown alt text")

            # 10. every CJK run is language-tagged (doc lang en), upright via CSS
            span_re = r'<span class="cjk lang-(zh|ja|ko)" lang="\1" xml:lang="\1">[^<]*</span>'
            leftover = {n: CJK_RE.findall(re.sub(span_re, "", xhtml_body(x)))[:4]
                        for n, x in texts.items()}
            leftover = {n: v for n, v in leftover.items() if v}
            chk("epub", "cjk_lang_tagged",
                not leftover
                and '<span class="cjk lang-ja" lang="ja" xml:lang="ja">ヨーロッパ原産</span>' in ch1
                and '<span class="cjk lang-zh" lang="zh" xml:lang="zh">萧百中</span>' in p1,
                f"CJK outside a lang span: {leftover}")
            chk("epub", "cjk_upright_css",
                "span.cjk { font-style: normal; }" in css
                and re.search(r"span\.lang-zh \{ font-family:", css) is not None
                and re.search(r"span\.lang-ja \{ font-family:", css) is not None,
                "stylesheet lacks the upright-CJK rule or the CJK font stacks")

            # 11. figure + figcaption (captioned), bare figure (uncaptioned)
            chk("epub", "figure_figcaption",
                re.search(r'<figure class="midflow"><img [^>]*mf_001_fig_alt\.png[^>]*/>'
                          r"<figcaption><em>A caption under the figure, with .*?inside\.</em>"
                          r"</figcaption></figure>", ch1) is not None
                and ch1.count("A caption under the figure") == 1
                and re.search(r'<figure class="midflow"><img [^>]*mf_002_fig_nocap\.png[^>]*/></figure>',
                              ch1) is not None,
                "captioned figure lacks <figcaption>, or the caption also renders outside it")

            # 12. one <blockquote> per run of quote lines; no empty/literal lines
            bq1 = re.findall(r"<blockquote>(.*?)</blockquote>", p1, re.S)
            bqc = re.findall(r"<blockquote>(.*?)</blockquote>", ch1, re.S)
            empty = [n for n, x in texts.items() if "<p></p>" in x or "<p>&gt;" in x]
            chk("epub", "label_run_one_blockquote",
                [b.count("<p>") for b in bq1] == [3] and [b.count("<p>") for b in bqc] == [3, 1]
                and not empty,
                f"part_one <p> per blockquote={[b.count('<p>') for b in bq1]} (want [3]); "
                f"ch_01={[b.count('<p>') for b in bqc]} (want [3, 1]); empty/literal in {empty}")

            # 13. About the Author: an h1 page listed in the nav
            chk("epub", "about_author_h1_in_nav",
                '<a href="text/about.xhtml">About the Author</a>' in nav
                and '<h1 class="unit">About the Author</h1>' in t("about.xhtml"),
                "About the Author missing from the nav or not an h1")

            # 14. OPF title/creator; copyright + edition lines from config
            chk("epub", "opf_title_creator",
                '<dc:title id="main">Ebook Fixture</dc:title>' in opf
                and '<dc:creator id="author">Fixture Author</dc:creator>' in opf,
                "OPF dc:title / dc:creator do not match the config")
            cpy = t("copyright.xhtml")
            chk("epub", "copyright_lines_from_config",
                "Copyright © 2026 Fixture Author. All rights reserved." in cpy
                and "First edition, 2026. Fixture printing." in cpy,
                "strings.copyright_line / strings.first_edition_line not on the copyright page")

            # 15. config free text: *italic* parsed, no literal asterisk
            ded, epi, ab = t("dedication.xhtml"), t("epigraph.xhtml"), t("about.xhtml")
            chk("epub", "config_text_inline_markup",
                "<em>everyone</em>" in ded and "<em>white</em>" in epi
                and "<em>a label</em>" in epi and "<em>The First Book</em>" in ab
                and not any("*" in xhtml_body(x) for x in (ded, epi, ab)),
                "config free text lost its italics or leaked a literal asterisk")

            # 16. landmarks (with toc: the nav is in the spine) + opt-in Contents
            chk("epub", "landmarks_nav_optin",
                'epub:type="landmarks"' in nav
                and '<a epub:type="cover" href="text/cover.xhtml">' in nav
                and '<a epub:type="toc" href="nav.xhtml#toc">' in nav
                and '<a epub:type="bodymatter" href="text/part_one.xhtml">' in nav,
                "landmarks nav (cover, toc, bodymatter) missing")
            chk("epub", "incontents_with_kindle_include_toc",
                re.search(r'<itemref idref="nav"/>\s*<itemref idref="part_one"/>', opf) is not None,
                "kindle_include_toc: true did not put the Contents (nav) in the spine")
        else:
            fails.append(f"ebook epub: not produced at {epub}")
    finally:
        shutil.rmtree(ws, ignore_errors=True)


# ==== KITP-A PRINT LEG (2026-09-24, across_borders final render QC) ==========
# generate_book.js (print interior) only; cases P1-P9. Every P case FAILED on the
# pre-fix generator (negative-tested against the backup generate_book.js.kitpA,
# via print_leg(generator=...)). The two guards (latin_book_untouched,
# figure_no_floor_without_knob) hold on both: a book that does not opt in must
# build exactly as before.
PRINT_MASTER = """# Chapter One

A local name is marked 土名 on the label, and *the earth name 土名 is a small poem* in italics.

> BRIT610941 Calophanoides chinensis

> 李明红， 萧百中; [Li Minghong, Xiao Bai-Zhong]

> ヨーロッパ原産 [Native to Europe]

Body text between the labels, plain and unhurried, with enough words to look like prose.

![A small low-resolution label photo.](images/lowres.png)

*A caption under the small figure, with 中文 inside.*

Body after the caption, plain and unhurried.

![A tall portrait figure.](images/tall.png)

This paragraph follows a figure but is body prose, not a caption: it runs well past one hundred and twenty characters, so it must never be bound into a keep-lines block.
"""

PRINT_CONFIG = {
    "title": "Print Fixture",
    "subtitle": "Labels and Figures",
    "author": "Fixture Author",
    "slug": "_regprint",
    "is_fiction": False,
    "language": "en",
    "formats": ["kdp_paperback"],
    "min_pages": 1,
    "dedication": "For *everyone* who reads labels.",
    "epigraph": {"text": "Small *white* flowers.", "attribution": "From *a label*, 1957."},
    "readers_note": "A note with *emphasis* inside.",
    "about_the_author": "Fixture Author wrote *The First Book* and then this one.",
    "front_matter": [{"type": "half_title"}, {"type": "title"}, {"type": "copyright"},
                     {"type": "dedication"}, {"type": "epigraph"}, {"type": "readers_note"}],
    "interior": {"figure_max_h_in": 3.25, "body_space_after_pt": 0, "min_image_ppi": 300},
    "voice": {"unit_noun": "chapter", "no_em_dashes": True, "blacklist": []},
    "units": [{"id": "ch_01", "title": "Chapter One", "class": "C", "target_words": 80}],
}


def print_leg(checks: list, fails: list, generator=None, latin_docx=None) -> None:
    """P1-P9: build PRINT_MASTER with generate_book.js (kdp_paperback) in a fresh
    temp workspace and assert the DOCX XML. generator overrides the script path
    (negative tests); latin_docx is an already-built Latin-only print DOCX for
    the guard (the main fixture's)."""
    gen = Path(generator) if generator else TOOLS / "generate_book.js"
    ws = Path(tempfile.mkdtemp(prefix="bs_regprint_"))

    def chk(name, ok, detail=""):
        checks.append({"target": "print", "check": name, "pass": bool(ok), "detail": detail})
        if not ok:
            fails.append(f"print/{name}: {detail}")

    def ea_lang(rpr):     # w:lang's eastAsia (NOT w:rFonts' eastAsia font)
        m = re.search(r'<w:lang\b[^>]*\bw:eastAsia="([^"]*)"', rpr)
        return m.group(1) if m else None

    def doc_defaults(styles_xml):
        m = re.search(r"<w:docDefaults>.*?</w:docDefaults>", styles_xml, re.S)
        return m.group(0) if m else ""

    try:
        (ws / "outputs" / "markdown").mkdir(parents=True)
        (ws / "book_config.json").write_text(
            json.dumps(PRINT_CONFIG, indent=2, ensure_ascii=False), encoding="utf-8")
        (ws / "outputs" / "markdown" / "_regprint_v1.md").write_text(PRINT_MASTER, encoding="utf-8")
        tiny_png(ws / "images" / "lowres.png", w=600, h=400, rgb=(90, 90, 90))   # 126 ppi at 4.75 in
        tiny_png(ws / "images" / "tall.png", w=900, h=1800, rgb=(120, 90, 60))  # 4.3 in tall uncapped
        r = subprocess.run(["node", str(gen), "--config", str(ws / "book_config.json"),
                            "--format", "kdp_paperback"],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=180)
        if r.returncode != 0:
            fails.append(f"print leg generate_book.js rc={r.returncode}: "
                         f"{(r.stderr or r.stdout).strip()[-200:]}")
        docx = ws / "outputs" / "kdp_paperback" / "_regprint_KDP_PAPERBACK.docx"
        if not docx.exists():
            fails.append(f"print leg: DOCX not produced at {docx}")
            return
        with zipfile.ZipFile(docx) as z:
            doc = z.read("word/document.xml").decode("utf-8", "replace")
            styles = z.read("word/styles.xml").decode("utf-8", "replace")
            core = z.read("docProps/core.xml").decode("utf-8", "replace")
        paras = docx_paragraphs(doc)

        def para_with(sub):
            return next((p for p in paras if sub in p[2]), None)

        # P1. config free text parses *italic*; About is justified like body text
        about = para_with("wrote")
        chk("about_author_inline_justified",
            about is not None and "*" not in about[2]
            and any(t == "The First Book" and italic_on(rp) for rp, t in about[1])
            and '<w:jc w:val="both"/>' in about[0],
            f"About paragraph={about[2] if about else 'MISSING'!r}")
        ded, epi, att, note = (para_with(s) for s in ("who reads", "flowers", "1957", "A note with"))
        chk("config_text_inline_markup",
            all(p is not None and "*" not in p[2] for p in (ded, epi, att, note))
            and any(t == "emphasis" and italic_on(rp) for rp, t in note[1]),
            "dedication/epigraph/attribution/readers_note: "
            + " | ".join(repr(p[2]) if p else "MISSING" for p in (ded, epi, att, note)))

        # P2. CJK never italic; the Latin beside it keeps its italics
        cjk_runs = [(rp, t) for _, runs, _, _ in paras for rp, t in runs if CJK_RE.search(t)]
        italic_cjk = [t for rp, t in cjk_runs if italic_on(rp)]
        latin_kept = (any(t.startswith("; [Li Minghong") and italic_on(rp)
                          for _, runs, _, _ in paras for rp, t in runs)
                      and any(t == "the earth name " and italic_on(rp)
                              for _, runs, _, _ in paras for rp, t in runs))
        chk("cjk_never_italic", cjk_runs and not italic_cjk and latin_kept,
            f"{len(cjk_runs)} CJK runs; italic CJK={italic_cjk[:5]}; Latin italics kept={latin_kept}")

        # P3. East Asian w:lang on every CJK run; kinsoku defaults for a Latin book
        untagged = [t for rp, t in cjk_runs if ea_lang(rp) is None]
        chk("cjk_east_asian_lang",
            cjk_runs and not untagged
            and any("ヨーロッパ原産" in t and ea_lang(rp) == "ja-JP" for rp, t in cjk_runs)
            and any(t == "李明红， 萧百中" and ea_lang(rp) == "zh-CN" for rp, t in cjk_runs),
            f"CJK runs without an East Asian w:lang: {untagged[:5]}")
        dd = doc_defaults(styles)
        chk("kinsoku_doc_defaults",
            re.search(r'<w:lang\b[^>]*w:eastAsia="zh-CN"', dd) is not None
            and '<w:overflowPunct w:val="0"/>' in dd,
            f"docDefaults={dd[:300]!r}")
        if latin_docx is not None and Path(latin_docx).exists():
            with zipfile.ZipFile(latin_docx) as z:
                ldd = doc_defaults(z.read("word/styles.xml").decode("utf-8", "replace"))
            chk("latin_book_untouched", "<w:lang" not in ldd and "overflowPunct" not in ldd,
                f"Latin-only book docDefaults gained East Asian settings: {ldd[:300]!r}")

        # P4. figure height knob + the opt-in ppi floor (min_image_ppi 300 here)
        figs = [k for k, p in enumerate(paras) if "<w:drawing>" in p[3]]

        def extent_in(raw):
            m = re.search(r'<wp:extent cx="(\d+)" cy="(\d+)"', raw)
            return (int(m.group(1)) / 914400, int(m.group(2)) / 914400) if m else (0.0, 0.0)
        low = extent_in(paras[figs[0]][3]) if len(figs) == 2 else (0.0, 0.0)
        tall = extent_in(paras[figs[1]][3]) if len(figs) == 2 else (0.0, 0.0)
        chk("figure_300ppi_floor", len(figs) == 2 and 1.9 <= low[0] <= 600 / 300 + 1e-9,
            f"600x400 px placed {low[0]:.3f}x{low[1]:.3f} in "
            f"({600 / low[0] if low[0] else 0:.0f} ppi; want <= 2.000 in = 300 ppi)")
        chk("figure_max_h_knob", len(figs) == 2 and abs(tall[1] - 3.25) < 0.02,
            f"900x1800 px placed {tall[0]:.3f}x{tall[1]:.3f} in (want 3.25 in tall: figure_max_h_in)")
        # Guard: the floor is OPT-IN. The same book built WITHOUT min_image_ppi
        # keeps the historical sizing (600x400 px at the full 4.75 in block
        # width, 126 ppi), so books that do not set the knob stay byte-identical.
        nofloor = dict(PRINT_CONFIG, interior={k: v for k, v in PRINT_CONFIG["interior"].items()
                                                if k != "min_image_ppi"})
        (ws / "book_config_nofloor.json").write_text(
            json.dumps(nofloor, indent=2, ensure_ascii=False), encoding="utf-8")
        nf_docx = ws / "nofloor.docx"
        r2 = subprocess.run(["node", str(gen), "--config", str(ws / "book_config_nofloor.json"),
                             "--format", "kdp_paperback", "--out", str(nf_docx)],
                            capture_output=True, text=True, encoding="utf-8",
                            errors="replace", timeout=180)
        nf_low = (0.0, 0.0)
        if nf_docx.exists():
            with zipfile.ZipFile(nf_docx) as z:
                nf_paras = docx_paragraphs(z.read("word/document.xml").decode("utf-8", "replace"))
            nf_figs = [k for k, p in enumerate(nf_paras) if "<w:drawing>" in p[3]]
            if len(nf_figs) == 2:
                nf_low = extent_in(nf_paras[nf_figs[0]][3])
        chk("figure_no_floor_without_knob",
            r2.returncode == 0 and abs(nf_low[0] - 4.75) < 0.01 and abs(nf_low[1] - 4.75 * 400 / 600) < 0.02,
            f"without min_image_ppi the 600x400 px figure placed {nf_low[0]:.3f}x{nf_low[1]:.3f} in "
            f"(want the historical 4.750x3.167 in); rc={r2.returncode}")

        # P5. the caption keeps its lines (the image keeps with it); prose is not bound
        cap_ok, detail = False, f"{len(figs)} image paragraphs (want 2)"
        if len(figs) == 2 and figs[1] + 1 < len(paras):
            cap, prose = paras[figs[0] + 1], paras[figs[1] + 1]
            cap_ok = ("<w:keepNext/>" in paras[figs[0]][0]
                      and cap[2] == "A caption under the small figure, with 中文 inside."
                      and "<w:keepLines/>" in cap[0] and spacing_of(cap[0])[1] == 120
                      and prose[2].startswith("This paragraph follows a figure")
                      and "<w:keepLines/>" not in prose[0])
            detail = f"caption pPr={cap[0][:120]!r}; prose-after-figure pPr={prose[0][:120]!r}"
        chk("caption_keeplines", cap_ok, detail)

        # P6. TOC1/TOC2 in the book font with a hanging turnover indent
        def style(sid):
            m = re.search(rf'<w:style [^>]*w:styleId="{sid}".*?</w:style>', styles, re.S)
            return m.group(0) if m else ""
        t1, t2 = style("TOC1"), style("TOC2")
        chk("toc_styles_book_font_hanging",
            '<w:name w:val="toc 1"/>' in t1 and 'w:ascii="Georgia"' in t1
            and 'w:left="360"' in t1 and 'w:hanging="360"' in t1
            and '<w:name w:val="toc 2"/>' in t2 and 'w:ascii="Georgia"' in t2
            and 'w:left="720"' in t2 and 'w:hanging="360"' in t2,
            f"TOC1={t1[:160]!r} TOC2={t2[:160]!r}")

        # P7. interior.body_space_after_pt drives body paragraphs (captions keep 6 pt)
        body = [p for p in paras if '<w:jc w:val="both"/>' in p[0] and 'w:firstLine="360"' in p[0]
                and not p[2].startswith("A caption under")]
        afters = sorted({spacing_of(p[0])[1] for p in body})
        chk("body_space_after_knob", bool(body) and afters == [0],
            f"body paragraph space-after values={afters} (want [0]: body_space_after_pt=0)")

        # P8. folio footer 0.375 in from the trim (front matter keeps footer 0)
        foot = sorted(set(re.findall(r'w:footer="(\d+)"', doc)))
        chk("folio_footer_distance", foot == ["0", "540"],
            f"sectPr footer distances={foot} (want 540 = 0.375 in on page-numbered sections)")

        # P9. DOCX core properties
        def core_tag(tag):
            m = re.search(rf"<{tag}>([^<]*)</{tag}>", core)
            return html.unescape(m.group(1)) if m else None
        chk("core_properties",
            core_tag("dc:title") == "Print Fixture" and core_tag("dc:subject") == "Labels and Figures"
            and core_tag("dc:creator") == "Fixture Author"
            and core_tag("cp:lastModifiedBy") == "Fixture Author",
            f"core.xml={re.sub(r'<dcterms:[^>]*>[^<]*</dcterms:[^>]*>', '', core)[-260:]!r}")
    finally:
        shutil.rmtree(ws, ignore_errors=True)
# ==== end KITP-A PRINT LEG ====================================================


# ==== KIT2-OTHER LEG (2026-09-24, across_borders final render QC round 2) ======
# build_epub.py, generate_kindle.js, build_digital_pdf.py, composite_cover.py.
# Cases K1-K9 (QC rows in brackets). Every K case FAILED on the pre-fix tools
# (negative-tested against the *.kit2o backups via kit2o_leg(tools=<a dir
# holding them>)); the default_* guards hold on both: a book that does not set
# a new knob keeps today's output.
#  K1 [S10] EPUB figure, figcaption display:block: MuPDF lays a chapter's figure
#           out AFTER the chapter title and the paragraph before it (it hoisted
#           the figure above the title)
#  K2 [S11] EPUB block-quote lines ragged-right (MuPDF: normal word gaps on a
#           wrapped label line, not justified ones)
#  K3 [N8]  EPUB copyright page centered: a short line shares the block's center
#  K4 [N12] EPUB OPF: creator role + file-as, dc:date, dc:rights, schema.org
#           accessMode / accessModeSufficient / accessibilityFeature /
#           accessibilityHazard / accessibilitySummary
#  K5 [S12] Kindle label text in the body colour; ornaments keep their grey
#  K6 [S8]  digital PDF digital_pdf.back_cover_last: back cover after the last
#           page; bookmarks still land on their headings
#  K7 [N5]  digital PDF /PageLabels = the printed folios (front matter roman by
#           print position, covers named, stripped blanks skipped)
#  K8 [S9]  hardcover back laid out like the paperback back, trim for trim; a
#           blurb line whose glyphs end above the barcode keep-out keeps the
#           full width (never broken early), and nothing enters the keep-out
#  K9 [N7]  Kindle cover title/subtitle width cap (cover.kindle_text_width_frac)
KIT2O_MASTER = """# Chapter One

The opening paragraph of the chapter runs as ordinary prose for a few lines on a narrow screen, so the figure below it sits well inside the chapter.

![A test photograph of a herbarium sheet.](images/k2o_fig.png)

*A caption under the test photograph.*

The paragraph after the figure, plain and unhurried, with enough words to wrap.

> Col. No. 6345 Family Asteraceae Pneumonoultramicroscopicsilicovolcanoconiosis
>
> 萧百中 Xiao Bai-Zhong

The closing paragraph of the chapter.
"""

KIT2O_CONFIG = {
    "title": "Kit Two Fixture",
    "subtitle": "Figures and Labels",
    "author": "Fixture Q. Author",
    "slug": "_regk2o",
    "is_fiction": False,
    "language": "en",
    "formats": ["kindle", "epub"],
    "publication_date": "2026-09",
    "strings": {"copyright_line": "Copyright © 2026 Fixture Q. Author. All rights reserved. No part "
                                  "of this book may be reproduced in any form without written permission.",
                "first_edition_line": "First edition, 2026."},
    "epigraph": {"text": "Small fixture flowers slightly creeping.", "attribution": "From a fixture label"},
    "voice": {"unit_noun": "chapter", "no_em_dashes": True, "blacklist": []},
    "units": [{"id": "ch_01", "title": "Chapter One", "class": "C", "target_words": 80}],
}

# A blurb about as long as across_borders' (its last paragraph broke early on
# the hardcover back): three paragraphs, the last carrying an italic title.
KIT2O_BLURB = (
    "<p>For more than a year a retired scientist sat at his desk decoding the handwriting "
    "of a famous botanist. Then the herbarium asked him for something else: thousands of "
    "pressed plants from China, Taiwan and Japan lay in its cabinets, photographed and "
    "cataloged but impossible to find, because their labels were written in languages "
    "the database could not read.</p><p>So he read them. Record by record, day by day, he "
    "carried the words of collectors he would never meet into English: a small herb from "
    "a mountain whose local name means a little red; a grass called the girl who watches "
    "the wheat; a fern pressed on an island in 1935; a plant with no name at all, "
    "collected at the northern tip of the island in 1957.</p><p><i>Kit Two Fixture</i> is "
    "the story of that quiet work, and of a life that came full circle: from a steel town "
    "and a college of medicine, through twenty-four years of science, and back to the "
    "plants where his training began. A companion to <i>The First Book</i>, it is for "
    "anyone who loves plants, languages, or the patient kind of work that lets the past "
    "be found.</p>")


def _k2o_load(tools: Path, name: str):
    """Import a tool module from a given tools dir (the negative test points it at
    the backups) under a name unique to that dir."""
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        f"_k2o_{name}_{abs(hash(str(tools.resolve())))}", tools / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _k2o_interior(path: Path) -> None:
    """A 6x9 print interior (16 pp): half title, blank, title, copyright,
    Contents, blank, then folios 1-4 from print page 7, a blank verso (folio 5
    unprinted), folios 6-8 (About the Author on 8), two trailing blanks."""
    import fitz
    body = "This line is ordinary body text in the synthetic interior."
    pages = [(None, ["REGK2D BOOK"]), (None, []),
             (None, ["REGK2D BOOK: A Regression Fixture", "Fixture Author"]),
             (None, ["Copyright 2026 Fixture Author. All rights reserved."]),
             (None, ["C O N T E N T S", "Part I: The First Part . . . 1",
                     "The Opening Chapter . . . 3", "Another Chapter Title . . . 6"]),
             (None, []),
             ("1", ["Part I: The First Part", body]), ("2", [body, body]),
             ("3", ["The Opening Chapter", body]), ("4", [body] * 6),
             (None, []),
             ("6", ["Another Chapter Title", body]), ("7", [body] * 4),
             ("8", ["A B O U T  T H E  A U T H O R", "Fixture Author writes fixtures."]),
             (None, []), (None, [])]
    doc = fitz.open()
    for folio, lines in pages:
        pg = doc.new_page(width=432, height=648)
        if folio:                        # a centered footer folio, 0.4 in from the trim
            pg.insert_text((212, 620), folio, fontsize=9)
        for k, ln in enumerate(lines):
            pg.insert_text((54, 90 + 18 * k), ln, fontsize=11)
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(path))
    doc.close()


def kit2o_leg(checks: list, fails: list, tools=None) -> None:
    """K1-K9 (see the block comment). tools = the directory holding the four
    tools under test (default: this kit's _tools); nothing in the repo is
    touched, every build runs in a fresh temp dir."""
    import fitz
    from PIL import Image, ImageChops, ImageDraw
    tools = Path(tools) if tools else TOOLS
    ws = Path(tempfile.mkdtemp(prefix="bs_regk2o_"))

    def chk(target, name, ok, detail=""):
        checks.append({"target": target, "check": name, "pass": bool(ok), "detail": detail})
        if not ok:
            fails.append(f"{target}/{name}: {detail}")

    def guarded(target, name, fn):
        import contextlib
        import io
        try:                              # the compositor prints: keep --json clean
            with contextlib.redirect_stdout(io.StringIO()), \
                    contextlib.redirect_stderr(io.StringIO()):
                ok, detail = fn()
        except Exception as exc:          # a missing function on old tools is a FAIL
            ok, detail = False, f"{type(exc).__name__}: {exc}"
        chk(target, name, ok, detail)

    try:
        # ---------------- EPUB + Kindle DOCX (K1-K5) ----------------
        ews = ws / "ebook"
        (ews / "outputs" / "markdown").mkdir(parents=True)
        (ews / "book_config.json").write_text(
            json.dumps(KIT2O_CONFIG, indent=2, ensure_ascii=False), encoding="utf-8")
        (ews / "outputs" / "markdown" / "_regk2o_v1.md").write_text(KIT2O_MASTER, encoding="utf-8")
        tiny_png(ews / "images" / "k2o_fig.png", w=600, h=400, rgb=(40, 120, 60))
        tiny_png(ews / "cover_art" / "_regk2o_src.png", w=160, h=256)
        cfg_path = str(ews / "book_config.json")
        r = subprocess.run([sys.executable, str(tools / "build_epub.py"), "--config", cfg_path],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=180)
        if r.returncode != 0:
            fails.append(f"kit2o build_epub rc={r.returncode}: {(r.stderr or r.stdout).strip()[-300:]}")
        epub = ews / "outputs" / "epub" / "_regk2o.epub"
        if epub.exists():
            with zipfile.ZipFile(epub) as z:
                opf = z.read("OEBPS/content.opf").decode("utf-8", "replace")
                css = z.read("OEBPS/css/style.css").decode("utf-8", "replace")
            doc = fitz.open(str(epub))
            doc.layout(width=340, height=540, fontsize=11)
            lines = []                    # (page, y0, x0, x1, text) in reading order
            images = []                   # (page, y0)
            for i in range(doc.page_count):
                for b in doc[i].get_text("dict")["blocks"]:
                    if b["type"] == 1:
                        images.append((i, b["bbox"][1]))
                        continue
                    for ln in b.get("lines", []):
                        t = "".join(s["text"] for s in ln["spans"])
                        if t.strip():
                            lines.append((i, ln["bbox"][1], ln["bbox"][0], ln["bbox"][2], t.strip()))

            def first(pred):
                return next((ln for ln in lines if pred(ln[4])), None)

            # K1: figure after the title and the paragraph before it
            def k1():
                title = first(lambda t: t.lower() == "chapter one")
                para = first(lambda t: t.startswith("The opening paragraph"))
                cap = first(lambda t: t.startswith("A caption under the test"))
                if not (title and para and cap):
                    return False, f"lines not found: title={title} para={para} caption={cap}"
                img = max((im for im in images if im <= (cap[0], cap[1])), default=None)
                key = lambda ln: (ln[0], ln[1])  # noqa: E731
                ok = (key(title) < key(para) < key(cap) and img is not None
                      and key(para) < img and "figure, figcaption { display: block; }" in css)
                return ok, (f"(page, y): title {key(title)}, paragraph {key(para)}, image {img}, "
                            f"caption {key(cap)}; display:block rule in CSS: "
                            f"{'figure, figcaption { display: block; }' in css}")
            guarded("epub", "k1_figure_after_chapter_title", k1)

            # K2: the wrapped label's first line keeps normal word gaps
            def k2():
                col = first(lambda t: t.startswith("Col."))
                longw = first(lambda t: t.startswith("Pneumono"))
                if not (col and longw) or (col[0], col[1]) == (longw[0], longw[1]):
                    return False, "the label line did not wrap before the long word (fixture broken)"
                # group by baseline: MuPDF splits a justified line into one
                # line entry per word, so (block, line) numbers cannot be used
                words = [w for w in doc[col[0]].get_text("words") if abs(w[1] - col[1]) < 2.5]
                words.sort(key=lambda w: w[0])
                gaps = [round(words[k + 1][0] - words[k][2], 1) for k in range(len(words) - 1)]
                rule = re.search(r"blockquote p \{[^}]*\}", css)
                css_ok = rule is not None and "text-align: left" in rule.group(0)
                ok = len(words) >= 3 and max(gaps) < 8.0 and css_ok
                return ok, (f"first label line words {[w[4] for w in words]} gaps(pt) {gaps} "
                            f"(want < 8); blockquote p text-align: left in CSS: {css_ok}")
            guarded("epub", "k2_label_lines_ragged_right", k2)

            # K3: the copyright page is centered (a short line shares the center)
            def k3():
                top = first(lambda t: t.startswith("Copyright ©"))
                ed = first(lambda t: t == "First edition, 2026.")
                if not (top and ed):
                    return False, f"copyright lines not found: {top} {ed}"
                c_top, c_ed = (top[2] + top[3]) / 2, (ed[2] + ed[3]) / 2
                return abs(c_top - c_ed) <= 4.0, (f"centers: first copyright line {c_top:.1f}, "
                                                   f"'First edition, 2026.' {c_ed:.1f} pt (want within 4)")
            guarded("epub", "k3_copyright_page_centered", k3)

            # K4: OPF metadata
            def k4():
                want = [
                    '<meta refines="#author" property="role" scheme="marc:relators">aut</meta>',
                    '<meta refines="#author" property="file-as">Author, Fixture Q.</meta>',
                    "<dc:date>2026-09</dc:date>",
                    "<dc:rights>Copyright © 2026 Fixture Q. Author. All rights reserved. No part",
                    '<meta property="schema:accessMode">textual</meta>',
                    '<meta property="schema:accessMode">visual</meta>',
                    '<meta property="schema:accessModeSufficient">textual</meta>',
                    '<meta property="schema:accessModeSufficient">textual,visual</meta>',
                    '<meta property="schema:accessibilityFeature">alternativeText</meta>',
                    '<meta property="schema:accessibilityFeature">structuralNavigation</meta>',
                    '<meta property="schema:accessibilityFeature">tableOfContents</meta>',
                    '<meta property="schema:accessibilityHazard">none</meta>',
                ]
                missing = [w for w in want if w not in opf]
                summ = re.search(r'<meta property="schema:accessibilitySummary">([^<]+)</meta>', opf)
                ok = not missing and summ is not None and "Chinese" in summ.group(1)
                return ok, (f"missing: {missing}; summary: {summ.group(1) if summ else None!r}")
            guarded("epub", "k4_opf_metadata", k4)

            # K4 guard: file-as derivation keeps CJK names, lists and one-word names
            def k4b():
                be = _k2o_load(tools, "build_epub")
                got = {a: be.author_file_as({"author": a}) for a in
                       ("Huagang Chen", "陈华钢", "Plato", "Bo Chen and Huagang Chen",
                        "Martin Luther King Jr.")}
                got["explicit"] = be.author_file_as({"author": "X Y", "author_file_as": "Custom, Sort"})
                want = {"Huagang Chen": "Chen, Huagang", "陈华钢": "陈华钢", "Plato": "Plato",
                        "Bo Chen and Huagang Chen": "Bo Chen and Huagang Chen",
                        "Martin Luther King Jr.": "King, Martin Luther, Jr.",
                        "explicit": "Custom, Sort"}
                return got == want, f"file-as {got}"
            guarded("epub", "k4_file_as_derivation", k4b)
        else:
            fails.append(f"kit2o epub: not produced at {epub}")

        r = subprocess.run(["node", str(tools / "generate_kindle.js"), "--config", cfg_path],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=180)
        if r.returncode != 0:
            fails.append(f"kit2o generate_kindle.js rc={r.returncode}: "
                         f"{(r.stderr or r.stdout).strip()[-200:]}")
        docx = ews / "outputs" / "kindle" / "_regk2o_KINDLE.docx"
        if docx.exists():
            with zipfile.ZipFile(docx) as z:
                dx = z.read("word/document.xml").decode("utf-8", "replace")
            paras = docx_paragraphs(dx)

            # K5: label runs in the body colour (000000); ornaments stay grey
            def colour(rpr):
                m = re.search(r'<w:color w:val="([0-9A-Fa-f]{6})"', rpr)
                return m.group(1).upper() if m else "none"

            def k5():
                lab = [p for p in paras if 'w:left="720"' in p[0]]
                cols = sorted({colour(rp) for p in lab for rp, t in p[1] if t.strip()})
                orn = sorted({colour(rp) for p in paras for rp, t in p[1] if t.strip() == "✦"})
                ok = len(lab) >= 2 and cols == ["000000"] and orn == ["999999"]
                return ok, f"{len(lab)} label paragraphs; label run colours {cols}; ornament {orn}"
            guarded("kindle", "k5_label_text_body_colour", k5)

            # K5b: copyright and epigraph text in the body colour, never a fixed grey
            # (grey stays dim in Kindle dark mode; generate_kindle.js used 555555/666666/888888)
            def k5b():
                fm = [p for p in paras if any(("First edition" in t or "fixture flowers" in t or "fixture label" in t)
                                              for rp, t in p[1])]
                cols = sorted({colour(rp) for p in fm for rp, t in p[1] if t.strip()})
                ok = len(fm) >= 3 and cols == ["000000"]
                return ok, f"{len(fm)} copyright/epigraph paragraphs; run colours {cols}"
            guarded("kindle", "k5b_front_matter_body_colour", k5b)
        else:
            fails.append(f"kit2o kindle: DOCX not produced at {docx}")

        # ---------------- digital PDF (K6, K7) ----------------
        dig_cfg = {"slug": "_regk2d", "title": "Regk2d Book", "subtitle": "A Fixture",
                   "author": "Fixture Author", "is_fiction": False, "formats": ["digital_pdf"],
                   "trim": {"w": 6, "h": 9},
                   "units": [{"id": "part_1", "title": "Part I: The First Part"},
                             {"id": "ch_01", "title": "The Opening Chapter"},
                             {"id": "ch_02", "title": "Another Chapter Title"}],
                   "about_the_author": "Fixture Author writes fixtures.",
                   "cover": {"palette": {"umber": "1F2A2E"}}}
        builds = {}
        for tag, extra in (("default", {}), ("last", {"digital_pdf": {"back_cover_last": True}})):
            dws = ws / f"dig_{tag}"
            pb = dws / "outputs" / "kdp_paperback"
            _k2o_interior(pb / "_regk2d_KDP_PAPERBACK.pdf")
            W, H, bl, s0, s1 = 3803, 2775, 37, 1837, 1964          # composite_cover's grid
            wrap = Image.new("RGB", (W, H), (255, 0, 255))          # bleed: magenta
            wrap.paste((200, 40, 40), (bl, bl, s0, H - bl))         # back face: red
            wrap.paste((30, 30, 30), (s0, 0, s1, H))                # spine: dark
            wrap.paste((40, 160, 60), (s1, bl, W - bl, H - bl))     # front face: green
            wrap.save(pb / "cover_wrap.jpg", format="PNG")          # lossless
            (dws / "book_config.json").write_text(json.dumps(dict(dig_cfg, **extra)), encoding="utf-8")
            r = subprocess.run([sys.executable, str(tools / "build_digital_pdf.py"),
                                "--config", str(dws / "book_config.json"), "--workspace", str(dws)],
                               capture_output=True, text=True, encoding="utf-8",
                               errors="replace", timeout=180)
            out = dws / "outputs" / "digital" / "_regk2d_DIGITAL.pdf"
            if r.returncode != 0 or not out.exists():
                fails.append(f"kit2o build_digital_pdf ({tag}) rc={r.returncode}: "
                             f"{(r.stderr or r.stdout).strip()[-300:]}")
                continue
            builds[tag] = fitz.open(str(out))

        def face(d, i):                   # the page's centre colour: which cover?
            pix = d[i].get_pixmap(matrix=fitz.Matrix(0.05, 0.05))
            c = pix.pixel(pix.width // 2, pix.height // 2)
            return "front" if c[1] > 120 and c[0] < 100 else "back" if c[0] > 150 and c[1] < 90 else "text"

        def toc_ok(d):                    # each bookmark opens on its heading
            bad = []
            for _lvl, title, pno in d.get_toc():
                body = [ln for ln in d[pno - 1].get_text().splitlines()
                        if ln.strip() and not ln.strip().isdigit()]      # skip the folio
                head = re.sub(r"[^a-z0-9]", "", " ".join(body).lower())[:40]
                if not head.startswith(re.sub(r"[^a-z0-9]", "", title.lower())):
                    bad.append((title, pno))
            return bad

        interior = ["i", "iii", "iv", "v", "1", "2", "3", "4", "6", "7", "8"]
        if "last" in builds:
            d = builds["last"]

            def k6():
                faces = [face(d, 0), face(d, 1), face(d, d.page_count - 1)]
                toc = d.get_toc()
                bad = toc_ok(d)
                ok = (faces == ["front", "text", "back"] and d.page_count == 13
                      and [p for _l, _t, p in toc] == [6, 8, 10, 12] and not bad)
                return ok, (f"{d.page_count} pages; faces p1/p2/last {faces} (want front/text/back); "
                            f"bookmarks {[(t, p) for _l, t, p in toc]}; off-heading {bad}")
            guarded("digital", "k6_back_cover_last", k6)

            def k7():
                labels = [d[i].get_label() for i in range(d.page_count)]
                want = ["Cover"] + interior + ["Back Cover"]
                return labels == want, f"labels {labels} (want {want})"
            guarded("digital", "k7_page_labels_printed_folios", k7)
        if "default" in builds:
            d = builds["default"]

            def k6g():
                faces = [face(d, 0), face(d, 1), face(d, 2)]
                toc = d.get_toc()
                ok = (faces == ["front", "back", "text"] and [p for _l, _t, p in toc] == [7, 9, 11, 13]
                      and not toc_ok(d))
                return ok, f"faces p1-p3 {faces}; bookmarks {[(t, p) for _l, t, p in toc]}"
            guarded("digital", "default_back_cover_page_2", k6g)

            def k7d():
                labels = [d[i].get_label() for i in range(d.page_count)]
                want = ["Cover", "Back Cover"] + interior
                return labels == want, f"labels {labels} (want {want})"
            guarded("digital", "k7_page_labels_default_order", k7d)
        for d in builds.values():
            d.close()

        # ---------------- covers (K8, K9) ----------------
        cc = _k2o_load(tools, "composite_cover")
        art = ws / "art.png"
        grad = Image.linear_gradient("L").resize((1200, 1800))
        Image.merge("RGB", (grad.point(lambda v: 120 + v // 3), grad.point(lambda v: 110 + v // 3),
                            grad.point(lambda v: 90 + v // 3))).save(art)
        pal = {"umber": "1F2A2E", "cream": "F4EFE3", "gold": "B23A2B"}
        base_cfg = {"title": "Kit Two Fixture", "author": "Fixture Author", "slug": "k2o",
                    "subtitle": "Labels and Figures", "trim": {"w": 6, "h": 9}, "paper": "white",
                    "cover": {"palette": pal, "back_series_line": "", "back_quote": ""},
                    "kdp_metadata": {"description": KIT2O_BLURB}}

        def spy_back(run):
            """Run run() with render_back_text instrumented: every cream call of
            ImageDraw.text inside it (the blurb) is recorded as (x, y, text,
            font, anchor)."""
            calls, real = [], cc.render_back_text

            def wrapped(canvas, cfg, *a, **k):
                orig = ImageDraw.ImageDraw.text

                def text(self, xy, txt, *ta, **tk):
                    if tk.get("fill") == cfg.col_cream:
                        calls.append((xy[0], xy[1], txt, tk.get("font"), tk.get("anchor")))
                    return orig(self, xy, txt, *ta, **tk)
                ImageDraw.ImageDraw.text = text
                try:
                    return real(canvas, cfg, *a, **k)
                finally:
                    ImageDraw.ImageDraw.text = orig
            cc.render_back_text = wrapped
            try:
                run()
            finally:
                cc.render_back_text = real
            return calls

        def to_lines(calls):
            """Group recorded runs into lines by baseline (an "ls" run is drawn at
            its baseline, a plain one at its ascender line): [(top, x0, x1, text,
            font, glyph_bottom)], top = the ascender line, glyph_bottom = the
            baseline plus the deepest face descent on the line."""
            rows = {}
            for x, y, t, f, anc in calls:
                base = y if anc == "ls" else y + f.getmetrics()[0]
                rows.setdefault(round(base), []).append((x, t, f))
            out = []
            for base in sorted(rows):
                runs = sorted(rows[base], key=lambda r: r[0])
                asc = max(f.getmetrics()[0] for _x, _t, f in runs)
                desc = max(f.getmetrics()[1] for _x, _t, f in runs)
                x1 = max(x + f.getlength(t) for x, t, f in runs)
                out.append((base - asc, runs[0][0], x1, "".join(t for _x, t, _f in runs),
                            runs[0][2], base + desc))
            return out

        # K8a: the hardcover back = the paperback back, trim for trim
        def k8a():
            cfg = cc.CoverConfig(dict(base_cfg))
            cfg.workspace = ws
            got = {}
            for prof, edge in (("kdp-wrap", 37), ("kdp-hardcover", 212)):
                calls = spy_back(lambda: cc.build_kdp_wrap(cfg, 180, prof, art, ws / f"cov_{prof}"))
                got[prof] = [(top - edge, round(x0) - edge, t, f.size)
                             for top, x0, _x1, t, f, _gb in to_lines(calls)]
            pb, hc = got["kdp-wrap"], got["kdp-hardcover"]
            same = (len(pb) == len(hc) and len(pb) > 6
                    and all(abs(a[0] - b[0]) <= 1 and abs(a[1] - b[1]) <= 1 and a[2:] == b[2:]
                            for a, b in zip(pb, hc)))
            return same, (f"{len(pb)} paperback vs {len(hc)} hardcover blurb lines; sizes "
                          f"{sorted({x[3] for x in pb})} vs {sorted({x[3] for x in hc})}; last lines "
                          f"{[x[2] for x in pb[-2:]]} vs {[x[2] for x in hc[-2:]]}")
        guarded("cover", "k8_hc_back_matches_pb_back", k8a)

        # K8b: sweep the blurb across the keep-out top; a line whose glyphs end
        # above it is never broken early, and no ink enters the keep-out
        def k8b():
            plain = ("<p>" + " ".join(["Record by record he carried the words of collectors into "
                                       "English, and every label he read was a small letter home."] * 5)
                     + "</p>")
            cfg = cc.CoverConfig(dict(base_cfg, kdp_metadata={"description": plain}))
            cfg.workspace = ws
            left, right, bottom, panel = 100, 1676, 2600, 2775
            band_top = bottom - int(cfg.isbn_h_in * cc.DPI)
            narrow_right = right - int(cfg.isbn_w_in * cc.DPI) - int(0.15 * cc.DPI)
            straddles, broken, intrude = 0, [], []
            for off in range(0, 80, 2):
                canvas = Image.new("RGB", (1800, 2800), (20, 20, 20))
                calls = spy_back(lambda: cc.render_back_text(canvas, cfg, left, right, 1300 + off,
                                                             bottom, panel, isbn_keepout=True))
                ls = to_lines(calls)
                for k, (top, _x0, x1, t, f, g_bot) in enumerate(ls):
                    lh = int(f.size * 1.48)
                    if g_bot <= band_top < top + lh:
                        straddles += 1
                    if g_bot > band_top and x1 > narrow_right + 1:
                        intrude.append((off, t[:30]))
                    nxt = ls[k + 1] if k + 1 < len(ls) else None
                    if g_bot <= band_top and nxt and nxt[0] - top < lh * 1.2:
                        cand = t + " " + nxt[3].split(" ")[0]
                        if f.getlength(cand) <= right - left:
                            broken.append((off, t[-24:]))
            ok = straddles > 0 and not broken and not intrude
            return ok, (f"{straddles} straddling line(s) across the sweep; broken early above the "
                        f"keep-out: {broken[:3]}; ink into the keep-out: {intrude[:3]}")
        guarded("cover", "k8_full_width_above_keepout", k8b)

        # K9: Kindle cover title/subtitle width cap; guard: absent = the print cap
        def ink_width(cfg, out_dir):
            res = cc.build_kindle_front(cfg, art, out_dir)
            img = Image.open(res["files"][0]).convert("RGB")
            base = cc.scale_to_cover(Image.open(art).convert("RGB"), img.width, img.height)
            mask = ImageChops.difference(img, base).convert("L").point(lambda v: 255 if v > 40 else 0)
            bb = mask.getbbox()
            return (bb[2] - bb[0]) if bb else 0, img.width

        def k9():
            kc = dict(base_cfg, title="Across Borders and Herbaria",
                      subtitle="A Retired Scientist’s Journey Decoding Asia’s Botanical Heritage")
            capped = cc.CoverConfig(dict(kc, cover=dict(kc["cover"], kindle_text_width_frac=0.88)))
            w_cap, width = ink_width(capped, ws / "k9_cap")
            limit = round(0.88 * width) + 28        # + the halo stroke and JPEG ringing
            return w_cap <= limit, f"ink width {w_cap}px with frac 0.88 (limit {limit}px of {width})"
        guarded("cover", "k9_kindle_text_width_cap", k9)

        def k9g():
            kc = dict(base_cfg, title="Across Borders and Herbaria",
                      subtitle="A Retired Scientist’s Journey Decoding Asia’s Botanical Heritage")
            w_def, width = ink_width(cc.CoverConfig(kc), ws / "k9_def")
            return w_def > round(0.88 * width) + 28, (f"no knob: ink width {w_def}px (the print "
                                                      f"cap, wider than a 0.88 cap)")
        guarded("cover", "default_kindle_text_width", k9g)
    finally:
        shutil.rmtree(ws, ignore_errors=True)
# ==== end KIT2-OTHER LEG ======================================================


# ==== KIT2-PRINT LEG (2026-09-24, across_borders final render QC round 2) =====
# generate_book.js (print interior) only; cases R1-R10 (QC rows in brackets).
# Every R case FAILED on the pre-round-2 generator (negative-tested against the
# backup generate_book.js.kit2p via kit2p_leg(generator=...)); the five guards
# hold on both: a book that sets none of the new knobs builds as before.
#  R1  [S2]  interior.label_keep_max_lines 10: a run of quote (label) lines is
#            one block, keepNext down the run and keepLines on each line; a run
#            taller than 10 printed lines keeps only its first and next-to-last
#            lines bound (long lines get widowControl, not keepLines); a bare ">"
#            never prints (that part holds without the knob too)
#  R2  [S3]  a Latin book carrying CJK: docDefaults autoSpaceDE/autoSpaceDN off,
#            settings characterSpacingControl=compressPunctuation (guard: a
#            Latin-only book gets neither)
#  R3  [S4]  interior.hyphenate: autoHyphenation, limit 2, zone 360 and
#            doNotHyphenateCaps in schema order; headings, labels, the caption,
#            front matter, About and TOC1/TOC2 carry suppressAutoHyphens (in pPr
#            order), body text does not
#  R4  [S5]  interior.caption: 10.5 pt, centered, no first-line indent,
#            keepLines, leading scaled to the size
#  R5  [S6]  title_lines: half-title and title page set on the given lines, core
#            title unchanged; lines that do not spell the title fail the build
#  R6  [S7]  TOC1/TOC2 right indent 576; interior.part_title_break sets a part
#            heading as "Part One:" + line break + "The Setup" and leaves a
#            chapter heading with a colon whole
#  R7  [S13] figure alt text in docPr descr/title (markup stripped); name = the
#            manuscript's file name
#  R8  [N2]  interior.label_cjk_nobreak_max 4: CJK words of <= 4 characters in a
#            label are joined with U+200D in one run; longer runs and body text
#            are not
#  R9  [N4]  header distance 432 twips (0.3 in) in every section
#  R10 [N9]  on a part page (a label + one italic line) the line takes the
#            label's indents, ragged right; after a label inside a chapter an
#            italic line stays a body paragraph
KIT2P_LONG = ("Kalimeris shimadai (Kitamura) Kitamura MIAOLI HSIEN: Shihtan Village, Touwu. "
              "Elev ca. 50-100 m. Ching-I Peng 5425 June 20, 1983 HERBARIUM, INSTITUTE OF BOTANY, "
              "ACADEMIA SINICA, TAIPEI (HAST) inches 3 1 2 3 4 5 D50 Illuminant, 2 degree observer")

KIT2P_MASTER = """# Part One: The Setup

> Translation Notes

> 3-21-2024

> 萧百中 Xiao Bai-Zhong

*The first entry in the notes, on the first morning.*

# Chapter One: The Start

A body paragraph that names 萧百中 in running prose and then goes on, plain and unhurried, with enough ordinary words to fill a justified line or two.

> BRIT610990 萧百中 Xiao Bai-Zhong 3543
>
> 湖南省莽山自然保护区小黄家 Mt. Mangshan
>
> 土名： 一点红 Native name: A little red

*An italic line after a label inside a chapter.*

Another body paragraph between the labels.

> LONG

> LONG

> LONG

> LONG

![A test figure with *emphasis* in its alt.](images/fig.png)

*A caption under the figure.*

Body after the caption.
""".replace("LONG", KIT2P_LONG)

KIT2P_CONFIG = {
    "title": "Print Two Fixture",
    "title_lines": ["Print Two", "Fixture"],
    "subtitle": "Labels, Captions and Titles",
    "author": "Fixture Author",
    "slug": "_regk2p",
    "is_fiction": False,
    "language": "en",
    "formats": ["kdp_paperback"],
    "min_pages": 1,
    "about_the_author": "Fixture Author wrote *The First Book* and then this one.",
    "front_matter": [{"type": "half_title"}, {"type": "title"}, {"type": "copyright"}],
    "interior": {"hyphenate": True, "caption": {"size_pt": 10.5, "align": "center"},
                 "part_title_break": True, "label_cjk_nobreak_max": 4, "label_keep_max_lines": 10},
    "voice": {"unit_noun": "chapter", "no_em_dashes": True, "blacklist": []},
    "units": [{"id": "part_one", "title": "Part One: The Setup", "class": "C", "target_words": 20},
              {"id": "ch_01", "title": "Chapter One: The Start", "class": "C", "target_words": 80}],
}


def kit2p_leg(checks: list, fails: list, generator=None, latin_docx=None) -> None:
    """R1-R10 (see the block comment) plus five guards. generator overrides the
    script (negative tests); latin_docx is a Latin-only print DOCX for the R2
    guard (the main fixture's). Every build runs in a fresh temp workspace."""
    gen = Path(generator) if generator else TOOLS / "generate_book.js"
    ws = Path(tempfile.mkdtemp(prefix="bs_regk2p_"))
    ZWJ = chr(0x200D)   # U+200D, written as chr(): an invisible literal reads as ""

    def chk(name, ok, detail=""):
        checks.append({"target": "print", "check": name, "pass": bool(ok), "detail": detail})
        if not ok:
            fails.append(f"print/{name}: {detail}")

    def build(cfg, name):
        cp = ws / f"{name}.json"          # config in the workspace root: images + master resolve
        cp.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
        docx = ws / f"{name}.docx"
        r = subprocess.run(["node", str(gen), "--config", str(cp), "--format", "kdp_paperback",
                            "--out", str(docx)], capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=180)
        parts = {}
        if docx.exists():
            with zipfile.ZipFile(docx) as z:
                for n in ("word/document.xml", "word/styles.xml", "word/settings.xml", "docProps/core.xml"):
                    parts[n] = z.read(n).decode("utf-8", "replace")
        return r, parts

    def ppr(p):
        return re.sub(r"<w:rPr>.*?</w:rPr>", "", p[0], flags=re.S) if p else ""

    def style_ppr(styles, sid):
        m = re.search(rf'<w:style [^>]*w:styleId="{sid}".*?</w:style>', styles, re.S)
        m2 = re.search(r"<w:pPr>(.*?)</w:pPr>", m.group(0), re.S) if m else None
        return m2.group(1) if m2 else ""

    def doc_defaults(styles):
        m = re.search(r"<w:docDefaults>.*?</w:docDefaults>", styles, re.S)
        return m.group(0) if m else ""

    try:
        (ws / "outputs" / "markdown").mkdir(parents=True)
        (ws / "outputs" / "markdown" / "_regk2p_v1.md").write_text(KIT2P_MASTER, encoding="utf-8")
        tiny_png(ws / "images" / "fig.png", w=600, h=400, rgb=(90, 110, 90))
        r, parts = build(KIT2P_CONFIG, "knobs")
        if r.returncode != 0 or "word/document.xml" not in parts:
            fails.append(f"kit2p leg build rc={r.returncode}: {(r.stderr or r.stdout).strip()[-200:]}")
            return
        doc, styles = parts["word/document.xml"], parts["word/styles.xml"]
        settings, core = parts["word/settings.xml"], parts["docProps/core.xml"]
        paras = docx_paragraphs(doc)

        def para(start, pool=None):
            return next((p for p in (pool or paras) if p[2].replace(ZWJ, "").startswith(start)), None)

        # R1 [S2] label run keep chain; a tall run keeps only its ends; bare ">" silent
        run3 = [para(s) for s in ("BRIT610990", "湖南省莽山", "土名")]
        longs = [p for p in paras if p[2].startswith("Kalimeris shimadai")]
        kn = [p is not None and "<w:keepNext/>" in ppr(p) for p in run3]
        kl = [p is not None and "<w:keepLines/>" in ppr(p) for p in run3]
        lkn = ["<w:keepNext/>" in ppr(p) for p in longs]
        lwc = ["<w:widowControl/>" in ppr(p) and "<w:keepLines/>" not in ppr(p) for p in longs]
        bare = [p[2] for p in paras if p[2].strip() == ">"]
        chk("label_run_keep_chain",
            kn == [True, True, False] and kl == [True, True, True] and lkn == [True, False, True, False]
            and all(lwc) and len(longs) == 4 and not bare,
            f"short run keepNext={kn} keepLines={kl}; tall run keepNext={lkn} (want T,F,T,F) "
            f"widowControl-not-keepLines={lwc}; literal '>' paragraphs={bare}")

        # R2 [S3] Latin book with CJK: no autospace, compressed CJK punctuation
        dd = doc_defaults(styles)
        csc = settings.find('<w:characterSpacingControl w:val="compressPunctuation"/>')
        chk("latin_cjk_spacing",
            '<w:autoSpaceDE w:val="0"/>' in dd and '<w:autoSpaceDN w:val="0"/>' in dd
            and 0 <= csc < settings.find("<w:updateFields"),
            f"docDefaults={dd[-260:]!r}; characterSpacingControl at {csc}")
        if latin_docx is not None and Path(latin_docx).exists():
            with zipfile.ZipFile(latin_docx) as z:
                lset = z.read("word/settings.xml").decode("utf-8", "replace")
                ldd = doc_defaults(z.read("word/styles.xml").decode("utf-8", "replace"))
            chk("guard_latin_book_no_cjk_spacing",
                "characterSpacingControl" not in lset and "autoSpaceD" not in ldd
                and "autoHyphenation" not in lset,
                f"Latin-only book gained CJK spacing / hyphenation settings: {lset[-300:]!r}")

        # R3 [S4] hyphenation settings in order; display text exempt, body text not
        order = [settings.find(t) for t in ("<w:autoHyphenation/>", '<w:consecutiveHyphenLimit w:val="2"/>',
                                            '<w:hyphenationZone w:val="360"/>', "<w:doNotHyphenateCaps/>",
                                            "<w:evenAndOddHeaders")]
        heading = next((p for p in paras if '<w:pStyle w:val="Heading1"/>' in p[0] and p[2].startswith("Part One")), None)
        exempt = {"part heading": heading, "label": run3[0], "caption": para("A caption under the figure"),
                  "title page": para("PRINT TWO"), "About": para("Fixture Author wrote")}
        no_sup = [k for k, p in exempt.items() if p is None or "<w:suppressAutoHyphens/>" not in ppr(p)]
        lab = ppr(run3[0])
        body = para("A body paragraph that names")
        chk("hyphenation_knob",
            all(k >= 0 for k in order) and order == sorted(order) and not no_sup
            and all("<w:suppressAutoHyphens/>" in style_ppr(styles, s) for s in ("TOC1", "TOC2"))
            and lab.find("<w:suppressAutoHyphens/>") < lab.find("<w:spacing")
            and body is not None and "<w:suppressAutoHyphens/>" not in ppr(body),
            f"settings positions={order}; exempt paragraphs lacking suppressAutoHyphens={no_sup}; "
            f"body suppressed={body is not None and '<w:suppressAutoHyphens/>' in ppr(body)}")

        # R4 [S5] caption style knob
        cap = para("A caption under the figure")
        cp_ = ppr(cap)
        sz_re = re.compile(r'<w:sz w:val="(\d+)"')
        cap_sizes = [sz_re.findall(rp) for rp, t in cap[1] if t.strip()] if cap else []
        chk("caption_style_knob",
            cap is not None and '<w:jc w:val="center"/>' in cp_ and "w:firstLine" not in cp_
            and "<w:keepLines/>" in cp_ and 'w:line="298"' in cp_
            and bool(cap_sizes) and all(s == ["21"] for s in cap_sizes),
            f"caption pPr={cp_!r} run sizes={cap_sizes} (want 21 half-points)")

        # R5 [S6] title lines on the half-title and title page; a mismatch fails
        tl = [p for p in paras if re.search(r">PRINT TWO</w:t>.*?<w:br/>.*?>FIXTURE</w:t>", p[3], re.S)]
        rbad, _ = build(dict(KIT2P_CONFIG, title_lines=["Print Two", "Fixtures"]), "badtitle")
        chk("title_lines",
            len(tl) == 2 and "<dc:title>Print Two Fixture</dc:title>" in core
            and rbad.returncode != 0 and "title_lines" in (rbad.stderr + rbad.stdout),
            f"title paragraphs with the break={len(tl)} (want 2: half-title + title page); "
            f"mismatched title_lines rc={rbad.returncode}")

        # R6 [S7] Contents right indent; part heading split, chapter heading whole
        ch_head = next((p for p in paras if '<w:pStyle w:val="Heading1"/>' in p[0] and p[2].startswith("Chapter One")), None)
        chk("toc_right_indent_part_title_break",
            'w:right="576"' in style_ppr(styles, "TOC1") and 'w:right="576"' in style_ppr(styles, "TOC2")
            and heading is not None and re.search(r">Part One:</w:t>.*?<w:br/>.*?>The Setup</w:t>", heading[3], re.S)
            and ch_head is not None and ch_head[2] == "Chapter One: The Start" and "<w:br/>" not in ch_head[3],
            f"TOC1 pPr={style_ppr(styles, 'TOC1')!r}; part heading={heading[3][-300:] if heading else None!r}; "
            f"chapter heading={ch_head[2] if ch_head else None!r}")

        # R7 [S13] alt text on the print figure
        docprs = [dict(re.findall(r'(\w+)="([^"]*)"', a)) for a in re.findall(r"<wp:docPr\b([^>]*)/>", doc)]
        alt = "A test figure with emphasis in its alt."
        chk("figure_alt_text",
            len(docprs) == 1 and html.unescape(docprs[0].get("descr", "")) == alt
            and html.unescape(docprs[0].get("title", "")) == alt and docprs[0].get("name") == "fig.png",
            f"docPr={docprs}")

        # R8 [N2] short CJK words in labels joined with U+200D, in one run
        lab_runs = [t for p in paras if 'w:left="720"' in p[0] for _, t in p[1]]
        long_lab, local = run3[1], run3[2]
        chk("label_cjk_nobreak",
            ZWJ.join("萧百中") in lab_runs
            and long_lab is not None and ZWJ not in long_lab[2]
            and local is not None and ZWJ.join("土名") in local[2] and ZWJ.join("一点红") in local[2]
            and body is not None and ZWJ not in body[2],
            f"label runs with 萧百中={[t for t in lab_runs if '萧' in t]}; 13-character run joined="
            f"{long_lab is not None and ZWJ in long_lab[2]}; body joined={body is not None and ZWJ in body[2]}")

        # R9 [N4] header distance 0.3 in everywhere
        hd = sorted(set(re.findall(r'w:header="(\d+)"', doc)))
        chk("header_distance", hd == ["432"], f"sectPr header distances={hd} (want ['432'])")

        # R10 [N9] the part-page note takes the label's indents; a chapter's does not
        note = para("The first entry in the notes")
        ch_it = para("An italic line after a label")
        np_, cp2 = ppr(note), ppr(ch_it)
        chk("label_note_indent",
            note is not None and 'w:left="720"' in np_ and 'w:right="360"' in np_
            and '<w:jc w:val="left"/>' in np_ and "w:firstLine" not in np_
            and ch_it is not None and 'w:firstLine="360"' in cp2 and '<w:jc w:val="both"/>' in cp2,
            f"part note pPr={np_!r}; chapter italic line pPr={cp2!r}")

        # Guards: no knobs set = no hyphenation markup, body-style caption, one-run
        # title and part heading, no joiners
        plain = dict(KIT2P_CONFIG, interior={})
        plain.pop("title_lines")
        r0, p0 = build(plain, "plain")
        d0 = p0.get("word/document.xml", "")
        s0 = p0.get("word/settings.xml", "") + p0.get("word/styles.xml", "")
        pa0 = docx_paragraphs(d0)
        chk("guard_no_hyphenation_without_knob",
            r0.returncode == 0 and "autoHyphenation" not in s0 and "suppressAutoHyphens" not in d0 + s0,
            f"rc={r0.returncode}; hyphenation markup present without interior.hyphenate")
        cap0 = next((p for p in pa0 if p[2].startswith("A caption under the figure")), None)
        head0 = next((p for p in pa0 if '<w:pStyle w:val="Heading1"/>' in p[0] and p[2].startswith("Part One")), None)
        chk("guard_default_caption_title_heading",
            cap0 is not None and '<w:jc w:val="both"/>' in cap0[0] and 'w:firstLine="360"' in cap0[0]
            and any(p[2] == "PRINT TWO FIXTURE" for p in pa0)
            and head0 is not None and head0[2] == "Part One: The Setup" and "<w:br/>" not in head0[3],
            f"caption pPr={cap0[0][:160] if cap0 else None!r}; part heading={head0[2] if head0 else None!r}")
        chk("guard_no_joiners_without_knob", ZWJ not in d0, "U+200D in a build without label_cjk_nobreak_max")
        # interior.label_keep_max_lines unset: labels carry no keep flags (as before)
        # (label lines only: the part-page note shares the indent but keeps its lines)
        labs0 = [p for p in pa0 if 'w:left="720"' in p[0] and not p[2].startswith("The first entry")]
        chk("guard_label_keep_off_by_default",
            r0.returncode == 0 and len(labs0) >= 7
            and not any(re.search(r"<w:keepNext/>|<w:keepLines/>|<w:widowControl/>", p[0]) for p in labs0),
            f"rc={r0.returncode}; {len(labs0)} label paragraphs; keep flags without the knob="
            f"{[p[2][:20] for p in labs0 if re.search(r'<w:keep', p[0])]}")
    finally:
        shutil.rmtree(ws, ignore_errors=True)
# ==== end KIT2-PRINT LEG ======================================================


def main(argv=None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    as_json = "--json" in (argv or sys.argv[1:])

    if not shutil.which("node") or not (TOOLS / "node_modules" / "docx").is_dir():
        print(json.dumps({"status": "skip", "detail": "node or vendored node_modules absent"})
              if as_json else "regression_fixtures: SKIP (node/node_modules absent)")
        return 2

    ws = Path(tempfile.mkdtemp(prefix="bs_regfix_"))
    fails: list[str] = []
    try:
        (ws / "manuscript" / "current").mkdir(parents=True)
        (ws / "outputs" / "markdown").mkdir(parents=True)
        (ws / "book_config.json").write_text(json.dumps(CONFIG, indent=2), encoding="utf-8")
        (ws / "outputs" / "markdown" / "_regfix_v1.md").write_text(MASTER, encoding="utf-8")
        tiny_png(ws / "images" / "mf_test.png")
        # Grayscale-derivative sibling: print must PREFER this over the original.
        tiny_png(ws / "images" / "mf_test_print.png", w=10, h=8, rgb=(60, 60, 60))
        tiny_png(ws / "cover_art" / "_regfix_src.png")  # epub leg needs a cover

        for gen, outname in (("generate_book.js", None), ("generate_kindle.js", None)):
            cmd = ["node", str(TOOLS / gen), "--config", str(ws / "book_config.json")]
            if gen == "generate_book.js":
                cmd += ["--format", "kdp_paperback"]
            r = subprocess.run(cmd, capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=180)
            if r.returncode != 0:
                fails.append(f"{gen} rc={r.returncode}: {(r.stderr or r.stdout).strip()[-200:]}")

        checks = []
        for label, docx in (("print", ws / "outputs" / "kdp_paperback" / "_regfix_KDP_PAPERBACK.docx"),
                            ("kindle", ws / "outputs" / "kindle" / "_regfix_KINDLE.docx")):
            if not docx.exists():
                fails.append(f"{label}: DOCX not produced at {docx}")
                continue
            runs, text, settings, media, media_bytes = docx_text_and_settings(docx)
            def chk(name, ok, detail=""):
                checks.append({"target": label, "check": name, "pass": bool(ok), "detail": detail})
                if not ok:
                    fails.append(f"{label}/{name}: {detail}")
            chk("currency_literal", "$14.99" in text and "$24.99" in text,
                "dollar amounts must survive as literal prose")
            chk("math_converts", ("→" in text and "⋯" in text and "⋃" in text),
                f"expected → ⋯ ⋃ in rendered text")
            chk("no_literal_hashes", "####" not in text,
                "H4 heading leaked as body text with hashes")
            chk("h4_text_present", "A Deep Subsection" in text, "H4 content missing")
            chk("no_orphan_bold_markers", not any(t.strip() == "**" for t in runs),
                "orphaned ** run from bold-wrapped code")
            chk("no_literal_doublestar", "**" not in text,
                "literal ** reached the rendered artifact (bold span failed to pair)")
            chk("bold_across_code_intact",
                "The brain (" in text and "), honestly labeled." in text and "d3" in text,
                "bold-span-containing-code content missing or mangled")
            chk("no_dashes_rendered", not any(ch in text for ch in DASHES),
                "em/en dash reached the rendered artifact")
            chk("epigraph_attribution", "The Ledger" in text, "epigraph attribution missing")
            chk("image_prose_kept", "the crowd still would not look away" in text,
                "[IMAGES prose line was eaten by the image-block skip")
            chk("no_literal_md_image", "![test photo]" not in text,
                "literal markdown image line reached the rendered artifact")
            chk("midflow_caption_kept", "A caption line under the photo." in text,
                "caption paragraph after the mid-flow image was lost")
            chk("midflow_embedded", len(media) >= 1,
                f"expected >=1 word/media entry (mid-flow image), got {len(media)}")
            orig_b = (ws / "images" / "mf_test.png").read_bytes()
            print_b = (ws / "images" / "mf_test_print.png").read_bytes()
            if label == "kindle":
                chk("midflow_original_variant", any(b == orig_b for b in media_bytes),
                    "kindle must embed the ORIGINAL (color) mid-flow image")
            if label == "print":
                chk("midflow_print_variant",
                    any(b == print_b for b in media_bytes)
                    and not any(b == orig_b for b in media_bytes),
                    "print must prefer the grayscale _print sibling over the original")
            if label == "print":
                enabled = re.search(r"<w:evenAndOddHeaders\b(?![^>]*w:val=\"(?:false|0)\")", settings)
                chk("evenAndOddHeaders_enabled", bool(enabled),
                    "outer page numbers need the ENABLED flag in settings.xml")

        # ---- EPUB leg (pure Python): mid-flow image embeds as figure.midflow ----
        r = subprocess.run([sys.executable, str(TOOLS / "build_epub.py"),
                            "--config", str(ws / "book_config.json")],
                           capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=180)
        epub = ws / "outputs" / "epub" / "_regfix.epub"
        if r.returncode != 0:
            fails.append(f"build_epub rc={r.returncode}: {(r.stderr or r.stdout).strip()[-300:]}")
        if epub.exists():
            def echk(name, ok, detail=""):
                checks.append({"target": "epub", "check": name, "pass": bool(ok), "detail": detail})
                if not ok:
                    fails.append(f"epub/{name}: {detail}")
            with zipfile.ZipFile(epub) as z:
                nm = z.namelist()
                mf = [n for n in nm if n.startswith("OEBPS/images/mf_")]
                ch1 = ""
                for n in nm:
                    if n.endswith("ch_01.xhtml"):
                        ch1 = z.read(n).decode("utf-8", "replace")
                rd = lambda n: z.read(n).decode("utf-8", "replace") if n in nm else ""  # noqa: E731
                nav, opf = rd("OEBPS/nav.xhtml"), rd("OEBPS/content.opf")
                cpy = rd("OEBPS/text/copyright.xhtml")
            echk("midflow_file_embedded", len(mf) == 1,
                 f"OEBPS/images mf_* count={len(mf)} (want 1)")
            echk("midflow_figure_referenced",
                 'class="midflow"' in ch1 and "mf_001_mf_test.png" in ch1,
                 "figure.midflow with the image ref missing from ch_01.xhtml")
            echk("no_literal_md_image", "![test photo]" not in ch1,
                 "literal markdown image line leaked into the XHTML")
            echk("midflow_caption_kept", "A caption line under the photo." in ch1,
                 "caption paragraph after the mid-flow image was lost")
            # 16 (default path): landmarks without a toc entry, no in-book
            # Contents unless kindle_include_toc opts in; 14: edition line.
            echk("landmarks_nav_default",
                 'epub:type="landmarks"' in nav
                 and '<a epub:type="cover" href="text/cover.xhtml">' in nav
                 and '<a epub:type="bodymatter" href="text/ch_01.xhtml">' in nav
                 and 'epub:type="toc" href="nav.xhtml' not in nav,
                 "landmarks nav (cover + bodymatter, no toc landmark by default) missing")
            echk("no_incontents_by_default", '<itemref idref="nav"/>' not in opf,
                 "nav document in the spine without kindle_include_toc (LESSONS_LEDGER §16.4)")
            echk("copyright_first_edition_default", "<p>First edition</p>" in cpy,
                 "EPUB copyright page lacks the edition line the print/Kindle editions carry")
        else:
            fails.append(f"epub: not produced at {epub}")

        ebook_leg(checks, fails)
        print_leg(checks, fails,   # KITP-A print leg (P1-P9 + two default-behavior guards)
                  latin_docx=ws / "outputs" / "kdp_paperback" / "_regfix_KDP_PAPERBACK.docx")
        kit2o_leg(checks, fails)   # KIT2-OTHER leg (K1-K9 + two default-behavior guards)
        kit2p_leg(checks, fails,   # KIT2-PRINT leg (R1-R10 + five default-behavior guards)
                  latin_docx=ws / "outputs" / "kdp_paperback" / "_regfix_KDP_PAPERBACK.docx")

        status = "pass" if not fails else "fail"
        out = {"status": status, "workspace": str(ws), "checks": checks, "fails": fails}
        if as_json:
            print(json.dumps(out, ensure_ascii=False, indent=2))
        else:
            for c in checks:
                print(f"  [{'OK ' if c['pass'] else 'XX '}] {c['target']:6} {c['check']}"
                      + ("" if c["pass"] else f" -- {c['detail']}"))
            print(f"REGRESSION_FIXTURES: {'PASS' if status == 'pass' else 'FAIL'} "
                  f"({len(checks)} checks, {len(fails)} fail)")
        return 0 if status == "pass" else 1
    finally:
        shutil.rmtree(ws, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())

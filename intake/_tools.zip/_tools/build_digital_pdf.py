"""
build_digital_pdf.py — Digital / reader PDF assembler.

BOOKSMITH toolchain component. Assembles the email/Drive reader PDF:
  page 1  front cover (exact 6x9-pt MediaBox)
  page 2  back cover  (cropped from the print wrap's bleed back to 6x9 trim)
  pages 3+  the print interior with every print-only blank verso + header-ghost
            page stripped, so it reads continuously. Image-bearing pages
            (mid-flow figures) are never stripped (strip_blank_pages 2026-07-27).
  digital_pdf.back_cover_last: true moves the back cover from page 2 to the
            LAST page, after the interior, so a reader meets the book before the
            blurb (2026-09-24, final render QC S8). Default false = the order above.

Page labels (/PageLabels, 2026-09-24, final render QC N5): the viewer's page
number is the page's PRINTED folio. The arabic sequence is pinned by the folios
the interior actually prints (their most common page-minus-folio offset); pages
before folio 1 (front matter, printed without folios) are labeled in lowercase
roman numerals by their print position (i, iii, iv ... where blanks were
stripped); the covers are labeled "Cover" and "Back Cover" (localizable via
strings.epub_doc_titles.cover / .back_cover). An interior with no consistent
printed folio sequence (e.g. the ebook-only Kindle-DOCX fallback) gets no labels.

CONTRACT (KIT_ARCHITECTURE (c) build_digital_pdf.py):
  - Word-COM interior PDF (reuse docx_to_pdf.py) + crop covers
    (BLEED_PX = int(0.80*DPI) = 240 for Mixam-sourced back art) ->
    cover pages as an EXACT 432x648-pt MediaBox via fitz.new_page ->
    pypdf concat -> book_workspace/<slug>/outputs/digital/<slug>_DIGITAL.pdf.

PORTED FROM:
  - C:\\BOOK\\build_digital_atd.py                     (blank-strip + fitz cover pages + interior copy)
  - C:\\Inside_The_Region\\build_digital_with_covers.py (scale-to-fit letterbox cover render)

Cover-source resolution (first existing wins), all under the workspace outputs/:
  WRAP on disk (kdp_paperback/<slug>_cover_wrap.jpg | kdp_paperback/cover_wrap.jpg |
         kdp_paperback/<slug>_KDP_PAPERBACK_wrap.jpg): FRONT and BACK are its exact
         6x9 trim crops (1800x2700 px on 432x648 pt, edge to edge, no letterbox),
         so the reader PDF shows the printed book's own two faces (2026-09-24).
  no wrap (ebook-only): FRONT kindle/<slug>_KINDLE_cover.jpg | _KINDLE_COVER.jpg |
         _kindle_cover.jpg | <slug>_cover.jpg, placed scale-to-fit (letterboxed in
         the cover color, so edge content is never cropped); BACK a standalone
         kdp_paperback/<slug>_back.jpg | back_cover.jpg (used as-is), else none.
  INTERIOR DOCX: kdp_paperback/<slug>_KDP_PAPERBACK.docx (rendered to PDF if the
         PDF is absent), else the pre-rendered kdp_paperback/*.pdf.

The exact 6x9 MediaBox is written via fitz, never PIL (PIL truncates the
MediaBox to a floor(px/DPI) inch value and KDP-style 4-decimal validators reject
it — LESSONS_LEDGER §5.6). The document carries /Title "Title: Subtitle" and
/Author from the config (shown by viewers instead of the file name) and an
outline: one bookmark per unit at its opening page plus About the Author.

Usage:
  python build_digital_pdf.py --config book_config.json [--kit-env kit_env.json]
                              [--workspace <dir>]
  python build_digital_pdf.py --selftest   (synthetic workspace; no book touched)

Prints a JSON summary on stdout.
"""
import sys
import os
import io
import json
import re
import tempfile
import unicodedata

import fitz  # PyMuPDF
from PIL import Image
# pypdf is the maintained successor to the EOL PyPDF2 (drop-in PdfReader/PdfWriter
# API). Prefer it; fall back to PyPDF2 on machines that only have the old package.
try:
    from pypdf import PdfReader, PdfWriter
except ImportError:  # pragma: no cover - legacy fallback
    from PyPDF2 import PdfReader, PdfWriter

# Local sibling tools.
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)
import strip_blank_pages as _strip            # noqa: E402
# docx_to_pdf (Word COM, Windows-only) is imported lazily inside
# ensure_interior_pdf() so this module loads on any platform whenever a
# pre-rendered interior PDF already exists.

DPI = 300
TRIM_W_IN = 6.00
TRIM_H_IN = 9.00
PAGE_W_PTS = TRIM_W_IN * 72   # 432
PAGE_H_PTS = TRIM_H_IN * 72   # 648


def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def hex_to_rgb(h: str):
    h = (h or "").lstrip("#")
    if len(h) != 6:
        return (13, 27, 42)  # navy fallback
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def first_existing(*paths):
    for p in paths:
        if p and os.path.exists(p):
            return p
    return None


def resolve_workspace(cfg, workspace_arg):
    """The digital PDF lands under book_workspace/<slug>/outputs/. The workspace
    root is either passed explicitly or derived relative to the kit root."""
    slug = cfg["slug"]
    if workspace_arg:
        return os.path.abspath(workspace_arg)
    # Kit layout: <kit>/_tools/build_digital_pdf.py -> <kit>/book_workspace/<slug>
    kit_root = os.path.dirname(_THIS_DIR)
    return os.path.join(kit_root, "book_workspace", slug)


def bleed_px_for_back(cfg) -> int:
    """The back cover is cropped from the print wrap. resolve_covers() only ever
    sources the KDP paperback wrap ('{slug}_cover_wrap.jpg' / 'cover_wrap.jpg' /
    '{slug}_KDP_PAPERBACK_wrap.jpg') — all 0.125" KDP bleed. The Mixam wrap
    ('cover_wrap_mixam.jpg', 0.80" bleed) is NEVER in that list, so cropping with
    the Mixam bleed shears 0.675" off every edge. Read the KDP paperback bleed."""
    spine = cfg.get("spine") or {}
    kdp_bleed = spine.get("kdp_bleed_in", 0.125)
    # int(), exactly composite_cover's edge_px = int(edge_in * DPI): its panels
    # are placed on that grid, so the back trim is [37, 1837) and the spine
    # starts at 1837. round() gave 38, and the old crop took spine column 1837
    # as a 1 px dark line on the digital back's fold edge.
    return int(kdp_bleed * DPI)


def crop_trim_from_wrap(wrap_path: str, cfg, side: str) -> Image.Image:
    """Crop one trim face (6x9, no bleed) out of a KDP paperback wrap laid out as
    [back bleed | back trim | spine | front trim | front bleed]. The back is
    measured from the left bleed edge and the front from the right one, so the
    spine width never enters; rows start below the top bleed. Both use the
    compositor's own bleed grid (bleed_px_for_back), so no spine column leaks in.
    The crop is EXACTLY the trim in pixels (1800x2700 at 300 dpi), so the cover
    page is the printed face edge to edge: render_cover_jpeg then scales by 1.0
    and letterboxes nothing (2026-09-24, across_borders QC: the old 2699-row
    back crop left a 1 px cover-color row, and the letterboxed 1:1.6 Kindle
    front put 13 pt navy bars down both sides of page 1)."""
    wrap = Image.open(wrap_path).convert("RGB")
    W, H = wrap.size
    tw, th = int(round(TRIM_W_IN * DPI)), int(round(TRIM_H_IN * DPI))
    bleed_px = bleed_px_for_back(cfg)
    exp_h = th + 2 * float((cfg.get("spine") or {}).get("kdp_bleed_in", 0.125)) * DPI
    assert abs(H - exp_h) <= 2 and W >= 2 * tw + 2 * bleed_px, (
        f"wrap {W}x{H}px is not a {TRIM_W_IN:g}x{TRIM_H_IN:g} KDP paperback wrap "
        f"(expected height {exp_h:.0f}px); wrong bleed for source {wrap_path}")
    x0 = bleed_px if side == "back" else W - bleed_px - tw
    return wrap.crop((x0, bleed_px, x0 + tw, bleed_px + th))


def crop_back_trim_from_wrap(wrap_path: str, cfg) -> Image.Image:
    """The back-cover trim out of a print wrap (see crop_trim_from_wrap)."""
    return crop_trim_from_wrap(wrap_path, cfg, "back")


def render_cover_jpeg(img: Image.Image, cover_rgb, dpi: int = DPI) -> bytes:
    """Scale-to-fit the source image into an exact 6x9 @ dpi canvas, letterboxed
    in the cover color. Never crops edge content (a title baked at the top or a
    timestamp at an edge survives). Returns JPEG bytes."""
    page_w_px = int(round(TRIM_W_IN * dpi))
    page_h_px = int(round(TRIM_H_IN * dpi))
    src = img.convert("RGB")
    sw, sh = src.size
    scale = min(page_w_px / sw, page_h_px / sh)
    nw, nh = max(1, int(sw * scale)), max(1, int(sh * scale))
    scaled = src.resize((nw, nh), Image.LANCZOS)
    canvas = Image.new("RGB", (page_w_px, page_h_px), cover_rgb)
    canvas.paste(scaled, ((page_w_px - nw) // 2, (page_h_px - nh) // 2))
    buf = io.BytesIO()
    canvas.save(buf, format="JPEG", quality=92, optimize=True, dpi=(dpi, dpi))
    return buf.getvalue()


def build_cover_pages_pdf(front_jpeg: bytes, back_jpeg, out_path: str):
    """Cover PDF, each page an EXACT 432x648-pt MediaBox (via fitz, not PIL).
    Two pages (front + back) when back_jpeg is provided; front-only when it is
    None (an ebook-first digital edition has no print back cover)."""
    doc = fitz.open()
    p_front = doc.new_page(width=PAGE_W_PTS, height=PAGE_H_PTS)
    p_front.insert_image(p_front.rect, stream=front_jpeg)
    if back_jpeg is not None:
        p_back = doc.new_page(width=PAGE_W_PTS, height=PAGE_H_PTS)
        p_back.insert_image(p_back.rect, stream=back_jpeg)
    doc.save(out_path, deflate=True, garbage=4, clean=True)
    doc.close()


def ensure_interior_pdf(cfg, ws: str) -> str:
    """Return a path to the print interior PDF, rendering it from the paperback
    DOCX via Word COM if only the DOCX exists."""
    slug = cfg["slug"]
    pb_dir = os.path.join(ws, "outputs", "kdp_paperback")

    existing_pdf = first_existing(
        os.path.join(pb_dir, f"{slug}_KDP_PAPERBACK.pdf"),
        os.path.join(pb_dir, f"{slug}_KDP.pdf"),
        os.path.join(pb_dir, f"{slug}.pdf"),
    )

    docx = first_existing(
        os.path.join(pb_dir, f"{slug}_KDP_PAPERBACK.docx"),
        os.path.join(pb_dir, f"{slug}_KDP.docx"),
        os.path.join(pb_dir, f"{slug}.docx"),
    )
    if not docx:
        # Ebook-only workspace (no print format configured): the digital reading
        # copy renders from the KINDLE interior instead - reflowable styling, but
        # a complete, honest PDF of the book (cloud one-shot tickets, 2026-08-13).
        kindle_docx = os.path.join(ws, "outputs", "kindle", f"{slug}_KINDLE.docx")
        if os.path.exists(kindle_docx):
            docx = kindle_docx
        elif not existing_pdf:
            raise FileNotFoundError(
                f"No interior PDF or DOCX found in {pb_dir} (and no kindle DOCX "
                f"fallback). Produce the kdp_paperback or kindle format first.")

    # FRESHNESS, not existence (H0 lap a12b, 2026-08-24): the cached interior is
    # reusable only if it is at least as new as the DOCX it would be rendered
    # from. The first cloud REBUILD after a manual edit regenerated the kindle
    # DOCX but this function returned the build-#1 render of it - the customer's
    # edit reached every artifact EXCEPT the headline PDF. Same defect class as
    # the worker's archive head-skip: "exists -> skip" must be "fresh -> skip".
    if existing_pdf and (not docx
                         or os.path.getmtime(existing_pdf) >= os.path.getmtime(docx)):
        return existing_pdf

    out_pdf = os.path.join(pb_dir, f"{slug}_KDP_PAPERBACK.pdf")
    import docx_to_pdf as _docx_to_pdf  # lazy: Word COM (or Tier-2 LibreOffice), Windows-first
    pages, words, renderer = _docx_to_pdf.docx_to_pdf(docx, out_pdf)
    print(f"  Rendered interior via {renderer}: {pages} pages, {words} words",
          file=sys.stderr)
    return out_pdf


def refit_interior_to_trim(interior_pdf: str, out_dir: str) -> str:
    """Re-fit interior pages onto the exact 6x9 trim when the renderer produced
    another size: the ebook-only kindle-DOCX fallback renders via soffice at A4
    (Linux) or Word at Letter, and the digital_pdf_structure gate demands
    432x648 pt on every page. Vector re-fit via show_pdf_page (the
    pdf_replica_fit pattern): aspect-fit, centered, never cropped, never
    rasterized. Interiors already at trim pass through untouched."""
    src = fitz.open(interior_pdf)
    try:
        if all(abs(p.rect.width - PAGE_W_PTS) <= 0.5 and
               abs(p.rect.height - PAGE_H_PTS) <= 0.5 for p in src):
            return interior_pdf
        src_w, src_h = src[0].rect.width, src[0].rect.height
        fd, refit_pdf = tempfile.mkstemp(suffix="_refit.pdf", dir=out_dir)
        os.close(fd)
        out = fitz.open()
        for p in src:
            scale = min(PAGE_W_PTS / p.rect.width, PAGE_H_PTS / p.rect.height)
            w, h = p.rect.width * scale, p.rect.height * scale
            x0 = (PAGE_W_PTS - w) / 2.0
            y0 = (PAGE_H_PTS - h) / 2.0
            page = out.new_page(width=PAGE_W_PTS, height=PAGE_H_PTS)
            page.show_pdf_page(fitz.Rect(x0, y0, x0 + w, y0 + h), src, p.number)
        out.save(refit_pdf, deflate=True, garbage=4)
        out.close()
        print(f"  Re-fit interior {src_w:.1f}x{src_h:.1f}pt -> "
              f"{PAGE_W_PTS:.0f}x{PAGE_H_PTS:.0f}pt ({src.page_count} pages)",
              file=sys.stderr)
        return refit_pdf
    finally:
        src.close()


def resolve_covers(cfg, ws: str):
    """Return (front_img, back_img, cover_rgb, front_src, back_src).

    With a KDP paperback wrap on disk, BOTH faces are its exact trim crops: the
    reader PDF then opens on the printed front and closes on the printed back,
    edge to edge at 432x648 pt, nothing letterboxed. Without a wrap (ebook-only
    books, the cloud one-shot path) the front is the Kindle cover letterboxed
    to 2:3 and the back is a standalone back image or nothing, as before."""
    slug = cfg["slug"]
    kindle_dir = os.path.join(ws, "outputs", "kindle")
    pb_dir = os.path.join(ws, "outputs", "kdp_paperback")
    palette = ((cfg.get("cover") or {}).get("palette")) or {}
    cover_rgb = hex_to_rgb(palette.get("navy") or palette.get("umber") or "0D1B2A")

    wrap_path = first_existing(
        os.path.join(pb_dir, f"{slug}_cover_wrap.jpg"),
        os.path.join(pb_dir, "cover_wrap.jpg"),
        os.path.join(pb_dir, f"{slug}_KDP_PAPERBACK_wrap.jpg"),
    )
    if wrap_path:
        return (crop_trim_from_wrap(wrap_path, cfg, "front"),
                crop_trim_from_wrap(wrap_path, cfg, "back"), cover_rgb,
                f"{wrap_path} (front trim)", f"{wrap_path} (back trim)")

    front_path = first_existing(
        os.path.join(kindle_dir, f"{slug}_KINDLE_cover.jpg"),
        os.path.join(kindle_dir, f"{slug}_KINDLE_COVER.jpg"),
        os.path.join(kindle_dir, f"{slug}_kindle_cover.jpg"),
        os.path.join(kindle_dir, f"{slug}_cover.jpg"),
        os.path.join(kindle_dir, f"{slug}_KINDLE_cover.png"),
    )
    if not front_path:
        raise FileNotFoundError(
            f"No Kindle/front cover image found under {kindle_dir}. Produce the "
            f"kindle cover first.")
    front_img = Image.open(front_path).convert("RGB")

    # Back cover (no wrap on disk): a standalone back art, else none.
    back_standalone = first_existing(
        os.path.join(pb_dir, f"{slug}_back.jpg"),
        os.path.join(pb_dir, "back_cover.jpg"),
    )
    if not back_standalone:
        # Ebook-first / no print back cover: a reader PDF should open on the
        # front cover and go straight to the content. Reusing the front as a
        # fake "back" (the old behavior) shipped a confusing duplicate-cover
        # page 2. Return no back -> a front-only digital edition.
        back_img = None
        back_src = "(none; front-only digital edition, no print back cover)"
    else:
        back_img = Image.open(back_standalone).convert("RGB")
        back_src = back_standalone

    return front_img, back_img, cover_rgb, front_path, back_src


# ---- reader metadata + outline (2026-09-24, across_borders QC rows 18-19: the
# digital PDF had an empty Title/Author, so viewers showed the file name, and
# no bookmarks, so the sidebar was empty) ------------------------------------
def document_title(cfg) -> str:
    """/Title for the reader PDF: 'Title: Subtitle' from the config."""
    t = str(cfg.get("title") or "").strip()
    s = str(cfg.get("subtitle") or "").strip()
    return f"{t}: {s}" if t and s else (t or s)


def _compact(s: str) -> str:
    """Casefolded letters and digits only (after NFKC). Line wraps, letter-
    spacing ("A B O U T"), punctuation, hyphens and curly quotes all drop out,
    so a heading matches its config title however the generator set it."""
    s = unicodedata.normalize("NFKC", s or "").casefold()
    return "".join(ch for ch in s if ch.isalnum())


_FOLIO_LINE = re.compile(r"\d{1,4}|[ivxlcdm]{1,7}")


def find_outline_entries(interior_pdf: str, cfg):
    """([(title, page_index)], [titles not found]) for the interior PDF: each
    unit's opening page by its heading text, then About the Author.

    A page opens a unit when the unit's title starts within the first lines of
    its text (folio-only lines skipped). The Contents is skipped: a page headed
    "Contents", or one naming 3+ unit titles. The search runs forward in book
    order from the previous hit, so a later mention cannot pull an entry back."""
    titles = [str(u.get("title") or "").strip() for u in (cfg.get("units") or [])]
    titles = [t for t in titles if _compact(t)]
    targets = titles + (["About the Author"]
                        if str(cfg.get("about_the_author") or "").strip() else [])
    heads, fulls = [], []
    doc = fitz.open(interior_pdf)
    try:
        for pg in doc:
            lines = [ln.strip() for ln in (pg.get_text("text") or "").splitlines() if ln.strip()]
            body = [ln for ln in lines if not _FOLIO_LINE.fullmatch(ln.casefold())]
            heads.append(_compact(" ".join(body[:6])))
            fulls.append(_compact(" ".join(lines)))
    finally:
        doc.close()
    keys = {_compact(t) for t in titles}
    need = min(3, len(keys)) if len(keys) >= 2 else 99
    contents = {i for i, (h, f) in enumerate(zip(heads, fulls))
                if h.startswith(("contents", "tableofcontents"))
                or sum(1 for k in keys if k in f) >= need}
    entries, missing, start = [], [], 0
    for title in targets:
        key = _compact(title)
        hit = next((i for i in range(start, len(heads))
                    if i not in contents and 0 <= heads[i].find(key) <= 40), None)
        if hit is None:
            missing.append(title)
            continue
        entries.append((title, hit))
        start = hit
    return entries, missing


# ---- page labels (2026-09-24, across_borders final render QC N5: the viewer
# counted 1..163 while the page said 63, and the printed folios jump where the
# blank versos were stripped) -------------------------------------------------
_FOLIO_DIGITS = re.compile(r"\d{1,4}")


def detect_folios(pdf_path: str) -> dict:
    """{1-based page: printed folio} for every page that prints one: a text line
    of 1-4 digits alone in the footer or header band (the bottom or top 12% of
    the page; the candidate nearest the page edge wins)."""
    out = {}
    doc = fitz.open(pdf_path)
    try:
        for i, pg in enumerate(doc):
            h = pg.rect.height
            best = None
            for block in pg.get_text("dict").get("blocks", []):
                for line in block.get("lines", []):
                    t = "".join(s.get("text", "") for s in line.get("spans", [])).strip()
                    if not _FOLIO_DIGITS.fullmatch(t):
                        continue
                    y0, y1 = line["bbox"][1], line["bbox"][3]
                    if y0 >= 0.88 * h or y1 <= 0.12 * h:
                        edge = min(h - y1, y0)
                        if best is None or edge < best[0]:
                            best = (edge, int(t))
            if best is not None:
                out[i + 1] = best[1]
    finally:
        doc.close()
    return out


def _roman(n: int) -> str:
    out = []
    for v, s in ((1000, "m"), (900, "cm"), (500, "d"), (400, "cd"), (100, "c"), (90, "xc"),
                 (50, "l"), (40, "xl"), (10, "x"), (9, "ix"), (5, "v"), (4, "iv"), (1, "i")):
        while n >= v:
            out.append(s)
            n -= v
    return "".join(out)


def interior_page_labels(pdf_path: str, kept_pages: list):
    """(labels, info) for the kept interior pages (their 1-based page numbers in
    the print interior, in order). A label is ("/D", folio) or ("/r", n).

    The arabic sequence is the one the pages print: the most common
    page-minus-folio offset among the detected folios (10 when print page 11
    carries folio 1), accepted only when at least 3 folios and 80% of them
    agree. Every page at or after folio 1 is labeled with its folio, printed or
    not (an opener without a folio still has its number). Pages before folio 1
    are the unnumbered front matter: lowercase roman by print position. labels
    is None, with the reason in info, when no consistent sequence exists."""
    folios = detect_folios(pdf_path)
    if len(folios) < 3:
        return None, {"skipped": f"{len(folios)} printed folio(s) found; need 3 or more"}
    from collections import Counter
    offset, support = Counter(p - f for p, f in folios.items()).most_common(1)[0]
    if support < 0.8 * len(folios):
        return None, {"skipped": f"no consistent folio sequence: the best page-minus-folio "
                                 f"offset ({offset}) fits {support} of {len(folios)} folios"}
    labels = [("/D", p - offset) if p - offset >= 1 else ("/r", p) for p in kept_pages]
    return labels, {"offset": offset, "folios_found": len(folios), "folios_agreeing": support,
                    "front_matter_pages": sum(1 for s, _ in labels if s == "/r")}


def page_label_text(label) -> str:
    kind, val = label
    if kind == "/D":
        return str(val)
    if kind == "/r":
        return _roman(val)
    return str(val)


def write_page_labels(writer, labels) -> None:
    """Write /PageLabels for per-page labels: ("/D", n) arabic, ("/r", n) roman,
    ("text", s) a fixed label such as "Cover". A range starts wherever the
    style changes or a number is not the previous one plus 1."""
    try:
        from pypdf.generic import (ArrayObject, DictionaryObject, NameObject,
                                   NumberObject, TextStringObject)
    except ImportError:  # pragma: no cover - legacy PyPDF2
        from PyPDF2.generic import (ArrayObject, DictionaryObject, NameObject,
                                    NumberObject, TextStringObject)
    nums = ArrayObject()
    prev = None
    for idx, (kind, val) in enumerate(labels):
        continues = (kind != "text" and prev is not None and prev[0] == kind
                     and val == prev[1] + 1)
        prev = (kind, val)
        if continues:
            continue
        d = DictionaryObject()
        if kind == "text":
            d[NameObject("/P")] = TextStringObject(str(val))
        else:
            d[NameObject("/S")] = NameObject(kind)
            if val != 1:
                d[NameObject("/St")] = NumberObject(val)
        nums.append(NumberObject(idx))
        nums.append(d)
    root = getattr(writer, "root_object", None) or writer._root_object
    root[NameObject("/PageLabels")] = DictionaryObject({NameObject("/Nums"): nums})


def build(config_path, workspace_arg):
    cfg = load_json(config_path)
    slug = cfg["slug"]
    ws = resolve_workspace(cfg, workspace_arg)

    out_dir = os.path.join(ws, "outputs", "digital")
    os.makedirs(out_dir, exist_ok=True)
    out_pdf = os.path.join(out_dir, f"{slug}_DIGITAL.pdf")

    # 1. Interior PDF (render from DOCX via Word COM if needed).
    interior_pdf = ensure_interior_pdf(cfg, ws)

    # 1b. Conform to trim (RUNBOOK lesson 13): the kindle-DOCX fallback renders
    #     at A4/Letter; the structure gate stays exact, the interior bends to it.
    fitted_pdf = refit_interior_to_trim(interior_pdf, out_dir)

    # 2. Strip print-only blanks + header ghosts into a temp PDF.
    #    keep_covers=1 (NOT the default 2, NOT 0): the strip runs on the
    #    cover-LESS interior (covers are prepended below), so page 1 is the real
    #    half-title (e.g. 'THE TEST VOYAGE' = 13 chars, below min_chars=30);
    #    keep_covers=1 protects it unconditionally while still stripping page 2,
    #    the true blank verso. keep_covers=2 would preserve that blank verso.
    fd, stripped_pdf = tempfile.mkstemp(suffix="_stripped.pdf", dir=out_dir)
    os.close(fd)
    strip_result = _strip.strip_blank_pages(fitted_pdf, stripped_pdf, keep_covers=1)

    # 3. Build the two exact-MediaBox cover pages.
    front_img, back_img, cover_rgb, front_src, back_src = resolve_covers(cfg, ws)
    front_jpeg = render_cover_jpeg(front_img, cover_rgb)
    back_jpeg = render_cover_jpeg(back_img, cover_rgb) if back_img is not None else None
    fd, cover_pdf = tempfile.mkstemp(suffix="_covers.pdf", dir=out_dir)
    os.close(fd)
    build_cover_pages_pdf(front_jpeg, back_jpeg, cover_pdf)

    # 4. Concatenate covers + stripped interior via pypdf (per the contract).
    #    digital_pdf.back_cover_last moves the back cover behind the interior;
    #    n_cover counts the cover pages BEFORE the interior (bookmark offset).
    digital_pdf = cfg.get("digital_pdf") or {}
    back_last = digital_pdf.get("back_cover_last") is True
    writer = PdfWriter()
    cover_reader = PdfReader(cover_pdf)
    covers = list(cover_reader.pages)            # [front] or [front, back]
    lead, tail = (covers[:1], covers[1:]) if back_last else (covers, [])
    for page in lead:
        writer.add_page(page)
    n_cover = len(lead)
    interior_reader = PdfReader(stripped_pdf)
    for page in interior_reader.pages:
        writer.add_page(page)
    for page in tail:
        writer.add_page(page)

    # 4b. Reader metadata (Title "Title: Subtitle", Author) and an outline entry
    #     per unit + About the Author. Bookmarks never fail a build: a search
    #     error or an unfound heading is reported in the summary instead.
    doc_title = document_title(cfg)
    author = str(cfg.get("author") or "").strip()
    meta = {"/Title": doc_title} if doc_title else {}
    if author:
        meta["/Author"] = author
    if meta:
        writer.add_metadata(meta)
    try:
        entries, missing = find_outline_entries(stripped_pdf, cfg)
        for title, idx in entries:
            writer.add_outline_item(title, n_cover + idx)
    except Exception as exc:          # incl. a legacy PyPDF2 without add_outline_item
        entries, missing = [], [f"(outline skipped: {type(exc).__name__}: {exc})"]
    try:
        writer.create_viewer_preferences().display_doctitle = True  # title, not file name
        if entries:
            writer.page_mode = "/UseOutlines"                        # open the bookmarks
    except Exception:
        pass

    # 4c. Page labels: the viewer shows each page's printed folio (front matter
    #     in roman numerals by print position, covers by name). Like the
    #     bookmarks, labels never fail a build: a problem is reported instead.
    strings = cfg.get("strings") or {}
    doc_titles = strings.get("epub_doc_titles") or {}
    front_label = str(doc_titles.get("cover") or "Cover")
    back_label = str(doc_titles.get("back_cover") or "Back Cover")
    all_labels = None
    try:
        removed = {r["page"] for r in strip_result["removed"]}
        kept = [p for p in range(1, strip_result["pages_before"] + 1) if p not in removed]
        if len(kept) != len(interior_reader.pages):
            raise ValueError(f"kept-page map ({len(kept)}) != stripped interior "
                             f"({len(interior_reader.pages)} pages)")
        interior_labels, label_info = interior_page_labels(fitted_pdf, kept)
        if interior_labels is not None:
            all_labels = ([("text", front_label)]
                          + [("text", back_label)] * (len(lead) - 1)
                          + interior_labels
                          + [("text", back_label)] * len(tail))
            write_page_labels(writer, all_labels)
    except Exception as exc:
        label_info = {"skipped": f"page labels not written: {type(exc).__name__}: {exc}"}
        all_labels = None
    if all_labels is not None:
        texts = [page_label_text(lb) for lb in all_labels]
        label_info = dict(label_info, first=texts[:12], last=texts[-1])

    with open(out_pdf, "wb") as f:
        writer.write(f)

    # 5. Cleanup temps.
    temps = [stripped_pdf, cover_pdf]
    if fitted_pdf != interior_pdf:
        temps.append(fitted_pdf)
    for tmp in temps:
        try:
            os.remove(tmp)
        except OSError:
            pass

    total_pages = len(PdfReader(out_pdf).pages)
    size = os.path.getsize(out_pdf)

    summary = {
        "out": out_pdf,
        "total_pages": total_pages,
        "interior_source": interior_pdf,
        "interior_pages_before_strip": strip_result["pages_before"],
        "interior_pages_after_strip": strip_result["pages_after"],
        "blanks_stripped": len(strip_result["removed"]),
        "front_cover_source": front_src,
        "back_cover_source": back_src,
        "back_cover_position": ("none" if back_img is None
                                else "last page" if back_last else "page 2"),
        "page_labels": label_info,
        "covers_exact_trim_px": all(im is None or im.size == (int(round(TRIM_W_IN * DPI)),
                                                              int(round(TRIM_H_IN * DPI)))
                                    for im in (front_img, back_img)),
        "title": doc_title,
        "author": author,
        "outline": [[t, n_cover + i + 1] for t, i in entries],
        "outline_missing": missing,
        "size_bytes": size,
        "size_mb": round(size / 1024 / 1024, 2),
    }
    print(json.dumps(summary))
    return summary


def _selftest(m=None) -> int:
    """--selftest: a synthetic book in a temp dir (6x9 interior with blanks, a
    Contents page, folio-first openers, a mid-page title mention and About the
    Author; a KDP wrap on composite_cover's pixel grid with magenta bleed, a dark
    spine and flat faces; a 1:1.6 Kindle cover). Every check FAILS on the pre-fix
    builder:
      1 covers_from_wrap_exact  pages 1-2: one 1800x2700 image filling an exact
                                432x648 pt page, the wrap's front/back trim face
                                edge to edge (no letterbox, bleed or spine line)
      2 metadata_title_author   /Title "Title: Subtitle" and /Author
      3 outline_units           a bookmark per unit at its opener + About
    `m` lets a caller point the same checks at another module (negative test)."""
    import contextlib
    m = m or sys.modules[__name__]
    results = []

    def check(name, fn):
        try:
            ok, detail = fn()
        except Exception as exc:
            ok, detail = False, f"{type(exc).__name__}: {exc}"
        results.append((name, bool(ok), detail))

    with tempfile.TemporaryDirectory() as td:
        slug = "selftest"
        ws = os.path.join(td, slug)
        pb_dir = os.path.join(ws, "outputs", "kdp_paperback")
        k_dir = os.path.join(ws, "outputs", "kindle")
        os.makedirs(pb_dir)
        os.makedirs(k_dir)
        cfg = {"slug": slug, "title": "Selftest Book", "subtitle": "A Reader’s Subtitle",
               "author": "Test Author", "trim": {"w": 6, "h": 9},
               "units": [{"id": "part_1", "title": "Part I: The First Part"},
                         {"id": "ch_01", "title": "The Opening Chapter"},
                         {"id": "ch_02", "title": "Another Chapter Title"}],
               "about_the_author": "Test Author writes selftests.",
               "cover": {"palette": {"umber": "1F2A2E"}}}
        cfg_path = os.path.join(ws, "book_config.json")
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(cfg, f)
        body = "This line is ordinary body text in the synthetic interior."
        pages = [(None, ["SELFTEST BOOK"]), (None, []),
                 (None, ["C O N T E N T S", "Part I: The First Part . . . 1",
                         "The Opening Chapter . . . 3", "Another Chapter Title . . . 5"]),
                 (None, []),
                 ("1", ["Part I: The First Part", body]), ("2", [body, body]),
                 ("3", ["The Opening Chapter", body]),
                 ("4", [body] * 8 + ["See Another Chapter Title, later in the book."]),
                 ("5", ["Another Chapter Title", body]),
                 ("6", ["A B O U T  T H E  A U T H O R", "Test Author writes selftests."]),
                 (None, [])]
        doc = fitz.open()
        for folio, lines in pages:
            pg = doc.new_page(width=PAGE_W_PTS, height=PAGE_H_PTS)
            if folio:                       # Word's footer comes first in the stream
                pg.insert_text((210, 620), folio, fontsize=9)
            for k, ln in enumerate(lines):
                pg.insert_text((54, 90 + 18 * k), ln, fontsize=11)
        doc.save(os.path.join(pb_dir, f"{slug}_KDP_PAPERBACK.pdf"))
        doc.close()
        W, H, b, s0, s1 = 3803, 2775, 37, 1837, 1964      # composite_cover's grid
        wrap = Image.new("RGB", (W, H), (255, 0, 255))     # bleed: magenta
        wrap.paste((200, 40, 40), (b, b, s0, H - b))       # back face: red
        wrap.paste((30, 30, 30), (s0, 0, s1, H))           # spine: dark
        wrap.paste((40, 160, 60), (s1, b, W - b, H - b))   # front face: green
        wrap.save(os.path.join(pb_dir, "cover_wrap.jpg"), format="PNG")   # lossless
        Image.new("RGB", (1600, 2560), (40, 60, 200)).save(
            os.path.join(k_dir, f"{slug}_KINDLE_cover.jpg"), quality=95)
        with contextlib.redirect_stdout(io.StringIO()), \
                contextlib.redirect_stderr(io.StringIO()):
            m.build(cfg_path, ws)
        out = fitz.open(os.path.join(ws, "outputs", "digital", f"{slug}_DIGITAL.pdf"))
        try:
            def t_covers():
                notes = []
                for idx, rgb in ((0, (40, 160, 60)), (1, (200, 40, 40))):
                    pg = out[idx]
                    ims = pg.get_images(full=True)
                    if abs(pg.rect.width - PAGE_W_PTS) > 0.01 or abs(pg.rect.height - PAGE_H_PTS) > 0.01 \
                            or len(ims) != 1:
                        return False, f"page {idx + 1}: {pg.rect} with {len(ims)} image(s)"
                    bb = pg.get_image_bbox(ims[0])
                    im = Image.open(io.BytesIO(out.extract_image(ims[0][0])["image"])).convert("RGB")
                    edges = [im.crop(bx) for bx in ((0, 0, 1, im.height), (im.width - 1, 0, im.width, im.height),
                                                    (0, 0, im.width, 1), (0, im.height - 1, im.width, im.height))]
                    worst = max(max(abs(a - c) for a, c in zip(px, rgb))
                                for e in edges for px in e.getdata())
                    ok = im.size == (1800, 2700) and abs(bb.width - PAGE_W_PTS) < 0.5 \
                        and abs(bb.height - PAGE_H_PTS) < 0.5 and worst <= 40
                    notes.append(f"p{idx + 1} {im.size[0]}x{im.size[1]}px edge-deviation {worst}")
                    if not ok:
                        return False, "; ".join(notes)
                return True, "; ".join(notes)
            check("covers_from_wrap_exact", t_covers)
            md = out.metadata or {}
            check("metadata_title_author",
                  lambda: (md.get("title") == "Selftest Book: A Reader’s Subtitle"
                           and md.get("author") == "Test Author",
                           f"title={md.get('title')!r} author={md.get('author')!r}"))
            want = [[1, "Part I: The First Part", 5], [1, "The Opening Chapter", 7],
                    [1, "Another Chapter Title", 9], [1, "About the Author", 10]]
            got = out.get_toc()
            check("outline_units", lambda: (got == want, f"toc {got}"))
        finally:
            out.close()
    fails = [r for r in results if not r[1]]
    for name, ok, detail in results:
        print(f"[{'PASS' if ok else 'FAIL'}] {name}: {detail}")
    print(f"build_digital_pdf selftest: {len(results) - len(fails)}/{len(results)} PASS")
    return 1 if fails else 0


def main() -> int:
    args = sys.argv[1:]
    if "--selftest" in args:
        return _selftest()
    config_path = None
    workspace_arg = None
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--config":
            config_path = args[i + 1]; i += 2; continue
        if a == "--kit-env":
            # Accepted for interface symmetry; digital build needs no kit_env paths.
            i += 2; continue
        if a == "--workspace":
            workspace_arg = args[i + 1]; i += 2; continue
        i += 1

    if not config_path:
        print("Usage: python build_digital_pdf.py --config book_config.json "
              "[--workspace <dir>]", file=sys.stderr)
        return 2

    build(config_path, workspace_arg)
    return 0


if __name__ == "__main__":
    sys.exit(main())

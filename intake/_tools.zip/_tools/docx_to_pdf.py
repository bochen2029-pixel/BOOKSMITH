"""
docx_to_pdf.py — The only trustworthy docx->PDF path (Microsoft Word COM).

BOOKSMITH toolchain component. Renders a DOCX to a page-faithful PDF via Word
COM automation (the primary, page-faithful path). Pandoc / cloud converters
break fonts, TOC hyperlinks, and pagination; LibreOffice is close but not
guaranteed page-faithful, so it is a TIER-2 FALLBACK used only when Word is
absent (Mac / Linux / no-Word), never in preference to Word. Also returns the
authoritative page + word count that downstream spine math and parity checks use.

PORTED FROM:
  - C:\\BOOK\\_tools\\docx_to_pdf.py            (the base Dispatch/SaveAs shape)
  - C:\\Inside_The_Region\\update_hardcover_and_count.py  (double-Repaginate + stats)

CRITICAL FIX BAKED IN (LESSONS_LEDGER §3.7, transcript tx_book_aibook):
  A TOC .Update() DELETES AND RECREATES field handles. A live
  `for field in doc.Fields: field.Update()` then dereferences stale/deleted
  handles -> COM error -> exit 1. The fix is to iterate fields BY INDEX inside
  a try/except, in the exact order:
      update TOC(s) -> Repaginate() -> fields-by-index -> update TOC(s) -> Repaginate()
  A live iterator is NEVER used. See update_fields_by_index() below.

Word format constants:
  wdFormatPDF = 17 ; wdStatisticPages = 2 ; wdStatisticWords = 0.

Usage:
  python docx_to_pdf.py <input.docx> <output.pdf> [--pad-multiple N]
                        [--allow-libreoffice-fallback] [--save-docx <word_edition.docx>]

On success prints a single JSON object on stdout:
  {"docx": "...", "pdf": "...", "pages": <int>, "words": <int>}

--save-docx (opt-in, Word COM only; 2026-09-24, across_borders final QC): also
saves the document Word just updated as a .docx, the "Word edition". The
generator's DOCX carries an EMPTY Contents field plus <w:updateFields/>, so
opened as-is it prompts "update the fields?" and, answered No, shows a Contents
page with only its heading. The saved copy has the Contents filled with page
numbers, and w:updateFields (and any w:dirty field flag) is then removed, so it
opens clean. The result is verified (a TOC field must hold entries, each with a
page number; no updateFields may remain; every picture must keep its pixel
size) and reported under "word_edition"; a failed check exits 1. The target
must be in a different folder from the input: verify_build takes the newest
.docx in a format folder, and a Word edition there would stand in for the print
DOCX. Without the flag nothing changes.
"""
import sys
import os
import json
import shutil
import time

try:
    import win32com.client
    _WIN32COM_IMPORT_ERROR = None
except ImportError as _exc:  # non-Windows, or pywin32 not installed
    win32com = None
    _WIN32COM_IMPORT_ERROR = _exc


def _require_word():
    """Fail with an actionable JSON error instead of an import traceback."""
    if win32com is None:
        print(json.dumps({
            "error": "word_com_unavailable",
            "detail": "Print docx->PDF needs Microsoft Word COM (pywin32, page-faithful) "
                      "OR LibreOffice ('soffice' on PATH, Tier-2 best-effort). Neither was "
                      "found. Produce EPUB / Kindle DOCX here (Tier 2), install LibreOffice "
                      "for print PDFs off Windows, or render the DOCX externally.",
            "import_error": str(_WIN32COM_IMPORT_ERROR),
        }))
        raise SystemExit(3)

# Word enum constants (avoid importing the makepy typelib — plain ints are stable).
WD_FORMAT_PDF = 17       # wdFormatPDF
WD_FORMAT_DOCX = 16      # wdFormatDocumentDefault (.docx)
WD_STAT_PAGES = 2        # wdStatisticPages
WD_STAT_WORDS = 0        # wdStatisticWords
WD_ALERTS_NONE = 0       # wdAlertsNone


def _make_word():
    """Robust Word.Application factory.

    DispatchEx FIRST (QC 2026-07-23): Dispatch/EnsureDispatch ATTACH to any
    already-running Word — including a zombie leaked by a crashed prior run —
    whose busy RPC then rejects every call until the retry budget dies
    (observed live: RPC_E_CALL_REJECTED at Repaginate on the 344pp book). A
    fresh out-of-process instance is immune to zombies. EnsureDispatch (early
    binding, typelib loaded) second; plain Dispatch last resort."""
    w = win32com.client
    for factory in (
        lambda: w.DispatchEx("Word.Application"),
        lambda: w.gencache.EnsureDispatch("Word.Application"),
        lambda: w.Dispatch("Word.Application"),
    ):
        try:
            return factory()
        except Exception:
            continue
    return w.Dispatch("Word.Application")


def update_all_tocs(doc):
    """Update every TablesOfContents field. This is what deletes/recreates the
    underlying field handles, which is why the subsequent field loop must go by
    index, not by a live iterator."""
    # Resilient: a print interior with no TOC — or late-bound COM dispatch that
    # cannot resolve the TablesOfContents collection — must not kill the render.
    try:
        toc_count = doc.TablesOfContents.Count
    except Exception:
        return 0
    for i in range(1, toc_count + 1):
        try:
            doc.TablesOfContents(i).Update()
        except Exception:
            pass
    return toc_count


def update_fields_by_index(doc):
    """Update fields BY INDEX, each guarded in try/except.

    A live `for field in doc.Fields: field.Update()` can dereference handles
    that a prior TOC update deleted -> COM error -> exit 1 (LESSONS_LEDGER
    §3.7 / tx_book_aibook). Iterating by index and swallowing per-field errors
    is the crash fix."""
    # Snapshot the count once; do not trust a live iterator across updates.
    try:
        field_count = doc.Fields.Count
    except Exception:
        return
    for i in range(1, field_count + 1):
        try:
            doc.Fields(i).Update()
        except Exception:
            # Update fields by index (live iteration can hit deleted handles).
            pass


def _soffice_bin():
    """Locate a LibreOffice/OpenOffice 'soffice' binary for the Tier-2 fallback."""
    for name in ("soffice", "libreoffice", "soffice.bin"):
        p = shutil.which(name)
        if p:
            return p
    for c in (r"C:\Program Files\LibreOffice\program\soffice.exe",
              r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
              "/Applications/LibreOffice.app/Contents/MacOS/soffice",
              "/usr/bin/soffice", "/usr/bin/libreoffice", "/snap/bin/libreoffice"):
        if os.path.exists(c):
            return c
    return None


def _docx_to_pdf_libreoffice(soffice: str, docx_path: str, pdf_path: str):
    """Tier-2 (no Word): render via 'soffice --headless --convert-to pdf'. Best-effort,
    NOT guaranteed page-faithful (fonts/TOC/pagination can drift vs Word), so it runs
    only when Word COM is unavailable. Page + word counts are read back from the
    rendered PDF with PyMuPDF. An isolated user-profile dir avoids the soffice lock."""
    import subprocess
    import tempfile
    import glob
    outdir = tempfile.mkdtemp(prefix="bs_lo_")
    try:
        profile = "-env:UserInstallation=file:///" + outdir.replace("\\", "/") + "/profile"
        cmd = [soffice, "--headless", "--norestore", profile,
               "--convert-to", "pdf:writer_pdf_Export", "--outdir", outdir, docx_path]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        produced = glob.glob(os.path.join(outdir, "*.pdf"))
        if not produced:
            raise RuntimeError(f"LibreOffice produced no PDF (rc={r.returncode}): "
                               f"{(r.stdout + r.stderr).strip()[-300:]}")
        shutil.move(produced[0], pdf_path)
    finally:
        shutil.rmtree(outdir, ignore_errors=True)
    import fitz
    with fitz.open(pdf_path) as d:
        pages = d.page_count
        words = sum(len(pg.get_text("text").split()) for pg in d)
    return pages, words


def docx_to_pdf(docx_path: str, pdf_path: str, allow_lo_after_word_error: bool = False,
                save_docx: str | None = None):
    """Convert DOCX -> PDF. Primary: Word COM (page-faithful). Fallback: LibreOffice
    (Tier-2, best-effort) only when Word is ABSENT — a Word ERROR on a Tier-1 box
    re-raises rather than silently substituting the non-page-faithful renderer
    (pagination drift would feed spine math + recto parity unmarked). Pass
    allow_lo_after_word_error=True (--allow-libreoffice-fallback) to opt in.
    save_docx (opt-in): also save Word's field-updated document there as the
    Word edition (see the module docstring); Word COM only, never beside the
    input. Returns (pages, words, renderer)."""
    docx_path = os.path.abspath(docx_path)
    pdf_path = os.path.abspath(pdf_path)

    if not os.path.exists(docx_path):
        raise FileNotFoundError(f"Input DOCX not found: {docx_path}")

    out_dir = os.path.dirname(pdf_path)
    if out_dir and not os.path.isdir(out_dir):
        os.makedirs(out_dir, exist_ok=True)

    if save_docx:
        save_docx = os.path.abspath(save_docx)
        if os.path.normcase(os.path.dirname(save_docx)) == os.path.normcase(os.path.dirname(docx_path)):
            raise ValueError(
                f"--save-docx must write to a different folder than the input DOCX "
                f"({os.path.dirname(docx_path)}): verify_build reads the newest .docx "
                f"in a format folder, so a Word edition there would replace the print "
                f"DOCX in its checks.")
        if win32com is None:
            raise RuntimeError("--save-docx needs Microsoft Word COM (the Word edition is "
                               "Word's own field-updated save); it is not available here.")
        os.makedirs(os.path.dirname(save_docx), exist_ok=True)

    if win32com is not None:
        try:
            pages, words = _docx_to_pdf_word(docx_path, pdf_path, save_docx)
            return pages, words, "word"
        except Exception:
            if allow_lo_after_word_error and not save_docx:
                soffice = _soffice_bin()
                if soffice:
                    pages, words = _docx_to_pdf_libreoffice(soffice, docx_path, pdf_path)
                    return pages, words, "libreoffice_after_word_error"
            raise
    soffice = _soffice_bin()
    if soffice:
        pages, words = _docx_to_pdf_libreoffice(soffice, docx_path, pdf_path)
        return pages, words, "libreoffice"
    _require_word()  # emits the structured error + SystemExit(3)


# COM busy-noise armor (ported from check_part_pages.py, QC 2026-07-23): Word
# rejects incoming automation calls while paginating a large document
# (RPC_E_CALL_REJECTED / RPC_E_SERVERCALL_RETRYLATER) — and an orphaned or busy
# Word instance produces the same codes. Retrying is the standard cure; without
# it a 300pp+ render crashes at Repaginate() (observed live on the 344pp book).
_COM_BUSY = (-2147418111, -2147417846)


def _com_call(fn, tries=40, delay=3.0):
    last = None
    for _ in range(tries):
        try:
            return fn()
        except Exception as exc:
            code = exc.args[0] if getattr(exc, "args", None) else None
            if code not in _COM_BUSY:
                raise
            last = exc
            time.sleep(delay)
    raise last


def _docx_to_pdf_word(docx_path: str, pdf_path: str, save_docx: str | None = None):
    """The page-faithful Word COM path. Returns (pages, words). Paths are already
    absolute and the output dir exists (the docx_to_pdf dispatcher guarantees that).
    save_docx: after the PDF, also save this same field-updated document as .docx."""
    word = _make_word()
    word.Visible = False
    try:
        word.DisplayAlerts = WD_ALERTS_NONE
    except Exception:
        pass

    doc = None
    try:
        doc = _com_call(lambda: word.Documents.Open(docx_path))

        # --- The load-bearing order (LESSONS_LEDGER §3.7) ---
        # 1. update TOC(s)
        _com_call(lambda: update_all_tocs(doc))
        # 2. Repaginate (settle page numbers before touching fields)
        _com_call(doc.Repaginate)
        # 3. fields-by-index (guarded) — TOC update just invalidated handles
        _com_call(lambda: update_fields_by_index(doc))
        # 4. update TOC(s) again — field updates may have shifted page numbers
        _com_call(lambda: update_all_tocs(doc))
        # 5. Repaginate again — final settle for TOC-bearing docs
        _com_call(doc.Repaginate)

        pages = int(_com_call(lambda: doc.ComputeStatistics(WD_STAT_PAGES)))
        words = int(_com_call(lambda: doc.ComputeStatistics(WD_STAT_WORDS)))

        _com_call(lambda: doc.SaveAs(pdf_path, FileFormat=WD_FORMAT_PDF))
        if save_docx:
            # The Word edition: the document exactly as Word just laid it out,
            # every field current (the Contents filled with its page numbers).
            # After the PDF, so the PDF path is the same with or without it.
            if os.path.exists(save_docx):
                os.remove(save_docx)
            _com_call(lambda: doc.SaveAs2(save_docx, FileFormat=WD_FORMAT_DOCX))
        doc.Close(SaveChanges=False)
        doc = None
        return pages, words
    finally:
        if doc is not None:
            try:
                doc.Close(SaveChanges=False)
            except Exception:
                pass
        # Retried Quit so a busy Word cannot leak a zombie (QC 2026-07-23).
        try:
            _com_call(word.Quit, tries=5, delay=1.0)
        except Exception:
            print("WARN: Word.Quit failed; a WINWORD.EXE instance may linger",
                  file=sys.stderr)


def _docx_image_sizes(path: str):
    """[(part, (w, h) | None)] for every picture the document body references,
    in body order (a:blip r:embed -> document.xml.rels -> media part)."""
    import io
    import posixpath
    import re
    import zipfile
    from PIL import Image
    out = []
    with zipfile.ZipFile(path) as z:
        rels = z.read("word/_rels/document.xml.rels").decode("utf-8")
        body = z.read("word/document.xml").decode("utf-8")
        targets = {}
        for tag in re.findall(r"<Relationship\b[^>]*>", rels):
            rid = re.search(r'\bId="([^"]+)"', tag)
            tgt = re.search(r'\bTarget="([^"]+)"', tag)
            if rid and tgt:
                targets[rid.group(1)] = tgt.group(1)
        for rid in re.findall(r'<a:blip\b[^>]*?r:embed="([^"]+)"', body):
            tgt = targets.get(rid)
            if not tgt:
                continue
            part = tgt.lstrip("/") if tgt.startswith("/") else posixpath.normpath("word/" + tgt)
            try:
                with Image.open(io.BytesIO(z.read(part))) as im:
                    out.append((part, im.size))
            except Exception:
                out.append((part, None))
    return out


def finalize_word_edition(saved: str, source: str) -> dict:
    """Make the --save-docx Word edition open clean, then verify it.

    Word has just made every field current, so <w:updateFields> (the "update the
    fields?" prompt on open) and any w:dirty field flag are removed, and
    cp:lastModifiedBy takes dc:creator instead of the machine's Word user name;
    every other zip entry is copied byte for byte. Verified from the file on disk: the zip
    tests clean; when the body has a TOC field, its entries exist and each ends
    in a page number; no updateFields remains; every picture keeps the pixel
    size it has in the source DOCX (Word must not compress on save)."""
    import re
    import zipfile
    with zipfile.ZipFile(saved) as z:
        infos = z.infolist()
        data = {i.filename: z.read(i.filename) for i in infos}
    settings = data.get("word/settings.xml", b"").decode("utf-8")
    body = data["word/document.xml"].decode("utf-8")
    settings2, n_uf = re.subn(r"<w:updateFields\b[^>]*?/>|<w:updateFields\b[^>]*>.*?</w:updateFields>",
                              "", settings, flags=re.S)
    body2, n_dirty = re.subn(r'\s+w:dirty="(?:true|1|on)"', "", body)
    # Word stamps cp:lastModifiedBy with the machine's Word user name (here
    # "user"); the edition is the author's document, so it takes dc:creator.
    core = data.get("docProps/core.xml", b"").decode("utf-8")
    creator = re.search(r"<dc:creator>([^<]+)</dc:creator>", core)
    core2 = core
    if creator and creator.group(1).strip():
        core2 = re.sub(r"<cp:lastModifiedBy>[^<]*</cp:lastModifiedBy>",
                       lambda _m: f"<cp:lastModifiedBy>{creator.group(1)}</cp:lastModifiedBy>", core)
    if n_uf or n_dirty or core2 != core:
        data["word/settings.xml"] = settings2.encode("utf-8")
        data["word/document.xml"] = body2.encode("utf-8")
        if core2 != core:
            data["docProps/core.xml"] = core2.encode("utf-8")
        tmp = saved + ".tmp"
        with zipfile.ZipFile(tmp, "w") as zo:
            for i in infos:
                zo.writestr(i, data[i.filename])
        os.replace(tmp, saved)

    with zipfile.ZipFile(saved) as z:
        bad_member = z.testzip()
        body = z.read("word/document.xml").decode("utf-8")
        settings = z.read("word/settings.xml").decode("utf-8")
        core = z.read("docProps/core.xml").decode("utf-8") if "docProps/core.xml" in z.namelist() else ""
    has_toc = re.search(r'<w:instrText\b[^>]*>\s*TOC\b|w:instr="\s*TOC\b', body) is not None
    entries = []
    for para in re.findall(r"<w:p\b.*?</w:p>", body, flags=re.S):
        if re.search(r'<w:pStyle w:val="TOC\d"', para):
            entries.append("".join(re.findall(r"<w:t(?:\s[^>]*)?>([^<]*)</w:t>", para)).strip())
    with_page = [e for e in entries if re.search(r"(\d+|[ivxlcdm]+)$", e, flags=re.I)]
    src_sizes = [s for _, s in _docx_image_sizes(source)]
    out_sizes = [s for _, s in _docx_image_sizes(saved)]
    left = "<w:updateFields" in settings
    toc_ok = (not has_toc) or (bool(entries) and len(with_page) == len(entries))
    last_by = re.search(r"<cp:lastModifiedBy>([^<]*)</cp:lastModifiedBy>", core)
    return {
        "path": saved,
        "toc_field": has_toc,
        "toc_entries": len(entries),
        "toc_entries_with_page": len(with_page),
        "toc_sample": entries[:3],
        "update_fields_removed": n_uf,
        "dirty_flags_removed": n_dirty,
        "update_fields_left": left,
        "images": len(out_sizes),
        "images_preserved": src_sizes == out_sizes,
        "zip_ok": bad_member is None,
        "last_modified_by": last_by.group(1) if last_by else None,
        "ok": toc_ok and not left and src_sizes == out_sizes and bad_member is None,
    }


def _selftest() -> int:
    """--selftest (no Word needed): finalize_word_edition on synthetic DOCX files.
    A good Word edition (TOC entries with page numbers, <w:updateFields/>,
    w:dirty, a picture) must come out ok with the prompt flags gone and every
    other zip entry byte-identical; an EMPTY Contents (the generator's own DOCX,
    i.e. what the pre-fix pipeline shipped as the Word edition) and a picture
    Word downsampled on save must each fail."""
    import io
    import tempfile
    import zipfile
    from PIL import Image

    def png(w, h):
        b = io.BytesIO()
        Image.new("RGB", (w, h), (90, 120, 60)).save(b, format="PNG")
        return b.getvalue()

    W_NS = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'

    def toc_para(title, page):
        return (f'<w:p><w:pPr><w:pStyle w:val="TOC1"/></w:pPr><w:r><w:t>{title}</w:t></w:r>'
                f'<w:r><w:tab/></w:r><w:r><w:t>{page}</w:t></w:r></w:p>')

    def make(path, entries, img):
        toc = ('<w:p><w:r><w:fldChar w:fldCharType="begin" w:dirty="true"/></w:r>'
               '<w:r><w:instrText xml:space="preserve"> TOC \\o "1-1" \\h </w:instrText></w:r>'
               '<w:r><w:fldChar w:fldCharType="separate"/></w:r></w:p>'
               + "".join(toc_para(t, p) for t, p in entries)
               + '<w:p><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p>')
        doc = (f'<w:document {W_NS} xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
               'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><w:body>'
               f'{toc}<w:p><w:r><w:drawing><a:blip r:embed="rId9"/></w:drawing></w:r></w:p>'
               '</w:body></w:document>')
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("[Content_Types].xml", "<Types/>")
            z.writestr("word/document.xml", doc)
            z.writestr("word/settings.xml", f'<w:settings {W_NS}><w:updateFields w:val="true"/>'
                                            '<w:mirrorMargins/></w:settings>')
            z.writestr("word/_rels/document.xml.rels",
                       '<Relationships><Relationship Id="rId9" Type="image" '
                       'Target="media/image1.png"/></Relationships>')
            z.writestr("word/media/image1.png", img)
            z.writestr("docProps/core.xml", "<cp:coreProperties><dc:creator>Test Author</dc:creator>"
                                            "<cp:lastModifiedBy>user</cp:lastModifiedBy>"
                                            "</cp:coreProperties>")

    results = []
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, "print.docx")
        make(src, [], png(1200, 800))
        good = os.path.join(td, "good.docx")
        make(good, [("A Note on Names", 1), ("Part I: The Second Calling", 5)], png(1200, 800))
        with zipfile.ZipFile(good) as z:
            before = {n: z.read(n) for n in z.namelist()}
        r = finalize_word_edition(good, src)
        with zipfile.ZipFile(good) as z:
            after = {n: z.read(n) for n in z.namelist()}
        untouched = all(before[n] == after[n] for n in before
                        if n not in ("word/settings.xml", "word/document.xml", "docProps/core.xml"))
        ok = (r["ok"] and r["toc_entries"] == 2 and r["toc_entries_with_page"] == 2
              and r["update_fields_removed"] == 1 and r["dirty_flags_removed"] == 1
              and not r["update_fields_left"] and b"<w:mirrorMargins/>" in after["word/settings.xml"]
              and r["last_modified_by"] == "Test Author" and untouched)
        results.append(("good_edition_ok", ok, r))
        empty = os.path.join(td, "empty.docx")
        make(empty, [], png(1200, 800))
        r = finalize_word_edition(empty, src)
        results.append(("empty_contents_fails", not r["ok"] and r["toc_entries"] == 0, r))
        small = os.path.join(td, "small.docx")
        make(small, [("A Note on Names", 1)], png(600, 400))
        r = finalize_word_edition(small, src)
        results.append(("downsampled_picture_fails", not r["ok"] and not r["images_preserved"], r))
    fails = [x for x in results if not x[1]]
    for name, ok, r in results:
        print(f"[{'PASS' if ok else 'FAIL'}] {name}: ok={r['ok']} toc={r['toc_entries']}/"
              f"{r['toc_entries_with_page']} updateFields_left={r['update_fields_left']} "
              f"images_preserved={r['images_preserved']}")
    print(f"docx_to_pdf selftest: {len(results) - len(fails)}/{len(results)} PASS")
    return 1 if fails else 0


def pad_pdf_to_multiple(pdf_path, multiple):
    """Append blank pages (matching page 1 dimensions) until the page count is a
    multiple of `multiple`. Mixam requires the interior page count divisible by 4
    (KDP only needs 2); the JS generator defers this to a fitz post-step. Returns
    the final page count."""
    import fitz
    if not multiple or multiple <= 1:
        with fitz.open(pdf_path) as d:
            return d.page_count
    tmp = pdf_path + ".pad.tmp"
    with fitz.open(pdf_path) as doc:
        n = doc.page_count
        if n % multiple == 0:
            return n
        target = ((n // multiple) + 1) * multiple
        w, h = doc[0].rect.width, doc[0].rect.height
        for _ in range(target - n):
            doc.new_page(width=w, height=h)   # blank page appended at the end
        doc.save(tmp, deflate=True)
    os.replace(tmp, pdf_path)
    return target


def main() -> int:
    args = sys.argv[1:]
    if "--selftest" in args:
        return _selftest()
    pad_multiple = 0
    allow_lo = False
    save_docx = None
    positional = []
    i = 0
    while i < len(args):
        if args[i] == "--pad-multiple":
            pad_multiple = int(args[i + 1]); i += 2; continue
        if args[i] == "--allow-libreoffice-fallback":
            allow_lo = True; i += 1; continue
        if args[i] == "--save-docx":
            if i + 1 >= len(args) or args[i + 1].startswith("--"):
                print("--save-docx needs a path: the Word edition .docx to write",
                      file=sys.stderr)
                return 2
            save_docx = args[i + 1]; i += 2; continue
        positional.append(args[i]); i += 1
    if len(positional) != 2:
        print("Usage: python docx_to_pdf.py <input.docx> <output.pdf> "
              "[--pad-multiple N] [--allow-libreoffice-fallback] "
              "[--save-docx <word_edition.docx>]",
              file=sys.stderr)
        return 2
    docx_path, pdf_path = positional
    pages, words, renderer = docx_to_pdf(docx_path, pdf_path,
                                          allow_lo_after_word_error=allow_lo,
                                          save_docx=save_docx)
    final_pages = pages
    if pad_multiple:
        final_pages = pad_pdf_to_multiple(os.path.abspath(pdf_path), pad_multiple)
    out = {
        "docx": os.path.abspath(docx_path),
        "pdf": os.path.abspath(pdf_path),
        "pages": final_pages,
        "words": words,
        "renderer": renderer,
    }
    if pad_multiple:
        out["pages_before_pad"] = pages
    if save_docx:
        out["word_edition"] = finalize_word_edition(os.path.abspath(save_docx),
                                                    os.path.abspath(docx_path))
    # Renderer sidecar: lets verify_build mechanically assert a print PDF came
    # from the page-faithful engine long after this process is gone.
    try:
        with open(os.path.abspath(pdf_path) + ".render.json", "w", encoding="utf-8") as f:
            json.dump(out, f)
    except OSError:
        pass
    print(json.dumps(out))
    if save_docx and not out["word_edition"]["ok"]:
        print("ERROR: the Word edition failed its checks (see word_edition)", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

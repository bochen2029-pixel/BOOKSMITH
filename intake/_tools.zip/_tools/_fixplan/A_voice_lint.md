# FIX PLAN — cluster A_voice_lint

## Files you OWN (edit ONLY these; ignore fix-portions that touch other files — another agent owns them):
- _tools/lint_manuscript.py
- docs/author_voice/

## Tasks (11)

### [A_voice_lint.1] (AUDIT/high) Lint corruption checks false-positive on markdown tables and fenced code blocks, blocking valid builds
- loc: _tools/lint_manuscript.py:90 (iter_paragraphs), 110-198 (lint_corruption), 74-87 (is_structural_line)
- FIX: In _tools/lint_manuscript.py fix lint_corruption's paragraph loop to skip tables and fenced code, mirroring the em-dash carve-out at line 228. (1) In is_structural_line (line 74), after the existing checks add: `if re.match(r"^\|", stripped): return True` so a table row never demands terminal punctuation. (2) The paragraph checks at lines 161-183 (UNBALANCED_EMPHASIS, PARAGRAPH_NOT_TERMINATED, EMBEDDED_UNDERSCORE is line-level at 132) still fire on multi-line table blocks because iter_paragraphs treats the whole table as one paragraph whose first_line is a table row: after computing `first_line` at line 151, add a guard `if all(l.lstrip().startswith('|') for l in stripped_para.split('\n') if l.strip()): prev_para_lastline=None; continue` right after the is_structural_line check at line 152-154. (3) Fenced code: iter_paragraphs at line 90 has NO code-fence state, so a ```python block becomes a prose paragraph. Add a module-level pre-pass or track fence state: in lint_corruption, before the paragraph loop, build a set of line numbers inside fenced blocks (toggle on lines whose strip().startswith('```')) and in the paragraph loop skip any paragraph whose start_line falls inside a fenced region; also strip the EMBEDDED_UNDERSCORE line-level check (lines 132-134) for lines inside fenced code (the existing in_code toggle at 120-124 already covers MULTIPLE_SPACES/EMBEDDED_UNDERSCORE line-level, but the PARAGRAPH_NOT_TERMINATED paragraph check does not honor it). Expected result: a manuscript containing a normal markdown table or a fenced code block yields zero corruption findings.

### [A_voice_lint.2] (AUDIT/high) is_documentation_file excludes an entire manuscript when the workspace slug is a meta-dir marker word (silent falsely-CLEAN lint)
- loc: _tools/lint_manuscript.py:350-371 (is_documentation_file / META_DIR_MARKERS)
- FIX: In _tools/lint_manuscript.py is_documentation_file (lines 357-371), anchor the META_DIR_MARKERS match to path segments RELATIVE TO the workspace root so the slug segment (the dir directly under book_workspace/) is never treated as a meta-dir. Concrete change: pass the resolved workspace root into is_documentation_file (or compute the relative path there), and when iterating parts (line 365) skip the segment immediately following a 'book_workspace' component before applying the META_DIR_MARKERS test. Simplest robust form: `parts_l = [p.lower() for p in path.parts]; skip_idx = parts_l.index('book_workspace')+1 if 'book_workspace' in parts_l else -1` then in the loop `for i,part in enumerate(parts_l): if i==skip_idx: continue` before the `if part in META_DIR_MARKERS` test. Expected result: book_workspace/state/manuscript/current/ch_01_current.md is IN scope and linted; book_workspace/<slug>/reviews/... stays excluded.

### [A_voice_lint.3] (AUDIT/high) lint_manuscript.py exits 0 on zero files, voiding the em-dash/voice gate on a misresolved or empty root
- loc: C:\BOOKSMITH\_tools\lint_manuscript.py:517-525 (collect_manuscript_files returns [] path via lines 400-417 / workspace_root 383-397)
- FIX: In lint_manuscript.py, the `if not files:` block (lines 517-525) currently `return 0` when there are no config_findings. Change the no-files behavior so an EMPTY manuscript scan is not a silent pass: replace `return 0` at line 525 with a distinct 'no manuscript files found' outcome that returns exit code 2 (usage/environment error, matching the file's documented '2 usage' convention) and prints a WARNING that the em-dash + voice gate did NOT run because no files were collected under the resolved root. Keep the config_findings branch (lines 520-524) returning 1 as-is. Expected result: verify_build.check_lint (which treats returncode==0 as pass) can no longer report the voice gate green when the manuscript directory was misresolved or empty; a real book with files still exits 0.

### [A_voice_lint.4] (AUDIT/high) Slash-wrapped regex blacklist syntax does not compile as regex; H2/H3 meta-opener/summary-box atoms fail open when pasted verbatim
- loc: _tools/lint_manuscript.py:250-275 (compile_blacklist) vs docs/author_voice/_voiceprofile_soul.md:98,187,205-211
- FIX: In _tools/lint_manuscript.py, function compile_blacklist (lines 250-275), add a branch that recognizes slash-wrapped entries as regex, placed BEFORE the uppercase heuristic. After the `if entry.startswith("cs:"):` block (ends line 268) insert:

        if len(entry) >= 2 and entry.startswith("/") and entry.endswith("/"):
            pat = entry[1:-1]
            try:
                rx.append((re.compile(pat), f"blacklist regex {pat!r}"))
            except re.error as exc:
                print(f"[warn] bad blacklist regex {pat!r}: {exc}", file=sys.stderr)
            continue

Expected result: an entry like `/(?i)key takeaways/` or `/(?i)^in this (chapter|part|section)/` compiles into the rx tier and matches real prose, instead of landing in the ci tier as a literal substring that includes the slashes (which never appears in prose). Verify by re-running the reproduction: compile_blacklist(['/(?i)key takeaways/']) must return a non-empty rx list, and scan_voice on the text 'Key Takeaways from this part.' must produce a BLACKLIST finding.

### [A_voice_lint.5] (AUDIT/medium) Em-dash ceremonial-config scan omits `title`, the most visible leak site (baked into cover art + title page)
- loc: _tools/lint_manuscript.py:501-508 (ceremonial dict in main)
- FIX: In _tools/lint_manuscript.py, in the `ceremonial` dict at lines 501-508, add two entries: `"title": cfg.get("title"),` and `"author": cfg.get("author"),`. They flow through the existing loop (509-515) that already checks each str value for EM_DASHES and appends an EM_DASH config finding. Expected result: a config with `"title": "The Voyage — A Novel"` yields an EM_DASH finding and exit 1.

### [A_voice_lint.6] (AUDIT/medium) voice.greenlist is documented as scrub-protection but is never read by the linter
- loc: _tools/lint_manuscript.py:302-337 (scan_voice) & 475-482 (main) vs _tools/book_config.schema.json:279, docs/author_voice/_voiceprofile_soul.md:187
- FIX: Pick ONE of two directions.
(A) Implement it: in _tools/lint_manuscript.py main() (near lines 476-477 where blacklist/sacred_terms are read) add `greenlist = voice.get("greenlist", []) or []`; extend scan_voice's signature (line 302) to accept greenlist and, before appending any BLACKLIST finding for a line, skip the finding when the matched span falls inside a greenlisted phrase present on that line (i.e., for each greenlist phrase G, if G.lower() in line_lower and the blacklist needle is a substring of G, suppress). Pass greenlist through at the two scan_voice call sites (line 544).
(B) If not implementing now, relabel to stop over-promising: change book_config.schema.json:279 description from 'Sanctioned signature phrases/Bo-isms to preserve.' to 'Sanctioned signature phrases (reviewer reference; NOT yet enforced by lint_manuscript.py).' and change docs/author_voice/_voiceprofile_soul.md:187 'Greenlist = sanctioned language excluded from the scrub.' to note it is a reviewer-facing list, not a lint exclusion.
Expected result: either a greenlisted phrase containing a blacklisted substring stops firing BLACKLIST, or the docs/schema no longer claim protection the code does not provide.

### [A_voice_lint.7] (AUDIT/medium) Ceremonial em-dash scan omits readers_note, which renders into the interior front matter
- loc: _tools/lint_manuscript.py:501-508 (ceremonial dict) vs _tools/generate_book.js:587-616 (readersNoteChildren), _tools/book_config.schema.json:54
- FIX: In _tools/lint_manuscript.py, in the `ceremonial` dict (lines 501-508), add one entry:
            "readers_note": cfg.get("readers_note"),
(place it alongside "dedication" / "about_the_author"). No other change needed — the existing loop at lines 509-515 already scans every string value for em/en-dashes. Expected result: an em-dash placed in config.readers_note produces an [EM_DASH] config finding and exit 1, matching the treatment of config.dedication and config.epigraph.

### [A_voice_lint.8] (AUDIT/low) Em-dash gate misses U+2015 horizontal bar and U+2012 figure dash (and U+2212 minus)
- loc: _tools/lint_manuscript.py:209 (EM_DASHES dict)
- FIX: In _tools/lint_manuscript.py line 209, extend the EM_DASHES dict to `EM_DASHES = {"—": "U+2014 em-dash", "–": "U+2013 en-dash", "―": "U+2015 horizontal bar", "‒": "U+2012 figure dash", "−": "U+2212 minus sign"}`. The compound-adjective hyphen U+002D is a different character and is untouched. This dict is used by both lint_em_dashes (line 230) and the config ceremonial scan (line 511), so both paths gain coverage. Expected result: a line containing U+2015/U+2012/U+2212 yields EM_DASH findings.

### [A_voice_lint.9] (AUDIT/low) em-dash gate exempts every line beginning with '|', not just genuine table (n/a) cells
- loc: C:\BOOKSMITH\_tools\lint_manuscript.py:228-229 (lint_em_dashes pipe carve-out)
- FIX: The carve-out `if line.lstrip().startswith('|'): continue` (line 228) skips the WHOLE line for em/en-dash detection whenever it starts with a pipe. Narrow it so only the (n/a)-style placeholder is exempt, not the entire row: instead of skipping the line, remove em/en-dashes that appear as a standalone cell (regex the cell contents, exempt only a cell whose stripped content is exactly the dash character) and still flag em-dashes embedded in prose text inside table cells. Expected result: a real book that uses tables keeps its sanctioned '(n/a)' dash exemption (ledger §18.1) but an em-dash used as prose punctuation inside a table row no longer escapes the HARD gate.

### [A_voice_lint.10] (AUDIT/low) empirical.md presents F1-F8 (incl. F6 as a HARD gate) as verifier gates, but only F1 is implemented
- loc: docs/author_voice/_voiceprofile_empirical.md:121-136 vs _tools/lint_manuscript.py (and absence anywhere in _tools/)
- FIX: Reconcile the doc to the code rather than claiming gates that do not exist. In docs/author_voice/_voiceprofile_empirical.md, edit the F1-F8 table (lines 127-136): change F6's Type cell from 'HARD gate' to 'reviewer / advisory (not yet in lint)', and change line 136 'Minimum viable gate = F1 + F6 (both HARD).' to 'Minimum viable MECHANICAL gate = F1 (HARD, implemented). F6 (meta-opener/summary/bullet) is enforced via the blacklist regex tier once slash-wrapped regexes compile (see compile_blacklist fix); F2-F8 are reviewer/advisory, not yet coded.' Do the same one-line honesty fix in docs/author_voice/AUTHOR_VOICE_Bo_Chen.md:41 which marks F3 '(HARD)'. Optionally (separate task) implement an F2 semicolon-floor warn and an advisory tricolon flag in lint_manuscript.py. Expected result: no doc claims a HARD build gate that the kit does not run.

### [A_voice_lint.11] (AUDIT/low) Example config omits the dash-character blacklist atoms and the H2/H3 meta-opener/summary regexes the voice docs mandate
- loc: _tools/book_config.example.json:102-111 (voice.blacklist) vs docs/author_voice/_voiceprofile_soul.md:91-93,205-211 and AUTHOR_VOICE_Bo_Chen.md:48-51
- FIX: In _tools/book_config.example.json, expand voice.blacklist (lines 102-111) to lead with the dash atoms and include the meta/summary atoms per AUTHOR_VOICE_Bo_Chen.md:48-51, e.g. add at the front: "—", "–" (the literal em-dash and en-dash characters), plus "Key Takeaways", "It's important to note". Add the H2/H3 regexes in the slash form ONLY AFTER Finding 1 is fixed (otherwise they land in the literal tier and do nothing): "/(?i)^in this (chapter|part|section)/", "/(?i)key takeaways/", "/(?i)\\bin (summary|conclusion)\\b/". Do NOT rely on this to catch em-dashes in prose — that is already covered by the on-by-default no_em_dashes gate; the dash atoms here only add coverage for the config-ceremonial and cs-substring paths. Optionally add "no_em_dashes": true to voice for explicitness (it already defaults true in code). Expected result: the template a stranger copies carries the documented meta-opener/summary coverage instead of zero.

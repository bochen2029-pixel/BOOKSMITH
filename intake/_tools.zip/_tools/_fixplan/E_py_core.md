# FIX PLAN — cluster E_py_core

## Files you OWN (edit ONLY these; ignore fix-portions that touch other files — another agent owns them):
- _tools/assemble_manuscript.py
- _tools/init_contracts.py
- _tools/preset_lookup.py
- _tools/resize_image_safe.py
- _tools/estimate_tokens.py
- _tools/doctor.py
- _tools/make_giftable.py
- _tools/run_batch.py
- _tools/rehydrate.py
- _tools/on_session_start.py
- _tools/on_precompact.py
- _tools/transcript_to_md.py

## Tasks (4)

### [E_py_core.1] (AUDIT/low) assemble_manuscript parity report is tautological; --version overwrites a pinned master; KDP wrap math duplicated verifier-vs-compositor
- loc: _tools/assemble_manuscript.py:198-199,201-213,228; _tools/verify_build.py:376-390 vs _tools/composite_cover.py:719-732
- FIX: Three independent fixes in the named files. (1) Tautological parity: in _tools/assemble_manuscript.py, master_text is a pure `\n\n`.join of pieces (line 198) so word_count(master)==parts_sum ALWAYS (word_count = len(text.split()), whitespace join never merges/splits tokens). Either drop the parts_word_sum field (lines 212-213,222) since it proves nothing, OR make it a genuine independent check by recomputing from re-read disk files rather than the same in-memory pieces. (2) --version overwrite: in _tools/assemble_manuscript.py line 203, the exists-guard `if forced_version is None and os.path.exists(master_path)` is bypassed when --version N is given, so line 208 clobbers an existing vN despite the append-only docstring; add `if forced_version is not None and os.path.exists(master_path): raise SystemExit(f'refusing to overwrite {master_path} without --overwrite')` and add an explicit --overwrite flag to permit it. (3) stderr baseline: move `print(f'TOTAL_WORDS={total_words}')` from stderr to stdout (line 228 -> drop `file=sys.stderr`) to match the docstring's stdout promise and avoid breaking a stdout parser. (4) KDP math duplication: move the KDP paperback/hardcover wrap-dimension math out of verify_build._expected_wrap (lines 376-390) into preset_lookup helpers (e.g. kdp_paperback_wrap_dims / kdp_hardcover_wrap_dims) and call them from BOTH verify_build._expected_wrap and composite_cover.build_kdp_wrap (lines 719-732), mirroring how mixam_paperback/blurb already share preset_lookup. Expected result: parity is a real check or removed, a forced version cannot silently clobber a pinned master, TOTAL_WORDS is on stdout, and KDP wrap dims have a single source of truth.

### [E_py_core.2] (CRITIC/critical) The entire portability/robustness toolchain and the FRAME docs are untracked — a git clone yields a non-booting kit
- loc: git working tree: 33 untracked paths incl. _tools/doctor.py, make_giftable.py, estimate_tokens.py, comfy_client.py, on_session_start.py, on_precompact.py, rehydrate.py, transcript_to_md.py, fetch_weights.py, run_batch.py, kit_env.template.json; docs/SUPERSTRUCTURE.md, docs/BOOKSMITH_WIRING.svg, docs/author_voice/*, docs/COMPACTION_SURVIVAL.md; requirements.txt; templates/digest.template.md; fonts/LICENSES/; fonts/library/
- FIX: This is the single biggest giftability defect and it dwarfs every code-level finding. Stage and commit the robustness layer before shipping: at minimum requirements.txt, docs/SUPERSTRUCTURE.md + BOOKSMITH_WIRING.svg (CLAUDE.md's own top banner declares them load-bearing/'read in full'), docs/author_voice/* (GATE-2 mandates loading them), estimate_tokens.py (boot-sequence mandatory sizer), the compaction-survival tools + docs, kit_env.template.json, fonts/LICENSES + fonts/library, doctor.py, and make_giftable.py. Then re-run any audit against the COMMITTED tree, since the current audit read files a stranger never receives. Decide deliberately what NOT to track (personal memory) and gitignore it explicitly.

### [E_py_core.3] (CRITIC/high) Print pipeline is Windows+Word-only; 7 of 9 advertised formats cannot build cross-platform, and the documented LibreOffice fallback is unimplemented
- loc: _tools/docx_to_pdf.py:36-82 (win32com is the only PDF backend; raises on non-Windows) + requirements.txt:8 (pywin32; sys_platform=='win32'); doctor.py:547-560 check_soffice labels soffice a 'future Tier-2 print path' but no soffice call exists in docx_to_pdf.py
- FIX: Either (a) implement the LibreOffice `soffice --headless --convert-to pdf` fallback in docx_to_pdf.py so Mac/Linux can build print PDFs, gating on shutil.which('soffice') that doctor.py already probes, or (b) correct the portability claim in README/START_HERE/KIT_ARCHITECTURE to state print formats require Windows+Word and only EPUB/Kindle-docx are cross-platform. The kit currently implies full cross-platform giftability that the code does not deliver.

### [E_py_core.4] (CRITIC/medium) doctor.py is an environment preflight, not an end-to-end smoke test; nothing mechanically proves the pipeline still works after a change or on a fresh clone
- loc: _tools/doctor.py (checks python/pip/Word-COM/node/fonts/kit_env only; grep confirms zero calls to assemble_manuscript/generate_book/verify_build); no test_*/conftest anywhere in git ls-files
- FIX: Add a smoke target (e.g. `doctor.py --smoke` or a tiny _tools/smoke_test.py) that runs assemble_manuscript -> generate_kindle -> verify_build --format kindle over book_workspace/testvoyage and asserts exit 0 + word-count parity. This converts the testvoyage proof book into a standing regression fixture and would have caught the audit's lint-false-CLEAN and lint-exit-0-on-empty-root bugs mechanically.

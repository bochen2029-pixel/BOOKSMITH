# FIX PLAN — cluster D_js_gen

## Files you OWN (edit ONLY these; ignore fix-portions that touch other files — another agent owns them):
- _tools/generate_book.js
- _tools/generate_kindle.js
- _tools/inject_mirror_margins.js
- _tools/inject_front_matter_valign.js

## Tasks (5)

### [D_js_gen.1] (AUDIT/medium) interior.page_number_align schema knob is never read; footer hardcodes center (LESSONS_LEDGER wrongly marks it CODED)
- loc: _tools/book_config.schema.json:112 vs _tools/generate_book.js:683-690
- FIX: Pick one (honor or remove). To HONOR: in _tools/generate_book.js pageNumberFooters() (~line 683-690), read const align = (config.interior && config.interior.page_number_align) === 'outer' ? 'outer' : 'center'; and when 'outer', build TWO distinct footers — default (recto) using AlignmentType.RIGHT and even (verso) using AlignmentType.LEFT — instead of CENTER for both. To REMOVE: in _tools/book_config.schema.json line 112, delete 'outer' from the enum so it reads "enum": ["center"], and update docs/LESSONS_LEDGER.md §16.2 (line 654) to drop the false '✅ CODED (interior.page_number_align)' claim. Expected result: the schema no longer advertises an option the code ignores.

### [D_js_gen.2] (AUDIT/medium) Ceremonial em-dash scan omits readers_note, which renders into the interior front matter
- loc: _tools/lint_manuscript.py:501-508 (ceremonial dict) vs _tools/generate_book.js:587-616 (readersNoteChildren), _tools/book_config.schema.json:54
- FIX: In _tools/lint_manuscript.py, in the `ceremonial` dict (lines 501-508), add one entry:
            "readers_note": cfg.get("readers_note"),
(place it alongside "dedication" / "about_the_author"). No other change needed — the existing loop at lines 509-515 already scans every string value for em/en-dashes. Expected result: an em-dash placed in config.readers_note produces an [EM_DASH] config finding and exit 1, matching the treatment of config.dedication and config.epigraph.

### [D_js_gen.3] (AUDIT/low) interior.page_number_align 'outer' value is silently ignored (footer hard-codes CENTER)
- loc: C:\BOOKSMITH\_tools\generate_book.js:683-691 (pageNumberFooters, hard-codes AlignmentType.CENTER); knob defined at C:\BOOKSMITH\_tools\book_config.schema.json:112
- FIX: In C:\BOOKSMITH\_tools\generate_book.js, the pageNumberFooters() factory (lines 683-691) hard-codes alignment: AlignmentType.CENTER and never reads config.interior.page_number_align. A grep of the whole repo confirms NO .js file reads this knob, so setting it to 'outer' is a silent no-op. FIX (make the schema'd knob live): (1) read the knob near the top of the run/main function where `config` is in scope, e.g. `const pnAlign = (config.interior && config.interior.page_number_align) === 'outer' ? 'outer' : 'center';`. (2) In pageNumberFooters(), for pnAlign==='center' keep the single centered paragraph for both default+even; for pnAlign==='outer' build two variants — default (recto) with alignment: AlignmentType.RIGHT and even (verso) with alignment: AlignmentType.LEFT — so the number sits at the outer corner. Keep the same TextRun (PageNumber.CURRENT, font T.FONT, size 18, color 888888). ALTERNATIVELY, if 'outer' is intentionally retired (house style is center-only per LESSONS_LEDGER §16.2), instead DROP the dead option: change schema line 112 enum from ["center","outer"] to ["center"] and update its description, so no config can silently no-op. Prefer implementing the branch (it is the documented behavior). NOTE: only generate_book.js needs this — generate_kindle.js has no PageNumber footer (reflowable ebook), confirmed by grep.

### [D_js_gen.4] (GAP/—) generate_book.js and generate_kindle.js: add a real --help (usage + flags) and make expected-error output quiet (structured message, no raw stack dump).

### [D_js_gen.5] (GAP/—) Verify the three historically-open TODOs are actually DONE (with evidence) and fix if not: (1) Kindle no-TOC wiring honoring kindle_include_toc/interior.include_toc; (2) print TOC de-garble (title-case, not wide letter-spaced caps); (3) spine-font legible-minimum clamp. Also honor the new config-driven ornament/code/math font fields (coordinate with cluster F).

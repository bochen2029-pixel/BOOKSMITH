# FIX PLAN — cluster G_docs_core

## Files you OWN (edit ONLY these; ignore fix-portions that touch other files — another agent owns them):
- CLAUDE.md
- KIT_ARCHITECTURE.md
- README.md
- START_HERE.md
- INSTALL.md

## Tasks (14)

### [G_docs_core.1] (AUDIT/high) Documented format token `digital` does not exist — tools require `digital_pdf`
- loc: CLAUDE.md:112 and KIT_ARCHITECTURE.md:281
- FIX: In CLAUDE.md line 112 and KIT_ARCHITECTURE.md line 281, edit the produce-format grammar: replace the token `digital` (the last item before the closing `>`) with `digital_pdf`, so it reads `...|blurb_hardcover|digital_pdf>`. Do NOT change any output subdir — verify_build.py:85 maps digital_pdf->'digital' (FORMAT_DIR), so the `digital/` output directory name is correct and stays; only the format TOKEN is wrong.

### [G_docs_core.2] (AUDIT/high) §12 build order and tool-invocation index omit producers for epub, mixam_paperback, blurb_paperback, blurb_hardcover
- loc: CLAUDE.md:298 (§12 step 3) and CLAUDE.md:138 (tool-invocation index `produce format` row)
- FIX: 1) CLAUDE.md line 298 (§12 step 3): expand the format list to all 6 print formats generate_book.js supports: `--format <kdp_paperback|kdp_hardcover|mixam_hardcover|mixam_paperback|blurb_paperback|blurb_hardcover>`. 2) Add a new §12 step for the epub producer: `python _tools/build_epub.py --config book_config.json` (a working exporter with a --config CLI; place it near the digital step). 3) CLAUDE.md line 138 tool-invocation index `produce format <p>` row: add `_tools/build_epub.py` (epub producer) and `_tools/build_digital_pdf.py` (digital_pdf producer) to the producer chain so every one of the 9 formats has a named producer.

### [G_docs_core.3] (AUDIT/medium) Kindle cover documented as 1600x2560 but the compositor produces 1600x2400
- loc: docs/format_spec_sheet.md:138 and :169; README.md:13 (and docs/LESSONS_LEDGER.md §7.4 lines 396/399/602/717)
- FIX: This is a doc-vs-code disagreement, NOT a doc-only stale number. On disk, _tools/composite_cover.py:1224-1225 computes W=1600, H=1600*(TRIM_H_IN/TRIM_W_IN)=2400 for a 6x9 trim (comment literally says '6:9 -> 2400'), and VALIDATION.md:21 records the live output as '1600x2400 JPG'. BUT the docs are internally consistent and deliberate that the target is 1600x2560 (1.6:1): docs/LESSONS_LEDGER.md §7.4 (lines 396,399,717) states Amazon's RECOMMENDED Kindle cover ratio is 1.6:1 = 1600x2560, and docs/_lessons_audit/_delta_titanic_projects.md D6 (lines 56-61) prescribes the fix as 'reframe/pad-letterbox in the cover color via scale_to_fit, never crop' plus a ratio assert. So do NOT blindly rewrite the docs to 1600x2400. Resolve as a CODE change to match the documented intent: in build_kindle_front() at _tools/composite_cover.py:1224, set H=2560 (or letterbox/pad the 2:3 art to a 1600x2560 canvas in the cover color so no title space is cropped) so output matches the 1.6:1 spec the ledger mandates. Then update VALIDATION.md:21 to '1600x2560 JPG'. If instead the team decides 2:3 (matching the 6x9 trim) is correct, then edit format_spec_sheet.md:138 ('1600x2560 px (1.6:1)' -> '1600x2400 px (2:3, matches 6x9 trim)'), format_spec_sheet.md:169, README.md:13, and LESSONS_LEDGER §7.4 together. Either way doc and code must be made to agree; a doc-only edit that ignores the ledger's 1.6:1 rule is wrong.

### [G_docs_core.4] (AUDIT/medium) KIT_ARCHITECTURE.md dep list names three Python packages that are never imported and are not in requirements.txt
- loc: KIT_ARCHITECTURE.md:9
- FIX: In KIT_ARCHITECTURE.md:9 change the Python dependency clause from 'Python 3.10+ with `pywin32`, `Pillow`, `PyMuPDF (fitz)`, `PyPDF2`, `python-docx`, `numpy`, `pypdfium2`.' to 'Python 3.10+ with `pywin32`, `Pillow`, `PyMuPDF (fitz)`, `PyPDF2` (plus optional `requests`, `tiktoken`, `jsonschema`).' Drop `python-docx`, `numpy`, `pypdfium2` — none are imported anywhere in _tools/ and none are in requirements.txt. The optional set matches requirements.txt's optional block.

### [G_docs_core.5] (AUDIT/medium) GATE-5 tool-index row falsely claims verify_build.py invokes strip_blank_pages.py and build_digital_pdf.py
- loc: CLAUDE.md:140
- FIX: Edit CLAUDE.md line 140, GATE-5 row: change the parenthetical `(invokes check_part_pages.py, strip_blank_pages.py, build_digital_pdf.py as needed)` to `(invokes check_part_pages.py + lint_manuscript.py as needed)`. Do not add strip_blank_pages.py or build_digital_pdf.py here — they are producers (build_digital_pdf.py imports strip_blank_pages at build_digital_pdf.py:54 and runs as §12 step 9); reference them in the digital-format producer row instead.

### [G_docs_core.6] (AUDIT/medium) §12 step 8 cover-composite profile list covers only 3 of the 7 shipped composite profiles
- loc: CLAUDE.md:303 (§12 step 8)
- FIX: Edit CLAUDE.md line 303, §12 step 8: expand the `--profile <...>` list to all 7 shipped profiles matching composite_cover.py's argparse choices (lines 1242-1244): `--profile <kdp-wrap|kdp-hardcover|mixam-3panel|mixam-paperback-wrap|blurb-wrap|blurb-imagewrap|kindle>`.

### [G_docs_core.7] (AUDIT/low) CLAUDE.md and LESSONS_LEDGER cite pypdfium2 (and numpy) for gutter scans, but no shipped tool imports pypdfium2 and requirements.txt omits both
- loc: C:\BOOKSMITH\CLAUDE.md:267 (§10 two-verifier model); also docs\LESSONS_LEDGER.md:172, 226, 477, 505
- FIX: Two coordinated doc edits. (1) In CLAUDE.md line 267, change 'pypdfium2 dark-column/charbox gutter scans' to 'PyMuPDF (fitz) dark-column/charbox gutter scans' — fitz is the PDF lib actually declared (requirements.txt line 6, PyMuPDF>=1.23) and imported by verify_build.py (lines 247, 420). (2) In docs\LESSONS_LEDGER.md line 505 (§11.1), remove 'numpy, pypdfium2' from the required-package list (leave 'win32com, PIL, PyMuPDF (fitz), PyPDF2'), since neither is in requirements.txt nor imported by any shipped tool. Do NOT add pypdfium2/numpy to requirements.txt — no code uses them, so that would add dead dependencies. The ledger's other pypdfium2 mentions (lines 172/226/477) describe historical manual verification technique and can stay, but the two 'current dependency/verifier' claims above are the drift.

### [G_docs_core.8] (AUDIT/low) Documented pypdfium2 dark-column gutter scan that no tool implements
- loc: KIT_ARCHITECTURE.md:9 (dep) and CLAUDE.md:267 (capability)
- FIX: Remove the phantom mechanical-verifier claim. In CLAUDE.md:267 delete '`pypdfium2` dark-column/charbox gutter scans' from the list of mechanical checks (the surviving list — settings.xml/header inspection, ComputeStatistics(2) page counts, spine-math reconciliation, word-count parity — is real). Removing `pypdfium2` from KIT_ARCHITECTURE.md:9 is already covered by the dep-list fix above. Do not add pypdfium2 to requirements.txt. (If a gutter scan is genuinely wanted later, implement it in verify_build.py and add the dep then — but do not leave the capability documented-but-unbuilt.)

### [G_docs_core.9] (AUDIT/low) KIT_ARCHITECTURE promises examples/ holds reference books, but the directory is empty
- loc: KIT_ARCHITECTURE.md:103
- FIX: In KIT_ARCHITECTURE.md:103 the taxonomy line '└── examples/                 One or two filled reference books (config + a few contracts)' points at an empty directory. Fix: change it to point at the real shipped reference book, matching README.md:102: '└── book_workspace/testvoyage/  ships as the filled reference book (config + contracts + all outputs)'. Remove the empty examples/ entry from the taxonomy (or, alternatively, populate examples/ with a trimmed testvoyage config + a couple of contracts — but the doc pointer fix is the minimal correct change).

### [G_docs_core.10] (AUDIT/low) KIT_ARCHITECTURE templates/ taxonomy omits digest.template.md (referenced by CLAUDE.md and START_HERE)
- loc: KIT_ARCHITECTURE.md:95-101 (templates/ block)
- FIX: In the templates/ block of KIT_ARCHITECTURE.md (lines 96-101), add a line for digest.template.md so the taxonomy lists all seven files on disk. Insert '│   ├── digest.template.md' into the block (e.g. after handoff.template.md at line 98). On disk templates/ contains: WRONG.template.md, contract.template.md, digest.template.md, handoff.template.md, seed.template.md, state.template.md, threads.template.md (7 files); the spec currently lists only 6, omitting digest.template.md — which CLAUDE.md §3 ('a RELATIONAL digest ... per templates/digest.template.md') and START_HERE.md depend on.

### [G_docs_core.11] (AUDIT/low) `generate cover <format>` has no documented format-to-profile mapping
- loc: CLAUDE.md:116 and CLAUDE.md:139
- FIX: Add an explicit format->profile table to CLAUDE.md §3 generate-cover entry (near line 116) or to §12 step 8: kdp_paperback->kdp-wrap, kdp_hardcover->kdp-hardcover, mixam_hardcover->mixam-3panel, mixam_paperback->mixam-paperback-wrap, blurb_paperback->blurb-wrap, blurb_hardcover->blurb-imagewrap, kindle->kindle. Derive these exact pairs by inverting the `PROFILE_OUTDIR` dict in composite_cover.py (lines 143-151). Optionally expose the inverse as a shared constant (e.g. in preset_lookup.py) so docs and code cannot drift.

### [G_docs_core.12] (AUDIT/low) latex_to_unicode.js documented as a discrete pipeline step but is an imported library, not a stage
- loc: CLAUDE.md:138 (tool-invocation index `produce format` row)
- FIX: Edit CLAUDE.md line 138: remove `→ _tools/latex_to_unicode.js (math books)` from the end of the produce-format chain and instead note it as a library, e.g. append `(generate_book.js / generate_kindle.js import latex_to_unicode.js inline for math books)`. This matches KIT_ARCHITECTURE.md:173-175, which describes it as an importable module.

### [G_docs_core.13] (GAP/—) README.md: correct "five formats" -> "nine formats" everywhere; add a prerequisites banner (Windows+Word = Tier 1, else Tier 2); point at INSTALL.md and doctor.py; fix any empty-examples/ claim to point at book_workspace/testvoyage or examples/.

### [G_docs_core.14] (GAP/—) CLAUDE.md: ensure five->nine formats consistent; confirm MAINTAIN mode is documented in §1 mode detection; vision default text = auto; organ invocations framed as optional accelerators + portable fallbacks.

# FIX PLAN — cluster F_config

## Files you OWN (edit ONLY these; ignore fix-portions that touch other files — another agent owns them):
- _tools/book_config.schema.json
- _tools/book_config.example.json
- _tools/kit_env.json
- _tools/kit_env.template.json

## Tasks (19)

### [F_config.1] (AUDIT/high) Cover-art prompt guard rejects the kit's own shipped example prompt_seed (blocks first-run)
- loc: _tools/cover_gen.py:68-112 (TEXT_SIGNAL_TOKENS + check_prompt_no_text); consumed by do_single:386 / do_batch:477. Shipped seeds: _tools/book_config.example.json:50 and book_workspace/testvoyage/book_config.json:51
- FIX: In _tools/cover_gen.py, fix check_prompt_no_text (lines 93-112) so compositional idioms and negations do not fire. Step 1: before scanning, remove negated spans by replacing the substrings 'no text', 'without text', 'no lettering', 'no title' with '' in the lowercased copy `low`. Step 2: replace the bare tokens 'title', 'subtitle', 'author', 'text ', ' text', 'word ', ' words' in TEXT_SIGNAL_TOKENS (lines 68-72) — remove those seven entries and keep only the unambiguous ones ('byline','lettering','typography','caption','writing','inscription','signage','book cover text','cover text','logo text','nameplate'). Step 3: whitelist compositional phrases: if any of 'for a title','for title placement','title placement','room for the title','for the title','quiet for title' appear in `low`, do not flag on the word 'title'. The config-driven check at lines 106-111 (flagging the book's literal title/author strings) stays as the real guard against baking the actual title. Verify with: `python -c "import sys;sys.path.insert(0,'_tools');import cover_gen,json; c=json.load(open('_tools/book_config.example.json',encoding='utf-8')); print(cover_gen.check_prompt_no_text(c['cover']['art']['prompt_seed'],c))"` — must print []. Repeat for book_workspace/testvoyage/book_config.json (its seed contains both 'no text' and 'for a title'). Both must return no violations.

### [F_config.2] (AUDIT/high) check_part_pages.headings read by code but forbidden by schema (additionalProperties:false) — fails GATE-2
- loc: _tools/book_config.schema.json:8 (root additionalProperties:false) vs _tools/check_part_pages.py:140-142
- FIX: In _tools/book_config.schema.json, inside the top-level "properties" object (e.g. right after the "voice" property block, before the closing brace at line 285), add a new property:
    "check_part_pages": {
      "type": "object",
      "additionalProperties": false,
      "description": "Optional recto-parity heading override consumed by check_part_pages.py. If absent, headings are synthesized from units[].title / voice.unit_noun.",
      "properties": {
        "headings": { "type": "array", "items": { "type": "string" }, "description": "Explicit ordered list of heading STEMS to Find on recto pages (matched before the dash tail)." }
      }
    }
Remember to add a trailing comma to the preceding property. Expected result: a config using check_part_pages.headings passes jsonschema.validate (GATE-2).

### [F_config.3] (AUDIT/high) language read by build_epub but forbidden by schema — non-English EPUB fails GATE-2
- loc: _tools/book_config.schema.json:8 (root additionalProperties:false) vs _tools/build_epub.py:268
- FIX: In _tools/book_config.schema.json, inside top-level "properties" (e.g. after "is_fiction" at line 15, or anywhere among the root scalars), add:
    "language": { "type": "string", "default": "en", "description": "BCP-47 language tag for EPUB dc:language + xml:lang (read by build_epub.py). Defaults to 'en'." },
Ensure comma placement is valid. Expected result: a config setting language:'fr' passes GATE-2 jsonschema.validate.

### [F_config.4] (AUDIT/medium) KDP category count contradicts itself across three ledger sections (max 3 / pick 2 / floor-2-but-3-attested) with no forward pointer from the primary rule
- loc: docs/LESSONS_LEDGER.md:424-425 (§9.1) and :606 (§14) say ≤/max 3; :705 (§18.1) says "pick 2, not 3"; :756 (§19.3) says "2 (floor), 3 attested for nonfiction — anchor to the live picker". Schema _tools/book_config.schema.json:232 caps maxItems:3.
- FIX: In docs/LESSONS_LEDGER.md the authoritative reconciled position already lives at §19.3 line 756 ("2 floor, 3 attested for nonfiction, anchor to the live picker") and is corroborated by docs/_lessons_audit/_delta_book_booksmith_memory.md P5 (a real shipped book, ATD, used 3 nonfiction categories — so 2 must NOT be adopted as a universal cap). Do THREE edits and NOTHING else. (1) Line 705 (§18.1): replace the flat sentence 'KDP categories at submit = pick 2, not 3.' with 'KDP categories at submit: safe floor 2, but 3 is attested for nonfiction (ATD shipped 3) — anchor to the LIVE KDP picker on the run date; see §9.1 and §19.3.' (2) Line 425 (§9.1 Verify:): change '≤ 3 categories' to '2–3 categories (floor 2; up to 3 where the live picker offers them — see §18.1/§19.3)'. (3) Line 606 (§14 checklist): change '≤3 categories' to '2–3 categories (floor 2, max 3; §19.3)'. Do NOT change schema line 232 — maxItems:3 is the correct ceiling and matches '3 attested'; lowering it to 2 would reject the ATD-style nonfiction case.

### [F_config.5] (AUDIT/medium) interior.page_number_align schema knob is never read; footer hardcodes center (LESSONS_LEDGER wrongly marks it CODED)
- loc: _tools/book_config.schema.json:112 vs _tools/generate_book.js:683-690
- FIX: Pick one (honor or remove). To HONOR: in _tools/generate_book.js pageNumberFooters() (~line 683-690), read const align = (config.interior && config.interior.page_number_align) === 'outer' ? 'outer' : 'center'; and when 'outer', build TWO distinct footers — default (recto) using AlignmentType.RIGHT and even (verso) using AlignmentType.LEFT — instead of CENTER for both. To REMOVE: in _tools/book_config.schema.json line 112, delete 'outer' from the enum so it reads "enum": ["center"], and update docs/LESSONS_LEDGER.md §16.2 (line 654) to drop the false '✅ CODED (interior.page_number_align)' claim. Expected result: the schema no longer advertises an option the code ignores.

### [F_config.6] (AUDIT/medium) cover.title_face schema knob is never read; composite_cover hardcodes Cormorant Garamond
- loc: _tools/book_config.schema.json:153-157 vs _tools/composite_cover.py:130-131,263-277
- FIX: Pick one (honor or document-as-fixed). To DOCUMENT-AS-FIXED (lowest risk): in _tools/book_config.schema.json lines 153-157, change the title_face description to state it is currently informational only and the compositor always renders Cormorant Garamond; and fix fonts/library/FONTS.md line 7 to remove the false 'point cover.title_face at any family' claim. To HONOR: in composite_cover.py load_font(), resolve the font path from config.cover.title_face against FONTS_DIR / (REPO_ROOT/'fonts'/'library') by family name, falling back to the current Cormorant paths when unset/unmatched. Expected result: the schema/docs no longer promise a font override the compositor ignores.

### [F_config.7] (AUDIT/medium) cover.art prompt_seed/negative_prompt/steps/seed never read by cover_gen; only checkpoint+workflow are honored
- loc: _tools/book_config.schema.json:181-188 vs _tools/cover_gen.py:348-366,378-432,592-609
- FIX: In _tools/cover_gen.py do_single() (after config is loaded at line 383, before building args_obj at line 427), default any unset CLI arg from config.cover.art: art = ((config or {}).get('cover') or {}).get('art') or {}; if not args.prompt and art.get('prompt_seed'): args.prompt = art['prompt_seed']; if args.negative == DEFAULT_NEGATIVE and art.get('negative_prompt'): args.negative = art['negative_prompt']; if args.steps == 30 and 'steps' in art: args.steps = art['steps']; if args.seed == -1 and 'seed' in art: args.seed = art['seed']. Apply the same in do_batch. Expected result: cover.art.prompt_seed/negative_prompt/steps/seed in book_config drive generation when the CLI flag is omitted (single-source-of-knobs restored).

### [F_config.8] (AUDIT/medium) voice.greenlist is documented as scrub-protection but is never read by the linter
- loc: _tools/lint_manuscript.py:302-337 (scan_voice) & 475-482 (main) vs _tools/book_config.schema.json:279, docs/author_voice/_voiceprofile_soul.md:187
- FIX: Pick ONE of two directions.
(A) Implement it: in _tools/lint_manuscript.py main() (near lines 476-477 where blacklist/sacred_terms are read) add `greenlist = voice.get("greenlist", []) or []`; extend scan_voice's signature (line 302) to accept greenlist and, before appending any BLACKLIST finding for a line, skip the finding when the matched span falls inside a greenlisted phrase present on that line (i.e., for each greenlist phrase G, if G.lower() in line_lower and the blacklist needle is a substring of G, suppress). Pass greenlist through at the two scan_voice call sites (line 544).
(B) If not implementing now, relabel to stop over-promising: change book_config.schema.json:279 description from 'Sanctioned signature phrases/Bo-isms to preserve.' to 'Sanctioned signature phrases (reviewer reference; NOT yet enforced by lint_manuscript.py).' and change docs/author_voice/_voiceprofile_soul.md:187 'Greenlist = sanctioned language excluded from the scrub.' to note it is a reviewer-facing list, not a lint exclusion.
Expected result: either a greenlisted phrase containing a blacklisted substring stops firing BLACKLIST, or the docs/schema no longer claim protection the code does not provide.

### [F_config.9] (AUDIT/medium) Ceremonial em-dash scan omits readers_note, which renders into the interior front matter
- loc: _tools/lint_manuscript.py:501-508 (ceremonial dict) vs _tools/generate_book.js:587-616 (readersNoteChildren), _tools/book_config.schema.json:54
- FIX: In _tools/lint_manuscript.py, in the `ceremonial` dict (lines 501-508), add one entry:
            "readers_note": cfg.get("readers_note"),
(place it alongside "dedication" / "about_the_author"). No other change needed — the existing loop at lines 509-515 already scans every string value for em/en-dashes. Expected result: an em-dash placed in config.readers_note produces an [EM_DASH] config finding and exit 1, matching the treatment of config.dedication and config.epigraph.

### [F_config.10] (AUDIT/low) kit_env template/live key-parity drift: vision.fallback is live-only, node.note is template-only
- loc: C:\BOOKSMITH\_tools\kit_env.json:37 (vision.fallback) vs C:\BOOKSMITH\_tools\kit_env.template.json:12 (node.note)
- FIX: In C:\BOOKSMITH\_tools\kit_env.template.json, add a "fallback" line inside the "vision" block (after the "api" line ~45): "fallback": "claude — the harness's own vision via a resize_image_safe.py-resized image read from disk". Optionally add a "note" line to the live "node" block in kit_env.json (line 9) to mirror the template's node.note, or leave it — both are pure doc-strings consumed by no code. Key parity is the only goal.

### [F_config.11] (AUDIT/low) cover_gen launch_server shells to a 'comfy' binary never named in kit_env; comfy_client.py cannot start a server
- loc: _tools/cover_gen.py:141-166 (launch_server hardcodes comfy_bin='comfy'), called from do_single:409 / do_batch:498; kit_env.template.json cover_gen note (line 33)
- FIX: Two-part doc/UX fix. (1) In _tools/kit_env.template.json cover_gen note (line 33), add a sentence: 'AUTO-LAUNCH of ComfyUI requires comfy-cli on PATH (cover_gen runs `comfy launch --background`); the vendored comfy_client.py is a CLIENT only and cannot start a server. If comfy-cli is absent, start ComfyUI yourself so it serves comfyui_server, or pass --no-launch.' (2) In _tools/cover_gen.py, when launch_server returns False (lines 409-416 and 498-503), change the error 'error' string to distinguish the two causes: 'ComfyUI server not reachable at {server} and could not auto-launch it (comfy-cli not on PATH). Start ComfyUI so it serves {server}, or install comfy-cli, or pass --no-launch once it is running.' Keep the existing checkpoint hint as a separate 'hint' field. Do not change control flow — the happy path (server already serving) is unaffected.

### [F_config.12] (AUDIT/low) interior.page_number_align 'outer' value is silently ignored (footer hard-codes CENTER)
- loc: C:\BOOKSMITH\_tools\generate_book.js:683-691 (pageNumberFooters, hard-codes AlignmentType.CENTER); knob defined at C:\BOOKSMITH\_tools\book_config.schema.json:112
- FIX: In C:\BOOKSMITH\_tools\generate_book.js, the pageNumberFooters() factory (lines 683-691) hard-codes alignment: AlignmentType.CENTER and never reads config.interior.page_number_align. A grep of the whole repo confirms NO .js file reads this knob, so setting it to 'outer' is a silent no-op. FIX (make the schema'd knob live): (1) read the knob near the top of the run/main function where `config` is in scope, e.g. `const pnAlign = (config.interior && config.interior.page_number_align) === 'outer' ? 'outer' : 'center';`. (2) In pageNumberFooters(), for pnAlign==='center' keep the single centered paragraph for both default+even; for pnAlign==='outer' build two variants — default (recto) with alignment: AlignmentType.RIGHT and even (verso) with alignment: AlignmentType.LEFT — so the number sits at the outer corner. Keep the same TextRun (PageNumber.CURRENT, font T.FONT, size 18, color 888888). ALTERNATIVELY, if 'outer' is intentionally retired (house style is center-only per LESSONS_LEDGER §16.2), instead DROP the dead option: change schema line 112 enum from ["center","outer"] to ["center"] and update its description, so no config can silently no-op. Prefer implementing the branch (it is the documented behavior). NOTE: only generate_book.js needs this — generate_kindle.js has no PageNumber footer (reflowable ebook), confirmed by grep.

### [F_config.13] (AUDIT/low) Schema does not distinguish orchestrator/agent-consumed fields from toolchain-read ones (finish/genre/integration_mode/formats/reroll_budget)
- loc: _tools/book_config.schema.json:14 (genre), 16-21 (integration_mode), 80-85 (finish), 87-94 (formats), 188 (reroll_budget)
- FIX: In _tools/book_config.schema.json, append a marker to the descriptions of the agent-only fields so a reader knows the build tools do not consume them. Specifically append ' (orchestrator/agent-consumed; not read by the build toolchain).' to the description strings of: genre (line 14), integration_mode (line 20), finish (line 84), formats (line 89), and cover.art.reroll_budget (line 188). Expected result: the schema self-documents which knobs drive builders vs which drive the agent; no behavior change.

### [F_config.14] (AUDIT/low) Cosmetic mis-indent of spine_override_in property (6 spaces vs sibling 8)
- loc: _tools/book_config.schema.json:221
- FIX: In _tools/book_config.schema.json, re-indent line 221 from 6 leading spaces to 8 so it aligns with its sibling properties (per_page_cream etc.). Change '      "spine_override_in":' to '        "spine_override_in":'. No functional change. Expected result: consistent 8-space property indentation inside the spine.properties block.

### [F_config.15] (AUDIT/low) Example config omits the dash-character blacklist atoms and the H2/H3 meta-opener/summary regexes the voice docs mandate
- loc: _tools/book_config.example.json:102-111 (voice.blacklist) vs docs/author_voice/_voiceprofile_soul.md:91-93,205-211 and AUTHOR_VOICE_Bo_Chen.md:48-51
- FIX: In _tools/book_config.example.json, expand voice.blacklist (lines 102-111) to lead with the dash atoms and include the meta/summary atoms per AUTHOR_VOICE_Bo_Chen.md:48-51, e.g. add at the front: "—", "–" (the literal em-dash and en-dash characters), plus "Key Takeaways", "It's important to note". Add the H2/H3 regexes in the slash form ONLY AFTER Finding 1 is fixed (otherwise they land in the literal tier and do nothing): "/(?i)^in this (chapter|part|section)/", "/(?i)key takeaways/", "/(?i)\\bin (summary|conclusion)\\b/". Do NOT rely on this to catch em-dashes in prose — that is already covered by the on-by-default no_em_dashes gate; the dash atoms here only add coverage for the config-ceremonial and cs-substring paths. Optionally add "no_em_dashes": true to voice for explicitness (it already defaults true in code). Expected result: the template a stranger copies carries the documented meta-opener/summary coverage instead of zero.

### [F_config.16] (CRITIC/critical) The entire portability/robustness toolchain and the FRAME docs are untracked — a git clone yields a non-booting kit
- loc: git working tree: 33 untracked paths incl. _tools/doctor.py, make_giftable.py, estimate_tokens.py, comfy_client.py, on_session_start.py, on_precompact.py, rehydrate.py, transcript_to_md.py, fetch_weights.py, run_batch.py, kit_env.template.json; docs/SUPERSTRUCTURE.md, docs/BOOKSMITH_WIRING.svg, docs/author_voice/*, docs/COMPACTION_SURVIVAL.md; requirements.txt; templates/digest.template.md; fonts/LICENSES/; fonts/library/
- FIX: This is the single biggest giftability defect and it dwarfs every code-level finding. Stage and commit the robustness layer before shipping: at minimum requirements.txt, docs/SUPERSTRUCTURE.md + BOOKSMITH_WIRING.svg (CLAUDE.md's own top banner declares them load-bearing/'read in full'), docs/author_voice/* (GATE-2 mandates loading them), estimate_tokens.py (boot-sequence mandatory sizer), the compaction-survival tools + docs, kit_env.template.json, fonts/LICENSES + fonts/library, doctor.py, and make_giftable.py. Then re-run any audit against the COMMITTED tree, since the current audit read files a stranger never receives. Decide deliberately what NOT to track (personal memory) and gitignore it explicitly.

### [F_config.17] (GAP/—) Neutralize author in book_config.example.json: "Bo Chen" -> a generic placeholder (e.g. "Your Name"); example content (Titanic novel) is fine to keep.

### [F_config.18] (GAP/—) Confirm every new schema field (min_pages, kindle_include_toc, interior.include_toc, interior.page_number_align, voice.no_em_dashes) is present in schema AND has a placeholder in the example; verify example validates: python -c "import json,jsonschema;jsonschema.validate(json.load(open('_tools/book_config.example.json')),json.load(open('_tools/book_config.schema.json')))".

### [F_config.19] (GAP/—) Expose ornament/code/math font names (currently hardcoded "Segoe UI Symbol"/"Consolas"/"Cambria Math" in the generators) as optional book_config.interior fields with portable defaults, so the JS generators can read them (coordinate: the generator edit is cluster D).

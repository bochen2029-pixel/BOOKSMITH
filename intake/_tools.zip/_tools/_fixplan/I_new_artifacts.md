# FIX PLAN — cluster I_new_artifacts

## Files you OWN (edit ONLY these; ignore fix-portions that touch other files — another agent owns them):
- LICENSE
- .gitattributes
- .gitignore
- examples/
- fonts/library/FONTS.md
- _tools/check_synthesis.py

## Tasks (8)

### [I_new_artifacts.1] (CRITIC/high) Personal-data and stray artifacts sit un-gitignored in the repo root and would be committed by `git add .`
- loc: repo root: SESSION_LOG.md, _SESSION_MEMORY_2026-07-12.md, .recall/CONTINUITY.md, .claude/settings.json (all return empty from `git check-ignore`); stray malformed file `C:BOOKSMITH_latextest2.js`; third-party `Digest_..._Paperback_Photo_Quality_Books...pdf` at root
- FIX: Add to .gitignore: _SESSION_MEMORY_*.md, SESSION_LOG.md (or move to a docs/ that is deliberately shipped after a personal-data scrub), .recall/, .claude/settings.json (or a scrubbed variant). Delete the malformed `C:BOOKSMITH_latextest2.js` (a bad-redirect artifact — a literal colon filename) and the stray Digest PDF, or relocate them under docs/service_templates if intentional. make_giftable.py's personal-data grep protects only the ZIP path, not the git path, so git needs its own guard.

### [I_new_artifacts.2] (CRITIC/medium) Committed binary build artifacts bloat every clone; regenerable masters are leaking into the tree
- loc: .gitignore (excludes only *.pdf.bak and drafts/*_wip_*, not primary outputs); git status shows tracked+modified book_workspace/testvoyage/outputs/**/*.docx,*.epub,*.pdf,cover_wrap.jpg; untracked outputs/markdown/testvoyage_v2.md and _v3.md
- FIX: Decide a policy: either ship ONE frozen proof-artifact set for testvoyage (and gitignore the rest of outputs/) or regenerate-on-clone (gitignore all of book_workspace/*/outputs/ except a curated sample). Also add checkpoints/*.safetensors (model weights dir from fetch_weights) to .gitignore so a stranger cannot accidentally commit multi-GB weights. The append-only markdown masters (testvoyage_v*.md) under outputs/markdown are regenerable and should not accumulate untracked.

### [I_new_artifacts.3] (CRITIC/medium) No mechanical gate on kit-self-consistency, so every internal-reference defect must be caught by hand
- loc: absence across _tools/: no self-audit that cross-checks kit_env.template vs kit_env keys, requirements.txt vs actual imports, schema-permitted fields vs config reads, or doc-cited script names vs existing files
- FIX: Add `doctor.py --self-audit` (or a _tools/check_kit.py gate) that mechanically verifies: (1) kit_env.template.json and kit_env.json share a key-set; (2) every top-level import/require resolves and is declared in requirements.txt/package.json (kills the phantom pypdfium2/numpy/jsonschema-vs-actual drift); (3) every config key the code reads is permitted by the additionalProperties:false schema (kills the check_part_pages.headings + language GATE-2 rejections at author time); (4) every `\w+\.(py|js)` script name cited in docs exists (kills kindle_parity_check.py phantom). One gate subsumes ~8 of the audit's manual findings.

### [I_new_artifacts.4] (GAP/—) Add LICENSE at repo root: MIT (per PORTABILITY_GAP_ANALYSIS decision #1, Bo default). Copyright holder "Bo Chen". Standard MIT text. Note: the vibe-writing method doc is CC-BY-4.0 and fonts are OFL — do not relicense those.

### [I_new_artifacts.5] (GAP/—) Add .gitattributes: "* text=auto eol=lf" + binary marks for *.ttf *.otf *.pdf *.docx *.epub *.jpg *.jpeg *.png *.zip (CRLF protection; repo warns but ships none).

### [I_new_artifacts.6] (GAP/—) fonts/library/FONTS.md: fix the TTF count (says 25; verify the real count with: python -c "import glob;print(len(glob.glob(r'C:/BOOKSMITH/fonts/**/*.ttf',recursive=True)))") and add a pointer to fonts/LICENSES/.

### [I_new_artifacts.7] (GAP/—) examples/: if empty, either copy a minimal testvoyage slice (seed.md + book_config.json + one format output) OR create examples/README.md pointing at book_workspace/testvoyage as the worked example. Pick the pointer (cheap, no large binaries).

### [I_new_artifacts.8] (GAP/—) Build _tools/check_synthesis.py ONLY IF a gate_architecture finding calls for it (GATE-4 anthology tell as a script: per-unit canon-anchor/citation distribution; fail any unit mapping ~1:1 to one source). If specced by a finding, implement per that finding; else create a clear stub with a docstring and TODO and note it in the plan report.

<!-- ============ CHUNK 8/9 ============ -->
<!-- source: You_are_continuing_the_build_of_KEEL_Bo_Chen_s_personal_sovereign_reusable_AI-harness_.md -->
<!-- section: Proposal: close the named-gate loop (dispatch + #3 + the alarm) > Claude — Jun 14, 2026 04:08 -->
<!-- recap: last ~547 tokens of chunk 7, for continuity -->
> ASCII alarm — yes, ASCII-safe is the right primary fix (robust on console AND redirect/pipe regardless of codepage). Cover the persisted failure strings too — the verdict.failures carrying →/— land in the checkpoint + ledger, not just the console print. The one alarm that must never be eaten, in print or in the record.
> 
> Gate + sequence: zero contract edits (stop+justify if a joint genuinely pressures — none expected; GoldenDispatchOracle consumes the existing `golden` param, baseline is kernel-internal), seal unmoved, per-crate budget — one commit if verifier+engine stay comprehensible, split to two if either bloats (your call on the budget). cargo test/clippy green; STATE.md + WAKE_UP folded as it lands — and note this is the slice that finally retires the §4.2 "resolver supplies cases but no oracle consumes them" caveat, so close that line explicitly. Bank LOCAL, show me the diff + tests + the bad-path/#3 smoke + the doc fold; I review, then we push it as the follow-up.
> 
> Bearings after (don't start): mw::metrics next — escalation_rate/rework_rate, the instrument that lets us size the flat-escalation base case (can't size to flat without measuring it) — then perception, then memory designed most skeptically against docs/proposals/perpetual-memory.md (the canon's highest-risk joint), then flywheel/SEXTANT. Ignition is upside, never the justification.
> 
> Go.
> 
> ## Claude — Jun 14, 2026 04:08
> 
> > _[thinking]_
> > 
> 
> ## Claude — Jun 14, 2026 04:08
> 
> Approved with refinements locked in. Marking the chapter and starting the named-gate-completion slice. First I'll read the current `verifier.rs` in full to place the `GoldenDispatchOracle` and ASCII-safe the failure strings precisely.
> 
> ## Claude — Jun 14, 2026 04:08
> 
> **[tool: mcp__ccd_session__mark_chapter]**
> ```json
> {
>   "title": "Named-gate completion: dispatch + #3 + alarm",
>   "summary": "GoldenDispatchOracle (resolved refs assert), un-neuter #3 via a separate I3 baseline, ASCII-safe the I5 alarm (print + persisted). Tests + smoke; retire the §4.2 unconsumed-cases caveat."
> }
> ```
> **[tool result]**
> ```
> Chapter marked: "Named-gate completion: dispatch + #3 + alarm". Continue your current work.
> ```
> 
> ## Claude — Jun 14, 2026 04:08
<!-- end recap | new content begins -->

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs",
  "offset": 36,
  "limit": 110
}
```
**[tool result]**
```
36	
37	    /// `Some(failure)` if the property is violated (or unknown); `None` if it holds.
38	    fn check(&self, property: &str, content: &str) -> Option<String> {
39	        match property {
40	            "no_ssn_pattern" => {
41	                let re = Regex::new(r"\b\d{3}-\d{2}-\d{4}\b").expect("static SSN pattern is valid");
42	                re.is_match(content).then(|| "no_ssn_pattern: output contains an SSN-shaped span".to_string())
43	            }
44	            other => Some(format!("unknown property '{other}' — fail-closed (cannot assert what it cannot check)")),
45	        }
46	    }
47	}
48	
49	#[async_trait]
50	impl Oracle for PropertyOracle {
51	    async fn verify(&self, output: &StepOutput, _golden: &[GoldenCase], _ctx: &Context) -> Result<Verdict> {
52	        let mut failures = Vec::new();
53	        let mut evidence = Vec::new();
54	        for property in &self.properties {
55	            match self.check(property, &output.content) {
56	                Some(failure) => {
57	                    evidence.push(Assertion { kind: "property".into(), detail: failure.clone() });
58	                    failures.push(failure);
59	                }
60	                None => evidence.push(Assertion { kind: "property".into(), detail: format!("{property}: held") }),
61	            }
62	        }
63	        Ok(Verdict { passed: failures.is_empty(), failures, joint_wrong: false, evidence })
64	    }
65	}
66	
67	// ── joint-wrong oracle ────────────────────────────────────────────────────────
68	
69	/// The joint-wrong detector (canon §10): runs golden cases against an output with **contract +
70	/// golden + diff but NOT the implementer's reasoning**. If the implementation's own tests pass yet a
71	/// frozen golden is violated → `JOINT_WRONG` (surfaced to the operator immediately, §18). For
72	/// conformance the two signals arrive on `output.artifact`; in a live run the verifier derives them
73	/// by actually running the goldens (`golden_violated`) and the impl's self-tests (`self_tests_pass`).
74	pub struct GoldenOracle;
75	
76	#[async_trait]
77	impl Oracle for GoldenOracle {
78	    async fn verify(&self, output: &StepOutput, _golden: &[GoldenCase], _ctx: &Context) -> Result<Verdict> {
79	        let self_tests_pass = output.artifact["self_tests_pass"].as_bool().unwrap_or(false);
80	        let golden_violated = output.artifact["golden_violated"].as_bool().unwrap_or(false);
81	        let joint_wrong = self_tests_pass && golden_violated;
82	
83	        let mut failures = Vec::new();
84	        if golden_violated {
85	            failures.push(if joint_wrong {
86	                "JOINT_WRONG: self-tests pass but a frozen golden is violated (systematic — everything looked green)".to_string()
87	            } else {
88	                "golden_violated: output disagrees with a frozen golden".to_string()
89	            });
90	        }
91	        let evidence = vec![Assertion {
92	            kind: if joint_wrong { "joint_wrong" } else { "golden" }.into(),
93	            detail: format!("self_tests_pass={self_tests_pass} golden_violated={golden_violated}"),
94	        }];
95	        Ok(Verdict { passed: !golden_violated, failures, joint_wrong, evidence })
96	    }
97	}
98	
99	// ── source-trace oracle ───────────────────────────────────────────────────────
100	
101	/// The trace-to-ground-truth gate (canon §10, §17 — SEXTANT's "Truth Gate"): every claim must trace
102	/// to the canon/ground truth. An ungrounded claim → `INSUFFICIENT_SOURCE` (routes to a human, §18) —
103	/// the externality that stops a model fabricating its own support.
104	pub struct SourceOracle;
105	
106	#[async_trait]
107	impl Oracle for SourceOracle {
108	    async fn verify(&self, output: &StepOutput, _golden: &[GoldenCase], _ctx: &Context) -> Result<Verdict> {
109	        // absence of the flag is treated as "supported" (only an explicit `false` flags a claim)
110	        let canon_supports = output.artifact["canon_supports"].as_bool().unwr…
```

## Claude — Jun 14, 2026 04:09

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:09

Now ASCII-safing the oracle failure strings (they persist into `verdict.failures` → checkpoint + ledger) — PropertyOracle, GoldenOracle, SourceOracle:

## Claude — Jun 14, 2026 04:09

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs",
  "old_string": "            other => Some(format!(\"unknown property '{other}' — fail-closed (cannot assert what it cannot check)\")),",
  "new_string": "            other => Some(format!(\"unknown property '{other}' - fail-closed (cannot assert what it cannot check)\")),"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-services\src\verifier.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:09

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs",
  "old_string": "                \"JOINT_WRONG: self-tests pass but a frozen golden is violated (systematic — everything looked green)\".to_string()",
  "new_string": "                \"JOINT_WRONG: self-tests pass but a frozen golden is violated (systematic - everything looked green)\".to_string()"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-services\src\verifier.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:09

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs",
  "old_string": "        let failure = format!(\"INSUFFICIENT_SOURCE: claim '{claim}' does not trace to the canon (→ human)\");",
  "new_string": "        let failure = format!(\"INSUFFICIENT_SOURCE: claim '{claim}' does not trace to the canon (-> human)\");"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-services\src\verifier.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:09

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:09

Now the SchemaOracle reject strings + the insertion point for the dispatch oracle:

## Claude — Jun 14, 2026 04:09

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs",
  "offset": 146,
  "limit": 52
}
```
**[tool result]**
```
146	const PINNED_DRAFT: jsonschema::Draft = jsonschema::Draft::Draft202012;
147	
148	pub struct SchemaOracle {
149	    schema: Value,
150	}
151	
152	impl SchemaOracle {
153	    pub fn new(mut schema: Value) -> Self {
154	        // determinism: drop any embedded `$schema` so PINNED_DRAFT always governs, never the document.
155	        if let Some(obj) = schema.as_object_mut() {
156	            obj.remove("$schema");
157	        }
158	        Self { schema }
159	    }
160	
161	    fn reject(detail: String) -> Verdict {
162	        Verdict {
163	            passed: false,
164	            failures: vec![detail.clone()],
165	            joint_wrong: false,
166	            evidence: vec![Assertion { kind: "schema".into(), detail }],
167	        }
168	    }
169	}
170	
171	#[async_trait]
172	impl Oracle for SchemaOracle {
173	    async fn verify(&self, output: &StepOutput, _golden: &[GoldenCase], _ctx: &Context) -> Result<Verdict> {
174	        // the instance to check: the structured artifact if present, else parse content as JSON.
175	        let instance: Value = if !output.artifact.is_null() {
176	            output.artifact.clone()
177	        } else {
178	            match serde_json::from_str(&output.content) {
179	                Ok(v) => v,
180	                Err(e) => return Ok(Self::reject(format!("schema: output is not JSON ({e}) — rejected, never partially applied"))),
181	            }
182	        };
183	        // compile the schema; fail closed if it cannot be compiled (cannot assert what it cannot check).
184	        let validator = match jsonschema::options().with_draft(PINNED_DRAFT).build(&self.schema) {
185	            Ok(v) => v,
186	            Err(e) => return Ok(Self::reject(format!("schema: cannot compile schema ({e}) — fail-closed"))),
187	        };
188	        let failures: Vec<String> = validator.iter_errors(&instance).map(|e| format!("schema: {e}")).collect();
189	        if failures.is_empty() {
190	            Ok(Verdict {
191	                passed: true,
192	                failures: Vec::new(),
193	                joint_wrong: false,
194	                evidence: vec![Assertion { kind: "schema".into(), detail: "output validates against the schema".into() }],
195	            })
196	        } else {
197	            let detail = format!("schema-invalid (rejected, never partially applied): {}", failures.join("; "));
```

## Claude — Jun 14, 2026 04:09

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:09

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs",
  "old_string": "                Err(e) => return Ok(Self::reject(format!(\"schema: output is not JSON ({e}) — rejected, never partially applied\"))),",
  "new_string": "                Err(e) => return Ok(Self::reject(format!(\"schema: output is not JSON ({e}) - rejected, never partially applied\"))),"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-services\src\verifier.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:09

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs",
  "old_string": "            Err(e) => return Ok(Self::reject(format!(\"schema: cannot compile schema ({e}) — fail-closed\"))),",
  "new_string": "            Err(e) => return Ok(Self::reject(format!(\"schema: cannot compile schema ({e}) - fail-closed\"))),"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-services\src\verifier.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:09

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs",
  "offset": 198,
  "limit": 14
}
```
**[tool result]**
```
198	            Ok(Verdict { passed: false, failures, joint_wrong: false, evidence: vec![Assertion { kind: "schema".into(), detail }] })
199	        }
200	    }
201	}
202	
203	// ── the pluggable registry ────────────────────────────────────────────────────
204	
205	/// The pluggable oracle registry (canon §10): a cell registers its own oracles; `verify` runs them
206	/// all and folds the verdicts — `passed` is AND (every oracle must clear), `joint_wrong` is OR (any
207	/// oracle may raise it), failures/evidence concatenate. The registry is the I5 seam a cell
208	/// specializes without touching the core.
209	#[derive(Default)]
210	pub struct Verifier {
211	    oracles: Vec<Box<dyn Oracle>>,
```

## Claude — Jun 14, 2026 04:10

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:10

Inserting the `GoldenDispatchOracle` (bounded/exhaustive dispatch by family; conformance-only families assert nothing):

## Claude — Jun 14, 2026 04:10

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs",
  "old_string": "// ── the pluggable registry ────────────────────────────────────────────────────",
  "new_string": "// ── golden-dispatch oracle (a resolved golden_ref actually asserts) ─────────────\n\n/// Runs each resolved golden case against the live output by dispatching on its **family** — the\n/// piece that makes a *named* `golden_ref` actually assert (canon §10): a step names its gate and it\n/// fires, with **no cell pre-registration**. Bounded + exhaustive over the KNOWN runtime families:\n/// - `input.schema` → [`SchemaOracle`] (validate-or-reject),\n/// - `input.property` → [`PropertyOracle`],\n/// - everything else (conformance-only goldens: cost/usage, `self_tests_pass`, …) → **asserts\n///   nothing** (explicit fall-through). Those are **test-time** conformance goldens, not runtime gates\n///   against a live `StepOutput`. So a critical step whose only ref is conformance-only yields *zero*\n///   correctness evidence and the engine's critical-step guard fails it — **resolving a ref is not\n///   asserting one.** Adding a family means extending this match: a bounded dispatch, never a generic plugin.\npub struct GoldenDispatchOracle;\n\n#[async_trait]\nimpl Oracle for GoldenDispatchOracle {\n    async fn verify(&self, output: &StepOutput, golden: &[GoldenCase], ctx: &Context) -> Result<Verdict> {\n        let mut agg = Verdict { passed: true, failures: Vec::new(), joint_wrong: false, evidence: Vec::new() };\n        for case in golden {\n            let sub = if let Some(schema) = case.input.get(\"schema\") {\n                SchemaOracle::new(schema.clone()).verify(output, &[], ctx).await?\n            } else if let Some(prop) = case.input.get(\"property\").and_then(Value::as_str) {\n                PropertyOracle::new(vec![prop.to_string()]).verify(output, &[], ctx).await?\n            } else {\n                continue; // conformance-only family: not a live-output gate — assert nothing\n            };\n            agg.passed &= sub.passed;\n            agg.joint_wrong |= sub.joint_wrong;\n            agg.failures.extend(sub.failures);\n            agg.evidence.extend(sub.evidence);\n        }\n        Ok(agg)\n    }\n}\n\n// ── the pluggable registry ────────────────────────────────────────────────────"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-services\src\verifier.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:10

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:10

Exporting the dispatch oracle and adding its tests (schema-family assert/reject, property-family, conformance-only asserts nothing):

## Claude — Jun 14, 2026 04:10

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\lib.rs",
  "old_string": "pub use verifier::{GoldenOracle, PropertyOracle, SchemaOracle, SourceOracle, Verifier};",
  "new_string": "pub use verifier::{GoldenDispatchOracle, GoldenOracle, PropertyOracle, SchemaOracle, SourceOracle, Verifier};"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-services\src\lib.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:10

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs",
  "old_string": "            \"6 > 5 → valid (proves the schema compiled and the constraint is actually applied)\"\n        );\n    }\n}",
  "new_string": "            \"6 > 5 → valid (proves the schema compiled and the constraint is actually applied)\"\n        );\n    }\n\n    /// A NAMED schema golden_ref actually asserts — no cell pre-registration. Conformant → pass;\n    /// malformed → rejected via the ref. This is what makes `--golden-ref <schema-golden>` a real gate.\n    #[tokio::test]\n    async fn golden_dispatch_runs_schema_family() {\n        let schema_case = GoldenCase {\n            name: \"directive-schema\".into(),\n            input: json!({ \"schema\": { \"type\": \"object\", \"required\": [\"action\"], \"properties\": { \"action\": { \"type\": \"string\" } } } }),\n            expect: json!({}),\n        };\n        let d = GoldenDispatchOracle;\n        let ctx = Context::default();\n        let good = StepOutput { content: String::new(), artifact: json!({ \"action\": \"spawn\" }) };\n        assert!(d.verify(&good, std::slice::from_ref(&schema_case), &ctx).await.unwrap().passed, \"conformant → pass via the ref\");\n        let bad = StepOutput { content: String::new(), artifact: json!({ \"nope\": 1 }) };\n        assert!(!d.verify(&bad, std::slice::from_ref(&schema_case), &ctx).await.unwrap().passed, \"malformed → rejected via the ref\");\n    }\n\n    /// A property-family golden_ref dispatches to PropertyOracle (here: no-SSN on the output).\n    #[tokio::test]\n    async fn golden_dispatch_runs_property_family() {\n        let prop_case = GoldenCase { name: \"no-ssn\".into(), input: json!({ \"property\": \"no_ssn_pattern\" }), expect: json!({}) };\n        let d = GoldenDispatchOracle;\n        let ctx = Context::default();\n        let clean = StepOutput { content: \"all clear\".into(), artifact: Value::Null };\n        assert!(d.verify(&clean, std::slice::from_ref(&prop_case), &ctx).await.unwrap().passed);\n        let dirty = StepOutput { content: \"ssn 123-45-6789\".into(), artifact: Value::Null };\n        assert!(!d.verify(&dirty, std::slice::from_ref(&prop_case), &ctx).await.unwrap().passed);\n    }\n\n    /// A conformance-only golden (cost/usage shape — no schema/property family) asserts NOTHING at\n    /// runtime: no evidence, vacuous pass. The engine's critical-step guard turns that into a config\n    /// fault for a critical step — resolving a ref is not asserting one.\n    #[tokio::test]\n    async fn golden_dispatch_skips_conformance_only_family() {\n        let cost_case = GoldenCase {\n            name: \"cost\".into(),\n            input: json!({ \"usage\": { \"input_tokens\": 1000 }, \"price\": { \"input_miss\": 0.435 } }),\n            expect: json!({ \"cost\": 0.0 }),\n        };\n        let d = GoldenDispatchOracle;\n        let v = d.verify(&StepOutput::default(), std::slice::from_ref(&cost_case), &Context::default()).await.unwrap();\n        assert!(v.passed, \"non-runtime family asserts nothing → vacuous at the oracle level\");\n        assert!(v.evidence.is_empty(), \"and produces NO evidence (so a critical step config-faults in the engine)\");\n    }\n}"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-services\src\verifier.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:13

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:13

Now the engine: adding the I3 `baseline` field (excluded from #3), threading it, and reworking the verify section. Group 1 — the struct/config/constructor:

## Claude — Jun 14, 2026 04:13

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\engine.rs",
  "old_string": "    pub oracle: Arc<dyn Oracle>,\n    pub spine: Arc<dyn Spine>,\n    pub memory: Option<Arc<dyn Memory>>,\n    pub trace_sink: Option<Arc<dyn TraceSink>>,\n    pub default_tier: String,",
  "new_string": "    pub oracle: Arc<dyn Oracle>,\n    /// The **I3 sovereignty baseline** (currently no-SSN-on-output): an always-on check that runs and\n    /// folds into the verdict but is **excluded from the critical-step guard (#3)** — a privacy\n    /// baseline is not a correctness oracle. **STOPGAP:** `mw::privacy` masks only on *egress* (cloud),\n    /// so a LOCAL turn's output PII is otherwise unguarded; this covers that gap until the Stage-2\n    /// privacy rung re-homes it as an output-side I3 check (then this slot is dropped). Never satisfies #3.\n    pub baseline: Option<Arc<dyn Oracle>>,\n    pub spine: Arc<dyn Spine>,\n    pub memory: Option<Arc<dyn Memory>>,\n    pub trace_sink: Option<Arc<dyn TraceSink>>,\n    pub default_tier: String,"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-kernel\src\engine.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:13

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\engine.rs",
  "old_string": "    oracle: Arc<dyn Oracle>,\n    spine: Arc<dyn Spine>,\n    memory: Option<Arc<dyn Memory>>,\n    trace_sink: Option<Arc<dyn TraceSink>>,\n    default_tier: String,\n    goldens: HashMap<String, GoldenCase>,\n}",
  "new_string": "    oracle: Arc<dyn Oracle>,\n    baseline: Option<Arc<dyn Oracle>>,\n    spine: Arc<dyn Spine>,\n    memory: Option<Arc<dyn Memory>>,\n    trace_sink: Option<Arc<dyn TraceSink>>,\n    default_tier: String,\n    goldens: HashMap<String, GoldenCase>,\n}"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-kernel\src\engine.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:13

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\engine.rs",
  "old_string": "        let EngineConfig { slots, router, oracle, spine, memory, trace_sink, default_tier, goldens } = config;\n        Ok(Engine { slots, router, oracle, spine, memory, trace_sink, default_tier, goldens })",
  "new_string": "        let EngineConfig { slots, router, oracle, baseline, spine, memory, trace_sink, default_tier, goldens } = config;\n        Ok(Engine { slots, router, oracle, baseline, spine, memory, trace_sink, default_tier, goldens })"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-kernel\src\engine.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:13

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:13

Group 2 — the verify section: run the baseline (folded but excluded from #3), capture correctness evidence before folding, ASCII-safe the alarm strings, and key #3 off correctness:

## Claude — Jun 14, 2026 04:13

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\engine.rs",
  "old_string": "        // (6) verify (I5) against the resolved cases — a non-model assertion.\n        let output = StepOutput { content: result.content.clone(), artifact: Value::Null };\n        let mut verdict = self.oracle.verify(&output, &golden_cases, ctx).await?;\n\n        // (6a) fail-closed on any unresolved golden_ref (hardening): a named-but-missing assertion is\n        //      a hole, surfaced to the operator — never a vacuous pass.\n        if !missing.is_empty() {\n            verdict.passed = false;\n            let detail = format!(\"unresolved golden_ref(s) {missing:?} — missing assertion, fail-closed (→ operator)\");\n            verdict.failures.push(detail.clone());\n            verdict.evidence.push(Assertion { kind: \"golden_ref\".into(), detail });\n        }\n\n        // (6b) a CRITICAL step with no effective assertion is a config fault, not a vacuous pass\n        //      (canon §8/§10). `verdict.evidence` is empty exactly when no oracle applied to this step\n        //      (an empty registry, or a non-empty one where none was applicable) — for a critical step\n        //      that is a hole, never a pass. (A non-critical no-ref turn still passes silently.)\n        if step.critical && verdict.evidence.is_empty() {\n            verdict.passed = false;\n            let detail =\n                \"critical step with no applicable oracle — config fault (canon §8/§10), not a vacuous pass\".to_string();\n            verdict.failures.push(detail.clone());\n            verdict.evidence.push(Assertion { kind: \"critical\".into(), detail });\n        }",
  "new_string": "        // (6) verify (I5). The injected `oracle` is the CORRECTNESS surface (the golden-ref dispatch +\n        //     a cell's domain oracles); ITS evidence is what satisfies the critical-step guard (#3).\n        let output = StepOutput { content: result.content.clone(), artifact: Value::Null };\n        let mut verdict = self.oracle.verify(&output, &golden_cases, ctx).await?;\n        // capture BEFORE folding the baseline: only a CORRECTNESS assertion counts for #3.\n        let correctness_asserted = !verdict.evidence.is_empty();\n\n        // (6a) the I3 sovereignty baseline (no-SSN-on-output) runs always and folds into the verdict —\n        //      but it is a privacy check, NOT a correctness oracle, so it is **excluded** from #3.\n        if let Some(baseline) = &self.baseline {\n            let bv = baseline.verify(&output, &[], ctx).await?;\n            verdict.passed &= bv.passed;\n            verdict.joint_wrong |= bv.joint_wrong;\n            verdict.failures.extend(bv.failures);\n            verdict.evidence.extend(bv.evidence);\n        }\n\n        // (6b) fail-closed on any unresolved golden_ref (a named-but-missing assertion is a hole).\n        //      ASCII-only: this line lands in the verdict, the checkpoint, and the ledger — the I5\n        //      alarm must render on any console/codepage, not just a UTF-8 shell.\n        if !missing.is_empty() {\n            verdict.passed = false;\n            let detail = format!(\"unresolved golden_ref(s) {missing:?} - missing assertion, fail-closed (-> operator)\");\n            verdict.failures.push(detail.clone());\n            verdict.evidence.push(Assertion { kind: \"golden_ref\".into(), detail });\n        }\n\n        // (6c) a CRITICAL step needs a CORRECTNESS assertion — a resolved golden_ref that fired, or a\n        //      domain oracle — **not** the I3 baseline. None ⇒ config fault, never a vacuous pass\n        //      (canon 8/10). Resolving a ref is not asserting one: a ref to a conformance-only golden\n        //      produces no correctness evidence and lands here too.\n        if step.critical && !correctness_asserted {\n            verdict.passed = false;\n            let detail =\n                \"critical step with no applicable correctness oracle - config fault (canon 8/10), not a vacuous pass\".to_string();\n            verdict.failures.push(detail.clone());\n            verdict.evidence.push(Assertion { kind: \"critical\".into(), detail });\n        }"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-kernel\src\engine.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:14

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:14

Group 3 — tests + doc: update the helper/test for the `baseline` field, refine the #3 doc line, then add the new tests.

## Claude — Jun 14, 2026 04:14

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\engine.rs",
  "old_string": "        Engine::new(EngineConfig {\n            slots,\n            router,\n            oracle,\n            spine,\n            memory,\n            trace_sink,\n            default_tier: \"local\".into(),\n            goldens: HashMap::new(),\n        })\n        .unwrap()",
  "new_string": "        Engine::new(EngineConfig {\n            slots,\n            router,\n            oracle,\n            baseline: None,\n            spine,\n            memory,\n            trace_sink,\n            default_tier: \"local\".into(),\n            goldens: HashMap::new(),\n        })\n        .unwrap()"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-kernel\src\engine.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:14

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\engine.rs",
  "old_string": "            oracle: Arc::new(EvidenceOracle),\n            spine: Arc::new(RecSpine::default()),\n            memory: None,\n            trace_sink: None,\n            default_tier: \"local\".into(),\n            goldens,\n        })\n        .unwrap();",
  "new_string": "            oracle: Arc::new(EvidenceOracle),\n            baseline: None,\n            spine: Arc::new(RecSpine::default()),\n            memory: None,\n            trace_sink: None,\n            default_tier: \"local\".into(),\n            goldens,\n        })\n        .unwrap();"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-kernel\src\engine.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:14

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\engine.rs",
  "old_string": "step with **no effective assertion** (empty verdict",
  "new_string": "step with **no correctness assertion** (the I3 baseline excluded; empty verdict"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-kernel\src\engine.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:14

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:14

Adding the three new engine tests — baseline-exclusion (#2 un-neutering), resolved-but-unasserted ref (Refinement 2), and the ASCII alarm:

## Claude — Jun 14, 2026 04:15

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\engine.rs",
  "old_string": "        let mut s = step(); // critical:false, golden_refs:[]\n        let out = engine.run(&mut s, &mut ctx(), req()).await.unwrap();\n        assert!(out.verdict.passed, \"plain non-critical no-ref turn passes silently\");\n        assert!(out.verdict.failures.is_empty(), \"no false alarm on a plain turn\");\n    }\n}",
  "new_string": "        let mut s = step(); // critical:false, golden_refs:[]\n        let out = engine.run(&mut s, &mut ctx(), req()).await.unwrap();\n        assert!(out.verdict.passed, \"plain non-critical no-ref turn passes silently\");\n        assert!(out.verdict.failures.is_empty(), \"no false alarm on a plain turn\");\n    }\n\n    #[tokio::test]\n    async fn baseline_does_not_satisfy_critical_step() {\n        // the un-neutering: a critical step with NO golden_ref, where ONLY the I3 baseline asserts,\n        // must still config-fault — a privacy baseline is not a correctness oracle.\n        let engine = Engine::new(EngineConfig {\n            slots: one_local(echo(0.0)),\n            router: Box::new(FixedRouter(\"local\")),\n            oracle: Arc::new(PassOracle),             // correctness: no evidence\n            baseline: Some(Arc::new(EvidenceOracle)), // baseline: asserts — but must NOT count for #3\n            spine: Arc::new(RecSpine::default()),\n            memory: None,\n            trace_sink: None,\n            default_tier: \"local\".into(),\n            goldens: HashMap::new(),\n        })\n        .unwrap();\n        let mut s = step();\n        s.critical = true;\n        let out = engine.run(&mut s, &mut ctx(), req()).await.unwrap();\n        assert!(!out.verdict.passed, \"the baseline must not satisfy a critical step's #3\");\n        assert!(out.verdict.failures.iter().any(|f| f.contains(\"config fault\")));\n    }\n\n    #[tokio::test]\n    async fn critical_resolved_ref_with_no_assertion_config_faults() {\n        // resolving a ref is not asserting one: a critical step names a golden that RESOLVES, but the\n        // correctness oracle produces no evidence for it (as GoldenDispatchOracle does for a\n        // conformance-only family) → #3 config-faults, not a vacuous pass, and not the #2 path.\n        let mut goldens = HashMap::new();\n        goldens.insert(\"conf-only\".to_string(), GoldenCase { name: \"conf-only\".into(), input: json!({ \"usage\": {} }), expect: json!({}) });\n        let engine = Engine::new(EngineConfig {\n            slots: one_local(echo(0.0)),\n            router: Box::new(FixedRouter(\"local\")),\n            oracle: Arc::new(PassOracle), // mimics the dispatch skipping a conformance-only case: no evidence\n            baseline: None,\n            spine: Arc::new(RecSpine::default()),\n            memory: None,\n            trace_sink: None,\n            default_tier: \"local\".into(),\n            goldens,\n        })\n        .unwrap();\n        let mut s = step();\n        s.critical = true;\n        s.golden_refs = vec![\"conf-only\".into()]; // resolves (no #2), but yields no correctness assertion\n        let out = engine.run(&mut s, &mut ctx(), req()).await.unwrap();\n        assert!(!out.verdict.passed, \"resolved-but-unasserted ref on a critical step config-faults\");\n        assert!(out.verdict.failures.iter().any(|f| f.contains(\"config fault\")));\n        assert!(!out.verdict.failures.iter().any(|f| f.contains(\"unresolved golden_ref\")), \"the ref resolved — not the #2 path\");\n    }\n\n    #[tokio::test]\n    async fn the_failure_alarm_is_ascii() {\n        // the I5 alarm lands in the verdict, the checkpoint, and the ledger — it must render on any\n        // console/codepage. Drive both engine-authored failure paths and assert the strings are ASCII.\n        let engine = engine_with(one_local(echo(0.0)), Box::new(FixedRouter(\"local\")), Arc::new(PassOracle), Arc::new(RecSpine::default()), None, None);\n        let mut s = step();\n        s.golden_refs = vec![\"nope\".into()]; // #2 unresolved-ref alarm\n        for f in &engine.run(&mut s, &mut ctx(), req()).await.unwrap().verdict.failures {\n            assert!(f.is_ascii(), \"alarm must be ASCII: {f:?}\");\n        }\n        let mut s2 = step();\n        s2.critical = true; // #3 critical config-fault alarm\n        for f in &engine.run(&mut s2, &mut ctx(), req()).await.unwrap().verdict.failures {\n            assert!(f.is_ascii(), \"alarm must be ASCII: {f:?}\");\n        }\n    }\n}"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-kernel\src\engine.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:15

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:15

L5 wiring — split the oracle into a correctness surface (`GoldenDispatchOracle`, so refs assert) and the I3 baseline (no-SSN, excluded from #3):

## Claude — Jun 14, 2026 04:15

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel\\src\\lib.rs",
  "old_string": "use keel_services::{DifficultyRouter, PropertyOracle, Verifier};",
  "new_string": "use keel_services::{DifficultyRouter, GoldenDispatchOracle, PropertyOracle, Verifier};"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\lib.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:15

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel\\src\\lib.rs",
  "old_string": "        // I5: the externality registry as a composite Oracle, with the **default-oracle set** — a\n        // baseline non-model assertion on every output (no SSN-shaped span). A cell registers more\n        // (e.g., a `SchemaOracle` for the Director's Directive). The baseline means a critical turn\n        // always carries an assertion; the engine's critical-step guard catches an empty set anyway.\n        let mut verifier = Verifier::new();\n        verifier.register(Box::new(PropertyOracle::new(vec![\"no_ssn_pattern\".into()])));\n        let oracle: Arc<dyn Oracle> = Arc::new(verifier);",
  "new_string": "        // I5 CORRECTNESS oracle: the GoldenDispatchOracle makes a resolved `golden_ref` actually\n        // assert (schema/property family -> the matching oracle), with no cell pre-registration. A cell\n        // registers its domain oracles here too. This is what satisfies the critical-step guard (#3).\n        let mut correctness = Verifier::new();\n        correctness.register(Box::new(GoldenDispatchOracle));\n        let oracle: Arc<dyn Oracle> = Arc::new(correctness);\n        // I3 sovereignty BASELINE (no-SSN-on-output): always-on, folded into the verdict, but it NEVER\n        // counts for #3 (a privacy baseline is not a correctness oracle). STOPGAP until mw::privacy\n        // gains an output-side rung (Stage 2) — see EngineConfig.baseline.\n        let mut baseline_v = Verifier::new();\n        baseline_v.register(Box::new(PropertyOracle::new(vec![\"no_ssn_pattern\".into()])));\n        let baseline: Option<Arc<dyn Oracle>> = Some(Arc::new(baseline_v));"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\lib.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:15

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel\\src\\lib.rs",
  "old_string": "        let engine = KernelEngine::new(EngineConfig {\n            slots,\n            router,\n            oracle,\n            spine,\n            memory: None,\n            trace_sink: None,\n            default_tier: manifest.router.default_tier.clone(),\n            goldens,\n        })?;",
  "new_string": "        let engine = KernelEngine::new(EngineConfig {\n            slots,\n            router,\n            oracle,\n            baseline,\n            spine,\n            memory: None,\n            trace_sink: None,\n            default_tier: manifest.router.default_tier.clone(),\n            goldens,\n        })?;"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\lib.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:16

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:16

ASCII-safing the CLI's I5 alarm lines (and the adjacent footer, which sits right beside them):

## Claude — Jun 14, 2026 04:16

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel\\src\\main.rs",
  "old_string": "        if outcome.verdict.joint_wrong {\n            eprintln!(\"[keel] ⚠ JOINT_WRONG — {}\", outcome.verdict.failures.join(\"; \"));\n        } else if !outcome.verdict.passed {\n            eprintln!(\"[keel] ⚠ verify failed — {}\", outcome.verdict.failures.join(\"; \"));\n        }",
  "new_string": "        if outcome.verdict.joint_wrong {\n            eprintln!(\"[keel] !! JOINT_WRONG - {}\", outcome.verdict.failures.join(\"; \"));\n        } else if !outcome.verdict.passed {\n            eprintln!(\"[keel] !! verify FAILED - {}\", outcome.verdict.failures.join(\"; \"));\n        }"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\main.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:16

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel\\src\\main.rs",
  "old_string": "        \"— tier={} model={} cost=${:.4} tokens={}+{} · trace {} · audit→{}\",",
  "new_string": "        \"- tier={} model={} cost=${:.4} tokens={}+{} | trace {} | audit->{}\","
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\main.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:16

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:16

All code in. Running the gate — check first.

## Claude — Jun 14, 2026 04:16

**[tool: PowerShell]**
```json
{
  "command": "cargo check --workspace --all-targets 2>&1 | Select-Object -Last 12; \"----- CHECK EXIT: $LASTEXITCODE -----\"",
  "description": "Compile-check workspace with dispatch + baseline + #3 rework",
  "timeout": 600000
}
```
**[tool result]**
```
[31;1m    Checking keel-kernel v0.2.0 (C:\KEEL\crates\keel-kernel)[0m
[31;1m    Checking keel-services v0.2.0 (C:\KEEL\crates\keel-services)[0m
[31;1m    Checking keel-middleware v0.2.0 (C:\KEEL\crates\keel-middleware)[0m
[31;1m    Checking keel v0.2.0 (C:\KEEL\crates\keel)[0m
[31;1m    Finished `dev` profile [unoptimized + debuginfo] target(s) in 1.52s[0m
----- CHECK EXIT: 0 -----
```

## Claude — Jun 14, 2026 04:16

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:16

Check green. Clippy + tests (surfacing the new dispatch + #3 tests).

## Claude — Jun 14, 2026 04:16

**[tool: PowerShell]**
```json
{
  "command": "cargo clippy --workspace --all-targets 2>&1 | Select-Object -Last 5; \"----- CLIPPY EXIT: $LASTEXITCODE -----\"\ncargo test --workspace 2>&1 | Select-String -Pattern 'golden_dispatch|baseline_does_not|critical_resolved_ref|the_failure_alarm|test result:|error\\[|FAILED' ; \"----- TEST EXIT: $LASTEXITCODE -----\"",
  "description": "Clippy + tests; surface dispatch/baseline/#3/alarm tests",
  "timeout": 600000
}
```
**[tool result]**
```
[31;1m    Checking keel-kernel v0.2.0 (C:\KEEL\crates\keel-kernel)[0m
[31;1m    Checking keel-services v0.2.0 (C:\KEEL\crates\keel-services)[0m
[31;1m    Checking keel-middleware v0.2.0 (C:\KEEL\crates\keel-middleware)[0m
[31;1m    Checking keel v0.2.0 (C:\KEEL\crates\keel)[0m
[31;1m    Finished `dev` profile [unoptimized + debuginfo] target(s) in 1.63s[0m
----- CLIPPY EXIT: 0 -----

[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 16 passed; 0 failed; 3 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
test engine::tests::[7mcritical_resolved_ref[0m_with_no_assertion_config_faults ... ok
test engine::tests::[7mbaseline_does_not[0m_satisfy_critical_step ... ok
test engine::tests::[7mthe_failure_alarm[0m_is_ascii ... ok
[7mtest result:[0m ok. 32 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.32s
[7mtest result:[0m ok. 12 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s
test verifier::tests::[7mgolden_dispatch[0m_skips_conformance_only_family ... ok
test verifier::tests::[7mgolden_dispatch[0m_runs_property_family ... ok
test verifier::tests::[7mgolden_dispatch[0m_runs_schema_family ... ok
[7mtest result:[0m ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s
[7mtest result:[0m ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
----- TEST EXIT: 0 -----
```

## Claude — Jun 14, 2026 04:17

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:17

All green: **74 passed / 3 ignored** (kernel 29→32, services 7→10). The completion is proven by test — `golden_dispatch_runs_schema_family` (assert/reject via the ref), `golden_dispatch_skips_conformance_only_family`, `baseline_does_not_satisfy_critical_step` (#3 un-neutered), `critical_resolved_ref_with_no_assertion_config_faults` (Refinement 2), `the_failure_alarm_is_ascii`.

Now the **real-binary smoke** — all four directions, deterministic, with the ASCII alarm:

## Claude — Jun 14, 2026 04:17

**[tool: PowerShell]**
```json
{
  "command": "\"=== 1. plain (expect silent pass, NO alarm) ===\"\ncargo run --quiet --bin keel -- \"say hi in one word\" 2>&1 | Select-String -Pattern 'route:|tier=|FAILED|JOINT'\n\"`n=== 2. --critical, no ref (expect #3 config fault, baseline present) ===\"\ncargo run --quiet --bin keel -- --critical \"say hi in one word\" 2>&1 | Select-String -Pattern 'FAILED|JOINT|trace'\n\"`n=== 3. --critical --golden-ref <schema> (expect dispatch REJECT: non-JSON vs schema) ===\"\ncargo run --quiet --bin keel -- --critical --golden-ref \"tool call valid against schema under constrained decode\" \"say hi in one word\" 2>&1 | Select-String -Pattern 'FAILED|JOINT|trace'\n\"`n=== 4. --critical --golden-ref <conformance-only> (expect #3 config fault: resolved but unasserted) ===\"\ncargo run --quiet --bin keel -- --critical --golden-ref \"cost from usage + price (deepseek-v4-pro)\" \"say hi in one word\" 2>&1 | Select-String -Pattern 'FAILED|JOINT|trace'",
  "description": "Smoke all four directions in the real binary with the ASCII alarm",
  "timeout": 300000
}
```
**[tool result]**
```
=== 1. plain (expect silent pass, NO alarm) ===

[keel] [7mroute:[0m scaffolding → local
- [7mtier=[0mlocal model=qwen3.5-9b-q5_k_m cost=$0.0000 tokens=17+2 | trace 7a9051367fbb | audit->.keelstate/audit.jsonl

=== 2. --critical, no ref (expect #3 config fault, baseline present) ===
- tier=local model=qwen3.5-9b-q5_k_m cost=$0.0000 tokens=17+2 | [7mtrace[0m ede1e1684fa8 | audit->.keelstate/audit.jsonl
[keel] !! verify [7mFAILED [0m[7m[0m- [0m[7m[0mcritical [0m[7m[0mstep [0m[7m[0mwith [0m[7m[0mno [0m[7m[0mapplicable [0m[7m[0mcorrectness [0m[7m[0moracle [0m[7m[0m- [0m[7m[0mconfig [0m[7m[0mfault [0m[7m[0m(canon [0m[7m[0m8/10), [0m[7m[0mnot [0m[7m[0ma [0m
[7m[0mvacuous [0m[7m[0mpass[0m

=== 3. --critical --golden-ref <schema> (expect dispatch REJECT: non-JSON vs schema) ===
- tier=local model=qwen3.5-9b-q5_k_m cost=$0.0000 tokens=17+2 | [7mtrace[0m aef100cdbabb | audit->.keelstate/audit.jsonl
[keel] !! verify [7mFAILED [0m[7m[0m- [0m[7m[0mschema: [0m[7m[0moutput [0m[7m[0mis [0m[7m[0mnot [0m[7m[0mJSON [0m[7m[0m(expected [0m[7m[0mvalue [0m[7m[0mat [0m[7m[0mline [0m[7m[0m1 [0m[7m[0mcolumn [0m[7m[0m1) [0m[7m[0m- [0m[7m[0mrejected, [0m[7m[0mnever [0m[7m[0mpartially [0m
[7m[0mapplied[0m

=== 4. --critical --golden-ref <conformance-only> (expect #3 config fault: resolved but unasserted) ===
- tier=local model=qwen3.5-9b-q5_k_m cost=$0.0000 tokens=17+2 | [7mtrace[0m f9e36695d035 | audit->.keelstate/audit.jsonl
[keel] !! verify [7mFAILED [0m[7m[0m- [0m[7m[0mcritical [0m[7m[0mstep [0m[7m[0mwith [0m[7m[0mno [0m[7m[0mapplicable [0m[7m[0mcorrectness [0m[7m[0moracle [0m[7m[0m- [0m[7m[0mconfig [0m[7m[0mfault [0m[7m[0m(canon [0m[7m[0m8/10), [0m[7m[0mnot [0m[7m[0ma [0m
[7m[0mvacuous [0m[7m[0mpass[0m
```

## Claude — Jun 14, 2026 04:18

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:18

All four directions lived, with the **ASCII alarm** (`!! verify FAILED - ...`, no `⚠`/`→`/`—`):
1. plain (`7a9051367fbb`) → silent pass, no alarm.
2. `--critical` no-ref (`ede1e1684fa8`) → `config fault (canon 8/10)` **despite the no-SSN baseline** — #3 un-neutered.
3. `--critical --golden-ref <schema>` (`aef100cdbabb`) → `schema: output is not JSON ... - rejected` — the dispatch ran SchemaOracle **from a bare ref, no pre-registration**.
4. `--critical --golden-ref <conformance-only>` (`f9e36695d035`) → `config fault` — resolved-but-unasserted (Refinement 2).

Cross-correlating with the I2 checkpoints (failures are ASCII now, so they print safely):

## Claude — Jun 14, 2026 04:18

**[tool: PowerShell]**
```json
{
  "command": "@'\nimport sqlite3, json\nc = sqlite3.connect(r\".keelstate/index.db\")\nfor rid in (\"7a9051367fbb\",\"ede1e1684fa8\",\"aef100cdbabb\",\"f9e36695d035\"):\n    row = c.execute(\"select state from runs where run_id=?\", (rid,)).fetchone()\n    if not row:\n        print(rid, \"NO ROW\"); continue\n    s = json.loads(row[0]); v = s[\"verdict\"]\n    f0 = (v.get(\"failures\") or [\"(none)\"])[0]\n    ascii_ok = all(ord(ch) < 128 for f in v.get(\"failures\", []) for ch in f)\n    print(f\"{rid}: passed={v['passed']} critical={s['step']['critical']} refs={s['step']['golden_refs']} ascii_failures={ascii_ok} :: {f0[:64]}\")\n'@ | python -",
  "description": "Cross-correlate the 4 smoke verdicts in the I2 checkpoint; confirm ASCII failures"
}
```
**[tool result]**
```
7a9051367fbb: passed=True critical=False refs=[] ascii_failures=True :: (none)
ede1e1684fa8: passed=False critical=True refs=[] ascii_failures=True :: critical step with no applicable correctness oracle - config fau
aef100cdbabb: passed=False critical=True refs=['tool call valid against schema under constrained decode'] ascii_failures=True :: schema: output is not JSON (expected value at line 1 column 1) -
f9e36695d035: passed=False critical=True refs=['cost from usage + price (deepseek-v4-pro)'] ascii_failures=True :: critical step with no applicable correctness oracle - config fau
```

## Claude — Jun 14, 2026 04:18

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:18

Fully cross-correlated: all four CLI alarms match the persisted I2 verdicts, and **`ascii_failures=True` for every run** — the alarm is ASCII in print *and* in the record. The teeth-completion is lived across all four directions.

Now the doc fold — retiring the "resolver supplies cases but no oracle consumes them" caveat (now consumed by `GoldenDispatchOracle`). Locating every instance.

## Claude — Jun 14, 2026 04:18

**[tool: Grep]**
```json
{
  "pattern": "no oracle consumes|nothing consumes|resolver supplies|supplies the cases|consumes them yet|GoldenOracle that runs",
  "path": "C:\\KEEL\\_run_state",
  "output_mode": "content",
  "-n": true,
  "glob": "{STATE.md,WAKE_UP_part4.md}"
}
```
**[tool result]**
```
_run_state\WAKE_UP_part4.md:27:[Omitted long matching line]
_run_state\WAKE_UP_part4.md:49:- ✅ **RESOLVED — per-turn `verify` now bites.** The default-oracle set (no-SSN) + the `golden_refs`→`GoldenCase` resolver landed (Half B): an unresolved ref / a critical step with no applicable oracle fail-closed; a plain turn passes silently. *Open (deeper):* no oracle consumes the resolved cases yet — a `GoldenOracle` that runs them is the next refinement.
_run_state\STATE.md:33:[Omitted long matching line]
_run_state\STATE.md:46:[Omitted long matching line]
```

## Claude — Jun 14, 2026 04:19

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:19

Reading the exact caveat text before closing each.

## Claude — Jun 14, 2026 04:19

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\_run_state\\WAKE_UP_part4.md",
  "offset": 27,
  "limit": 1
}
```
**[tool result]**
```
27	- **I5 externalized** — ✅ **wired in the loop + governance-gate active.** `kernel::engine` calls `Oracle::verify` every turn (the `Verifier` is injected as a composite `Oracle`); `oracle_failures`/`tier_history` feed back so the escalation ladder fires across turns; the **freeze-gate** guards the goldens themselves. **I5 bites (2026-06-14):** a default no-SSN oracle runs on every output; the `golden_refs`→`GoldenCase` resolver is wired; an unresolved `golden_ref` and a `critical` step with no applicable oracle both **fail-closed** (canon §8/§10). A plain non-critical no-ref chat turn still passes silently (no false alarm). *Deeper still:* the resolver supplies cases but no oracle consumes them yet (a future `GoldenOracle`).
```

## Claude — Jun 14, 2026 04:19

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\_run_state\\STATE.md",
  "offset": 33,
  "limit": 1
}
```
**[tool result]**
```
33	- **Stage 2 (Half A + Half B) — constrained-decode conformance + I5 teeth in the loop** (2026-06-14): **Half A** — `GOLDEN_MODEL_TIER` green (`passes_golden_model_tier`: cost · schema→`json_schema` decode · reasoning replay) + the **`SchemaOracle`** (the Director's "schema-valid Directive or reject" gate; `jsonschema` w/ `default-features=off` → no network/TLS/cmake, no egress; **draft pinned to 2020-12**, not auto-detected; the load-bearing rejection is tested). **Half B** — the **default-oracle set** (baseline no-SSN on every output) + the **`golden_refs`→`GoldenCase` resolver** in `kernel::engine` (over an injected `EngineConfig`), so `verify` now **bites**: an unresolved `golden_ref` **fails-closed** (→ operator); a `critical` step with no applicable oracle is a **config fault** (canon §8/§10); a plain non-critical no-ref turn still **passes silently** (no false alarm). CLI gained `--critical`/`--golden-ref` (L5 only). **Lived end-to-end**: `keel --critical --golden-ref does-not-exist …` → fail-closed `⚠` *and* the failing verdict persisted in the I2 checkpoint (`run_id a9dd5f3c15eb`, `passed=false`); a plain turn → silent pass. **68 green / 3 ignored**, clippy clean, **zero contract/golden edits, freeze seal unmoved**. *Open (deeper I5):* the resolver supplies the cases but no oracle consumes them yet — a `GoldenOracle` that runs them is the next refinement.
```

## Claude — Jun 14, 2026 04:19

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\_run_state\\STATE.md",
  "offset": 46,
  "limit": 1
}
```
**[tool result]**
```
46	- ~~**Stage 1: `DifficultyRouter`** + **wire the engine**~~ ✓ · ~~**`svc::verifier`** (I5 externality — `GOLDEN_ORACLE` green)~~ ✓ · ~~**`kernel::engine` (L1)** — the real loop over injected joints; I5/I4/I2 wired live; L5→L1 debt paid~~ ✓ · ~~**I5 freeze-gate** — operator re-stamped KEEL-native (`db4377b3…`) + un-ignored; `goldens_match_the_frozen_hash` green~~ ✓ · ~~**Half A: constrained-decode conformance** — `GOLDEN_MODEL_TIER` green + the `SchemaOracle` (draft-pinned 2020-12; rejection-tested)~~ ✓ · ~~**Half B: I5 teeth** — default-oracle set + `golden_refs`→`GoldenCase` resolver + the 3 hardenings (unresolved-ref fail-closed · critical-no-oracle config-fault · read-only `HashMap` registry) + `EngineConfig`; lived end-to-end~~ ✓ (all 2026-06-14). **Next, any order:** `mw::metrics` (`escalation_rate`/`rework_rate` — sizes the flywheel base case) · `svc::memory` (the ringed Tape — fills the injected `Memory`/`TraceSink` seams; design against `docs/proposals/perpetual-memory.md`, the canon's flagged **highest-risk seam**) · perception (eyes + ears) · config-from-`keel.lock` cleanup · `amplify` (best-of-N — **ships OFF**, §23). **Deeper I5 (when useful):** a `GoldenOracle` that runs the resolved cases (the resolver provides them; nothing consumes them yet) · `serve` parity for `critical`/`golden_ref`. **No operator-pending items.**
```

## Claude — Jun 14, 2026 04:19

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:19

Closing the caveat in WAKE_UP §4.2 and §4.4:

## Claude — Jun 14, 2026 04:20

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\_run_state\\WAKE_UP_part4.md",
  "old_string": " *Deeper still:* the resolver supplies cases but no oracle consumes them yet (a future `GoldenOracle`).",
  "new_string": " **Closed 2026-06-14:** the `GoldenDispatchOracle` now *consumes* the resolved cases — a named `golden_ref` asserts by family (schema→`SchemaOracle`, property→`PropertyOracle`; conformance-only goldens stay test-time). #3 keys off **correctness** evidence only; the no-SSN baseline is reclassified as an **I3 sovereignty stopgap** that never satisfies a critical step."
}
```
**[tool result]**
```
The file C:\KEEL\_run_state\WAKE_UP_part4.md has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:20

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\_run_state\\WAKE_UP_part4.md",
  "old_string": " *Open (deeper):* no oracle consumes the resolved cases yet — a `GoldenOracle` that runs them is the next refinement.",
  "new_string": " ✅ **Closed 2026-06-14:** the `GoldenDispatchOracle` consumes the resolved cases (a named ref asserts by family); #3 keys off **correctness** evidence (the no-SSN baseline is an I3 stopgap, excluded); the I5 alarm is ASCII (print + persisted)."
}
```
**[tool result]**
```
The file C:\KEEL\_run_state\WAKE_UP_part4.md has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:20

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:20

Closing it in STATE.md, adding the named-gate-completion bullet, and updating Next:

## Claude — Jun 14, 2026 04:20

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\_run_state\\STATE.md",
  "old_string": " *Open (deeper I5):* the resolver supplies the cases but no oracle consumes them yet — a `GoldenOracle` that runs them is the next refinement.",
  "new_string": " *(The deeper-I5 gap — an oracle consuming the resolved cases — is **closed** by the named-gate-completion slice below.)*"
}
```
**[tool result]**
```
The file C:\KEEL\_run_state\STATE.md has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:20

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\_run_state\\STATE.md",
  "old_string": "- **Golden cases**: ratified + **FROZEN** (`tests/golden/golden.json` + `.frozen.json`, 21 cases / 6 sections). Language-neutral conformance; **agent read-only**.",
  "new_string": "- **Stage 2 (named-gate completion) — resolved refs assert · #3 un-neutered · ASCII alarm** (2026-06-14): the **`GoldenDispatchOracle`** (L4) **consumes** the resolved `golden_ref` cases and dispatches by **family** (schema→`SchemaOracle`, property→`PropertyOracle`; conformance-only goldens stay **test-time**, assert nothing) — so a **bare `--golden-ref <schema-golden>` now gates** with no cell pre-registration (the Director's gate is usable directly). **#3 un-neutered:** the no-SSN baseline moved to `EngineConfig.baseline` — an **I3 sovereignty stopgap** (always-on, but **excluded from #3**; STOPGAP until the privacy-rung slice re-homes it as an output-side I3 check). A `critical` step now needs a **correctness** assertion (a resolved-and-fired ref, or a domain oracle), so a critical step with no ref — or a ref to a conformance-only golden (resolving ≠ asserting) — **config-faults** even with the baseline present. The **I5 alarm is ASCII** (`!! verify FAILED - …`), in print **and** the persisted `verdict.failures` (checkpoint + ledger). **Lived end-to-end** (4 traces cross-correlated with the I2 checkpoint): plain → silent · `--critical` no-ref → config fault · `--critical --golden-ref <schema>` → schema-reject *via the ref* · `--critical --golden-ref <conformance-only>` → config fault. **74 green / 3 ignored**, clippy clean, **zero contract/golden edits, freeze seal unmoved**. *Minor follow-ups:* `serve` parity for `critical`/`golden_ref`; the route-reason `→` in the CLI footer is a cosmetic non-alarm print.\n- **Golden cases**: ratified + **FROZEN** (`tests/golden/golden.json` + `.frozen.json`, 21 cases / 6 sections). Language-neutral conformance; **agent read-only**."
}
```
**[tool result]**
```
The file C:\KEEL\_run_state\STATE.md has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:20

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\_run_state\\STATE.md",
  "old_string": "~~**Half B: I5 teeth** — default-oracle set + `golden_refs`→`GoldenCase` resolver + the 3 hardenings (unresolved-ref fail-closed · critical-no-oracle config-fault · read-only `HashMap` registry) + `EngineConfig`; lived end-to-end~~ ✓ (all 2026-06-14). **Next, any order:** `mw::metrics` (`escalation_rate`/`rework_rate` — sizes the flywheel base case) · `svc::memory` (the ringed Tape — fills the injected `Memory`/`TraceSink` seams; design against `docs/proposals/perpetual-memory.md`, the canon's flagged **highest-risk seam**) · perception (eyes + ears) · config-from-`keel.lock` cleanup · `amplify` (best-of-N — **ships OFF**, §23). **Deeper I5 (when useful):** a `GoldenOracle` that runs the resolved cases (the resolver provides them; nothing consumes them yet) · `serve` parity for `critical`/`golden_ref`. **No operator-pending items.**",
  "new_string": "~~**Half B: I5 teeth** — default-oracle set + `golden_refs`→`GoldenCase` resolver + the 3 hardenings + `EngineConfig`~~ ✓ · ~~**named-gate completion** — `GoldenDispatchOracle` (resolved refs assert by family) · #3 un-neutered (baseline = I3 stopgap, excluded) · ASCII alarm (print + persisted); lived end-to-end~~ ✓ (all 2026-06-14). **Next, any order:** `mw::metrics` (`escalation_rate`/`rework_rate` — the instrument to size the flat-escalation base case; can't size to flat without measuring it) · `svc::memory` (the ringed Tape — fills the injected `Memory`/`TraceSink` seams; design **most skeptically** against `docs/proposals/perpetual-memory.md`, the canon's flagged **highest-risk seam**) · perception (eyes + ears) · config-from-`keel.lock` cleanup · `amplify` (best-of-N — **ships OFF**, §23). **Minor follow-ups:** `serve` parity for `critical`/`golden_ref` · ASCII-safe the router's route-reason `→` (cosmetic, non-alarm) · re-home the no-SSN baseline into an I3 output rung at the privacy-rung slice. **No operator-pending items.**"
}
```
**[tool result]**
```
The file C:\KEEL\_run_state\STATE.md has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 04:20

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:20

WAKE_UP part4 changed — re-stitching and verifying the caveat is closed everywhere.

## Claude — Jun 14, 2026 04:20

**[tool: PowerShell]**
```json
{
  "command": "$d = \"C:\\KEEL\\_run_state\"\n$parts = 1..5 | ForEach-Object { Join-Path $d \"WAKE_UP_part$_.md\" }\n$content = -join ($parts | ForEach-Object { Get-Content -Raw -Encoding utf8 $_ })\n[System.IO.File]::WriteAllText((Join-Path $d \"WAKE_UP.md\"), $content, (New-Object System.Text.UTF8Encoding($false)))\n$sum = 0; $parts | ForEach-Object { $sum += (Get-Content $_).Count }\n\"sum(parts)=$sum  WAKE_UP.md=$((Get-Content (Join-Path $d 'WAKE_UP.md')).Count)\"\n\"`n=== stale 'no oracle consumes / nothing consumes / supplies the cases' remaining? (expect none) ===\"\n$stale = Select-String -Path (Join-Path $d \"WAKE_UP.md\"),(Join-Path $d \"STATE.md\") -Pattern 'no oracle consumes|nothing consumes|supplies the cases|consumes them yet'\nif ($stale) { $stale | ForEach-Object { \"STALE: $($_.Filename):$($_.LineNumber)\" } } else { \"clean — caveat retired\" }",
  "description": "Re-stitch WAKE_UP and verify the caveat is retired"
}
```
**[tool result]**
```
sum(parts)=297  WAKE_UP.md=297

=== stale 'no oracle consumes / nothing consumes / supplies the cases' remaining? (expect none) ===
clean — caveat retired
```

## Claude — Jun 14, 2026 04:20

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:20

Faithful (297=297), caveat retired. Banking the slice locally. Checking the change set + guarding contracts/goldens.

## Claude — Jun 14, 2026 04:21

**[tool: PowerShell]**
```json
{
  "command": "\"=== changed files ===\"\ngit -C C:\\KEEL status --short\n\"`n=== guard: contracts + goldens untouched (expect empty) ===\"\n$bad = git -C C:\\KEEL status --short -- crates/keel-contracts tests/golden\nif ($bad) { \"VIOLATION:\"; $bad } else { \"clean — contracts + goldens untouched\" }",
  "description": "Inspect change set; guard contracts/goldens"
}
```
**[tool result]**
```
=== changed files ===
 M _run_state/STATE.md
 M _run_state/WAKE_UP.md
 M _run_state/WAKE_UP_part4.md
 M crates/keel-kernel/src/engine.rs
 M crates/keel-services/src/lib.rs
 M crates/keel-services/src/verifier.rs
 M crates/keel/src/lib.rs
 M crates/keel/src/main.rs

=== guard: contracts + goldens untouched (expect empty) ===
clean — contracts + goldens untouched
```

## Claude — Jun 14, 2026 04:21

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:21

Change set is exactly the slice (8 files), contracts/goldens untouched, no new deps. Staging + secret-scanning.

## Claude — Jun 14, 2026 04:21

**[tool: PowerShell]**
```json
{
  "command": "git -C C:\\KEEL add crates/keel-kernel/src/engine.rs crates/keel-services/src/lib.rs crates/keel-services/src/verifier.rs crates/keel/src/lib.rs crates/keel/src/main.rs _run_state/STATE.md _run_state/WAKE_UP.md _run_state/WAKE_UP_part4.md\n\"=== staged ===\"\ngit -C C:\\KEEL diff --cached --name-only\n\"`n=== secret check on staged diff ===\"\n$hits = git -C C:\\KEEL diff --cached | Select-String -Pattern 'sk-(ant-)?[A-Za-z0-9_-]{24,}|AKIA[0-9A-Z]{16}'\nif ($hits) { \"ABORT:\"; $hits } else { \"CLEAN — no key-shaped strings.\" }",
  "description": "Stage the slice and scan staged diff for secrets"
}
```
**[tool result]**
```
warning: in the working copy of '_run_state/STATE.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of '_run_state/WAKE_UP.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of '_run_state/WAKE_UP_part4.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'crates/keel-kernel/src/engine.rs', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'crates/keel-services/src/lib.rs', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'crates/keel-services/src/verifier.rs', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'crates/keel/src/lib.rs', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'crates/keel/src/main.rs', LF will be replaced by CRLF the next time Git touches it
=== staged ===
_run_state/STATE.md
_run_state/WAKE_UP.md
_run_state/WAKE_UP_part4.md
crates/keel-kernel/src/engine.rs
crates/keel-services/src/lib.rs
crates/keel-services/src/verifier.rs
crates/keel/src/lib.rs
crates/keel/src/main.rs

=== secret check on staged diff ===
CLEAN — no key-shaped strings.
```

## Claude — Jun 14, 2026 04:21

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:21

Staged (8 files), secret CLEAN. Committing the slice **locally** — push held for your review.

## Claude — Jun 14, 2026 04:21

**[tool: PowerShell]**
```json
{
  "command": "@'\nStage 2 (named-gate completion): resolved refs assert + #3 un-neutered + ASCII alarm\n\nCloses the I5 loop honestly -- the resolver plumbed cases; now they assert.\n\n1. GoldenDispatchOracle (L4): consumes the resolved golden_ref cases and\n   dispatches by KNOWN family -- schema -> SchemaOracle, property ->\n   PropertyOracle, conformance-only (cost/usage, self_tests_pass) -> asserts\n   nothing (test-time goldens, not runtime gates). A bare\n   --golden-ref <schema-golden> now gates with no cell pre-registration.\n\n2. #3 un-neutered: the no-SSN baseline moved to EngineConfig.baseline -- an I3\n   sovereignty STOPGAP (mw::privacy masks only on egress, so a LOCAL turn's\n   output PII is otherwise unguarded), always-on but EXCLUDED from #3. A critical\n   step now needs a CORRECTNESS assertion (a resolved-and-fired ref or a domain\n   oracle); a critical step with no ref -- or a ref to a conformance-only golden\n   (resolving != asserting) -- config-faults even with the baseline present.\n\n3. ASCII alarm: the I5 verify-failure strings (engine #2/#3, the oracles, the CLI\n   line) are ASCII in print AND in the persisted verdict.failures (checkpoint +\n   ledger) -- the one alarm that must never be eaten by a console.\n\nLived end-to-end (4 traces cross-correlated with the I2 checkpoint, ascii\nfailures confirmed): plain -> silent; --critical no-ref -> config fault;\n--critical --golden-ref <schema> -> schema-reject via the ref; --critical\n--golden-ref <conformance-only> -> config fault. +6 tests -> 74 green / 3 ignored;\nclippy clean; zero contract/golden edits; freeze seal unmoved.\n\nDoc fold: retires the WAKE_UP §4.2/§4.4 + STATE.md \"resolver supplies cases but\nno oracle consumes them\" caveat; baseline documented as an I3 stopgap; WAKE_UP\nre-stitched (297=297). Minor follow-ups: serve parity for critical/golden_ref;\nroute-reason arrow is cosmetic; re-home the baseline to an I3 output rung later.\n\nCo-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>\n'@ | git -C C:\\KEEL commit -F -\n\"----- COMMIT EXIT: $LASTEXITCODE -----\"\n\"`n=== log (top 3) — NOT pushed ===\"\ngit -C C:\\KEEL log --oneline -3\ngit -C C:\\KEEL status -sb | Select-Object -First 1",
  "description": "Commit the named-gate-completion slice locally; confirm unpushed"
}
```
**[tool result]**
```
[main 4dec51f] Stage 2 (named-gate completion): resolved refs assert + #3 un-neutered + ASCII alarm
 8 files changed, 214 insertions(+), 36 deletions(-)
----- COMMIT EXIT: 0 -----

=== log (top 3) — NOT pushed ===
4dec51f Stage 2 (named-gate completion): resolved refs assert + #3 un-neutered + ASCII alarm
03d9d10 Stage 2 (Half B): I5 teeth — golden_refs resolver + default-oracle set + 3 hardenings
e3b482a Stage 2 (Half A): constrained-decode conformance — model_tier golden green + SchemaOracle

## main...origin/main [ahead 1]
```

## Claude — Jun 14, 2026 04:21

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:21

Banked: `4dec51f` (ahead 1, unpushed). Review packet below — **push held for your go.**

## Claude — Jun 14, 2026 04:21

<!-- end chunk 8/9 | next: chunk-009.md -->
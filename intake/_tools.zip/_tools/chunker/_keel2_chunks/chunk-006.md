<!-- ============ CHUNK 6/9 ============ -->
<!-- source: You_are_continuing_the_build_of_KEEL_Bo_Chen_s_personal_sovereign_reusable_AI-harness_.md -->
<!-- section: Next slice — proposal: constrained-decode conformance + I5 teeth > Claude — Jun 14, 2026 02:59 -->
<!-- recap: last ~89 tokens of chunk 5, for continuity -->
> ## Claude — Jun 14, 2026 02:59
> 
> > _[thinking]_
> > 
> 
> ## Claude — Jun 14, 2026 02:59
> 
> Now the load-bearing tests in verifier.rs — the **rejection test** (hardening #1: missing-required AND wrong-type → rejected) plus the golden-driven case-[1] enforcement:
> 
> ## Claude — Jun 14, 2026 02:59
<!-- end recap | new content begins -->

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs",
  "old_string": "        assert!(v.verify(&jw, &[], &Context::default()).await.unwrap().joint_wrong);\n    }\n}",
  "new_string": "        assert!(v.verify(&jw, &[], &Context::default()).await.unwrap().joint_wrong);\n    }\n\n    /// The Director's gate (canon §17): a conformant Directive validates; a malformed one is\n    /// **rejected, never partially applied.** The rejection case is load-bearing — a validator that\n    /// accepts everything passes the accept-case trivially, so we prove it *catches the bad*.\n    #[tokio::test]\n    async fn schema_oracle_validates_and_rejects() {\n        // a Director-shaped Directive schema: required action(string) + bounded intensity(int 0..10).\n        let schema = json!({\n            \"type\": \"object\",\n            \"required\": [\"action\", \"intensity\"],\n            \"properties\": {\n                \"action\": { \"type\": \"string\" },\n                \"intensity\": { \"type\": \"integer\", \"minimum\": 0, \"maximum\": 10 }\n            },\n            \"additionalProperties\": false\n        });\n        let oracle = SchemaOracle::new(schema);\n        let ctx = Context::default();\n\n        // conformant Directive → accepted\n        let good = StepOutput { content: String::new(), artifact: json!({ \"action\": \"spawn\", \"intensity\": 7 }) };\n        assert!(oracle.verify(&good, &[], &ctx).await.unwrap().passed, \"conformant Directive must validate\");\n\n        // LOAD-BEARING: malformed — missing required `action` AND wrong-typed `intensity` — must be\n        // REJECTED (invalid, never partially applied), with the violations listed.\n        let bad = StepOutput { content: String::new(), artifact: json!({ \"intensity\": \"high\" }) };\n        let v = oracle.verify(&bad, &[], &ctx).await.unwrap();\n        assert!(!v.passed, \"malformed Directive must be rejected\");\n        assert!(!v.failures.is_empty(), \"rejection must list the violations\");\n\n        // a value the schema forbids (out-of-range + extra prop) → also rejected\n        let oob = StepOutput { content: String::new(), artifact: json!({ \"action\": \"x\", \"intensity\": 99, \"extra\": true }) };\n        assert!(!oracle.verify(&oob, &[], &ctx).await.unwrap().passed, \"out-of-range / extra-prop must be rejected\");\n\n        // content path: non-JSON output with a null artifact → fail-closed (cannot validate ⇒ reject).\n        let nonjson = StepOutput { content: \"not json at all\".into(), artifact: Value::Null };\n        assert!(!oracle.verify(&nonjson, &[], &ctx).await.unwrap().passed, \"non-JSON output fails closed\");\n    }\n\n    /// GOLDEN_MODEL_TIER case [1], verify side: the golden's schema validates a conformant tool-call\n    /// (`tool_call_valid_against_schema: true`) and rejects one that violates it. (The decode side —\n    /// schema → llama-server `json_schema` — is asserted in keel-adapters `passes_golden_model_tier`.)\n    #[tokio::test]\n    async fn golden_model_tier_schema_is_enforced() {\n        let path = concat!(env!(\"CARGO_MANIFEST_DIR\"), \"/../../tests/golden/golden.json\");\n        let raw = std::fs::read_to_string(path).expect(\"read golden.json\");\n        let golden: Value = serde_json::from_str(&raw).expect(\"parse golden.json\");\n        let cases = golden[\"model_tier\"].as_array().expect(\"model_tier cases\");\n        let schema = cases\n            .iter()\n            .find_map(|c| c[\"input\"].get(\"schema\").cloned())\n            .expect(\"a model_tier case carrying a schema\");\n\n        let oracle = SchemaOracle::new(schema);\n        let ctx = Context::default();\n        // conformant to {required:[path], properties:{path:string}} → valid\n        let good = StepOutput { content: String::new(), artifact: json!({ \"path\": \"/etc/hosts\" }) };\n        assert!(oracle.verify(&good, &[], &ctx).await.unwrap().passed, \"conformant tool-call must validate\");\n        // missing required `path` → rejected\n        let bad = StepOutput { content: String::new(), artifact: json!({ \"wrong\": 1 }) };\n        assert!(!oracle.verify(&bad, &[], &ctx).await.unwrap().passed, \"non-conformant tool-call must be rejected\");\n    }\n}"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-services\src\verifier.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 02:59

> _[thinking]_
> 

## Claude — Jun 14, 2026 02:59

Now the adapter-side conformance — `passes_golden_model_tier` in local_llama.rs covering all three cases model-free (cost, decode-hook, reasoning replay):

## Claude — Jun 14, 2026 03:00

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-adapters\\src\\local_llama.rs",
  "old_string": "    #[test]\n    fn caps_report_vision() {\n        assert!(tier().caps().vision);\n    }\n\n    /// Live end-to-end against a running llama-server. Run with:",
  "new_string": "    #[test]\n    fn caps_report_vision() {\n        assert!(tier().caps().vision);\n    }\n\n    /// GOLDEN_MODEL_TIER conformance (model-free; the live model is the `#[ignore]` test below).\n    /// Covers the adapter/cost/decode side of the three frozen cases; the schema *validation* side of\n    /// case [1] (the SchemaOracle) lives in keel-services `golden_model_tier_schema_is_enforced`.\n    #[test]\n    fn passes_golden_model_tier() {\n        let path = concat!(env!(\"CARGO_MANIFEST_DIR\"), \"/../../tests/golden/golden.json\");\n        let raw = std::fs::read_to_string(path).expect(\"read golden.json\");\n        let golden: Value = serde_json::from_str(&raw).expect(\"parse golden.json\");\n        let cases = golden[\"model_tier\"].as_array().expect(\"model_tier cases\");\n        assert!(!cases.is_empty());\n\n        for case in cases {\n            let name = case[\"name\"].as_str().unwrap_or(\"?\");\n            let input = &case[\"input\"];\n            let expect = &case[\"expect\"];\n\n            // case [0] — cost from usage + price (compute_cost is the non-model arithmetic oracle).\n            if let (Some(u), Some(p)) = (input.get(\"usage\"), input.get(\"price\")) {\n                let usage = keel_contracts::Usage {\n                    input_tokens: u[\"input_tokens\"].as_u64().unwrap_or(0),\n                    output_tokens: u[\"output_tokens\"].as_u64().unwrap_or(0),\n                    cache_hit_tokens: u[\"cache_hit_tokens\"].as_u64().unwrap_or(0),\n                };\n                let price = Price {\n                    input_miss: p[\"input_miss\"].as_f64().unwrap_or(0.0),\n                    input_hit: p[\"input_hit\"].as_f64().unwrap_or(0.0),\n                    output: p[\"output\"].as_f64().unwrap_or(0.0),\n                };\n                let cost = keel_contracts::compute_cost(&usage, &price);\n                let want = expect[\"cost\"].as_f64().expect(\"expect.cost\");\n                let tol = expect[\"tol\"].as_f64().unwrap_or(1e-9);\n                assert!((cost - want).abs() <= tol, \"case '{name}': cost {cost} vs {want} (tol {tol})\");\n            }\n\n            // case [1] — constrained decode: a JSON schema must reach llama-server's `json_schema`\n            // field (the decode-time constraint). The validation side is the SchemaOracle (services).\n            if let Some(schema) = input.get(\"schema\") {\n                let body = tier()\n                    .build_body(&req_text(\"call the tool\", Effort::default(), Some(schema.clone())))\n                    .unwrap();\n                assert_eq!(&body[\"json_schema\"], schema, \"case '{name}': schema must reach the decode constraint\");\n                assert!(\n                    expect[\"tool_call_valid_against_schema\"].as_bool().unwrap_or(false),\n                    \"case '{name}': golden asserts schema validity\"\n                );\n            }\n\n            // case [2] — reasoning_content must survive a tool round-trip (replayed, or providers 400).\n            if input.get(\"two_turn_thinking\").and_then(|v| v.as_bool()).unwrap_or(false) {\n                let assistant = Message {\n                    role: Role::Assistant,\n                    content: vec![Content::Text { text: \"partial\".into() }],\n                    name: None,\n                    reasoning_content: Some(\"chain-of-thought\".into()),\n                    tool_call_id: None,\n                };\n                let req = GenerateRequest {\n                    messages: vec![assistant],\n                    model: \"m\".into(),\n                    tools: vec![],\n                    grammar: None,\n                    effort: Effort::default(),\n                    cache_prefix_len: None,\n                };\n                let body = base_body(&req, \"m\", 256).unwrap();\n                assert_eq!(\n                    body[\"messages\"][0][\"reasoning_content\"].as_str(),\n                    Some(\"chain-of-thought\"),\n                    \"case '{name}': reasoning_content must be replayed (no 400)\"\n                );\n                assert!(expect[\"reasoning_content_preserved\"].as_bool().unwrap_or(false));\n                assert!(expect[\"no_400\"].as_bool().unwrap_or(false));\n            }\n        }\n    }\n\n    /// Live end-to-end against a running llama-server. Run with:"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-adapters\src\local_llama.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 03:00

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:00

All Half-A code is in. Running the gate — `cargo check` first (this will confirm the `jsonschema` API calls compile).

## Claude — Jun 14, 2026 03:00

**[tool: PowerShell]**
```json
{
  "command": "cargo check --workspace --all-targets 2>&1 | Select-Object -Last 20; \"----- CHECK EXIT: $LASTEXITCODE -----\"",
  "description": "Compile-check the workspace with SchemaOracle + conformance tests",
  "timeout": 600000
}
```
**[tool result]**
```
[31;1m    Checking fluent-uri v0.4.1[0m
[31;1m    Checking serde_urlencoded v0.7.1[0m
[31;1m    Checking email_address v0.2.9[0m
[31;1m    Checking axum v0.8.9[0m
[31;1m    Checking hashbrown v0.14.5[0m
[31;1m    Checking tower-http v0.6.11[0m
[31;1m    Checking referencing v0.46.5[0m
[31;1m    Checking reqwest v0.12.28[0m
[31;1m    Checking hashlink v0.9.1[0m
[31;1m    Checking keel-kernel v0.2.0 (C:\KEEL\crates\keel-kernel)[0m
[31;1m    Checking rusqlite v0.32.1[0m
[31;1m    Checking keel-adapters v0.2.0 (C:\KEEL\crates\keel-adapters)[0m
[31;1m    Checking keel-store v0.2.0 (C:\KEEL\crates\keel-store)[0m
[31;1m    Checking regex v1.12.4[0m
[31;1m    Checking fancy-regex v0.18.0[0m
[31;1m    Checking keel-middleware v0.2.0 (C:\KEEL\crates\keel-middleware)[0m
[31;1m    Checking jsonschema v0.46.5[0m
[31;1m    Checking keel-services v0.2.0 (C:\KEEL\crates\keel-services)[0m
[31;1m    Checking keel v0.2.0 (C:\KEEL\crates\keel)[0m
[31;1m    Finished `dev` profile [unoptimized + debuginfo] target(s) in 8.11s[0m
----- CHECK EXIT: 0 -----
```

## Claude — Jun 14, 2026 03:00

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:00

`cargo check` green — the `jsonschema` API (`validator_for` + `iter_errors`) compiles, and the `reqwest 0.12` shown is keel-adapters' existing HTTP client, not jsonschema's (the lean config held). Now clippy and tests.

## Claude — Jun 14, 2026 03:00

**[tool: PowerShell]**
```json
{
  "command": "cargo clippy --workspace --all-targets 2>&1 | Select-Object -Last 8; \"----- CLIPPY EXIT: $LASTEXITCODE -----\"",
  "description": "Run clippy across the workspace",
  "timeout": 600000
}
```
**[tool result]**
```
[31;1m    Checking keel-contracts v0.2.0 (C:\KEEL\crates\keel-contracts)[0m
[31;1m    Checking keel-kernel v0.2.0 (C:\KEEL\crates\keel-kernel)[0m
[31;1m    Checking keel-services v0.2.0 (C:\KEEL\crates\keel-services)[0m
[31;1m    Checking keel-store v0.2.0 (C:\KEEL\crates\keel-store)[0m
[31;1m    Checking keel-adapters v0.2.0 (C:\KEEL\crates\keel-adapters)[0m
[31;1m    Checking keel-middleware v0.2.0 (C:\KEEL\crates\keel-middleware)[0m
[31;1m    Checking keel v0.2.0 (C:\KEEL\crates\keel)[0m
[31;1m    Finished `dev` profile [unoptimized + debuginfo] target(s) in 3.59s[0m
----- CLIPPY EXIT: 0 -----
```

## Claude — Jun 14, 2026 03:00

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:00

Clippy clean. Now the test suite — surfacing the new conformance + SchemaOracle tests, the freeze gate, and the result tallies.

## Claude — Jun 14, 2026 03:00

**[tool: PowerShell]**
```json
{
  "command": "cargo test --workspace 2>&1 | Select-String -Pattern 'passes_golden_model_tier|schema_oracle|golden_model_tier_schema|goldens_match_the_frozen_hash|test result:|error\\[|warning:|FAILED' ; \"----- TEST EXIT: $LASTEXITCODE -----\"",
  "description": "Run workspace tests; surface the new + conformance test lines",
  "timeout": 600000
}
```
**[tool result]**
```
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
test local_llama::tests::[7mpasses_golden_model_tier[0m ... ok
[7mtest result:[0m ok. 16 passed; 0 failed; 3 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
test [7mgoldens_match_the_frozen_hash[0m ... ok
[7mtest result:[0m ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 24 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.30s
[7mtest result:[0m ok. 12 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.03s
test verifier::tests::[7mgolden_model_tier_schema[0m_is_enforced ... ok
test verifier::tests::[7mschema_oracle[0m_validates_and_rejects ... ok
[7mtest result:[0m ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s
[7mtest result:[0m ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
----- TEST EXIT: 0 -----
```

## Claude — Jun 14, 2026 03:01

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:01

All green: **62 passed / 3 ignored**. The new tests are all there — `passes_golden_model_tier` (adapters 15→16), `schema_oracle_validates_and_rejects` + `golden_model_tier_schema_is_enforced` (services 4→6), and `goldens_match_the_frozen_hash` still green (goldens untouched). No warnings/errors.

Verifying the change set, layer-cleanliness, and no contract/golden edits before banking.

## Claude — Jun 14, 2026 03:01

**[tool: PowerShell]**
```json
{
  "command": "\"=== changed files ===\"\ngit -C C:\\KEEL status --short\n\"`n=== diff stat ===\"\ngit -C C:\\KEEL diff --stat\n\"`n=== guard: NO contract or golden edits (expect empty) ===\"\n$bad = git -C C:\\KEEL status --short -- crates/keel-contracts tests/golden\nif ($bad) { \"VIOLATION:\"; $bad } else { \"clean — contracts + goldens untouched\" }",
  "description": "Inspect Half A change set; guard contracts/goldens"
}
```
**[tool result]**
```
=== changed files ===
 M Cargo.lock
 M crates/keel-adapters/src/local_llama.rs
 M crates/keel-services/Cargo.toml
 M crates/keel-services/src/lib.rs
 M crates/keel-services/src/verifier.rs

=== diff stat ===
warning: in the working copy of 'Cargo.lock', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'crates/keel-adapters/src/local_llama.rs', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'crates/keel-services/Cargo.toml', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'crates/keel-services/src/lib.rs', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'crates/keel-services/src/verifier.rs', LF will be replaced by CRLF the next time Git touches it
 Cargo.lock                              | 338 +++++++++++++++++++++++++++++++-
 crates/keel-adapters/src/local_llama.rs |  76 +++++++
 crates/keel-services/Cargo.toml         |   5 +-
 crates/keel-services/src/lib.rs         |   2 +-
 crates/keel-services/src/verifier.rs    | 123 ++++++++++++
 5 files changed, 541 insertions(+), 3 deletions(-)

=== guard: NO contract or golden edits (expect empty) ===
clean — contracts + goldens untouched
```

## Claude — Jun 14, 2026 03:02

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:02

Change set is exactly Half A: SchemaOracle + conformance + the jsonschema dep — **contracts and goldens untouched** (guard confirms), `Cargo.lock` grew with the lean jsonschema tree. Per the protocol, I update STATE.md §5.1 as Half A lands. Reading the current "Next" line to edit it precisely.

## Claude — Jun 14, 2026 03:02

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\_run_state\\STATE.md",
  "offset": 44,
  "limit": 3
}
```
**[tool result]**
```
44	- **Stage 0 spine is essentially complete** (self-sufficient · three-tier economy · invariant chain · ledger + index · embedded + protocol). **Deferred:** kernel `lock` (substrate-hash verify — a no-op until the operator pins the `sha256: TODO` fields; the golden-freeze check belongs with Stage 2's freeze gate) · kernel `engine` (the canonical loop — better in Stage 1, it ties router + drivers + amplify; the CLI/serve already run the minimal route→chain→result).
45	- ~~**Stage 1: `DifficultyRouter`** + **wire the engine**~~ ✓ · ~~**`svc::verifier`** (I5 externality — `GOLDEN_ORACLE` green)~~ ✓ · ~~**`kernel::engine` (L1)** — the real loop over injected joints; I5/I4/I2 wired live; L5→L1 debt paid~~ ✓ · ~~**I5 freeze-gate** — operator re-stamped KEEL-native (`db4377b3…`) + un-ignored; `goldens_match_the_frozen_hash` green~~ ✓ (all 2026-06-14). **Next (operator-sequenced):** **(1) constrained-decode conformance** (`model_tier` golden — the local adapter already has the GBNF/JSON hook; this *is* the Backrooms Director's "schema-valid Directive or reject" gate → unblocks that dogfood); **(2) the default oracle set + the golden-registry** (`golden_refs`→`GoldenCase` resolver) — sequenced **sooner, not parked deep in Stage 2**, because it is what gives the live per-turn `verify` **teeth** (turns route-and-record into actually-verify). Then, any order: `mw::metrics` (`escalation_rate`/`rework_rate` — sizes the flywheel base case) · `svc::memory` (the ringed Tape — fills the injected `Memory`/`TraceSink` seams; design against `docs/proposals/perpetual-memory.md`) · perception (eyes + ears) · `amplify` (best-of-N — **ships OFF**, §23). **No operator-pending items.**
46	- **SIRP harvest backlog** (from the review): latency axis (needs a `Step` field — operator-frozen) · Layer-2 semantic-abstraction preprocessor (a future I3 "text retina": abstract-for-reasoning-and-privacy then re-inflate) · cooling = the Stage-3 flywheel. `SirpRouter` = a future swappable `Router` policy, only once its quality-signal rests on a non-model oracle (I5).
```

## Claude — Jun 14, 2026 03:02

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:02

Marking Half A landed in STATE.md and folding the three hardenings + EngineConfig into the Half-B "Next" so the record carries the plan:

## Claude — Jun 14, 2026 03:02

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\_run_state\\STATE.md",
  "old_string": "~~**I5 freeze-gate** — operator re-stamped KEEL-native (`db4377b3…`) + un-ignored; `goldens_match_the_frozen_hash` green~~ ✓ (all 2026-06-14). **Next (operator-sequenced):** **(1) constrained-decode conformance** (`model_tier` golden — the local adapter already has the GBNF/JSON hook; this *is* the Backrooms Director's \"schema-valid Directive or reject\" gate → unblocks that dogfood); **(2) the default oracle set + the golden-registry** (`golden_refs`→`GoldenCase` resolver) — sequenced **sooner, not parked deep in Stage 2**, because it is what gives the live per-turn `verify` **teeth** (turns route-and-record into actually-verify). Then, any order: `mw::metrics` (`escalation_rate`/`rework_rate` — sizes the flywheel base case) · `svc::memory` (the ringed Tape — fills the injected `Memory`/`TraceSink` seams; design against `docs/proposals/perpetual-memory.md`) · perception (eyes + ears) · `amplify` (best-of-N — **ships OFF**, §23). **No operator-pending items.**",
  "new_string": "~~**I5 freeze-gate** — operator re-stamped KEEL-native (`db4377b3…`) + un-ignored; `goldens_match_the_frozen_hash` green~~ ✓ · ~~**Half A: constrained-decode conformance** — `GOLDEN_MODEL_TIER` green (`passes_golden_model_tier`: cost · schema→`json_schema` decode · reasoning replay) + the `SchemaOracle` (the Director's \"schema-valid Directive or reject\" gate; in-memory `jsonschema` w/ `default-features=off`, no egress; rejection-tested)~~ ✓ (all 2026-06-14). **Next — Half B: give the per-turn `verify` teeth (operator-sequenced):** the **default-oracle set + the `golden_refs`→`GoldenCase` resolver** in `kernel::engine`, with the three hardenings — (1) an unresolved `golden_ref` → **fail-closed** (not a vacuous pass); (2) a `critical` step with an empty effective oracle set → **config fault** (fail/escalate, never a silent pass, canon §8/§10); (3) the resolver only **reads** `golden.json`, the map stays a plain `HashMap<String, GoldenCase>` (no `GoldenSource` trait until a second backing appears). `Engine::new` → a small kernel-internal `EngineConfig` struct. Then, any order: `mw::metrics` (`escalation_rate`/`rework_rate` — sizes the flywheel base case) · `svc::memory` (the ringed Tape — fills the injected `Memory`/`TraceSink` seams; design against `docs/proposals/perpetual-memory.md`) · perception (eyes + ears) · `amplify` (best-of-N — **ships OFF**, §23). **No operator-pending items.**"
}
```
**[tool result]**
```
The file C:\KEEL\_run_state\STATE.md has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 03:02

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:02

Half A is green, layer-clean, contracts/goldens untouched, STATE.md updated. Banking it **locally** (push held for your review of A). Staging + secret-scanning the diff first.

## Claude — Jun 14, 2026 03:02

**[tool: PowerShell]**
```json
{
  "command": "git -C C:\\KEEL add Cargo.lock crates/keel-adapters/src/local_llama.rs crates/keel-services/Cargo.toml crates/keel-services/src/lib.rs crates/keel-services/src/verifier.rs _run_state/STATE.md\n\"=== staged ===\"\ngit -C C:\\KEEL diff --cached --name-only\n\"`n=== secret check on staged diff ===\"\n$hits = git -C C:\\KEEL diff --cached | Select-String -Pattern 'sk-(ant-)?[A-Za-z0-9_-]{24,}|AKIA[0-9A-Z]{16}'\nif ($hits) { \"ABORT:\"; $hits } else { \"CLEAN — no key-shaped strings.\" }",
  "description": "Stage Half A and scan staged diff for secrets"
}
```
**[tool result]**
```
warning: in the working copy of 'Cargo.lock', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of '_run_state/STATE.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'crates/keel-adapters/src/local_llama.rs', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'crates/keel-services/Cargo.toml', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'crates/keel-services/src/lib.rs', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'crates/keel-services/src/verifier.rs', LF will be replaced by CRLF the next time Git touches it
=== staged ===
Cargo.lock
_run_state/STATE.md
crates/keel-adapters/src/local_llama.rs
crates/keel-services/Cargo.toml
crates/keel-services/src/lib.rs
crates/keel-services/src/verifier.rs

=== secret check on staged diff ===
CLEAN — no key-shaped strings.
```

## Claude — Jun 14, 2026 03:03

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:03

Staged (6 files), secret scan CLEAN. Committing Half A **locally** — **not pushing** (you review A first; we push A+B together).

## Claude — Jun 14, 2026 03:03

**[tool: PowerShell]**
```json
{
  "command": "@'\nStage 2 (Half A): constrained-decode conformance — model_tier golden green + SchemaOracle\n\nGOLDEN_MODEL_TIER is now conformance-tested (model-free, plain cargo test):\n- keel-adapters passes_golden_model_tier — case [0] cost via compute_cost;\n  case [1] schema routes to llama-server json_schema (the decode constraint);\n  case [2] reasoning_content replayed across a tool round-trip (no 400).\n- keel-services SchemaOracle (canon §10/§17) — the Backrooms Director's\n  \"schema-valid Directive or reject\" gate: validates output JSON against a JSON\n  Schema in-memory, invalid -> rejected (never partially applied), uncompilable\n  schema -> fail-closed. golden_model_tier_schema_is_enforced proves case [1]'s\n  validate side; schema_oracle_validates_and_rejects proves the load-bearing\n  REJECT path (missing-required + wrong-type + out-of-range + non-JSON).\n\nDependency: jsonschema 0.46 with default-features = false — strips its\nresolve-http(reqwest)/resolve-file/tls(aws-lc-rs+cmake) defaults, so a\nsafety-critical oracle pulls no network/TLS/C-crypto stack and cannot egress\n(I3). The mature crate, not a hand-rolled parser: the oracle's correctness IS\nthe I5 guarantee, so hand-rolling it would be a JOINT_WRONG risk.\n\n62 tests green / 3 ignored (live); clippy clean; zero contract/golden edits;\nfreeze seal unmoved (goldens_match_the_frozen_hash green). STATE.md §5.1: Half A\nlanded, Half B (teeth-in-loop + 3 hardenings) is next.\n\nCo-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>\n'@ | git -C C:\\KEEL commit -F -\n\"----- COMMIT EXIT: $LASTEXITCODE -----\"\n\"`n=== log (top 3) — note: NOT pushed ===\"\ngit -C C:\\KEEL log --oneline -3\n\"`n=== status (ahead of origin, unpushed) ===\"\ngit -C C:\\KEEL status -sb | Select-Object -First 1",
  "description": "Commit Half A locally; confirm unpushed"
}
```
**[tool result]**
```
[main e3b482a] Stage 2 (Half A): constrained-decode conformance — model_tier golden green + SchemaOracle
 6 files changed, 542 insertions(+), 4 deletions(-)
----- COMMIT EXIT: 0 -----

=== log (top 3) — note: NOT pushed ===
e3b482a Stage 2 (Half A): constrained-decode conformance — model_tier golden green + SchemaOracle
099f386 docs(state): refresh WAKE_UP to post-engine truth; re-stitch from parts
d341d43 docs(state): freeze-gate live — re-stamped KEEL-native, gate active

=== status (ahead of origin, unpushed) ===

## main...origin/main [ahead 1]
```

## Claude — Jun 14, 2026 03:03

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:03

Half A banked locally: `e3b482a`, **ahead of origin by 1, unpushed**. Showing you the substantive diff (the new oracle + the conformance test) for review.

## Claude — Jun 14, 2026 03:03

**[tool: PowerShell]**
```json
{
  "command": "git -C C:\\KEEL show e3b482a -- crates/keel-services/src/verifier.rs crates/keel-adapters/src/local_llama.rs 2>&1 | Select-String -NotMatch -Pattern '^\\s*$' | Select-Object -First 200",
  "description": "Show the SchemaOracle + conformance test diff for review"
}
```
**[tool result]**
```
commit e3b482acb82d6f73c0ec43ef7be4d77784b18de0
Author: Bo Chen <bochen2029@gmail.com>
Date:   Sun Jun 14 03:03:12 2026 -0500
    Stage 2 (Half A): constrained-decode conformance — model_tier golden green + SchemaOracle
    GOLDEN_MODEL_TIER is now conformance-tested (model-free, plain cargo test):
    - keel-adapters passes_golden_model_tier — case [0] cost via compute_cost;
      case [1] schema routes to llama-server json_schema (the decode constraint);
      case [2] reasoning_content replayed across a tool round-trip (no 400).
    - keel-services SchemaOracle (canon §10/§17) — the Backrooms Director's
      "schema-valid Directive or reject" gate: validates output JSON against a JSON
      Schema in-memory, invalid -> rejected (never partially applied), uncompilable
      schema -> fail-closed. golden_model_tier_schema_is_enforced proves case [1]'s
      validate side; schema_oracle_validates_and_rejects proves the load-bearing
      REJECT path (missing-required + wrong-type + out-of-range + non-JSON).
    Dependency: jsonschema 0.46 with default-features = false — strips its
    resolve-http(reqwest)/resolve-file/tls(aws-lc-rs+cmake) defaults, so a
    safety-critical oracle pulls no network/TLS/C-crypto stack and cannot egress
    (I3). The mature crate, not a hand-rolled parser: the oracle's correctness IS
    the I5 guarantee, so hand-rolling it would be a JOINT_WRONG risk.
    62 tests green / 3 ignored (live); clippy clean; zero contract/golden edits;
    freeze seal unmoved (goldens_match_the_frozen_hash green). STATE.md §5.1: Half A
    landed, Half B (teeth-in-loop + 3 hardenings) is next.
    Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>
diff --git a/crates/keel-adapters/src/local_llama.rs b/crates/keel-adapters/src/local_llama.rs
index cd107e7..4ce994b 100644
--- a/crates/keel-adapters/src/local_llama.rs
+++ b/crates/keel-adapters/src/local_llama.rs
@@ -177,6 +177,82 @@ mod tests {
         assert!(tier().caps().vision);
     }
+    /// GOLDEN_MODEL_TIER conformance (model-free; the live model is the `#[ignore]` test below).
+    /// Covers the adapter/cost/decode side of the three frozen cases; the schema *validation* side of
+    /// case [1] (the SchemaOracle) lives in keel-services `golden_model_tier_schema_is_enforced`.
+    #[test]
+    fn passes_golden_model_tier() {
+        let path = concat!(env!("CARGO_MANIFEST_DIR"), "/../../tests/golden/golden.json");
+        let raw = std::fs::read_to_string(path).expect("read golden.json");
+        let golden: Value = serde_json::from_str(&raw).expect("parse golden.json");
+        let cases = golden["model_tier"].as_array().expect("model_tier cases");
+        assert!(!cases.is_empty());
+
+        for case in cases {
+            let name = case["name"].as_str().unwrap_or("?");
+            let input = &case["input"];
+            let expect = &case["expect"];
+
+            // case [0] — cost from usage + price (compute_cost is the non-model arithmetic oracle).
+            if let (Some(u), Some(p)) = (input.get("usage"), input.get("price")) {
+                let usage = keel_contracts::Usage {
+                    input_tokens: u["input_tokens"].as_u64().unwrap_or(0),
+                    output_tokens: u["output_tokens"].as_u64().unwrap_or(0),
+                    cache_hit_tokens: u["cache_hit_tokens"].as_u64().unwrap_or(0),
+                };
+                let price = Price {
+                    input_miss: p["input_miss"].as_f64().unwrap_or(0.0),
+                    input_hit: p["input_hit"].as_f64().unwrap_or(0.0),
+                    output: p["output"].as_f64().unwrap_or(0.0),
+                };
+                let cost = keel_contracts::compute_cost(&usage, &price);
+                let want = expect["cost"].as_f64().expect("expect.cost");
+                let tol = expect["tol"].as_f64().unwrap_or(1e-9);
+                assert!((cost - want).abs() <= tol…
```

## Claude — Jun 14, 2026 03:04

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:04

The SchemaOracle and conformance test are landed and shown above. **Half A is banked locally (`e3b482a`, ahead 1, unpushed) — holding the push for your review.**

## The dependency decision (you asked me to flag if heavy/surprising — it was)
`jsonschema 0.46` **default** pulls `reqwest` + `rustls` + **`aws-lc-rs` (C crypto, needs `cmake`)** + cert stores — remote-`$ref` HTTP resolution. In a sovereign, safety-critical oracle that's a **network egress surface (I3)** *and* a fragile build dep. Resolution: **`default-features = false`** — `cargo tree` confirms reqwest/rustls/aws-lc/webpki/security-framework/schannel all **gone**, `cargo check` green (no cmake). You get your ruling (the trustworthy crate, not a hand-rolled parser) with the heavy/surprising part stripped and an egress hole closed. Flagging for your sign-off; if you'd still rather a different validator, say so and I'll swap before push.

## Gate
| | |
|---|---|
| `cargo check` / `clippy` | ✅ green / clean |
| `cargo test` | ✅ **62 passed / 3 ignored** (live only) |
| new tests | `passes_golden_model_tier` ✓ · `schema_oracle_validates_and_rejects` ✓ · `golden_model_tier_schema_is_enforced` ✓ · `goldens_match_the_frozen_hash` still ✓ |
| contracts / goldens | **untouched** (guard confirmed; freeze seal unmoved) |
| layer / deps | services gained `jsonschema`(lean) + `serde_json`; no upward imports; no contract edit |

## Hardening #1 (the load-bearing one) — done in A
`schema_oracle_validates_and_rejects` proves the oracle **catches the bad**, not just blesses the good: it rejects a Directive that's **missing-required `action` AND wrong-typed `intensity`**, also rejects out-of-range/extra-prop, and **fail-closes** on non-JSON and on an uncompilable schema. The Director framing is explicit in the test: *invalid → rejected, never partially applied.* Hardenings **#2 (unresolved `golden_ref` → fail-closed)** and **#3 (`critical` step + empty oracle set → config fault)** are Half B — recorded in STATE.md §5.1's Half-B plan so they're not lost.

## Coverage shape (the double-duty you wanted)
- **Decode side** (keel-adapters): the golden's schema routes to llama-server's `json_schema` — constrain at decode.
- **Validate side** (keel-services `SchemaOracle`): validate-or-reject — verify independently of the generator (the I5 belt-and-suspenders).
- Together = `GOLDEN_MODEL_TIER` green **and** the Backrooms Director's literal gate, built once.

All conformance is **model-free** and ran green in plain `cargo test` — CI needs no llama-server (the live adapter test stays `#[ignore]`).

**Stopping here for your review of A.** On your go I'll do **Half B** (the resolver + default-oracle set + hardenings #2/#3 + the `EngineConfig` refactor), bank it local, show you, prove the reject path by test, and smoke a `golden_ref`'d critical step end-to-end if the CLI/serve can carry one — then we push A+B together.

## You — Jun 14, 2026 03:13

Clean Half A — and the right things are true: the rejection test is the load-bearing one and it's there (missing-required AND wrong-type → rejected, Director framing explicit), the conformance is model-free and green in plain cargo test, contracts and goldens are untouched with the seal unmoved, and you banked local and held the push. That's the standard. The dep call, one new hardening, then go on B.

jsonschema default-features=false — APPROVED, and that's exactly the catch I wanted. You did precisely what the ruling asked: pulled the trustworthy crate, cargo tree'd it, and found the heavy/surprising part — and the surprise wasn't just bloat, it was a network egress surface (reqwest / remote-$ref) plus a cmake/aws-lc C-crypto build dep living inside a sovereign safety oracle. Stripping it with default-features=false keeps the mature validator (the I5-correct call) while closing an I3 egress hole and a fragile build dep. Keep the crate, lean config. Flagging it instead of silently shipping the default tree is the discipline working.

One new hardening before/with B — pin the schema DRAFT; do not auto-detect. A validator that selects the draft from $schema (or defaults to latest when it's absent) is the silent-JOINT_WRONG risk for a safety oracle: validate the Director's Directive against a different draft than it was authored for and you get subtly-wrong accept/reject with everything green. So: the SchemaOracle pins an explicit draft (the one KEEL/the Director author against — name it in the code), OR every golden schema must declare $schema and you assert it. Add a test that proves the pinned draft is the one used (a schema whose accept/reject differs by draft → behaves per the pin). And confirm the conformance test reads the schema FROM golden.json (the frozen source), not a hardcoded copy — so the freeze-gate actually protects what's validated. Determinism is the entire point of a non-model oracle.

EngineConfig refactor — approved for B. Fold the args into the kernel-internal config/parts struct now; it keeps Memory/TraceSink/goldens from churning the signature later. Readable constructor, no contract edit. A-then-B as two commits is right; push them together.

Go on Half B — resolver + default-oracle set + hardenings #2/#3. These are what make verify actually bite; skip neither:
- #2 unresolved golden_ref → FAIL-CLOSED. A step naming a ref not in the map surfaces a missing-assertion (fail / route to human), never verifies vacuously — same as PropertyOracle's unknown-property. A named-but-unresolvable golden silently passing is a hole.
- #3 critical step + no APPLICABLE oracle → config fault, not a vacuous pass. Compute on the effective set (a non-empty registry with zero oracles applicable to THIS step still counts as zero). step.critical == true with nothing actually asserting must fail/escalate. This is the §8/§10 guard that makes "vacuous on a plain chat turn" SAFE: vacuous is fine for non-critical + no-ref; critical-with-no-oracle is not.
- Keep the no-false-alarms shape: a plain non-critical, no-ref chat turn STILL passes silently. Prove BOTH directions in tests — the reject path (ref'd/critical + bad output → fail) AND the silent path (plain turn → pass).

Prove B in the REAL binary, not just stubs — like you did the engine loop. If the CLI/serve can carry a golden_ref'd critical step, smoke it: bad output → rejected/escalated, observed end-to-end, artifacts cross-correlated. If the Step-construction surface can't carry a golden_ref/critical today, say so plainly and do the cleanest full-engine-path integration test instead — keep the lived-vs-reconstructed line exact (don't claim "observed" for a stub). If a tiny L5 flag (--golden-ref / --critical) is the clean way to make it smokeable, fine — L5 only, no contract edit.

Gate + sequence: zero contract edits (stop and justify if a joint genuinely pressures — I expect none), freeze seal unmoved, per-crate budget (keep verifier and engine comprehensible; split if either bloats), cargo test/clippy green, STATE.md §5.1 updated as B lands. Bank B LOCAL, show me the diff + cargo test/clippy + the reject-path proof (test and/or smoke) + the STATE.md update. I review B, then we push A+B together — one clean public moment, the I5 loop with real teeth.

After B lands, one honesty fold: the "verify is vacuous until oracles register" caveat in WAKE_UP §4.2 / the scorecard and STATE.md is now superseded — once the default-oracle set + resolver are in, I5 bites on critical/ref'd work, so the first-read anchor must say that. Do it with B's STATE.md update, and re-stitch WAKE_UP if you touch a part — same discipline you just applied.

Go on Half B.

## Claude — Jun 14, 2026 03:18

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:18

Rulings noted: jsonschema lean config approved, EngineConfig approved, and the new hardening **#4 — pin the schema draft** (no auto-detect — a draft mismatch is a silent JOINT_WRONG). I'll fold #4 into B (it hardens A's SchemaOracle, and we push A+B together).

Starting **Half B**. First the draft-pin (the riskiest API surface — I'll verify it compiles before the larger engine work). Pinning Draft 2020-12 explicitly + stripping any embedded `$schema`:

## Claude — Jun 14, 2026 03:19

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs",
  "old_string": "pub struct SchemaOracle {\n    schema: Value,\n}\n\nimpl SchemaOracle {\n    pub fn new(schema: Value) -> Self {\n        Self { schema }\n    }",
  "new_string": "/// The JSON Schema draft KEEL pins for **every** `SchemaOracle` — Draft 2020-12 (the current IETF\n/// standard; KEEL and its cells author Directive/tool schemas against it). A safety oracle must\n/// **never** auto-select the draft from `$schema` (or default to \"latest\"): validating against a\n/// different draft than the schema was authored for is a silent JOINT_WRONG (subtly-wrong\n/// accept/reject, everything green). The pin is explicit and the constructor strips any embedded\n/// `$schema`, so the governing draft is deterministic regardless of the document. (A cell needing a\n/// different draft is a future explicit `with_draft` param — never an auto-detect.)\nconst PINNED_DRAFT: jsonschema::Draft = jsonschema::Draft::Draft202012;\n\npub struct SchemaOracle {\n    schema: Value,\n}\n\nimpl SchemaOracle {\n    pub fn new(mut schema: Value) -> Self {\n        // determinism: drop any embedded `$schema` so PINNED_DRAFT always governs, never the document.\n        if let Some(obj) = schema.as_object_mut() {\n            obj.remove(\"$schema\");\n        }\n        Self { schema }\n    }"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-services\src\verifier.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 03:19

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs",
  "old_string": "        let validator = match jsonschema::validator_for(&self.schema) {\n            Ok(v) => v,\n            Err(e) => return Ok(Self::reject(format!(\"schema: cannot compile schema ({e}) — fail-closed\"))),\n        };",
  "new_string": "        let validator = match jsonschema::options().with_draft(PINNED_DRAFT).build(&self.schema) {\n            Ok(v) => v,\n            Err(e) => return Ok(Self::reject(format!(\"schema: cannot compile schema ({e}) — fail-closed\"))),\n        };"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-services\src\verifier.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 03:19

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs",
  "old_string": "        let bad = StepOutput { content: String::new(), artifact: json!({ \"wrong\": 1 }) };\n        assert!(!oracle.verify(&bad, &[], &ctx).await.unwrap().passed, \"non-conformant tool-call must be rejected\");\n    }\n}",
  "new_string": "        let bad = StepOutput { content: String::new(), artifact: json!({ \"wrong\": 1 }) };\n        assert!(!oracle.verify(&bad, &[], &ctx).await.unwrap().passed, \"non-conformant tool-call must be rejected\");\n    }\n\n    /// Hardening: the oracle **pins** the draft (Draft 2020-12) and never auto-selects from `$schema`\n    /// — else a Directive validated against the wrong draft is a silent JOINT_WRONG. Proof:\n    /// `exclusiveMinimum` is *numeric* in Draft 2020-12 (the value must exceed it) but a *boolean*\n    /// modifier in Draft 4; we even embed a draft-04 `$schema` decoy. Under the pin, instance `5`\n    /// violates `exclusiveMinimum: 5` (5 is not > 5) → **rejected**; `6` → accepted (which also proves\n    /// the schema compiled + the constraint is live, so the rejection isn't a fail-closed artifact).\n    #[tokio::test]\n    async fn schema_oracle_pins_the_draft() {\n        let schema = json!({\n            \"$schema\": \"http://json-schema.org/draft-04/schema#\", // decoy — must NOT take effect\n            \"type\": \"integer\",\n            \"exclusiveMinimum\": 5\n        });\n        let oracle = SchemaOracle::new(schema);\n        let ctx = Context::default();\n        let five = StepOutput { content: String::new(), artifact: json!(5) };\n        assert!(\n            !oracle.verify(&five, &[], &ctx).await.unwrap().passed,\n            \"pinned Draft 2020-12: 5 is not > 5 → rejected (the decoy draft-04 must be ignored)\"\n        );\n        let six = StepOutput { content: String::new(), artifact: json!(6) };\n        assert!(\n            oracle.verify(&six, &[], &ctx).await.unwrap().passed,\n            \"6 > 5 → valid (proves the schema compiled and the constraint is actually applied)\"\n        );\n    }\n}"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-services\src\verifier.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 03:19

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:19

Verifying the draft-pin API compiles and the draft-distinguishing test behaves per the pin, before the larger engine work.

## Claude — Jun 14, 2026 03:19

**[tool: PowerShell]**
```json
{
  "command": "cargo test -p keel-services 2>&1 | Select-String -Pattern 'schema_oracle|golden_model_tier|test result:|error\\[|error:|warning:' | Select-Object -First 30; \"----- EXIT: $LASTEXITCODE -----\"",
  "description": "Test keel-services: draft-pin API + schema oracle tests",
  "timeout": 300000
}
```
**[tool result]**
```
test verifier::tests::[7mschema_oracle[0m_pins_the_draft ... ok
test verifier::tests::[7mgolden_model_tier[0m_schema_is_enforced ... ok
test verifier::tests::[7mschema_oracle[0m_validates_and_rejects ... ok
[7mtest result:[0m ok. 7 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s
[7mtest result:[0m ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
----- EXIT: 0 -----
```

## Claude — Jun 14, 2026 03:21

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:21

Draft-pin works: `schema_oracle_pins_the_draft ... ok` (the `options().with_draft(Draft202012).build()` API compiles, and instance `5` is rejected / `6` accepted under the pin, decoy draft-04 ignored). keel-services at 7 tests.

Now the engine: `EngineConfig` + the `golden_refs`→`GoldenCase` resolver + hardenings #2/#3. This is a structural change to `Engine::new` and the run loop, so I'll rewrite `engine.rs` cleanly rather than do fragile multi-site edits.

## Claude — Jun 14, 2026 03:23

**[tool: Write]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\engine.rs",
  "content": "//! keel-kernel::engine — the canonical closed loop (canon §8). L1.\n//!\n//! The kernel ships **one** cycle as a default; exotic cells compose their own from the same joints\n//! and still inherit the invariants, because the invariants live in the *chain* and the *spine*, not\n//! here. This engine is **injection-only**: it imports nothing but L0 (`keel-contracts`) and its own\n//! kernel modules, and is handed the concrete policies — the `Router`, the I5 `Oracle`, the I2\n//! `Spine`, optionally `Memory`/`TraceSink`, and the operator-frozen golden registry — as L0 trait\n//! objects + data via [`EngineConfig`]. The same dyn-injection the [`Registry`](crate::Registry)\n//! uses for `ModelTier`, applied to the loop.\n//!\n//! One turn (canon §8): **assemble → route → chain → verify → checkpoint → emit.** The engine **owns\n//! the [`Context`]** (it folds in `result.cost` after the chain returns — I4 — because the chain only\n//! sees `&Context`) and the [`Step`]'s history (it appends `tier_history` and bumps `oracle_failures`\n//! on a failure), so the escalation ladder (canon §9) fires across turns.\n//!\n//! **I5 teeth (canon §8/§10):** the loop resolves `step.golden_refs` against the injected registry\n//! and verifies against the resolved cases. Two guards keep \"vacuous on a plain chat turn\" *safe*:\n//! (a) an **unresolved** `golden_ref` → **fail-closed** (a named-but-missing assertion is a hole,\n//! never a vacuous pass); (b) a **`critical`** step with **no effective assertion** (empty verdict\n//! evidence) → **config fault**, never a silent pass. A non-critical, no-ref turn still passes\n//! silently — the teeth bite on critical/ref'd work, not on plain chat.\n//!\n//! **Per-tier chains (I3, canon §8 footnote):** the privacy mask differs by destination, so the\n//! engine holds one egress-correct [`Chain`] per tier and runs the routed tier through *its* chain.\n\nuse crate::Chain;\nuse keel_contracts::{\n    Assertion, Content, Context, Decision, Effort, GenerateRequest, GenerateResult, GoldenCase, KeelError,\n    Memory, Message, ModelTier, Oracle, Result, Role, Router, Spine, Step, StepOutput, Trace, TraceSink,\n    Verdict, VerifiedTrace,\n};\nuse serde_json::Value;\nuse std::collections::{BTreeMap, HashMap};\nuse std::sync::Arc;\n\n/// The tier ladder, cheapest first — the engine walks DOWN it to substitute an available tier when\n/// the routed one is unplugged.\nconst LADDER: [&str; 3] = [\"local\", \"cheap-API\", \"frontier\"];\n\n/// One wired tier: its brain adapter, the model id to send it, and the **egress-correct** invariant\n/// chain for that tier (local pass-through vs cloud-masked, I3 — canon §8 footnote). Built by the\n/// wiring layer and injected.\npub struct TierSlot {\n    pub tier: Arc<dyn ModelTier>,\n    pub chain: Chain,\n    pub model: String,\n}\n\n/// Everything the engine is injected with (canon §6 — the wiring layer builds the concrete services\n/// and hands them in as L0 trait objects + data). A config struct rather than a long argument list,\n/// so new seams (`Memory`, `TraceSink`, `goldens`, …) don't churn the constructor signature.\npub struct EngineConfig {\n    pub slots: BTreeMap<String, TierSlot>,\n    pub router: Box<dyn Router>,\n    pub oracle: Arc<dyn Oracle>,\n    pub spine: Arc<dyn Spine>,\n    pub memory: Option<Arc<dyn Memory>>,\n    pub trace_sink: Option<Arc<dyn TraceSink>>,\n    pub default_tier: String,\n    /// Operator-frozen ground truth keyed by case name; the loop resolves `step.golden_refs` against\n    /// it. **Read-only at runtime** — populated from `golden.json` / a cell's goldens by the wiring\n    /// layer (the engine never writes it).\n    pub goldens: HashMap<String, GoldenCase>,\n}\n\n/// The outcome of one routed, verified turn: the model output plus the routing + externality story\n/// (for the operator / ledger / serve response).\n#[derive(Debug)]\npub struct Outcome {\n    pub result: GenerateResult,\n    /// What the router chose (its tier + reason).\n    pub decision: Decision,\n    /// The tier actually run — equals `decision.tier` unless that tier was unplugged.\n    pub tier_used: String,\n    /// True when the chosen tier was unavailable and the engine fell back down the ladder.\n    pub substituted: bool,\n    /// The I5 verdict — a non-model assertion on this output (`passed`, `joint_wrong`, failures).\n    pub verdict: Verdict,\n}\n\n/// The canonical engine: hold every available tier (behind its chain), let the injected [`Router`]\n/// pick one per turn, run it, verify (I5), accumulate cost (I4), checkpoint (I2), and emit verified\n/// traces (the flywheel feed). The model that thinks is interchangeable; this loop is the self.\npub struct Engine {\n    slots: BTreeMap<String, TierSlot>,\n    router: Box<dyn Router>,\n    oracle: Arc<dyn Oracle>,\n    spine: Arc<dyn Spine>,\n    memory: Option<Arc<dyn Memory>>,\n    trace_sink: Option<Arc
…[truncated]
```
**[tool result]**
```
The file C:\KEEL\crates\keel-kernel\src\engine.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 03:23

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:23

Engine rewritten with `EngineConfig` + resolver + hardenings #2/#3. Now wiring L5: the default-oracle set + the golden registry. Reading the current L5 assemble to edit precisely.

## Claude — Jun 14, 2026 03:23

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel\\src\\lib.rs",
  "offset": 16,
  "limit": 42
}
```
**[tool result]**
```
16	
17	use keel_adapters::{Anthropic, DeepSeek, LocalLlama};
18	use keel_contracts::{
19	    Context, GenerateRequest, GenerateResult, KeelError, ModelTier, Oracle, Result, Router, Spine, Step,
20	};
21	use keel_kernel::engine::{Engine as KernelEngine, TierSlot};
22	use keel_kernel::{Chain, Manifest, Registry, TierCfg};
23	use keel_middleware::{AuditMiddleware, AuditSink, CostMiddleware, FileAuditSink, PrivacyMiddleware, Redactor};
24	use keel_services::{DifficultyRouter, Verifier};
25	use keel_store::SqliteStore;
26	use std::collections::BTreeMap;
27	use std::sync::Arc;
28	
29	/// The outcome of a routed, verified turn (defined in the kernel; re-exported for app callers).
30	pub use keel_kernel::engine::Outcome;
31	
32	pub const DEEPSEEK_ENDPOINT: &str = "https://api.deepseek.com";
33	pub const ANTHROPIC_ENDPOINT: &str = "https://api.anthropic.com";
34	pub const AUDIT_LEDGER: &str = ".keelstate/audit.jsonl";
35	/// The SQLite index backing the I2 `Spine` (derived/rebuildable; the file ledger is the record).
36	pub const INDEX_DB: &str = ".keelstate/index.db";
37	// local substrate launch (paths match keel.lock; keel.lock-driven config is a refinement)
38	pub const LLAMA_EXE: &str = r"C:\llama.cpp\llama-server.exe";
39	pub const LLAMA_MODEL: &str = r"C:\models\Qwen3.5-9B-Q5_K_M.gguf";
40	pub const LLAMA_MMPROJ: &str = r"C:\models\mmproj-F16.gguf";
41	pub const LLAMA_LOG: &str = ".keelstate/llama-server.log";
42	
43	// ── the self-driving engine (L5 injection → L1 loop) ──────────────────────────
44	
45	/// The self-driving engine: a thin **injection wrapper** over [`kernel::engine::Engine`](keel_kernel::engine::Engine).
46	/// It wires every available tier behind its egress-correct chain and constructs the swappable joints
47	/// (the §9 `DifficultyRouter`, the I5 `Verifier` as a composite `Oracle`, the SQLite `Spine`), then
48	/// delegates the canonical loop to the kernel. The policy stays behind the seams so a learned router
49	/// or a cell's oracles slot in later without touching this crate.
50	pub struct Engine(KernelEngine);
51	
52	impl Engine {
53	    /// Assemble from `keel.lock`: wire every tier whose substrate is reachable — **local always**
54	    /// (resolving/launching llama-server), a **cloud tier only when its key is in the env** (absent
55	    /// key ⇒ skipped, not fatal) — each behind an `audit · privacy · cost` chain whose egress mask
56	    /// matches whether that tier leaves the box (I3). Then inject the joints into the kernel engine.
57	    pub fn assemble(manifest: &Manifest) -> Result<Engine> {
```

## Claude — Jun 14, 2026 03:23

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:23

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel\\src\\lib.rs",
  "offset": 85,
  "limit": 35
}
```
**[tool result]**
```
85	        let router: Box<dyn Router> = Box::new(DifficultyRouter::new(manifest.router.escalate_after_oracle_failures));
86	        // I5: the externality registry as a single composite Oracle. Empty by default — a cell
87	        // registers its oracles; an empty registry verifies vacuously, so the *mechanism* is live
88	        // (oracle_failures feeds the escalation ladder) even before a cell plugs its assertions in.
89	        let oracle: Arc<dyn Oracle> = Arc::new(Verifier::new());
90	        // I2: the SQLite index is the first Spine. The append-only file ledger stays the system of
91	        // record; this index is derived and rebuildable from it. (.keelstate is created by the sink.)
92	        let spine: Arc<dyn Spine> =
93	            Arc::new(SqliteStore::open(INDEX_DB).map_err(|e| KeelError::Other(format!("index {INDEX_DB}: {e}")))?);
94	        // Memory + TraceSink: the seams exist; their impls (the ringed Tape, the flywheel feed) land
95	        // in Stage 2 (svc::memory). `None` today ⇒ no Ring-0 assembly and no distill emit — no-ops.
96	        let engine = KernelEngine::new(
97	            slots,
98	            router,
99	            oracle,
100	            spine,
101	            None,
102	            None,
103	            manifest.router.default_tier.clone(),
104	        )?;
105	        Ok(Engine(engine))
106	    }
107	
108	    /// The tiers actually wired (sorted).
109	    pub fn available(&self) -> Vec<String> {
110	        self.0.available()
111	    }
112	
113	    /// Route + run + verify + checkpoint one turn (canon §8). Mutates `step` (history/failure
114	    /// feedback) and `ctx` (cost accumulation) — the engine owns both.
115	    pub async fn run(&self, step: &mut Step, ctx: &mut Context, req: GenerateRequest) -> Result<Outcome> {
116	        self.0.run(step, ctx, req).await
117	    }
118	
119	    /// Manual override: run on a named wired tier, skipping route + verify (the full chain still runs).
```

## Claude — Jun 14, 2026 03:24

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:24

L5 assemble located. Wiring the default-oracle set + the golden registry. Imports + the `GOLDEN_PATH` const first:

## Claude — Jun 14, 2026 03:24

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel\\src\\lib.rs",
  "old_string": "use keel_adapters::{Anthropic, DeepSeek, LocalLlama};\nuse keel_contracts::{\n    Context, GenerateRequest, GenerateResult, KeelError, ModelTier, Oracle, Result, Router, Spine, Step,\n};\nuse keel_kernel::engine::{Engine as KernelEngine, TierSlot};\nuse keel_kernel::{Chain, Manifest, Registry, TierCfg};\nuse keel_middleware::{AuditMiddleware, AuditSink, CostMiddleware, FileAuditSink, PrivacyMiddleware, Redactor};\nuse keel_services::{DifficultyRouter, Verifier};\nuse keel_store::SqliteStore;\nuse std::collections::BTreeMap;\nuse std::sync::Arc;",
  "new_string": "use keel_adapters::{Anthropic, DeepSeek, LocalLlama};\nuse keel_contracts::{\n    Context, GenerateRequest, GenerateResult, GoldenCase, KeelError, ModelTier, Oracle, Result, Router, Spine, Step,\n};\nuse keel_kernel::engine::{Engine as KernelEngine, EngineConfig, TierSlot};\nuse keel_kernel::{Chain, Manifest, Registry, TierCfg};\nuse keel_middleware::{AuditMiddleware, AuditSink, CostMiddleware, FileAuditSink, PrivacyMiddleware, Redactor};\nuse keel_services::{DifficultyRouter, PropertyOracle, Verifier};\nuse keel_store::SqliteStore;\nuse std::collections::{BTreeMap, HashMap};\nuse std::sync::Arc;"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\lib.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 03:24

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel\\src\\lib.rs",
  "old_string": "/// The SQLite index backing the I2 `Spine` (derived/rebuildable; the file ledger is the record).\npub const INDEX_DB: &str = \".keelstate/index.db\";",
  "new_string": "/// The SQLite index backing the I2 `Spine` (derived/rebuildable; the file ledger is the record).\npub const INDEX_DB: &str = \".keelstate/index.db\";\n/// Operator-frozen ground truth the engine resolves `step.golden_refs` against (read-only). KEEL's\n/// own conformance set; a cell points the registry at its own goldens instead.\npub const GOLDEN_PATH: &str = \"tests/golden/golden.json\";"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\lib.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 03:24

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:24

The oracle (default set) + engine (EngineConfig) construction:

## Claude — Jun 14, 2026 03:25

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel\\src\\lib.rs",
  "old_string": "        // I5: the externality registry as a single composite Oracle. Empty by default — a cell\n        // registers its oracles; an empty registry verifies vacuously, so the *mechanism* is live\n        // (oracle_failures feeds the escalation ladder) even before a cell plugs its assertions in.\n        let oracle: Arc<dyn Oracle> = Arc::new(Verifier::new());\n        // I2: the SQLite index is the first Spine. The append-only file ledger stays the system of\n        // record; this index is derived and rebuildable from it. (.keelstate is created by the sink.)\n        let spine: Arc<dyn Spine> =\n            Arc::new(SqliteStore::open(INDEX_DB).map_err(|e| KeelError::Other(format!(\"index {INDEX_DB}: {e}\")))?);\n        // Memory + TraceSink: the seams exist; their impls (the ringed Tape, the flywheel feed) land\n        // in Stage 2 (svc::memory). `None` today ⇒ no Ring-0 assembly and no distill emit — no-ops.\n        let engine = KernelEngine::new(\n            slots,\n            router,\n            oracle,\n            spine,\n            None,\n            None,\n            manifest.router.default_tier.clone(),\n        )?;\n        Ok(Engine(engine))",
  "new_string": "        // I5: the externality registry as a composite Oracle, with the **default-oracle set** — a\n        // baseline non-model assertion on every output (no SSN-shaped span). A cell registers more\n        // (e.g., a `SchemaOracle` for the Director's Directive). The baseline means a critical turn\n        // always carries an assertion; the engine's critical-step guard catches an empty set anyway.\n        let mut verifier = Verifier::new();\n        verifier.register(Box::new(PropertyOracle::new(vec![\"no_ssn_pattern\".into()])));\n        let oracle: Arc<dyn Oracle> = Arc::new(verifier);\n        // I2: the SQLite index is the first Spine. The append-only file ledger stays the system of\n        // record; this index is derived and rebuildable from it. (.keelstate is created by the sink.)\n        let spine: Arc<dyn Spine> =\n            Arc::new(SqliteStore::open(INDEX_DB).map_err(|e| KeelError::Other(format!(\"index {INDEX_DB}: {e}\")))?);\n        // I5 golden registry: resolve `step.golden_refs` against operator-frozen ground truth\n        // (read-only, best-effort from golden.json; a cell injects its own). Empty if the file is\n        // absent — a plain chat turn carries no refs, so the fail-closed guard only bites a ref'd step.\n        let goldens = load_goldens(GOLDEN_PATH);\n        // Memory + TraceSink: the seams exist; their impls (the ringed Tape, the flywheel feed) land\n        // in Stage 2 (svc::memory). `None` today ⇒ no Ring-0 assembly and no distill emit — no-ops.\n        let engine = KernelEngine::new(EngineConfig {\n            slots,\n            router,\n            oracle,\n            spine,\n            memory: None,\n            trace_sink: None,\n            default_tier: manifest.router.default_tier.clone(),\n            goldens,\n        })?;\n        Ok(Engine(engine))"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\lib.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 03:25

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:25

The `load_goldens` helper (read-only, best-effort), appended after the resolver helper:

## Claude — Jun 14, 2026 03:25

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel\\src\\lib.rs",
  "old_string": "            Ok(ep) // handle drops here; the process keeps running (detached for reuse)\n        }\n    }\n}",
  "new_string": "            Ok(ep) // handle drops here; the process keeps running (detached for reuse)\n        }\n    }\n}\n\n/// Load operator-frozen ground truth into a name→case map for the engine's `golden_refs` resolver.\n/// **Read-only**, best-effort: a missing/unparseable file yields an empty map (a plain chat turn\n/// carries no refs, so the engine's fail-closed guard only bites a step that *names* a golden). The\n/// flat sections of `golden.json` (every key but `_meta`) are merged by case `name`.\nfn load_goldens(path: &str) -> HashMap<String, GoldenCase> {\n    let mut map = HashMap::new();\n    let Ok(raw) = std::fs::read_to_string(path) else { return map };\n    let Ok(json) = serde_json::from_str::<serde_json::Value>(&raw) else { return map };\n    let Some(obj) = json.as_object() else { return map };\n    for (section, cases) in obj {\n        if section == \"_meta\" {\n            continue;\n        }\n        let Some(arr) = cases.as_array() else { continue };\n        for case in arr {\n            if let Ok(gc) = serde_json::from_value::<GoldenCase>(case.clone()) {\n                map.insert(gc.name.clone(), gc);\n            }\n        }\n    }\n    map\n}"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\lib.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 03:25

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:25

Now the CLI flags (`--critical` / `--golden-ref`) so the teeth are smokeable. Reading current main.rs.

## Claude — Jun 14, 2026 03:25

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel\\src\\main.rs",
  "offset": 23,
  "limit": 73
}
```
**[tool result]**
```
23	async fn run() -> keel_contracts::Result<()> {
24	    let mut manifest_path = "keel.lock".to_string();
25	    let mut tier_override: Option<String> = None;
26	    let mut think = false;
27	    let mut core_wire = false;
28	    let mut sovereign = false;
29	    let mut prompt = Vec::new();
30	    let mut args = std::env::args().skip(1);
31	    while let Some(a) = args.next() {
32	        match a.as_str() {
33	            "--manifest" => manifest_path = args.next().unwrap_or_default(),
34	            "--tier" => tier_override = args.next(),
35	            "--kind" => core_wire = matches!(args.next().as_deref(), Some("core-wire") | Some("core_wire")),
36	            "--sovereign" => sovereign = true,
37	            "--think" => think = true,
38	            _ => prompt.push(a),
39	        }
40	    }
41	    let prompt = prompt.join(" ");
42	    if prompt.trim().is_empty() {
43	        eprintln!("usage: keel [--manifest PATH] [--tier NAME] [--kind core-wire] [--sovereign] [--think] <prompt>");
44	        std::process::exit(2);
45	    }
46	
47	    let manifest = Manifest::load(&manifest_path)?;
48	    let mut ctx = new_context(&manifest);
49	    let user = Message {
50	        role: Role::User,
51	        content: vec![Content::Text { text: prompt.clone() }],
52	        name: None,
53	        reasoning_content: None,
54	        tool_call_id: None,
55	    };
56	
57	    if let Some(t) = tier_override {
58	        // ── manual override: pin one tier, skip the router (no needless local cold-start) ──
59	        let asm = keel::assemble(&manifest, Some(&t))?;
60	        let req = GenerateRequest {
61	            messages: vec![user],
62	            model: asm.model.clone(),
63	            tools: vec![],
64	            grammar: None,
65	            effort: Effort { n: 1, thinking: Some(if think { "high" } else { "low" }.into()) },
66	            cache_prefix_len: None,
67	        };
68	        let res = asm.chain.run(req, &ctx, asm.tier.clone()).await?;
69	        report(&res, &ctx, &format!("manual override → {}", asm.tier_name), think);
70	    } else {
71	        // ── self-driving: the router picks the tier for this turn ──
72	        let engine = keel::Engine::assemble(&manifest)?;
73	        let mut step = Step {
74	            kind: if core_wire { Kind::CoreWire } else { Kind::Scaffolding },
75	            ty: "user_turn".into(),
76	            trust_required: Trust::Normal,
77	            data_class: if sovereign { DataClass::Sovereign } else { DataClass::Normal },
78	            tier_history: vec![],
79	            oracle_failures: 0,
80	            projected_cost: None,
81	            critical: false,
82	            source: Some("cli".into()),
83	            content: vec![Content::Text { text: prompt.clone() }],
84	            golden_refs: vec![],
85	        };
86	        let req = GenerateRequest {
87	            messages: vec![user],
88	            model: String::new(), // the engine sets the routed tier's model
89	            tools: vec![],
90	            grammar: None,
91	            // let the router pick thinking per tier; `--think` forces it on regardless of tier.
92	            effort: Effort { n: 1, thinking: if think { Some("high".into()) } else { None } },
93	            cache_prefix_len: None,
94	        };
95	        let outcome = engine.run(&mut step, &mut ctx, req).await?;
```

## Claude — Jun 14, 2026 03:25

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:25

Adding the flags, usage, and wiring them into the Step:

## Claude — Jun 14, 2026 03:25

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel\\src\\main.rs",
  "old_string": "    let mut sovereign = false;\n    let mut prompt = Vec::new();\n    let mut args = std::env::args().skip(1);\n    while let Some(a) = args.next() {\n        match a.as_str() {\n            \"--manifest\" => manifest_path = args.next().unwrap_or_default(),\n            \"--tier\" => tier_override = args.next(),\n            \"--kind\" => core_wire = matches!(args.next().as_deref(), Some(\"core-wire\") | Some(\"core_wire\")),\n            \"--sovereign\" => sovereign = true,\n            \"--think\" => think = true,\n            _ => prompt.push(a),\n        }\n    }",
  "new_string": "    let mut sovereign = false;\n    let mut critical = false;\n    let mut golden_refs: Vec<String> = Vec::new();\n    let mut prompt = Vec::new();\n    let mut args = std::env::args().skip(1);\n    while let Some(a) = args.next() {\n        match a.as_str() {\n            \"--manifest\" => manifest_path = args.next().unwrap_or_default(),\n            \"--tier\" => tier_override = args.next(),\n            \"--kind\" => core_wire = matches!(args.next().as_deref(), Some(\"core-wire\") | Some(\"core_wire\")),\n            \"--sovereign\" => sovereign = true,\n            \"--critical\" => critical = true,\n            \"--golden-ref\" => {\n                if let Some(n) = args.next() {\n                    golden_refs.push(n);\n                }\n            }\n            \"--think\" => think = true,\n            _ => prompt.push(a),\n        }\n    }"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\main.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 03:25

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel\\src\\main.rs",
  "old_string": "        eprintln!(\"usage: keel [--manifest PATH] [--tier NAME] [--kind core-wire] [--sovereign] [--think] <prompt>\");",
  "new_string": "        eprintln!(\"usage: keel [--manifest PATH] [--tier NAME] [--kind core-wire] [--sovereign] [--critical] [--golden-ref NAME] [--think] <prompt>\");"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\main.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 03:25

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel\\src\\main.rs",
  "old_string": "            critical: false,\n            source: Some(\"cli\".into()),\n            content: vec![Content::Text { text: prompt.clone() }],\n            golden_refs: vec![],\n        };",
  "new_string": "            critical,\n            source: Some(\"cli\".into()),\n            content: vec![Content::Text { text: prompt.clone() }],\n            golden_refs,\n        };"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\main.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 03:25

> _[thinking]_
> 

## Claude — Jun 14, 2026 03:25

All Half-B code in. Running the gate — check first.

## Claude — Jun 14, 2026 03:25

<!-- end chunk 6/9 | next: chunk-007.md -->
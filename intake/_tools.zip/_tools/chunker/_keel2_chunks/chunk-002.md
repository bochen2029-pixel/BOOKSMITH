<!-- ============ CHUNK 2/9 ============ -->
<!-- source: You_are_continuing_the_build_of_KEEL_Bo_Chen_s_personal_sovereign_reusable_AI-harness_.md -->
<!-- section: You are continuing the build of KEEL — Bo Chen's personal, sovereign, reusable AI-harness … > Claude — Jun 14, 2026 01:23 -->
<!-- recap: last ~581 tokens of chunk 1, for continuity -->
> On the items you named:
> 4. Yes — add the one-line canon §8 footnote for per-tier egress-correct chains (the I3 reality). Document it; don't change behavior. Approved as a canon clarification.
> 5. impl Oracle for Verifier — the registry-of-oracles is a composite oracle; keep the engine seam a single &dyn Oracle. L4 addition, zero contract edit. Go with it.
> 6. Defer the golden_refs→GoldenCase resolver to Stage 2. For this slice, activate the mechanism (registry present, verify runs even if vacuous). Name the runtime golden-registry seam in STATE.md as Stage-2; don't improvise it now.
> 
> Step-1 escalation model: go with record + surface the Verdict + return; escalation realized across turns via the persisted oracle_failures/tier_history (what §8/§9 imply — the Step carries the history, the next route re-reads it). In-turn re-escalate-and-retry is a clean follow-up, not this slice.
> 
> Sequence + gate: record-first is right. Do Step 0 now (the doc fixes; I handle the re-stamp in parallel). Then go straight into Step 1 — write kernel::engine over the injected joints and shrink keel::Engine (L5) to pure injection — and bank a local commit, but do NOT push. Show me the diff, the cargo test/clippy result, and the updated STATE.md; I'll review and tell you to push. Zero contract/golden edits, freeze seal unmoved, per-crate budget respected — as you laid out.
> 
> Go.
> 
> ## Claude — Jun 14, 2026 01:23
> 
> > _[thinking]_
> > 
> 
> ## Claude — Jun 14, 2026 01:23
> 
> The standard is set and the rulings are clear. Marking the shift from onboarding to build, then executing Step 0 (docs) and Step 1 (`kernel::engine`).
> 
> First, I need exact on-disk text for the doc edits and the full type/kernel surface to write the engine correctly. Reading the relevant files.
> 
> ## Claude — Jun 14, 2026 01:23
> 
> **[tool: mcp__ccd_session__mark_chapter]**
> ```json
> {
>   "title": "Step 0+1: record fix + kernel::engine",
>   "summary": "Reconcile docs (Director ruling, build-state, Marrow bench, canon §8 footnote), then build kernel::engine (L1) wiring I5/I4/I2 and shrink keel::Engine to injection."
> }
> ```
> **[tool result]**
> ```
> Chapter marked: "Step 0+1: record fix + kernel::engine". Continue your current work.
> ```
> 
> ## Claude — Jun 14, 2026 01:23
<!-- end recap | new content begins -->

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\CLAUDE.md"
}
```
**[tool result]**
```
1	# CLAUDE.md — KEEL build instructions for Claude Code
2	
3	You are building **KEEL** (Bo Chen's personal, sovereign, reusable harness core — the *genome* from which every specialization is grown as a *cell*). Read `KEEL_ARCHITECTURE.md` (the canon) **and** this file at the start of every session before writing code.
4	
5	---
6	
7	## What this is
8	The persistent, sovereign **self** that perceives (eyes + ears), remembers, routes every unit of work to the cheapest brain that clears the trust bar, amplifies a small local model, and grounds every critical output in an assertion no model authored. The model that thinks is interchangeable, **rented cognition**; KEEL is the self. Native Rust core, consumed **embedded** (in-process) *or* **over protocol** (HTTP + MCP + OpenAI-egress) — the *.NET-of-my-AI-apps* reuse model.
9	
10	**L1 personal tool, not a product.** No multi-tenancy, no features for hypothetical users. "Universal" = the *intersection* of what the operator's projects actually need (canon §2, §16), never their union.
11	
12	## Environment (Windows 11)
13	- Repo `C:\KEEL\`. Rust stable `x86_64-pc-windows-msvc`, edition 2021. **Build/test from a native MSVC dev shell (PowerShell)**, not git-bash.
14	- **Known toolchain issue — resolve before Stage 0:** `rustc` can't find `std`/`core` for the host target (E0463) though `rustup` reports `rust-std` installed/up-to-date — a missing/corrupt std rlib on disk. Fix: `rustup toolchain install stable-x86_64-pc-windows-msvc --force` (or `rustup update stable`). **Operator-gated** (it touches the global toolchain DAVE/TERMINAL share). `cargo check` must pass before any Stage-0 slice is "done."
15	- Substrate (resolved, not embedded — canon §13): `C:\llama.cpp` (llama-server), `C:\models` (Qwen3.5-9B-Q5_K_M + `mmproj-F16`, whisper `large-v3-turbo`, the OpenAI privacy-filter), `C:\whisper.cpp`. Cloud keys (`DEEPSEEK_API_KEY` / `ANTHROPIC_API_KEY`) live in env; the operator rotates them — **never hardcode or commit a key.**
16	- **Reference bench:** Marrow-L1 (Python, green, golden-tested) at `C:\loom\marrow-l1` is the executable oracle the Rust core diffs against (the ASTRA-textverse pattern). Don't port its code — diff against its behavior + the goldens.
17	
18	## Non-negotiable rules
19	1. **The canon is the source of truth** (`KEEL_ARCHITECTURE.md`). When code and canon disagree, fix the wrong one **in the same change**. Never let them drift.
20	2. **The ten contracts are sacred** (`crates/keel-contracts`, canon §7). Don't change a joint without updating both sides + the golden cases in the same change. The joints are the genome; they are meant never to be rewritten.
21	3. **Golden cases are agent-frozen** (`tests/golden/golden.json` + `.frozen.json`) — the *language-neutral conformance layer*. You MAY NOT edit them; if a golden fails, fix the **code**. Ratifying/freezing/changing a golden is an **operator action only**.
22	4. **Per-crate budget.** Each crate stays comprehensible in one session; keep it lean, split before it becomes a god-crate.
23	5. **Layer-import rule:** `contracts ← kernel ← {adapters, middleware} ← services ← apps`. A service may import middleware; middleware may **never** import a service; the kernel imports only contracts. Enforce via cargo deps / a lint; violations are bugs, not style.
24	6. **Protocol-first.** Chat Completions + MCP + OpenAPI/HTTP. A new provider is a new adapter; nothing above changes. Never invent a wire protocol.
25	7. **Async by default** (the contracts already are).
26	8. **The five invariants + the reversibility gate hold on every call** (canon §5): I1 audit · I2 spine · I3 sovereign/perception-local · I4 cost-capped · I5 externalized. **Memory safety is I5 applied to the source — let the compiler be the oracle** (ADR #5).
27	
28	## Hard prohibitions (reversibility gate — see AUTONOMY_CHARTER.md)
29	- No `git reset --hard`, `clean -fd/-fx`, `checkout -- <path>`, `restore` on uncommitted work; no `push --force`; no `branch -D` on unm…
```

## Claude — Jun 14, 2026 01:23

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-contracts\\src\\types.rs"
}
```
**[tool result]**
```
1	//! KEEL L0 — core types. Frozen with the traits; the genome's data surface.
2	//!
3	//! Contracts stay clock-free and side-effect-free: time is an `i64` the kernel stamps,
4	//! opaque state is JSON. Multimodal `Content` carries the eyes/ears (canon §10, §12).
5	
6	use serde::{Deserialize, Serialize};
7	use std::collections::HashMap;
8	
9	/// Arbitrary JSON (tool args, opaque artifacts, golden input/expect, run-state).
10	pub type Json = serde_json::Value;
11	/// Unix epoch milliseconds. The kernel stamps time; contracts never read a clock.
12	pub type Time = i64;
13	/// Resumable-run identifier (I2).
14	pub type RunId = String;
15	/// Opaque, serializable per-step state for the run-state spine (I2).
16	pub type State = Json;
17	
18	// ── messages & multimodal content ──────────────────────────────────────────
19	
20	#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
21	#[serde(rename_all = "snake_case")]
22	pub enum Role {
23	    System,
24	    User,
25	    Assistant,
26	    Tool,
27	}
28	
29	/// A message part. Vision rides the cognition protocol (canon §3, §12); raw `Image`/`Clip`/
30	/// `Audio` are sovereign-by-default (I3) and force the local tier.
31	#[derive(Clone, Debug, Serialize, Deserialize)]
32	#[serde(tag = "type", rename_all = "snake_case")]
33	pub enum Content {
34	    Text { text: String },
35	    Image { source: String },                 // path or data-uri
36	    Clip { video: String, frames: String },    // video ref + frame spec
37	    Audio { source: String },
38	}
39	
40	#[derive(Clone, Debug, Serialize, Deserialize)]
41	pub struct Message {
42	    pub role: Role,
43	    pub content: Vec<Content>,
44	    #[serde(default, skip_serializing_if = "Option::is_none")]
45	    pub name: Option<String>,
46	    /// DeepSeek: MUST be replayed across tool turns or the provider 400s.
47	    #[serde(default, skip_serializing_if = "Option::is_none")]
48	    pub reasoning_content: Option<String>,
49	    #[serde(default, skip_serializing_if = "Option::is_none")]
50	    pub tool_call_id: Option<String>,
51	}
52	
53	// ── routing primitives ──────────────────────────────────────────────────────
54	
55	#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
56	#[serde(rename_all = "snake_case")]
57	pub enum Kind {
58	    Scaffolding,
59	    CoreWire,
60	}
61	
62	/// Trust as a first-class routable quantity (canon §4). Ordered Low < Normal < High < Critical.
63	#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
64	#[serde(rename_all = "snake_case")]
65	pub enum Trust {
66	    Low,
67	    Normal,
68	    High,
69	    Critical,
70	}
71	
72	#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
73	#[serde(rename_all = "snake_case")]
74	pub enum DataClass {
75	    Normal,
76	    Sovereign,
77	    Phi,
78	}
79	
80	/// The amplification dial (canon §4): best-of-N width × thinking depth.
81	#[derive(Clone, Debug, Serialize, Deserialize)]
82	pub struct Effort {
83	    pub n: u32,
84	    #[serde(default, skip_serializing_if = "Option::is_none")]
85	    pub thinking: Option<String>, // "low" | "high" | "max"
86	}
87	impl Default for Effort {
88	    fn default() -> Self {
89	        Self { n: 1, thinking: None }
90	    }
91	}
92	
93	// ── usage, price, cost ───────────────────────────────────────────────────────
94	
95	#[derive(Clone, Copy, Debug, Default, Serialize, Deserialize)]
96	pub struct Usage {
97	    pub input_tokens: u64,
98	    pub output_tokens: u64,
99	    /// DeepSeek prompt_cache_hit_tokens — the 100× lever.
100	    pub cache_hit_tokens: u64,
101	}
102	
103	/// USD per 1,000,000 tokens.
104	#[derive(Clone, Copy, Debug, Default, Serialize, Deserialize)]
105	pub struct Price {
106	    pub input_miss: f64,
107	    pub input_hit: f64,
108	    pub output: f64,
109	}
110	
111	/// Cost from usage + tier price. Cache-miss input = total input minus cache hits.
112	/// Pinned by GOLDEN_MODEL_TIER (the language-neutral conformance layer).
113	pub fn c…
```

## Claude — Jun 14, 2026 01:23

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:23

Now the kernel internals, the store (Spine impl), the error type, and the two app entrypoints that consume `Engine` — so I shrink L5 without breaking callers.

## Claude — Jun 14, 2026 01:23

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\lib.rs"
}
```
**[tool result]**
```
1	//! # keel-kernel — L1, the spine
2	//!
3	//! The kernel runs the genome. It imports **only** L0 (`keel-contracts`) — never adapters,
4	//! middleware, or services (the layer rule, canon §6). Built one slice at a time:
5	//!
6	//! - **landed:** `manifest` (config → behavior) · `context` (the object that flows every call) ·
7	//!   `registry` (tier → adapter) · `chain` (the middleware executor) · `lifecycle` (the substrate
8	//!   resolver — probe/resolve **and** launch/supervise).
9	//! - **next:** `engine` (the closed loop) · `lock` (reproducibility / substrate pin).
10	
11	pub mod chain;
12	pub mod context;
13	pub mod lifecycle;
14	pub mod manifest;
15	pub mod registry;
16	
17	pub use chain::Chain;
18	pub use context::{new_context, new_trace_id, now_millis};
19	pub use lifecycle::{
20	    default_local_candidates, launch, probe, resolve_endpoint, LlamaServer, LlamaServerConfig,
21	};
22	pub use manifest::{CostCfg, Manifest, PriceCfg, RouterCfg, TierCfg};
23	pub use registry::Registry;
24	
```

## Claude — Jun 14, 2026 01:23

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\chain.rs"
}
```
**[tool result]**
```
1	//! keel-kernel::chain — the middleware executor (canon §6, §14).
2	//!
3	//! The onion that threads every call through the registered `Middleware`s, in order, down to a
4	//! terminal `ModelTier::generate`. Because the chain wraps **every** call, the cross-cutting
5	//! invariants that live in middleware — I1 audit, I3 privacy, I4 cost — become structurally
6	//! unbypassable: there is no path to a tier that does not pass through here.
7	//!
8	//! `Middleware::handle` receives `&Context` (it observes, gates, and transforms the *request*);
9	//! it cannot mutate the context. Accumulation that must persist across a run (cost totals,
10	//! redaction state) is therefore the engine's job — the engine owns the `Context` and folds in
11	//! `result.cost` after the chain returns. This keeps the frozen contract honest.
12	
13	use keel_contracts::{Context, GenerateRequest, GenerateResult, Middleware, ModelTier, Next, Result};
14	use std::sync::Arc;
15	
16	/// An ordered stack of middleware, run around a terminal tier. Cheap to clone (shared `Arc`).
17	#[derive(Clone, Default)]
18	pub struct Chain {
19	    middleware: Arc<Vec<Arc<dyn Middleware>>>,
20	}
21	
22	impl Chain {
23	    /// Build a chain from middleware in **outermost-first** order: index 0 sees the call first
24	    /// (and the response last).
25	    pub fn new(middleware: Vec<Arc<dyn Middleware>>) -> Self {
26	        Self { middleware: Arc::new(middleware) }
27	    }
28	
29	    /// Number of middleware layers.
30	    pub fn len(&self) -> usize {
31	        self.middleware.len()
32	    }
33	
34	    pub fn is_empty(&self) -> bool {
35	        self.middleware.is_empty()
36	    }
37	
38	    /// Run a request through the full stack, terminating at `terminal.generate`.
39	    pub async fn run(
40	        &self,
41	        req: GenerateRequest,
42	        ctx: &Context,
43	        terminal: Arc<dyn ModelTier>,
44	    ) -> Result<GenerateResult> {
45	        let link = Link { chain: self.middleware.clone(), idx: 0, terminal };
46	        link.run(req, ctx).await
47	    }
48	}
49	
50	/// One position in the onion: middleware `idx`, or the terminal once `idx` runs off the end.
51	/// Fully owned (`Arc` clones), so the recursive `&dyn Next` borrow has no lifetime tangles.
52	struct Link {
53	    chain: Arc<Vec<Arc<dyn Middleware>>>,
54	    idx: usize,
55	    terminal: Arc<dyn ModelTier>,
56	}
57	
58	#[async_trait::async_trait]
59	impl Next for Link {
60	    async fn run(&self, req: GenerateRequest, ctx: &Context) -> Result<GenerateResult> {
61	        match self.chain.get(self.idx) {
62	            Some(mw) => {
63	                let next = Link {
64	                    chain: self.chain.clone(),
65	                    idx: self.idx + 1,
66	                    terminal: self.terminal.clone(),
67	                };
68	                mw.handle(req, ctx, &next).await
69	            }
70	            None => self.terminal.generate(req, ctx).await,
71	        }
72	    }
73	}
74	
75	#[cfg(test)]
76	mod tests {
77	    use super::*;
78	    use async_trait::async_trait;
79	    use keel_contracts::{Capabilities, KeelError};
80	    use std::sync::Mutex;
81	
82	    fn req() -> GenerateRequest {
83	        GenerateRequest {
84	            messages: vec![],
85	            model: "m".into(),
86	            tools: vec![],
87	            grammar: None,
88	            effort: Default::default(),
89	            cache_prefix_len: None,
90	        }
91	    }
92	
93	    /// Terminal that records the model it was asked for and echoes it back.
94	    struct EchoTier {
95	        seen: Arc<Mutex<Vec<String>>>,
96	    }
97	    #[async_trait]
98	    impl ModelTier for EchoTier {
99	        fn caps(&self) -> Capabilities {
100	            Capabilities::default()
101	        }
102	        async fn generate(&self, req: GenerateRequest, _ctx: &Context) -> Result<GenerateResult> {
103	            self.seen.lock().unwrap().push(format!("terminal:{}", req.model));
104	            Ok(GenerateResult { content: req.…
```

## Claude — Jun 14, 2026 01:23

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\context.rs"
}
```
**[tool result]**
```
1	//! keel-kernel::context — minting and threading the universal `Context` (canon §14).
2	//!
3	//! `Context` is L0 *data* (every contract method receives it). The kernel owns its
4	//! *construction*: it stamps the clock and the trace id (L0 stays clock-free by design — see
5	//! `types.rs`), and seeds the per-task budget from the manifest (I4).
6	
7	use crate::manifest::Manifest;
8	use keel_contracts::{Context, Time};
9	
10	/// Unix epoch milliseconds. The kernel is where time is read; contracts never read a clock.
11	pub fn now_millis() -> Time {
12	    use std::time::{SystemTime, UNIX_EPOCH};
13	    SystemTime::now()
14	        .duration_since(UNIX_EPOCH)
15	        .map(|d| d.as_millis() as i64)
16	        .unwrap_or(0)
17	}
18	
19	/// A fresh 12-hex-char run/trace id (matches the bench's `uuid4().hex[:12]`).
20	pub fn new_trace_id() -> String {
21	    let s = uuid::Uuid::new_v4().simple().to_string();
22	    s[..12].to_string()
23	}
24	
25	/// Mint a fresh `Context` for a run: a new trace id, a clean redaction state (I3), and the
26	/// per-task budget (I4) seeded from the manifest.
27	pub fn new_context(manifest: &Manifest) -> Context {
28	    Context {
29	        trace_id: new_trace_id(),
30	        task_budget: Some(manifest.cost.budget_per_task),
31	        redaction_state: "clean".to_string(),
32	        ..Default::default()
33	    }
34	}
35	
36	#[cfg(test)]
37	mod tests {
38	    use super::*;
39	
40	    #[test]
41	    fn trace_id_is_twelve_hex_and_unique() {
42	        let a = new_trace_id();
43	        let b = new_trace_id();
44	        assert_eq!(a.len(), 12);
45	        assert!(a.chars().all(|c| c.is_ascii_hexdigit()));
46	        assert_ne!(a, b);
47	    }
48	
49	    #[test]
50	    fn now_millis_is_after_2024() {
51	        // 2024-01-01T00:00:00Z, in ms — a sanity floor, not a precise clock test.
52	        assert!(now_millis() > 1_704_067_200_000);
53	    }
54	
55	    #[test]
56	    fn new_context_seeds_budget_and_clean_state() {
57	        let m = Manifest::default();
58	        let c = new_context(&m);
59	        assert_eq!(c.redaction_state, "clean");
60	        assert_eq!(c.task_budget, Some(m.cost.budget_per_task));
61	        assert_eq!(c.budget_remaining(), Some(m.cost.budget_per_task));
62	        assert_eq!(c.trace_id.len(), 12);
63	    }
64	}
65	
```

## Claude — Jun 14, 2026 01:23

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:23

The chain doc comment (lines 8–11) is the explicit directive: *"the engine owns the `Context` and folds in `result.cost` after the chain returns"* — confirming cost-accumulation belongs in `kernel::engine`. Now the registry, the Spine impl, the error type, and the two app entrypoints.

## Claude — Jun 14, 2026 01:23

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\registry.rs"
}
```
**[tool result]**
```
1	//! keel-kernel::registry — tier name → brain adapter (canon §14).
2	//!
3	//! A container of `Arc<dyn ModelTier>` keyed by tier name. **The kernel may not import L2
4	//! adapters** (the layer rule, canon §6) — so, unlike the Marrow-L1 bench (whose `registry.py`
5	//! imports the adapter classes directly), here the wiring/app layer reads the `Manifest`,
6	//! constructs each adapter, and `register`s it. The kernel only ever holds the L0 trait object.
7	
8	use keel_contracts::{KeelError, ModelTier, Result};
9	use std::collections::BTreeMap;
10	use std::sync::Arc;
11	
12	/// Maps a tier name (`local` | `cheap-API` | `frontier` | …) to its brain adapter.
13	#[derive(Default, Clone)]
14	pub struct Registry {
15	    tiers: BTreeMap<String, Arc<dyn ModelTier>>,
16	}
17	
18	impl Registry {
19	    pub fn new() -> Self {
20	        Self::default()
21	    }
22	
23	    /// Register (or replace) the adapter for a tier. Returns `&mut self` for chaining.
24	    pub fn register(&mut self, name: impl Into<String>, tier: Arc<dyn ModelTier>) -> &mut Self {
25	        self.tiers.insert(name.into(), tier);
26	        self
27	    }
28	
29	    /// The adapter for a tier, or an error if none is registered (a wiring/config fault).
30	    pub fn get(&self, tier: &str) -> Result<Arc<dyn ModelTier>> {
31	        self.tiers
32	            .get(tier)
33	            .cloned()
34	            .ok_or_else(|| KeelError::Other(format!("no adapter registered for tier '{tier}'")))
35	    }
36	
37	    pub fn contains(&self, tier: &str) -> bool {
38	        self.tiers.contains_key(tier)
39	    }
40	
41	    /// Registered tier names (sorted, since the backing store is a `BTreeMap`).
42	    pub fn names(&self) -> Vec<String> {
43	        self.tiers.keys().cloned().collect()
44	    }
45	
46	    pub fn len(&self) -> usize {
47	        self.tiers.len()
48	    }
49	
50	    pub fn is_empty(&self) -> bool {
51	        self.tiers.is_empty()
52	    }
53	}
54	
55	#[cfg(test)]
56	mod tests {
57	    use super::*;
58	    use async_trait::async_trait;
59	    use keel_contracts::{Capabilities, Context, GenerateRequest, GenerateResult};
60	
61	    /// A no-op tier — exercises the registry without needing a runtime (generate is never awaited).
62	    struct DummyTier;
63	
64	    #[async_trait]
65	    impl ModelTier for DummyTier {
66	        fn caps(&self) -> Capabilities {
67	            Capabilities::default()
68	        }
69	        async fn generate(&self, _req: GenerateRequest, _ctx: &Context) -> Result<GenerateResult> {
70	            Ok(GenerateResult::default())
71	        }
72	    }
73	
74	    #[test]
75	    fn register_get_contains_names() {
76	        let mut r = Registry::new();
77	        assert!(r.is_empty());
78	        r.register("local", Arc::new(DummyTier))
79	            .register("cheap-API", Arc::new(DummyTier));
80	
81	        assert_eq!(r.len(), 2);
82	        assert!(r.contains("local"));
83	        assert!(r.get("local").is_ok());
84	        assert!(r.get("frontier").is_err()); // unregistered tier
85	        assert_eq!(r.names(), vec!["cheap-API".to_string(), "local".to_string()]);
86	    }
87	
88	    #[test]
89	    fn register_replaces() {
90	        let mut r = Registry::new();
91	        r.register("local", Arc::new(DummyTier));
92	        r.register("local", Arc::new(DummyTier));
93	        assert_eq!(r.len(), 1);
94	    }
95	}
96	
```

## Claude — Jun 14, 2026 01:23

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-store\\src\\lib.rs"
}
```
**[tool result]**
```
1	//! keel-store — L2, the index (canon §13). **SQLite baked into the binary** (the `bundled`
2	//! feature; ~1 MB, the one primitive small enough to truly embed), behind a `Store` seam. This
3	//! first cut implements the `Spine` contract (I2): durable, resumable run-state. The append-only
4	//! file ledger remains the system of record; this index is **derived and rebuildable** from it.
5	
6	use async_trait::async_trait;
7	use keel_contracts::{KeelError, Result, RunId, Spine, State};
8	use rusqlite::{params, Connection, OptionalExtension};
9	use std::sync::Mutex;
10	
11	const SCHEMA: &str =
12	    "CREATE TABLE IF NOT EXISTS runs (run_id TEXT PRIMARY KEY, state TEXT NOT NULL, updated_at INTEGER NOT NULL);";
13	
14	/// A SQLite-backed index. The `Spine` impl persists run-state for crash-resume (I2). The
15	/// connection sits behind a `Mutex` (rusqlite is sync; the guard is never held across an await).
16	pub struct SqliteStore {
17	    conn: Mutex<Connection>,
18	}
19	
20	impl SqliteStore {
21	    /// Open (creating the file + schema) at `path`.
22	    pub fn open(path: &str) -> Result<Self> {
23	        let conn = Connection::open(path).map_err(sql_err)?;
24	        conn.execute_batch(SCHEMA).map_err(sql_err)?;
25	        Ok(Self { conn: Mutex::new(conn) })
26	    }
27	
28	    /// An ephemeral in-memory index (tests, scratch).
29	    pub fn in_memory() -> Result<Self> {
30	        let conn = Connection::open_in_memory().map_err(sql_err)?;
31	        conn.execute_batch(SCHEMA).map_err(sql_err)?;
32	        Ok(Self { conn: Mutex::new(conn) })
33	    }
34	}
35	
36	fn sql_err(e: rusqlite::Error) -> KeelError {
37	    KeelError::Other(format!("sqlite: {e}"))
38	}
39	
40	fn now_millis() -> i64 {
41	    use std::time::{SystemTime, UNIX_EPOCH};
42	    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_millis() as i64).unwrap_or(0)
43	}
44	
45	#[async_trait]
46	impl Spine for SqliteStore {
47	    async fn checkpoint(&self, run: &RunId, state: &State) -> Result<()> {
48	        let json = serde_json::to_string(state).map_err(|e| KeelError::Other(format!("state encode: {e}")))?;
49	        let conn = self.conn.lock().unwrap();
50	        conn.execute(
51	            "INSERT INTO runs (run_id, state, updated_at) VALUES (?1, ?2, ?3) \
52	             ON CONFLICT(run_id) DO UPDATE SET state = ?2, updated_at = ?3",
53	            params![run, json, now_millis()],
54	        )
55	        .map_err(sql_err)?;
56	        Ok(())
57	    }
58	
59	    async fn resume(&self, run: &RunId) -> Result<Option<State>> {
60	        let conn = self.conn.lock().unwrap();
61	        let row: Option<String> = conn
62	            .query_row("SELECT state FROM runs WHERE run_id = ?1", params![run], |r| r.get(0))
63	            .optional()
64	            .map_err(sql_err)?;
65	        match row {
66	            Some(s) => {
67	                Ok(Some(serde_json::from_str(&s).map_err(|e| KeelError::Other(format!("state decode: {e}")))?))
68	            }
69	            None => Ok(None),
70	        }
71	    }
72	}
73	
74	#[cfg(test)]
75	mod tests {
76	    use super::*;
77	    use serde_json::json;
78	
79	    #[tokio::test]
80	    async fn checkpoint_then_resume_roundtrips() {
81	        let store = SqliteStore::in_memory().unwrap();
82	        let run = "run-1".to_string();
83	        assert!(store.resume(&run).await.unwrap().is_none()); // nothing yet
84	        store.checkpoint(&run, &json!({ "step": 3, "plan": "x" })).await.unwrap();
85	        let got = store.resume(&run).await.unwrap().unwrap();
86	        assert_eq!(got["step"], 3);
87	        assert_eq!(got["plan"], "x");
88	    }
89	
90	    #[tokio::test]
91	    async fn checkpoint_upserts_latest_state() {
92	        let store = SqliteStore::in_memory().unwrap();
93	        let run = "run-2".to_string();
94	        store.checkpoint(&run, &json!({ "step": 1 })).await.unwrap();
95	        store.checkpoint(&run, &json!({ "step": 9 })).await.unwrap();
96	        assert_eq!(store.resume(&run).await.unwra…
```

## Claude — Jun 14, 2026 01:23

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-contracts\\src\\errors.rs"
}
```
**[tool result]**
```
1	//! KEEL error taxonomy (canon §18). Typed, with stable codes that match the canon table.
2	
3	use std::fmt;
4	
5	/// Every fallible contract method returns `Result<T>` over this taxonomy.
6	pub type Result<T> = std::result::Result<T, KeelError>;
7	
8	#[derive(Clone, Debug)]
9	pub enum KeelError {
10	    /// No tier clears the bar within budget.
11	    RouteNoTier(String),
12	    /// Provider/server down or OOM.
13	    TierUnavailable(String),
14	    /// Output failed an oracle.
15	    OracleFail(String),
16	    /// Tests + code agree, a golden disagrees. Surfaced to the operator immediately.
17	    JointWrong(String),
18	    /// Task cost cap hit (I4 hard-stop).
19	    BudgetExceeded(String),
20	    /// All tiers failed the oracle.
21	    EscalationExhausted(String),
22	    /// Undo cost unstatable in one sentence (the reversibility gate).
23	    ReversibilityBlock(String),
24	    /// A claim cannot be grounded in ground truth (routes to human).
25	    InsufficientSource(String),
26	    /// A sense returned below its confidence floor (routes to review).
27	    PerceptLowConfidence(String),
28	    /// No inference layer found or launchable.
29	    SubstrateUnresolved(String),
30	    /// Constrained decode produced invalid output (should be impossible; adapter bug on repeat).
31	    GrammarViolation(String),
32	    /// Anything else, carried with a message.
33	    Other(String),
34	}
35	
36	impl KeelError {
37	    /// The stable code string (canon §18).
38	    pub fn code(&self) -> &'static str {
39	        use KeelError::*;
40	        match self {
41	            RouteNoTier(_) => "ROUTE_NO_TIER",
42	            TierUnavailable(_) => "TIER_UNAVAILABLE",
43	            OracleFail(_) => "ORACLE_FAIL",
44	            JointWrong(_) => "JOINT_WRONG",
45	            BudgetExceeded(_) => "BUDGET_EXCEEDED",
46	            EscalationExhausted(_) => "ESCALATION_EXHAUSTED",
47	            ReversibilityBlock(_) => "REVERSIBILITY_BLOCK",
48	            InsufficientSource(_) => "INSUFFICIENT_SOURCE",
49	            PerceptLowConfidence(_) => "PERCEPT_LOW_CONFIDENCE",
50	            SubstrateUnresolved(_) => "SUBSTRATE_UNRESOLVED",
51	            GrammarViolation(_) => "GRAMMAR_VIOLATION",
52	            Other(_) => "KEEL_ERROR",
53	        }
54	    }
55	
56	    /// The carried human-readable message.
57	    pub fn message(&self) -> &str {
58	        use KeelError::*;
59	        match self {
60	            RouteNoTier(s) | TierUnavailable(s) | OracleFail(s) | JointWrong(s) | BudgetExceeded(s)
61	            | EscalationExhausted(s) | ReversibilityBlock(s) | InsufficientSource(s)
62	            | PerceptLowConfidence(s) | SubstrateUnresolved(s) | GrammarViolation(s) | Other(s) => s,
63	        }
64	    }
65	}
66	
67	impl fmt::Display for KeelError {
68	    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
69	        write!(f, "[{}] {}", self.code(), self.message())
70	    }
71	}
72	
73	impl std::error::Error for KeelError {}
74	
```

## Claude — Jun 14, 2026 01:23

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:23

Now the two app entrypoints that consume `Engine`, to shrink L5 without breaking callers.

## Claude — Jun 14, 2026 01:23

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel\\src\\main.rs"
}
```
**[tool result]**
```
1	//! keel — the daily-driver CLI (L5). By default it **self-drives**: it builds the multi-tier
2	//! [`Engine`](keel::Engine), lets the router pick the tier for the turn (scaffolding → local ·
3	//! core-wire → cheap-API · escalate → frontier), runs it through the invariant chain, and prints
4	//! the answer + the routing reason. `--tier` pins a tier manually (the single-tier path).
5	//!
6	//!   keel "read me the config"                  # → routed (scaffolding → local)
7	//!   keel --kind core-wire "weigh the tradeoffs"# → routed (core-wire → cheap-API)
8	//!   keel --sovereign "summarize my journal"    # → forced local (I3)
9	//!   keel --tier frontier "hard question"       # → manual override (no router)
10	//!   keel --think "…"      keel --manifest C:\KEEL\keel.lock "hello"
11	
12	use keel_contracts::{Content, Context, DataClass, Effort, GenerateRequest, GenerateResult, Kind, Message, Role, Step, Trust};
13	use keel_kernel::{new_context, Manifest};
14	
15	#[tokio::main]
16	async fn main() {
17	    if let Err(e) = run().await {
18	        eprintln!("keel: {e}");
19	        std::process::exit(1);
20	    }
21	}
22	
23	async fn run() -> keel_contracts::Result<()> {
24	    let mut manifest_path = "keel.lock".to_string();
25	    let mut tier_override: Option<String> = None;
26	    let mut think = false;
27	    let mut core_wire = false;
28	    let mut sovereign = false;
29	    let mut prompt = Vec::new();
30	    let mut args = std::env::args().skip(1);
31	    while let Some(a) = args.next() {
32	        match a.as_str() {
33	            "--manifest" => manifest_path = args.next().unwrap_or_default(),
34	            "--tier" => tier_override = args.next(),
35	            "--kind" => core_wire = matches!(args.next().as_deref(), Some("core-wire") | Some("core_wire")),
36	            "--sovereign" => sovereign = true,
37	            "--think" => think = true,
38	            _ => prompt.push(a),
39	        }
40	    }
41	    let prompt = prompt.join(" ");
42	    if prompt.trim().is_empty() {
43	        eprintln!("usage: keel [--manifest PATH] [--tier NAME] [--kind core-wire] [--sovereign] [--think] <prompt>");
44	        std::process::exit(2);
45	    }
46	
47	    let manifest = Manifest::load(&manifest_path)?;
48	    let ctx = new_context(&manifest);
49	    let user = Message {
50	        role: Role::User,
51	        content: vec![Content::Text { text: prompt.clone() }],
52	        name: None,
53	        reasoning_content: None,
54	        tool_call_id: None,
55	    };
56	
57	    if let Some(t) = tier_override {
58	        // ── manual override: pin one tier, skip the router (no needless local cold-start) ──
59	        let asm = keel::assemble(&manifest, Some(&t))?;
60	        let req = GenerateRequest {
61	            messages: vec![user],
62	            model: asm.model.clone(),
63	            tools: vec![],
64	            grammar: None,
65	            effort: Effort { n: 1, thinking: Some(if think { "high" } else { "low" }.into()) },
66	            cache_prefix_len: None,
67	        };
68	        let res = asm.chain.run(req, &ctx, asm.tier.clone()).await?;
69	        report(&res, &ctx, &format!("manual override → {}", asm.tier_name), think);
70	    } else {
71	        // ── self-driving: the router picks the tier for this turn ──
72	        let engine = keel::Engine::assemble(&manifest)?;
73	        let step = Step {
74	            kind: if core_wire { Kind::CoreWire } else { Kind::Scaffolding },
75	            ty: "user_turn".into(),
76	            trust_required: Trust::Normal,
77	            data_class: if sovereign { DataClass::Sovereign } else { DataClass::Normal },
78	            tier_history: vec![],
79	            oracle_failures: 0,
80	            projected_cost: None,
81	            critical: false,
82	            source: Some("cli".into()),
83	            content: vec![Content::Text { text: prompt.clone() }],
84	            golden_refs: vec![],
85	        };
86	        let req = GenerateRequest {
87	            messag…
```

## Claude — Jun 14, 2026 01:23

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel\\src\\bin\\keel-serve.rs"
}
```
**[tool result]**
```
1	//! keel-serve (L5) — expose KEEL as an **OpenAI-compatible HTTP server** (canon §15), so any app
2	//! (DAVE, TERMINAL, the C#/Python fleet) consumes KEEL as a brain over protocol and gets the whole
3	//! economy for free: **router-driven tier selection**, the invariant chain (audit/privacy/cost),
4	//! the ledger, and the self-resolving substrate. One [`Engine`](keel::Engine) is assembled at
5	//! startup and shared across requests; every request is routed (it is not pinned to one tier).
6	//!
7	//!   keel-serve [keel.lock]      →  POST http://127.0.0.1:7070/v1/chat/completions
8	
9	use axum::{extract::State, http::StatusCode, response::IntoResponse, routing::{get, post}, Json, Router};
10	use keel::{Engine, Outcome};
11	use keel_contracts::{Content, DataClass, Effort, GenerateRequest, Kind, Message, Role, Step, Trust};
12	use keel_kernel::{new_context, Manifest};
13	use serde::Deserialize;
14	use serde_json::{json, Value};
15	use std::sync::Arc;
16	
17	const ADDR: &str = "127.0.0.1:7070";
18	
19	#[derive(Clone)]
20	struct AppState {
21	    engine: Arc<Engine>,
22	    manifest: Arc<Manifest>,
23	}
24	
25	#[tokio::main]
26	async fn main() {
27	    let manifest_path = std::env::args().nth(1).unwrap_or_else(|| "keel.lock".to_string());
28	    let manifest = Manifest::load(&manifest_path).unwrap_or_else(|e| fail(format!("manifest: {e}")));
29	    eprintln!("[keel-serve] assembling engine (resolves/launches the substrate, wires available tiers)…");
30	    let engine = Engine::assemble(&manifest).unwrap_or_else(|e| fail(format!("assemble: {e}")));
31	    eprintln!("[keel-serve] tiers={:?}", engine.available());
32	
33	    let state = AppState { engine: Arc::new(engine), manifest: Arc::new(manifest) };
34	    let app = Router::new()
35	        .route("/health", get(|| async { "ok" }))
36	        .route("/v1/models", get(models))
37	        .route("/v1/chat/completions", post(chat))
38	        .with_state(state);
39	
40	    let listener = tokio::net::TcpListener::bind(ADDR).await.unwrap_or_else(|e| fail(format!("bind {ADDR}: {e}")));
41	    eprintln!("[keel-serve] OpenAI-compatible endpoint → http://{ADDR}/v1/chat/completions");
42	    axum::serve(listener, app).await.unwrap();
43	}
44	
45	fn fail(msg: String) -> ! {
46	    eprintln!("keel-serve: {msg}");
47	    std::process::exit(1);
48	}
49	
50	/// Advertise the wired tiers as selectable "models" (the router still has final say per turn).
51	async fn models(State(st): State<AppState>) -> impl IntoResponse {
52	    let data: Vec<Value> = st
53	        .engine
54	        .available()
55	        .into_iter()
56	        .map(|t| json!({ "id": t, "object": "model", "owned_by": "keel" }))
57	        .collect();
58	    Json(json!({ "object": "list", "data": data }))
59	}
60	
61	#[derive(Deserialize)]
62	struct ChatRequest {
63	    #[serde(default)]
64	    messages: Vec<ChatMessage>,
65	    /// KEEL extension: this turn is core-wire reasoning (else scaffolding) — a routing hint.
66	    #[serde(default)]
67	    kind: Option<String>,
68	    /// KEEL extension: sovereign data — forces the local tier (I3).
69	    #[serde(default)]
70	    sovereign: Option<bool>,
71	    /// KEEL extension: route this turn through the model's thinking mode.
72	    #[serde(default)]
73	    think: Option<bool>,
74	}
75	
76	#[derive(Deserialize)]
77	struct ChatMessage {
78	    role: String,
79	    #[serde(default)]
80	    content: Value, // string or array of parts
81	}
82	
83	async fn chat(State(st): State<AppState>, Json(body): Json<ChatRequest>) -> impl IntoResponse {
84	    if body.messages.is_empty() {
85	        return (StatusCode::BAD_REQUEST, Json(json!({ "error": { "message": "no messages" } }))).into_response();
86	    }
87	    let messages: Vec<Message> = body
88	        .messages
89	        .iter()
90	        .map(|m| Message {
91	            role: parse_role(&m.role),
92	            content: parse_content(&m.content),
93	            name: None,
94	            reasoning_content: None,
95	            …
```

## Claude — Jun 14, 2026 01:27

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:27

I now have the full surface. Both apps consume `keel::Engine::assemble` + `engine.run(&step,&ctx,req) -> Outcome` and `keel::assemble` for the `--tier` path. The slice will: move the loop into `kernel::engine::Engine` (owns `Context` for I4 fold per the chain doc), add `impl Oracle for Verifier` (L4), and make `keel::Engine` a thin injection wrapper. Last reads before writing — the dependency graphs and a confirm that `mw::cost` is pre-call only (no double-count when I fold `result.cost`).

## Claude — Jun 14, 2026 01:27

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\Cargo.toml"
}
```
**[tool result]**
```
1	[package]
2	name = "keel-kernel"
3	description = "KEEL L1 — the spine: manifest (config→behavior) · context · registry. Imports only L0."
4	version.workspace = true
5	edition.workspace = true
6	license.workspace = true
7	
8	[dependencies]
9	keel-contracts = { path = "../keel-contracts" }
10	serde = { version = "1", features = ["derive"] }
11	serde_yaml_ng = "0.10"
12	uuid = { version = "1", features = ["v4"] }
13	async-trait = "0.1"
14	
15	[dev-dependencies]
16	tokio = { version = "1", features = ["rt", "macros"] }
17	
```

## Claude — Jun 14, 2026 01:27

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel\\Cargo.toml"
}
```
**[tool result]**
```
1	[package]
2	name = "keel"
3	description = "KEEL L5 — apps: the daily-driver CLI and the OpenAI-compatible server, sharing one wiring lib."
4	version.workspace = true
5	edition.workspace = true
6	license.workspace = true
7	default-run = "keel"
8	
9	[lib]
10	name = "keel"
11	path = "src/lib.rs"
12	
13	[[bin]]
14	name = "keel"
15	path = "src/main.rs"
16	
17	[[bin]]
18	name = "keel-serve"
19	path = "src/bin/keel-serve.rs"
20	
21	[dependencies]
22	keel-contracts = { path = "../keel-contracts" }
23	keel-kernel = { path = "../keel-kernel" }
24	keel-middleware = { path = "../keel-middleware" }
25	keel-adapters = { path = "../keel-adapters" }
26	keel-services = { path = "../keel-services" }
27	tokio = { version = "1", features = ["rt-multi-thread", "macros", "net"] }
28	axum = "0.8"
29	serde = { version = "1", features = ["derive"] }
30	serde_json = "1"
31	
```

## Claude — Jun 14, 2026 01:27

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-services\\Cargo.toml"
}
```
**[tool result]**
```
1	[package]
2	name = "keel-services"
3	description = "KEEL L4 — services (route · amplify · verify · memory · perception · driver). Composes adapters under middleware."
4	version.workspace = true
5	edition.workspace = true
6	license.workspace = true
7	
8	[dependencies]
9	keel-contracts = { path = "../keel-contracts" }
10	async-trait = "0.1"
11	regex = "1"
12	
13	[dev-dependencies]
14	serde_json = "1"
15	tokio = { version = "1", features = ["macros", "rt"] }
16	
```

## Claude — Jun 14, 2026 01:27

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-middleware\\src\\cost.rs"
}
```
**[tool result]**
```
1	//! keel-middleware::cost — I4, the budget hard-stop gate (canon §5, §9).
2	//!
3	//! Reads the run's remaining budget from the `Context` and **blocks the call before it reaches a
4	//! tier** (returns `BudgetExceeded`) when remaining sits under the hard-stop floor. It is a
5	//! *gate*, not an accumulator: the frozen `Middleware::handle` sees `&Context`, so totalling
6	//! spent cost stays the engine's job (it owns the `Context` and folds in `result.cost` after the
7	//! chain returns). Pre-call gate + post-call accumulate is the I4 split the chain's `&Context`
8	//! contract implies.
9	
10	use async_trait::async_trait;
11	use keel_contracts::{Context, GenerateRequest, GenerateResult, KeelError, Middleware, Next, Result};
12	
13	/// The I4 budget gate. Construct with the hard-stop floor (canonically `CostCfg.hard_stop_at`).
14	pub struct CostMiddleware {
15	    hard_stop_at: f64,
16	}
17	
18	impl CostMiddleware {
19	    /// Block a call when the run's remaining budget would fall below `hard_stop_at` dollars.
20	    pub fn new(hard_stop_at: f64) -> Self {
21	        Self { hard_stop_at }
22	    }
23	}
24	
25	#[async_trait]
26	impl Middleware for CostMiddleware {
27	    async fn handle(&self, req: GenerateRequest, ctx: &Context, next: &dyn Next) -> Result<GenerateResult> {
28	        // Unbudgeted runs (no task_budget) are not gated; budgeted runs hard-stop at the floor.
29	        if let Some(remaining) = ctx.budget_remaining() {
30	            if remaining < self.hard_stop_at {
31	                return Err(KeelError::BudgetExceeded(format!(
32	                    "remaining ${:.4} below hard-stop ${:.4}",
33	                    remaining, self.hard_stop_at
34	                )));
35	            }
36	        }
37	        next.run(req, ctx).await
38	    }
39	}
40	
41	#[cfg(test)]
42	mod tests {
43	    use super::CostMiddleware;
44	    use async_trait::async_trait;
45	    use keel_contracts::{
46	        Capabilities, Context, GenerateRequest, GenerateResult, KeelError, ModelTier, Result,
47	    };
48	    use keel_kernel::Chain;
49	    use std::sync::{Arc, Mutex};
50	
51	    /// Terminal that counts how many times it was actually reached.
52	    struct CountTier {
53	        calls: Arc<Mutex<u32>>,
54	    }
55	    #[async_trait]
56	    impl ModelTier for CountTier {
57	        fn caps(&self) -> Capabilities {
58	            Capabilities::default()
59	        }
60	        async fn generate(&self, _req: GenerateRequest, _ctx: &Context) -> Result<GenerateResult> {
61	            *self.calls.lock().unwrap() += 1;
62	            Ok(GenerateResult { content: "ok".into(), ..Default::default() })
63	        }
64	    }
65	
66	    fn req() -> GenerateRequest {
67	        GenerateRequest {
68	            messages: vec![],
69	            model: "m".into(),
70	            tools: vec![],
71	            grammar: None,
72	            effort: Default::default(),
73	            cache_prefix_len: None,
74	        }
75	    }
76	
77	    fn ctx_with(budget: f64, spent: f64) -> Context {
78	        let mut c = Context { task_budget: Some(budget), ..Default::default() };
79	        c.cost.add("local", spent);
80	        c
81	    }
82	
83	    async fn run(ctx: &Context, hard_stop: f64) -> (Result<GenerateResult>, u32) {
84	        let calls = Arc::new(Mutex::new(0));
85	        let chain = Chain::new(vec![Arc::new(CostMiddleware::new(hard_stop))]);
86	        let res = chain.run(req(), ctx, Arc::new(CountTier { calls: calls.clone() })).await;
87	        let n = *calls.lock().unwrap();
88	        (res, n)
89	    }
90	
91	    #[tokio::test]
92	    async fn passes_when_budget_healthy() {
93	        let (res, calls) = run(&ctx_with(5.0, 0.5), 1.0).await; // remaining 4.5 ≥ 1.0
94	        assert!(res.is_ok());
95	        assert_eq!(calls, 1); // terminal reached
96	    }
97	
98	    #[tokio::test]
99	    async fn blocks_at_the_floor_before_calling_the_tier() {
100	        let (res, calls) = run(&ctx_with(5.0, 4.5), 1.0).await; // remaining 0.5 < 1.0
101	  …
```

## Claude — Jun 14, 2026 01:29

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:29

Everything checks out: `mw::cost` is a pre-call gate that never accumulates (its own doc says totalling "stays the engine's job ... folds in `result.cost` after the chain returns") — so folding cost in the engine is correct and won't double-count. Two minimal, layer-legal Cargo additions are needed: `serde_json` for `keel-kernel` (to serialize the checkpoint `State`) and `keel-store` for `keel` (to inject the SQLite `Spine`).

I have everything to execute. Starting **Step 0 — the reconciliation doc fixes**. First the canon §8 footnote and the CLAUDE.md Marrow-bench rewording (different files, in parallel).

## Claude — Jun 14, 2026 01:29

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\KEEL_ARCHITECTURE.md",
  "old_string": "`amplify?` is optional and ships disabled: best-of-N + verifier-selection is the one genome capability the other six systems did *not* independently rediscover (they bought reliability with trained weights and oracle gates), so it earns its place only by passing the §23 amplification falsifier — never by assumption.\n\n---",
  "new_string": "`amplify?` is optional and ships disabled: best-of-N + verifier-selection is the one genome capability the other six systems did *not* independently rediscover (they bought reliability with trained weights and oracle gates), so it earns its place only by passing the §23 amplification falsifier — never by assumption.\n\n> **Implementation note (I3 — per-tier chains).** The single `chain` above is illustrative. Because the privacy mask (I3) differs by destination — `local` stays on the box (pass-through) while every cloud tier is scrubbed before egress — the engine holds **one egress-correct chain per tier** and runs the routed tier through *its* chain, not one shared chain with a static flag. The loop shape is unchanged; `chain` is resolved per `Decision.tier`.\n\n---"
}
```
**[tool result]**
```
The file C:\KEEL\KEEL_ARCHITECTURE.md has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 01:29

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\CLAUDE.md",
  "old_string": "- **Reference bench:** Marrow-L1 (Python, green, golden-tested) at `C:\\loom\\marrow-l1` is the executable oracle the Rust core diffs against (the ASTRA-textverse pattern). Don't port its code — diff against its behavior + the goldens.",
  "new_string": "- **Reference bench (read-only):** Marrow-L1 (Python, green, golden-tested) at `C:\\loom\\marrow-l1` is a **read-only behavior reference / diff-oracle — never a build or runtime dependency.** KEEL ships nothing of Marrow's and links nothing from it; this is how the \"self-contained\" directive and the bench reference reconcile (diff against its *behavior* + the goldens — the ASTRA-textverse pattern — don't port its code)."
}
```
**[tool result]**
```
The file C:\KEEL\CLAUDE.md has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 01:30

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:30

Now the CLAUDE.md "Build state" block (replacing the stale four bullets with a current summary that defers to STATE.md as the live source).

## Claude — Jun 14, 2026 01:30

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\CLAUDE.md",
  "old_string": "## Build state\n- **Canon:** v0.2 adopted; patched with embedder/reranker + the privacy three-rung; ADR #5 = native Rust.\n- **L0 contracts:** written (`crates/keel-contracts` — the ten joints + types + the §18 error taxonomy). **Compile-pending the toolchain fix above** (the failure is in dependency build scripts, not KEEL code).\n- **Golden cases:** PROPOSED in `tests/golden/golden.json` — awaiting operator ratification, then freeze (operator action).\n- **Next:** Stage 0 (the spine). Nothing above L0 exists yet.",
  "new_string": "## Build state\n*(Summary only — the live, authoritative per-slice anchor is `_run_state/STATE.md`. Trust STATE.md + `git`, never this block, for current state.)*\n- **Canon:** v0.2 adopted; patched with embedder/reranker + the privacy three-rung; ADR #5 = native Rust.\n- **L0 contracts:** the ten joints + types + the §18 error taxonomy — frozen, green (rustc 1.96, MSVC).\n- **Golden cases:** RATIFIED + FROZEN (`tests/golden/golden.json` + `.frozen.json`, 21 cases / 6 families) — agent read-only. The KEEL-native freeze-gate is built but `#[ignore]`-dormant pending the operator's one-time re-stamp.\n- **Stage 0 (spine):** complete — three-tier economy (local · cheap-API · frontier) through one invariant chain, file ledger + SQLite Spine (I2), self-resolving substrate, consumable embedded (CLI) **and** over protocol (`serve_openai`).\n- **Stage 1:** `DifficultyRouter` (GOLDEN_ROUTER ✓) + the self-driving engine landed.\n- **Stage 2 (in progress):** `svc::verifier` (I5, GOLDEN_ORACLE ✓) landed and **wired into the running loop** via `kernel::engine` (L1: route → chain → verify → checkpoint → emit). Still ahead: `svc::memory`, `mw::metrics`, privacy rung-3.\n- **Next:** see `_run_state/STATE.md`."
}
```
**[tool result]**
```
The file C:\KEEL\CLAUDE.md has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 01:30

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:30

Now STATE.md — the date stamp and the stale `C:\loom` cwd warning.

## Claude — Jun 14, 2026 01:30

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\_run_state\\STATE.md",
  "old_string": "*updated 2026-06-13*",
  "new_string": "*updated 2026-06-14*"
}
```
**[tool result]**
```
The file C:\KEEL\_run_state\STATE.md has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 01:30

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\_run_state\\STATE.md",
  "old_string": "   ⚠ **The session cwd is `C:\\loom`, so the AUTO-LOADED CLAUDE.md is Marrow-L1's, NOT KEEL's.** The active project is **KEEL at `C:\\KEEL`**. Do not act on the Marrow-L1 constitution.",
  "new_string": "   ✅ **A session started in `C:\\KEEL` auto-loads KEEL's `CLAUDE.md` correctly** (confirm the cwd). *(Historical caution: earlier sessions ran from `C:\\loom` and mis-loaded Marrow-L1's CLAUDE.md — the single biggest past source of confusion. If you ever see Marrow-L1's constitution, you are in the wrong cwd; the active project is **KEEL at `C:\\KEEL`**, and Marrow-L1 is a read-only reference bench, never the constitution.)*"
}
```
**[tool result]**
```
The file C:\KEEL\_run_state\STATE.md has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 01:30

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:30

Now the core reconciliation — STATE.md's Director line (ruling a). Splitting it into two bullets: SEXTANT as the canon's first cell, and the Director plainly demoted to the first external dogfood consumer (keeping its technical detail so the intent isn't lost).

## Claude — Jun 14, 2026 01:31

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\_run_state\\STATE.md",
  "old_string": "- **First cell = the first real test: the Backrooms game's Director** — operator-stated **live in-session** (2026-06-13), his own idea. *(Provenance correction: an earlier version of this line said \"discussed pre-compaction / my own earlier line\" — a **confabulation**. The warm pre-compaction fork confirms no game/Director in that record; it came from the operator, live. Logged here as the kind of fabricated citation the memory discipline exists to catch.)* Game = **`C:\\backrooms`**",
  "new_string": "- **The canon's first real cell = SEXTANT** (canon §17/§21) — the overnight job-search conductor, the most agentic of the seven; *done* = its Conductor/Router/Gate/Canon/State all come **from** KEEL unchanged, only job-domain periphery written. If a cell ever forces a kernel/contract edit, KEEL's boundary is wrong — fix KEEL first.\n- **The first external *dogfood consumer* (NOT a cell) = the Backrooms game's Director** — operator-stated **live in-session** (2026-06-13). *Status correction: an earlier version of this line called the Director \"KEEL's first cell\" — it is **not**. A **cell** is genome + periphery grown on KEEL (that is SEXTANT); the Director is an **independent app** that merely **consumes** KEEL as a localhost sidecar over `serve_openai`. (The provenance was also once mis-cited as \"discussed pre-compaction\" — a **confabulation** the warm pre-compaction fork disproved; it was operator-stated live, and is logged as the kind of fabricated citation the memory discipline exists to catch.)* Game = **`C:\\backrooms`**"
}
```
**[tool result]**
```
The file C:\KEEL\_run_state\STATE.md has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 01:31

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\_run_state\\STATE.md",
  "old_string": " **NightClerk / NightScribe / SEXTANT** = alternative/later cells.",
  "new_string": " **NightClerk / NightScribe** = alternative/earlier controlled-experiment cells (known shape, clean boundary signal)."
}
```
**[tool result]**
```
The file C:\KEEL\_run_state\STATE.md has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 01:33

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:33

Step 0 reconciliation fixes are in. Now **Step 1 — the code.** Let me confirm the L0 root re-exports (so my engine imports resolve), then write.

## Claude — Jun 14, 2026 01:33

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-contracts\\src\\lib.rs"
}
```
**[tool result]**
```
1	//! # keel-contracts — L0, the frozen joints
2	//!
3	//! The genome's load-bearing surface: the core types, the §18 error taxonomy, and the
4	//! **ten contracts** every layer above is built against. Get the joints right and the
5	//! bones can be swapped.
6	//!
7	//! These are **frozen** (canon §7). The accompanying golden cases (`tests/golden/golden.json`)
8	//! are the *language-neutral conformance layer*: any KEEL implementation, in any language,
9	//! must pass them — which is what makes the implementation language the most reversible
10	//! decision in the system (canon §20 #5).
11	//!
12	//! Layer rule (canon §6): contracts depend on nothing. Everything depends on contracts.
13	
14	pub mod errors;
15	pub mod traits;
16	pub mod types;
17	
18	pub use errors::{KeelError, Result};
19	pub use traits::*;
20	pub use types::*;
21	
```

## Claude — Jun 14, 2026 01:35

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:35

L0 re-exports everything at the root (`pub use traits::*; pub use types::*;`) — my engine imports will resolve. One last check before writing: how `FileAuditSink` handles the `.keelstate` directory, since I'm about to open a SQLite file in the same dir for the injected `Spine`.

## Claude — Jun 14, 2026 01:35

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-middleware\\src\\audit.rs"
}
```
**[tool result]**
```
1	//! keel-middleware::audit — I1, observability (canon §5).
2	//!
3	//! Emits one structured `AuditEvent` for **every** call through the chain — success or failure —
4	//! behind a pluggable `AuditSink` (an in-memory `Vec` for tests; the file ledger, I2, in an app).
5	//! Because it rides the chain like any middleware, no call to a tier escapes it.
6	
7	use async_trait::async_trait;
8	use keel_contracts::{Context, GenerateRequest, GenerateResult, Middleware, Next, Result};
9	use serde::{Deserialize, Serialize};
10	use std::sync::Arc;
11	
12	/// One audited call. Serializable so a file sink can append it as JSONL (the ledger).
13	#[derive(Clone, Debug, Serialize, Deserialize)]
14	pub struct AuditEvent {
15	    pub trace_id: String,
16	    pub t_utc: i64,
17	    pub model: String,
18	    pub tier: String,
19	    pub cost: f64,
20	    pub ok: bool,
21	    /// `"OK"` on success, else the `KeelError` code (canon §18).
22	    pub code: String,
23	}
24	
25	/// Where audit events go. Append-only; the file ledger is the system of record (canon §11, §13).
26	pub trait AuditSink: Send + Sync {
27	    fn emit(&self, event: &AuditEvent);
28	}
29	
30	/// I1 middleware: records a structured event per call, around the rest of the chain.
31	pub struct AuditMiddleware {
32	    sink: Arc<dyn AuditSink>,
33	}
34	
35	impl AuditMiddleware {
36	    pub fn new(sink: Arc<dyn AuditSink>) -> Self {
37	        Self { sink }
38	    }
39	}
40	
41	#[async_trait]
42	impl Middleware for AuditMiddleware {
43	    async fn handle(&self, req: GenerateRequest, ctx: &Context, next: &dyn Next) -> Result<GenerateResult> {
44	        let trace_id = ctx.trace_id.clone();
45	        let model = req.model.clone(); // req is moved into next; capture what we report on error
46	        let res = next.run(req, ctx).await;
47	        let event = match &res {
48	            Ok(r) => AuditEvent {
49	                trace_id,
50	                t_utc: keel_kernel::now_millis(),
51	                model,
52	                tier: r.tier.clone(),
53	                cost: r.cost,
54	                ok: true,
55	                code: "OK".to_string(),
56	            },
57	            Err(e) => AuditEvent {
58	                trace_id,
59	                t_utc: keel_kernel::now_millis(),
60	                model,
61	                tier: String::new(),
62	                cost: 0.0,
63	                ok: false,
64	                code: e.code().to_string(),
65	            },
66	        };
67	        self.sink.emit(&event);
68	        res
69	    }
70	}
71	
72	/// An append-only JSONL `AuditSink` — the file ledger (canon §11, §13). Best-effort: a write
73	/// failure goes to stderr and never crashes the call (a hash-chained durable sink swaps in later).
74	pub struct FileAuditSink {
75	    file: std::sync::Mutex<std::fs::File>,
76	}
77	
78	impl FileAuditSink {
79	    /// Open the audit ledger at `path` in append mode, creating parent dirs + the file.
80	    pub fn new(path: impl AsRef<std::path::Path>) -> std::io::Result<Self> {
81	        let path = path.as_ref();
82	        if let Some(dir) = path.parent() {
83	            if !dir.as_os_str().is_empty() {
84	                std::fs::create_dir_all(dir)?;
85	            }
86	        }
87	        let file = std::fs::OpenOptions::new().create(true).append(true).open(path)?;
88	        Ok(Self { file: std::sync::Mutex::new(file) })
89	    }
90	}
91	
92	impl AuditSink for FileAuditSink {
93	    fn emit(&self, event: &AuditEvent) {
94	        use std::io::Write;
95	        let Ok(line) = serde_json::to_string(event) else {
96	            eprintln!("[keel] audit serialize failed");
97	            return;
98	        };
99	        if let Ok(mut f) = self.file.lock() {
100	            if let Err(e) = writeln!(f, "{line}").and_then(|()| f.flush()) {
101	                eprintln!("[keel] audit write failed: {e}");
102	            }
103	        }
104	    }
105	}
106	
107	#[cfg(test)]
108	mod tests {
109	    use super::{AuditEvent, AuditMiddleware…
```

## Claude — Jun 14, 2026 01:35

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:36

`FileAuditSink::new` creates parent dirs, and it's constructed before the `Spine` in `assemble`, so `.keelstate/` will exist when I open the SQLite index. I have everything. Writing the code now.

**#1 — `impl Oracle for Verifier`** (L4, composite oracle, zero contract edit):

## Claude — Jun 14, 2026 01:36

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs",
  "old_string": "        Ok(agg)\n    }\n}\n\n#[cfg(test)]",
  "new_string": "        Ok(agg)\n    }\n}\n\n/// The registry is itself an [`Oracle`] (a composite): registering N oracles and folding their\n/// verdicts is exactly the `Oracle` contract at a coarser grain. This lets `kernel::engine` hold a\n/// single `&dyn Oracle` for the whole I5 surface while a cell composes many behind it — a pure L4\n/// addition (zero contract edit). The inherent [`Verifier::verify`] is the implementation; this just\n/// exposes it through the frozen joint.\n#[async_trait]\nimpl Oracle for Verifier {\n    async fn verify(&self, output: &StepOutput, golden: &[GoldenCase], ctx: &Context) -> Result<Verdict> {\n        Verifier::verify(self, output, golden, ctx).await\n    }\n}\n\n#[cfg(test)]"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-services\src\verifier.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 01:36

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:36

**#2 — `kernel::engine` (L1): the canonical loop over injected joints.**

## Claude — Jun 14, 2026 01:37

**[tool: Write]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\engine.rs",
  "content": "//! keel-kernel::engine — the canonical closed loop (canon §8). L1.\n//!\n//! The kernel ships **one** cycle as a default; exotic cells compose their own from the same joints\n//! and still inherit the invariants, because the invariants live in the *chain* and the *spine*, not\n//! here. This engine is **injection-only**: it imports nothing but L0 (`keel-contracts`) and its own\n//! kernel modules, and is handed the concrete policies — the `Router`, the I5 `Oracle`, the I2\n//! `Spine`, and optionally `Memory`/`TraceSink` — as L0 trait objects by the wiring layer (L5). The\n//! same dyn-injection the [`Registry`](crate::Registry) uses for `ModelTier`, applied to the loop.\n//!\n//! One turn (canon §8): **assemble → route → chain → verify → checkpoint → emit.** The engine **owns\n//! the [`Context`]** (it folds in `result.cost` after the chain returns — I4 — because the chain only\n//! sees `&Context`) and the [`Step`]'s history (it appends `tier_history` and bumps `oracle_failures`\n//! on an oracle failure), so the escalation ladder (canon §9) fires across turns. Verification (I5)\n//! is *recorded and surfaced* on the verdict; in-turn re-escalate-and-retry is a deliberate\n//! follow-up — escalation is realized on the **next** turn via the persisted history.\n//!\n//! **Per-tier chains (I3, canon §8 footnote):** the privacy mask differs by destination, so the\n//! engine holds one egress-correct [`Chain`] per tier and runs the routed tier through *its* chain.\n\nuse crate::Chain;\nuse keel_contracts::{\n    Content, Context, Decision, Effort, GenerateRequest, GenerateResult, KeelError, Memory, Message,\n    ModelTier, Oracle, Result, Role, Router, Spine, Step, StepOutput, Trace, TraceSink, Verdict, VerifiedTrace,\n};\nuse serde_json::Value;\nuse std::collections::BTreeMap;\nuse std::sync::Arc;\n\n/// The tier ladder, cheapest first — the engine walks DOWN it to substitute an available tier when\n/// the routed one is unplugged.\nconst LADDER: [&str; 3] = [\"local\", \"cheap-API\", \"frontier\"];\n\n/// One wired tier: its brain adapter, the model id to send it, and the **egress-correct** invariant\n/// chain for that tier (local pass-through vs cloud-masked, I3 — canon §8 footnote). Built by the\n/// wiring layer and injected.\npub struct TierSlot {\n    pub tier: Arc<dyn ModelTier>,\n    pub chain: Chain,\n    pub model: String,\n}\n\n/// The outcome of one routed, verified turn: the model output plus the routing + externality story\n/// (for the operator / ledger / serve response).\npub struct Outcome {\n    pub result: GenerateResult,\n    /// What the router chose (its tier + reason).\n    pub decision: Decision,\n    /// The tier actually run — equals `decision.tier` unless that tier was unplugged.\n    pub tier_used: String,\n    /// True when the chosen tier was unavailable and the engine fell back down the ladder.\n    pub substituted: bool,\n    /// The I5 verdict — a non-model assertion on this output (`passed`, `joint_wrong`, failures).\n    pub verdict: Verdict,\n}\n\n/// The canonical engine: hold every available tier (behind its chain), let the injected [`Router`]\n/// pick one per turn, run it, verify (I5), accumulate cost (I4), checkpoint (I2), and emit verified\n/// traces (the flywheel feed). The model that thinks is interchangeable; this loop is the self.\npub struct Engine {\n    slots: BTreeMap<String, TierSlot>,\n    router: Box<dyn Router>,\n    oracle: Arc<dyn Oracle>,\n    spine: Arc<dyn Spine>,\n    memory: Option<Arc<dyn Memory>>,\n    trace_sink: Option<Arc<dyn TraceSink>>,\n    default_tier: String,\n}\n\nimpl Engine {\n    /// Inject the wired tiers + the joints. The wiring layer (L5) builds the concrete services\n    /// (`DifficultyRouter`, the `Verifier` as a composite `Oracle`, the SQLite `Spine`, …) and hands\n    /// them in as L0 trait objects — the kernel imports none of them (the layer rule, canon §6).\n    /// Errors if no tier is wired (`SUBSTRATE_UNRESOLVED`).\n    pub fn new(\n        slots: BTreeMap<String, TierSlot>,\n        router: Box<dyn Router>,\n        oracle: Arc<dyn Oracle>,\n        spine: Arc<dyn Spine>,\n        memory: Option<Arc<dyn Memory>>,\n        trace_sink: Option<Arc<dyn TraceSink>>,\n        default_tier: String,\n    ) -> Result<Engine> {\n        if slots.is_empty() {\n            return Err(KeelError::SubstrateUnresolved(\n                \"engine: no tier wired (local substrate down and no cloud keys)\".into(),\n            ));\n        }\n        Ok(Engine { slots, router, oracle, spine, memory, trace_sink, default_tier })\n    }\n\n    /// The tiers actually wired (sorted).\n    pub fn available(&self) -> Vec<String> {\n        self.slots.keys().cloned().collect()\n    }\n\n    /// Run one turn of the canonical loop. Mutates `step` (history/failures feedback) and `ctx`\n    /// (cost accumulation) — the engine owns both. Honors `BLOCK` (I4 → `BudgetExceed
…[truncated]
```
**[tool result]**
```
File created successfully at: C:\KEEL\crates\keel-kernel\src\engine.rs (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 01:37

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:37

**#3 — register the module in the kernel lib + add `serde_json`** (needed to serialize the checkpoint `State`):

## Claude — Jun 14, 2026 01:37

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\lib.rs",
  "old_string": "//! - **landed:** `manifest` (config → behavior) · `context` (the object that flows every call) ·\n//!   `registry` (tier → adapter) · `chain` (the middleware executor) · `lifecycle` (the substrate\n//!   resolver — probe/resolve **and** launch/supervise).\n//! - **next:** `engine` (the closed loop) · `lock` (reproducibility / substrate pin).",
  "new_string": "//! - **landed:** `manifest` (config → behavior) · `context` (the object that flows every call) ·\n//!   `registry` (tier → adapter) · `chain` (the middleware executor) · `lifecycle` (the substrate\n//!   resolver — probe/resolve **and** launch/supervise) · `engine` (the canonical closed loop, §8).\n//! - **next:** `lock` (reproducibility / substrate pin)."
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-kernel\src\lib.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 01:37

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\Cargo.toml",
  "old_string": "serde = { version = \"1\", features = [\"derive\"] }\nserde_yaml_ng = \"0.10\"",
  "new_string": "serde = { version = \"1\", features = [\"derive\"] }\nserde_json = \"1\"\nserde_yaml_ng = \"0.10\""
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-kernel\Cargo.toml has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 01:37

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:37

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\lib.rs",
  "old_string": "pub mod chain;\npub mod context;\npub mod lifecycle;\npub mod manifest;\npub mod registry;\n\npub use chain::Chain;\npub use context::{new_context, new_trace_id, now_millis};",
  "new_string": "pub mod chain;\npub mod context;\npub mod engine;\npub mod lifecycle;\npub mod manifest;\npub mod registry;\n\npub use chain::Chain;\npub use context::{new_context, new_trace_id, now_millis};\npub use engine::{Engine, Outcome, TierSlot};"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel-kernel\src\lib.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 01:38

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:38

**#4 — shrink `keel::Engine` (L5) to a pure-injection wrapper** over `kernel::engine`, wiring the I5 `Oracle` + I2 `Spine`:

## Claude — Jun 14, 2026 01:38

**[tool: Write]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel\\src\\lib.rs",
  "content": "//! keel (L5) — the shared wiring both apps use. The loop itself lives in [`kernel::engine`](keel_kernel::engine)\n//! (L1, over injected joints); this crate is the **injection layer** that reads `keel.lock`, builds\n//! the concrete adapters/services, and hands them down as L0 trait objects. Two ways to assemble:\n//!\n//! - [`Engine`] — the **self-driving** path: a multi-tier registry of every *available* tier (local\n//!   always; a cloud tier only when its API key is in the env), each behind its **own** invariant\n//!   chain (audit → privacy → cost), fronted by a swappable [`Router`], an I5 [`Oracle`] (the\n//!   verifier-as-composite), and an I2 [`Spine`] (the SQLite index). `keel` (default) and\n//!   `keel-serve` route **every** turn through it — route → chain → verify → checkpoint → emit.\n//! - [`assemble`] — the **single-tier** path: build exactly one tier behind the chain. The CLI's\n//!   `--tier` override uses it so an explicit cloud call never needlessly cold-starts the local\n//!   substrate (and it skips the router + the I5 loop by design).\n//!\n//! The privacy egress mask (I3) is **per tier**: local stays on the box (pass-through), every cloud\n//! tier is masked before egress — which is why each tier gets its own chain (canon §8 footnote).\n\nuse keel_adapters::{Anthropic, DeepSeek, LocalLlama};\nuse keel_contracts::{\n    Context, GenerateRequest, GenerateResult, KeelError, ModelTier, Oracle, Result, Router, Spine, Step,\n};\nuse keel_kernel::engine::{Engine as KernelEngine, TierSlot};\nuse keel_kernel::{Chain, Manifest, Registry, TierCfg};\nuse keel_middleware::{AuditMiddleware, AuditSink, CostMiddleware, FileAuditSink, PrivacyMiddleware, Redactor};\nuse keel_services::{DifficultyRouter, Verifier};\nuse keel_store::SqliteStore;\nuse std::collections::BTreeMap;\nuse std::sync::Arc;\n\n/// The outcome of a routed, verified turn (defined in the kernel; re-exported for app callers).\npub use keel_kernel::engine::Outcome;\n\npub const DEEPSEEK_ENDPOINT: &str = \"https://api.deepseek.com\";\npub const ANTHROPIC_ENDPOINT: &str = \"https://api.anthropic.com\";\npub const AUDIT_LEDGER: &str = \".keelstate/audit.jsonl\";\n/// The SQLite index backing the I2 `Spine` (derived/rebuildable; the file ledger is the record).\npub const INDEX_DB: &str = \".keelstate/index.db\";\n// local substrate launch (paths match keel.lock; keel.lock-driven config is a refinement)\npub const LLAMA_EXE: &str = r\"C:\\llama.cpp\\llama-server.exe\";\npub const LLAMA_MODEL: &str = r\"C:\\models\\Qwen3.5-9B-Q5_K_M.gguf\";\npub const LLAMA_MMPROJ: &str = r\"C:\\models\\mmproj-F16.gguf\";\npub const LLAMA_LOG: &str = \".keelstate/llama-server.log\";\n\n// ── the self-driving engine (L5 injection → L1 loop) ──────────────────────────\n\n/// The self-driving engine: a thin **injection wrapper** over [`kernel::engine::Engine`](keel_kernel::engine::Engine).\n/// It wires every available tier behind its egress-correct chain and constructs the swappable joints\n/// (the §9 `DifficultyRouter`, the I5 `Verifier` as a composite `Oracle`, the SQLite `Spine`), then\n/// delegates the canonical loop to the kernel. The policy stays behind the seams so a learned router\n/// or a cell's oracles slot in later without touching this crate.\npub struct Engine(KernelEngine);\n\nimpl Engine {\n    /// Assemble from `keel.lock`: wire every tier whose substrate is reachable — **local always**\n    /// (resolving/launching llama-server), a **cloud tier only when its key is in the env** (absent\n    /// key ⇒ skipped, not fatal) — each behind an `audit · privacy · cost` chain whose egress mask\n    /// matches whether that tier leaves the box (I3). Then inject the joints into the kernel engine.\n    pub fn assemble(manifest: &Manifest) -> Result<Engine> {\n        let sink: Arc<dyn AuditSink> = Arc::new(\n            FileAuditSink::new(AUDIT_LEDGER).map_err(|e| KeelError::Other(format!(\"ledger {AUDIT_LEDGER}: {e}\")))?,\n        );\n        // operator sovereign markers (rung 1) are a future manifest field; rung 2 runs regardless.\n        let redactor = Arc::new(Redactor::new(vec![]));\n\n        let mut slots = BTreeMap::new();\n        for (name, tcfg) in &manifest.tiers {\n            let is_local = tcfg.adapter == \"local_llama\";\n            // a cloud tier is available only when its key is present — skip (don't fail) otherwise.\n            if !is_local && tcfg.api_key().is_none() {\n                let env = tcfg.api_key_env.as_deref().unwrap_or(\"?\");\n                eprintln!(\"[keel] tier '{name}' unavailable ({env} unset) — skipped\");\n                continue;\n            }\n            let tier = match build_tier(name, tcfg) {\n                Ok(t) => t,\n                Err(e) => {\n                    eprintln!(\"[keel] tier '{name}' could not be wired ({e}) — skipped\");\n                    continue;\n                }\n            };\n            let ch
…[truncated]
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\lib.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 14, 2026 01:38

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:38

**#5 — add the `keel-store` dependency to L5** (to inject the SQLite `Spine`):

## Claude — Jun 14, 2026 01:38

<!-- end chunk 2/9 | next: chunk-003.md -->
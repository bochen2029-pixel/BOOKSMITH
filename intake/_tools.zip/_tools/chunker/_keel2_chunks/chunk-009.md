<!-- ============ CHUNK 9/9 ============ -->
<!-- source: You_are_continuing_the_build_of_KEEL_Bo_Chen_s_personal_sovereign_reusable_AI-harness_.md -->
<!-- section: Proposal: close the named-gate loop (dispatch + #3 + the alarm) > Claude — Jun 14, 2026 04:21 -->
<!-- recap: last ~187 tokens of chunk 8, for continuity -->
> === log (top 3) — NOT pushed ===
> 4dec51f Stage 2 (named-gate completion): resolved refs assert + #3 un-neutered + ASCII alarm
> 03d9d10 Stage 2 (Half B): I5 teeth — golden_refs resolver + default-oracle set + 3 hardenings
> e3b482a Stage 2 (Half A): constrained-decode conformance — model_tier golden green + SchemaOracle
> 
> ## main...origin/main [ahead 1]
> ```
> 
> ## Claude — Jun 14, 2026 04:21
> 
> > _[thinking]_
> > 
> 
> ## Claude — Jun 14, 2026 04:21
> 
> Banked: `4dec51f` (ahead 1, unpushed). Review packet below — **push held for your go.**
> 
> ## Claude — Jun 14, 2026 04:21
<!-- end recap | new content begins -->

**[tool: PowerShell]**
```json
{
  "command": "git -C C:\\KEEL show 4dec51f --stat --oneline 2>&1 | Select-Object -First 11",
  "description": "Show the slice diff stat"
}
```
**[tool result]**
```
4dec51f Stage 2 (named-gate completion): resolved refs assert + #3 un-neutered + ASCII alarm
 _run_state/STATE.md                  |   5 +-
 _run_state/WAKE_UP.md                |   4 +-
 _run_state/WAKE_UP_part4.md          |   4 +-
 crates/keel-kernel/src/engine.rs     | 117 +++++++++++++++++++++++++++++++----
 crates/keel-services/src/lib.rs      |   2 +-
 crates/keel-services/src/verifier.rs |  90 +++++++++++++++++++++++++--
 crates/keel/src/lib.rs               |  22 ++++---
 crates/keel/src/main.rs              |   6 +-
 8 files changed, 214 insertions(+), 36 deletions(-)
```

## Claude — Jun 14, 2026 04:22

> _[thinking]_
> 

## Claude — Jun 14, 2026 04:22

The slice is banked (`4dec51f`, ahead 1, unpushed). Review packet:

## What landed (3 parts, each proven)
| Part | What | Proof |
|---|---|---|
| **1. Dispatch** | `GoldenDispatchOracle` (L4) consumes resolved cases, dispatches by **family** (schema→`SchemaOracle`, property→`PropertyOracle`; conformance-only → asserts nothing) → a **bare `--golden-ref` gates, no cell pre-registration** | tests `golden_dispatch_runs_schema_family` / `_property_family` / `_skips_conformance_only_family` ✓ **+ smoke 3** ✓ |
| **2. #3 un-neutered** | no-SSN moved to `EngineConfig.baseline` (I3 stopgap, **excluded from #3**); critical needs a **correctness** assertion | tests `baseline_does_not_satisfy_critical_step` / `critical_resolved_ref_with_no_assertion_config_faults` ✓ **+ smoke 2 & 4** ✓ |
| **3. ASCII alarm** | I5 failure strings ASCII in **print + persisted** `verdict.failures` | test `the_failure_alarm_is_ascii` ✓ **+ `ascii_failures=True` in all 4 checkpoints** ✓ |

## Refinements honored
- **R1 (baseline = I3):** documented in code + STATE as an I3 sovereignty **STOPGAP** (covers local-output PII that `mw::privacy`'s egress-only mask misses), to be re-homed to an output-side I3 rung at the privacy slice; **never counts for #3**.
- **R2 (the sharp seam):** `critical + conformance-only-ref → config fault` is tested (`critical_resolved_ref_with_no_assertion_config_faults`) **and** lived (smoke 4, `f9e36695d035`). Dispatch is a **bounded match** over known families with explicit fall-through — not a generic plugin.
- **Affirm:** conformant-good is **test-proven** (`golden_dispatch_runs_schema_family`, conformant artifact → pass), **not faked** in a smoke — the real conformant-good-in-binary arrives when the Director dogfood sends constrained-decoded Directives.

## Lived smoke (4 traces, cross-correlated with the I2 checkpoint)
- plain `7a9051367fbb` → `passed=True`, no alarm (silent).
- `--critical` no-ref `ede1e1684fa8` → `config fault` **despite the baseline** (#3 un-neutered).
- `--critical --golden-ref <schema>` `aef100cdbabb` → `schema: output is not JSON ... - rejected` (the dispatch fired from the bare ref).
- `--critical --golden-ref <conformance-only>` `f9e36695d035` → `config fault` (resolving ≠ asserting).
All persisted verdicts match the CLI alarms; all `verdict.failures` ASCII.

## Gate
`cargo test` **74 / 3 ignored** (kernel 29→32, services 7→10) · clippy clean · **zero contract/golden edits** · **freeze seal unmoved** · diff 8 files +214/−36 (`engine.rs +117`, `verifier.rs +90`).

## Doc fold
Retired the WAKE_UP §4.2/§4.4 + STATE.md **"resolver supplies cases but no oracle consumes them"** caveat (closed explicitly) · baseline documented as the I3 stopgap · WAKE_UP re-stitched (297=297).

## Honest open items (recorded in STATE.md, not hidden)
- `serve` parity for `critical`/`golden_ref` (CLI has them; serve doesn't yet).
- The CLI footer's route-reason `→` is a **cosmetic, non-alarm** print (the alarm itself is ASCII) — ASCII-safe later if wanted.
- Re-home the no-SSN baseline into an I3 output rung at the privacy-rung slice (then drop the `baseline` slot).

**Stopping for your review.** On your go I push `4dec51f` as the follow-up. After that, per your bearings: `mw::metrics` next (the instrument to size the flat-`escalation_rate` base case), then perception, then memory (most skeptically against `docs/proposals/perpetual-memory.md`).

<!-- end chunk 9/9 | next: (none - last) -->
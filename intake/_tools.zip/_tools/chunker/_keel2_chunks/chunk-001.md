<!-- ============ CHUNK 1/9 ============ -->
<!-- source: You_are_continuing_the_build_of_KEEL_Bo_Chen_s_personal_sovereign_reusable_AI-harness_.md -->
<!-- section: You are continuing the build of KEEL — Bo Chen's personal, sovereign, reusable AI-harness … -->

# You are continuing the build of KEEL — Bo Chen's personal, sovereign, reusable AI-harness …

Session: `e19e9071-6159-4468-ab85-8f44490f5dde`
cwd: `C:\KEEL`
branch: `main`
model: `claude-opus-4-8`
Started: Jun 14, 2026 02:33
Ended: Jun 14, 2026 04:22

---

## You — Jun 14, 2026 01:11

You are continuing the build of KEEL — Bo Chen's personal, sovereign, reusable AI-harness *genome* (native Rust; "rented cognition, owned self") — in the repo at C:\KEEL\ on Windows 11. Work in supervised mode. Do NOT write or edit any code, and do NOT run any git or otherwise-mutating command, until you have (1) read the required docs IN FULL, (2) verified the real state by artifact, (3) restated your understanding, and (4) I approve a plan. Proceed through the phases below and STOP at the end of Phase 4.

CWD note: because you are in C:\KEEL, the auto-loaded CLAUDE.md is correctly KEEL's. (Prior sessions ran in C:\loom and mis-loaded Marrow-L1's CLAUDE.md — a major past source of confusion; it does NOT apply to you.) Build and test from a native MSVC PowerShell, not git-bash.

PHASE 1 — READ (in this exact order, IN FULL, verbatim — do not skim)
  1. C:\KEEL\_run_state\WAKE_UP.md — the pre-digested, reconciled onboarding brief written for exactly this moment. Your fastest, lowest-context path to 100% up-to-speed; everything else corroborates it. (If it doesn't fit one read, read _run_state\WAKE_UP_part1..5.md in order, or use the chunker at C:\KEEL\chunker.)
  2. C:\KEEL\KEEL_ARCHITECTURE.md — THE CANON (v0.2). The source of truth for design.
  3. C:\KEEL\CLAUDE.md — the build constitution (the RULES). ⚠ Its "Build state" section is STALE — use it for the rules, NOT for the current state.
  4. C:\KEEL\AUTONOMY_CHARTER.md — the reversibility gate + hard prohibitions.
  5. C:\KEEL\_run_state\STATE.md — the live, per-slice build anchor (the authoritative current state).
  6. C:\KEEL\keel.lock — the substrate pin (models, servers, tiers, resolver order, ledger/index).
  7. C:\KEEL\tests\golden\golden.json + .frozen.json — the agent-frozen, language-neutral conformance layer (READ-ONLY; never edit).
  Secondary / on-demand — do NOT read fully now (the brief distills them); consult only for a specific raw detail: _run_state\handoff\forward-arc.md, _run_state\handoff\recent-turns.md, _run_state\trajectory-account.md, docs\proposals\perpetual-memory.md, _memories\KEEL_GENESIS_TRANSCRIPT_ASSESSMENT.md. The full pre-compaction transcript (_memories\You_are_continuing_…md, ~1.14 MB) is the lossless backstop — do NOT read it whole; chunk or grep it only for a specific fact.

PHASE 2 — VERIFY BY ARTIFACT (never trust recall or a summary)
  From PowerShell: git -C C:\KEEL log --oneline -15 ; git -C C:\KEEL status ; cargo check ; cargo clippy ; cargo test
  Confirm the brief + STATE.md match reality. If anything conflicts, the artifact wins — report the discrepancy rather than acting on the doc.

PHASE 3 — PROVE YOU UNDERSTAND (concise, in your own words)
  - KEEL in one sentence; the genome/cell model; the L1-personal-tool / not-a-product (intersection-not-union) boundary.
  - The five invariants + the reversibility gate, and what I5 (externalized correctness — ground truth from outside the model) means — and that it is NOT yet wired into the running loop.
  - The layer-import rule and the exact order.
  - The frozen-golden rule: contracts + goldens are agent-read-only; if a golden fails you fix the CODE; you never re-stamp the operator's seal.
  - The current build state (Stage 0 complete · Stage 1 router + self-driving engine landed · svc::verifier/I5 landed but UNWIRED), trusting STATE.md + git over CLAUDE.md.
  - The reconciled drift you must hold: the Backrooms "Director" is a first external CONSUMER / dogfood over serve_openai, NOT a cell, NOT the canon's first cell — SEXTANT remains the canon's first cell. The system is SUPERVISED (no autonomy grant).
  - The next slice and why: kernel::engine (L1) over injected &dyn Router/Oracle/Memory/Spine/TraceSink — route → chain → verify → checkpoint → emit — which wires I5 live, accumulates I4 cost, activates I2 checkpointing, and pays the L5→L1 engine debt.
  Then flag anything in the canon/docs you find ambiguous, internally inconsistent, or that you'd implement differently — NAME it; do not silently "fix" it.

PHASE 4 — PROPOSE THE NEXT SLICE, then STOP
  Propose a tight plan for the next slice — default the kernel::engine loop, but recommend whether to do the quick record-reconciliation first (WAKE_UP §5.1 Step 0: confirm the Director ruling, correct CLAUDE.md's stale build-state + STATE.md's Director line) so the record is clean before more code lands. Respect the layer order and the frozen contracts (I expect zero contract edits — if you think one is needed, justify it and wait). Then STOP and wait for my go. Do not write code or run any work-losing git command until I approve.

STANDING RULES (hold every session)
  - Verify by artifact, never recall. Contracts-first; never edit a contract/golden to ease an impl. Fix the code, never the golden; never re-stamp the seal.
  - Layer rule: contracts ← kernel ← {adapters, middleware} ← services ← apps. Async by default. Protocol-first; never invent a wire protocol. Genome = intersection of the operator's projects, never their union.
  - Reversibility gate: no git reset --hard / clean -fd/-fx / checkout -- <path> / restore on uncommitted work; no push --force; no branch -D on unmerged auto/; no rm / Remove-Item -Recurse -Force outside .\.keelstate\. Do NOT mutate the global Rust toolchain without asking. Never hardcode or commit a key (DEEPSEEK_API_KEY / ANTHROPIC_API_KEY live in env, User scope). No cloud egress of sovereign data (incl. raw frames + embedding vectors). Any action whose undo cost you can't state in one sentence → stop and ask.
  - One slice at a time, banked clean: layer-check → per-crate budget → golden-freeze unchanged → cargo test green → ONE commit, one-line intent. Commit/push ONLY when I ask. Commit trailer: Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>.
  - Build/test from PowerShell (MSVC), not git-bash. Note: a shell started before the API keys were set wires local-only by design — inject $env:DEEPSEEK_API_KEY = [Environment]::GetEnvironmentVariable('DEEPSEEK_API_KEY','User') (and Anthropic) to exercise cloud tiers.
  Match the operator: Skeptic pass (no sycophancy), honest reviews over agreeable ones, "lived vs reconstructed" kept distinct, one-step gating.
  Begin with Phase 1.

## Claude — Jun 14, 2026 01:11

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:11

I'll begin Phase 1 — reading the required documents in full, in order. Let me start with the WAKE_UP brief, which is the primary onboarding document.

## Claude — Jun 14, 2026 01:11

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\_run_state\\WAKE_UP.md"
}
```
**[tool result]**
```
1	# KEEL — WAKE-UP BRIEF (read this FIRST, before anything else)
2	
3	> **What this file is.** A complete, pre-digested onboarding for a *brand-new session starting in `C:\KEEL\`*. It was written by an instance that had — uniquely — read **the entire KEEL codebase** *and* **the entire pre-compaction chat transcript** *and* every run-state/handoff/memory artifact, all held in one ~1M-token context at once, then deep-thought and reconciled it for you. Its single purpose is to erase the "re-explanation tax": you should finish this brief understanding KEEL *emotively, conceptually, and technically* — what it is, why it is built exactly this way, what is already done, what is true vs aspirational, what to do next, and where to find anything you want to verify. It is deliberately **redundant on the load-bearing points** so you cannot drift.
4	>
5	> **Author + provenance:** Claude Opus 4.8 (1M context), 2026-06-13, synthesizing the genesis transcript, the live codebase, `STATE.md`, the two handoff files, `trajectory-account.md`, the `perpetual-memory` proposal, and a cross-instance review. **Verify anything load-bearing against the artifacts** (git, the contracts, the goldens) — that is KEEL's prime discipline and it applies to *this file too*.
6	
7	---
8	
9	## 0 · TL;DR — if you read only this box
10	
11	- **KEEL is a single-operator, sovereign, reusable AI-harness "genome," written once in Rust, that the operator (Bo Chen) consumes embedded *or* over protocol across all his projects.** One sentence: *the API is rented cognition — stateless, interchangeable, billed per token; **KEEL is the self** — persistent, user-owned, that perceives, remembers, routes every unit of work to the cheapest brain that clears the trust bar, and grounds every critical output in an assertion no model authored.* You own the self; you rent the thinking.
12	- **You are in `C:\KEEL\` — good.** The auto-loaded `CLAUDE.md` is now correctly **KEEL's** (prior sessions ran in `C:\loom\` and kept loading *Marrow-L1's* CLAUDE.md by mistake — that hazard is GONE for you, but it is the single biggest source of the prior confusion, so internalize it).
13	- **Where it stands:** Stage 0 (the spine) is **complete**; Stage 1 (router + self-driving engine) **landed**; one Stage-2 slice (`svc::verifier`, the I5 externality layer) **landed but is not yet wired into the running loop.** 7 crates, tests green, public at `github.com/bochen2029-pixel/keel`. The codebase is **ahead of its own documentation** — trust `STATE.md` + `git`, **not** `CLAUDE.md`'s stale "Build state" section (see Part 4).
14	- **The single highest-leverage next slice:** build the real **`kernel::engine` (L1)** loop over injected `&dyn Router/Oracle/Memory/Spine/TraceSink` running **route → chain → verify → checkpoint → emit**. That one slice wires I5 into the binary, fixes the I4 cost-accumulation gap, activates I2 checkpointing, and pays the "L5→L1 engine debt" — four things at once.
15	- **The prime directive: VERIFY BY ARTIFACT, NEVER RECALL.** Files and git over any summary or memory. The whole project exists to make a self that survives forgetting; honor that in how you work.
16	
17	---
18	
19	## 1 · The ten things you must not get wrong (the anti-drift list)
20	
21	Read these now; the rest of the brief justifies and expands them. If you ever feel uncertain, re-read this list.
22	
23	1. **The contracts and golden cases are FROZEN and agent-read-only.** The ten traits in `crates/keel-contracts` (canon §7) and `tests/golden/golden.json` + `.frozen.json` are the genome's load-bearing surface. **If a golden fails, you fix the *code*, never the golden.** Ratifying/changing/re-freezing a golden — and re-stamping the freeze seal — is an **operator-only** action you must never perform yourself. This is non-negotiable; it is *the* governance that keeps KEEL a substrate and not a wrapper.
24	2. **Verify by artifact, never recall.** `git -C C:\KEEL log/status`, `cargo check/clippy/test`, the canon, `keel.lock…
```

## Claude — Jun 14, 2026 01:11

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:11

The WAKE_UP brief is complete and absorbed. Now reading THE CANON in full.

## Claude — Jun 14, 2026 01:11

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\KEEL_ARCHITECTURE.md"
}
```
**[tool result]**
```
1	# KEEL — Architecture Canon
2	
3	**Codename:** KEEL — *the backbone laid first, running the whole length, that everything is built upon and that keeps the vessel upright in any sea.*
4	**Version:** 0.2.0 · **Status:** canon (spec-first; pre-implementation)
5	**Author:** Bo Chen — Dallas–Fort Worth — June 2026
6	**Lineage:** distilled as the *intersection* of seven independently-built systems across three languages (Tenancy, Terminal — Rust; TARS, REEL, the In-Home Companion, SEXTANT — Python; photo2deck, NightScribe, NightClerk — C#). KEEL is what every one of them rebuilt by hand. This document owes nothing to any prior framing; it is the thing itself, written once.
7	
8	> **One sentence:** *KEEL is a single-operator substrate that is the persistent, sovereign **self** — it perceives (eyes and ears), remembers, routes every unit of work to the cheapest brain that clears the trust bar, amplifies a small local model to punch above its weight, and grounds every critical output in an assertion no model authored — while the model that does the thinking is interchangeable, rented cognition plugged into a tiny stable core.*
9	
10	---
11	
12	## §0 · What KEEL Is
13	
14	The API (local or cloud) is **rented cognition** — stateless, interchangeable, billed per token. KEEL is **the self** — persistent, user-owned, sovereign, portable across providers and across years. The model provides the thinking. KEEL provides the *remembering, the perceiving, the routing, the verifying, and the continuity.*
15	
16	KEEL is not an agent and not a loop. It is a **trust-and-cost economy with a tiny immortal core**, inside which a closed *verify-and-distill cycle* lets the cheapest available brain clear a bar that something no model authored has set. Off-the-shelf harnesses orchestrate a single expensive brain well; none treats trust as a routable quantity, keeps a sovereign local self, runs a distillation flywheel, or enforces an externality principle. That gap is the entire reason KEEL exists, and it is where every line of original code is spent.
17	
18	KEEL is the **genome**: a frozen set of contracts and invariants from which every specialization (a companion, an OCR clerk, a job-search conductor, a meeting scribe) is grown by composing periphery — *never* by editing the core. The genome is written once and reused forever; the cells are many and disposable.
19	
20	---
21	
22	## §1 · Intent & The Bet
23	
24	**Why build, not buy.** In the age of capable coding models it is now feasible to build custom software for nearly everything; the *harness* is the one primitive worth getting exactly right, because it is load-bearing under everything else and because it must encode *this operator's* judgment — the core-wire/scaffolding routing doctrine, the externality principle, the reversibility gate, the trust threshold. No off-the-shelf harness encodes that doctrine; bending one to fit is permanent impedance mismatch. So KEEL is built custom **at the core** and composes the periphery ruthlessly.
25	
26	**The atomic bet (applied recursively).** Make every interface a protocol; make every protocol uniform across providers; keep the kernel tiny and the seams sharp. Then capability accumulates by writing adapters, not by rewriting the kernel — and adaptability becomes a property of *smallness plus clean seams*, never of pre-built generality. The future is absorbed cheaply at the edges; it is never anticipated in the center.
27	
28	**Future-proofing, honestly stated.** You cannot future-proof against "whatever AI becomes." You can (a) bet on the most durable protocols available, (b) keep the core small enough that a wrong bet is cheap to redo, and (c) write down the exact signals that say *re-architect* (§23). "Never re-architect" is a fantasy that breeds over-abstraction. "Re-architect rarely, cheaply, and only on a falsifier trip, with a blast radius one adapter wide" is the achievable, healthy version.
29	
30	---
31	
32	## §2 · Scope & Non-Goals (the honest en…
```

## Claude — Jun 14, 2026 01:11

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:11

The canon is absorbed. CLAUDE.md is already loaded in full via the project-instructions context block — I have its rules (and note its "Build state" section is stale per the brief). Now reading the AUTONOMY_CHARTER, the live STATE, the substrate lock, and the frozen goldens.

## Claude — Jun 14, 2026 01:11

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\AUTONOMY_CHARTER.md"
}
```
**[tool result]**
```
1	# AUTONOMY_CHARTER — KEEL (Stage 0, supervised)
2	
3	**System:** Bo Chen's personal, sovereign harness core. Single operator, single tenant.
4	
5	## §1 — Authority
6	Stage 0 runs **supervised**. No overnight/unattended autonomy until the run-state spine (I2) + the oracle layer (I5, Stage 2) exist and the operator explicitly authorizes it.
7	
8	## §5 — Hard prohibitions (the reversibility gate)
9	- No `git reset --hard`, `git clean -fd/-fx`, `git checkout -- <path>`, `git restore` on uncommitted/unmerged work.
10	- No `git push --force`; no `branch -D` on unmerged `auto/` branches.
11	- No `rm` / `Remove-Item -Recurse -Force` outside `.\.keelstate\` and explicitly ephemeral dirs.
12	- **No mutation of the global Rust toolchain** (rustup update / reinstall / component remove/add) without operator approval — DAVE, TERMINAL, and other projects share it.
13	- **No cloud egress of sovereign data** — including raw perception (screen / webcam / microphone frames) and embedding **vectors** (I3; vectors are invertible).
14	- **A secret must never be baked into a distilled LoRA** — scrub before a verified trace becomes distillation feedstock (the flywheel is the one irreversible sink).
15	- Any action whose undo cost cannot be stated in one sentence → **stop and ask the operator.** Reversibility-uncertain ⇒ treat as irreversible.
16	
17	## §7 — Termination
18	- Foundational-blocker fan-out ≥ 3 → prefer an early clean stop over speculative dependents; write an `ESCALATION` note and halt.
19	
20	## Frozen ground truth
21	The operator treats the **ten contracts** (`crates/keel-contracts`), the **golden cases** (`tests/golden/golden.json`), and `.frozen.json` like this charter: read-only, never self-edited. Authoring/ratifying/changing any of them is an **operator action**. The agent may not author its own ground truth (I5).
22	
```

## Claude — Jun 14, 2026 01:11

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:11

Now the live build anchor — STATE.md, the authoritative current state.

## Claude — Jun 14, 2026 01:11

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\_run_state\\STATE.md"
}
```
**[tool result]**
```
1	# KEEL — Build State & Reconstitution Anchor
2	*updated 2026-06-13*
3	
4	## ⛑ RECONSTITUTION PROTOCOL — read this FIRST after any compaction/resume, before ANY other action
5	The conversation summary is **lossy**. The committed repo + the canon are the truth. Before resuming work or answering a new turn:
6	0. **Read `_run_state/WAKE_UP.md` IN FULL, FIRST** — the pre-digested, reconciled onboarding brief (full intent + soul · current ground-truth state · the next slice · the resolved drift · where every artifact lives). Lowest-context path to 100% up-to-speed; everything below corroborates it. If it doesn't fit one read, read `_run_state/WAKE_UP_part1..5.md` in order, or chunk it (`C:\KEEL\chunker`).
7	1. **Read this file (STATE.md) fully**, then the live-session handoff in order: `_run_state/handoff/forward-arc.md` (the causal arc + the operator-confirmed next move) → `_run_state/handoff/recent-turns.md` (recent turns, reverse-chronological, newest-first). Those are the **narrative register** (per the `perpetual-memory` skill / REEL); the **factual register** is git + the contracts/goldens — trust it on any conflict.
8	2. **Read the canon** `C:\KEEL\KEEL_ARCHITECTURE.md` **+ the constitution** `C:\KEEL\CLAUDE.md`.
9	   ⚠ **The session cwd is `C:\loom`, so the AUTO-LOADED CLAUDE.md is Marrow-L1's, NOT KEEL's.** The active project is **KEEL at `C:\KEEL`**. Do not act on the Marrow-L1 constitution.
10	3. **Verify real state, never recall:** `git -C C:\KEEL log --oneline -8` + `git -C C:\KEEL status`; then from **PowerShell** `cargo check -p keel-contracts` (must be green).
11	4. Confirm goldens frozen: `C:\KEEL\tests\golden\.frozen.json` sha256 `63d5ba7cee610e92…`.
12	5. **Only then** resume from "Next" below. **Trust files over summary; verify by artifact, never by memory.**
13	6. **Backstop (per `perpetual-memory` skill):** the full session transcript on disk is the source of truth for anything the distillation dropped — `grep` the session `.jsonl` under `C:\Users\user\.claude\projects\C--loom\` for specifics (or open it in `C:\TRANSPORTER\claude_archive_viewer_v4.html` and concept-search). Do **not** re-read it whole.
14	
15	## Where we are (2026-06-13)
16	- **KEEL** = the sovereign genome harness. Canon **v0.2 adopted**. **Native Rust core** (ADR #5). Consumed **embedded or over protocol**. L1 personal tool, not a product.
17	- **Committed `d83d6ac` on `main`; pushed PUBLIC to `github.com/bochen2029-pixel/keel`.**
18	- **L0 contracts** (`crates/keel-contracts`): the ten joints + types + §18 error taxonomy. **`cargo check` + `cargo clippy` GREEN** on rustc **1.96.0**.
19	- **L1 kernel spine — slices 1–2 landed** (`crates/keel-kernel`): `manifest` (YAML; parses the real `keel.lock` → typed tiers/router/cost, reuses L0 `Price`/`Effort`/`Capabilities`) · `context` (trace-id + clock + per-task budget; L0 stays clock-free) · `registry` (tier→`Arc<dyn ModelTier>` container the **wiring layer** fills, so the kernel imports no L2 — a deliberate fix over the bench) · `chain` (the middleware onion; I1/I3/I4 ride here and become unbypassable; middleware observes/gates/transforms-request, the **engine owns `Context`** for accumulation). `check` + `clippy` clean, **12 tests green**. Manifest format = YAML behind serde (swappable); `rust-toolchain.toml` pin deferred (charter §5: a global-toolchain touch).
20	- **L3 invariant middleware — the deterministic trio landed** (`crates/keel-middleware`): `mw::audit` (I1 — structured `AuditEvent` per call behind a pluggable `AuditSink`; fires even on a blocked call) · `mw::privacy` (I3 — rung-1/2 deterministic mask: operator markers + regex/checksums incl. Luhn cards; redacts on egress, passes through locally; the operator's marker list stays operator-authored) · `mw::cost` (I4 — pre-call budget hard-stop gate). All compose on one chain → invariants proven unbypassable end-to-end. **12 middleware tests green**.
21	- **L2 first real tier landed** (`crates/keel-adapters`): `local_llama` — HTTP→llama…
```

## Claude — Jun 14, 2026 01:11

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:11

Now the substrate pin and the frozen goldens.

## Claude — Jun 14, 2026 01:11

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\keel.lock"
}
```
**[tool result]**
```
1	# keel.lock — the reproducible substrate KEEL expects.
2	# Pin hashes when the models/servers are installed. The substrate resolver (kernel::lifecycle)
3	# reads this to discover/launch/route; a fresh box is provisioned from it. Hashes are the
4	# reproducibility contract — a run is replayable only against pinned weights.
5	
6	keel:        { version: 0.2.0, stage: stage0 }   # spec -> stage0 -> stage1 -> stage2 -> stage3
7	
8	# --- canonical primitives ---------------------------------------------------
9	# disposition: `embedded` = baked into the binary; `shared` = system asset, download-once.
10	substrate:
11	  llm_vision:                                   # brain + eyes (native multimodal, early-fusion)
12	    id: qwen3.5-9b-q5_k_m
13	    mmproj: mmproj-F16                           # llama.cpp serves Qwen vision via this projector file
14	    sha256: TODO
15	    mmproj_sha256: TODO
16	    disposition: shared
17	    fallbacks: [qwen3.5-4b-q4_k_m]               # smaller-VRAM tier (resolver picks by HardwareProfile)
18	  audio:                                         # ears (separate organ; transcribes -> text pre-cognition)
19	    id: whisper-large-v3-turbo
20	    sha256: TODO
21	    disposition: shared
22	    fallback: whisper-base.en                    # faster-than-realtime CPU default
23	    gate: vad                                    # transcribe only on voiced audio
24	  embedding:                                     # recall + cheap routing-classification — a Memory organ, NOT a tier
25	    id: qwen3-embedding-0.6b-q8                    # capable local default (~1024-dim, sovereign-safe)
26	    sha256: TODO
27	    dim: 1024                                      # fingerprinted into the index; mismatch => rebuild-from-ledger
28	    disposition: shared                            # download-once system asset
29	    fallback: all-minilm-l6-v2                     # 384-dim, embedded, CPU -> the "never blind" floor
30	    sovereign_forces: local                        # I3: sovereign/PHI text never embeds off-box; vectors stay local
31	    format_committing: true                        # the one substrate exception to tier-interchangeability (ADR #13)
32	  rerank:                                          # cross-encoder upgrade to Memory's rerank() sub-seam
33	    id: qwen3-reranker-0.6b-q8
34	    sha256: TODO
35	    disposition: shared
36	    default: identity                              # SHIPS OFF (canon §11) — pass-through until GOLDEN_RECALL earns it on
37	  privacy:                                         # I3 mask, rung 3 — recall verification-pass (NOT the guarantee)
38	    id: openai-privacy-filter                      # bidirectional token-classifier (BIOES span head), 50M active / ~1.5B total, Apache-2.0
39	    sha256: TODO
40	    runtime: onnx                                  # in-process via the Rust `ort` crate (or transformers) — NOT a GGUF, NOT llama.cpp, no server to supervise
41	    disposition: shared                            # ~1GB weights, download-once (too big to bake in); but runs in-process like the embedder, unlike the server-based LLM/Whisper
42	    decode: viterbi                                # span-decode is deterministic, app-level, KEEL-owned -> the operating point is a NON-model knob
43	    default: off                                   # rungs 1-2 (markers+regex) ship Stage 0; model lands Stage 2 behind GOLDEN_PRIVACY
44	    operating_point: recall                        # = the Viterbi transition-bias: tune toward over-redaction; leak-uncertain => sovereign
45	    per_cell_finetune: true                        # general PII | medical PHI | code/secrets
46	    scrub_before_distill: true                     # reversibility gate: no secret fossilized into a LoRA
47	  store:                                         # the index (the ledger is files, see below)
48	    engine: sqlite                               # baked into the binary (~1 MB, embeddable)
49	    vector: sqlite-vec
50	    d…
```

## Claude — Jun 14, 2026 01:11

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:11

Now the frozen conformance layer — both golden files (read-only).

## Claude — Jun 14, 2026 01:11

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\tests\\golden\\golden.json"
}
```
**[tool result]**
```
1	{
2	  "_meta": {
3	    "status": "RATIFIED + FROZEN by operator 2026-06-13 — agent-frozen henceforth (I5). Hash in .frozen.json; changing any case is an operator action only.",
4	    "purpose": "The language-neutral conformance layer (canon §7). ANY KEEL implementation, in ANY language, must pass these. This is what makes the implementation language the most reversible decision in the system (ADR #5).",
5	    "freeze": "Verified by re-hashing `cases` (every section except _meta), canonical-sorted, vs .frozen.json. The Stage-0 CI gate enforces it.",
6	    "version": "0.2.0"
7	  },
8	  "router": [
9	    { "name": "file-read scaffolding -> local",        "input": {"kind": "scaffolding", "ty": "tool_call:read_file", "tier_history": []}, "expect": {"tier": "local"} },
10	    { "name": "multi-constraint reasoning -> cheap",    "input": {"kind": "core-wire", "ty": "reason:multi_constraint", "tier_history": []}, "expect": {"tier": "cheap-API"} },
11	    { "name": "local failed oracle twice -> escalate",  "input": {"kind": "scaffolding", "ty": "transform", "tier_history": ["local", "local"], "oracle_failures": 2}, "expect": {"tier_in": ["cheap-API", "frontier"]} },
12	    { "name": "sovereign data forces local",            "input": {"kind": "core-wire", "ty": "reason:multi_constraint", "data_class": "sovereign"}, "expect": {"tier": "local", "reason_contains": "privacy"} },
13	    { "name": "image content forces local",             "input": {"kind": "core-wire", "content": ["image"]}, "expect": {"tier": "local", "reason_contains": "perception"} },
14	    { "name": "projected cost over budget -> BLOCK",    "input": {"kind": "core-wire", "projected_cost": 9.99, "budget_remaining": 1.00}, "expect": {"tier": "BLOCK", "reason_contains": "budget"} }
15	  ],
16	  "model_tier": [
17	    { "name": "cost from usage + price (deepseek-v4-pro)", "input": {"usage": {"input_tokens": 1000, "output_tokens": 500, "cache_hit_tokens": 800}, "price": {"input_miss": 0.435, "input_hit": 0.003625, "output": 0.87}}, "expect": {"cost": 0.0005249, "tol": 1e-6} },
18	    { "name": "tool call valid against schema under constrained decode", "input": {"schema": {"type": "object", "required": ["path"], "properties": {"path": {"type": "string"}}}}, "expect": {"tool_call_valid_against_schema": true} },
19	    { "name": "reasoning_content survives a tool round-trip (no 400)", "input": {"two_turn_thinking": true}, "expect": {"reasoning_content_preserved": true, "no_400": true} }
20	  ],
21	  "oracle": [
22	    { "name": "redaction output with an SSN pattern fails a property oracle", "input": {"output": "patient ... 123-45-6789 ...", "property": "no_ssn_pattern"}, "expect": {"passed": false, "joint_wrong": false} },
23	    { "name": "code passing its own tests but failing a golden is JOINT_WRONG", "input": {"self_tests_pass": true, "golden_violated": true}, "expect": {"passed": false, "joint_wrong": true} },
24	    { "name": "claim not traceable to canon -> INSUFFICIENT_SOURCE (routes to human)", "input": {"claim": "led a team of 12", "canon_supports": false}, "expect": {"passed": false, "reason_contains": "INSUFFICIENT_SOURCE"} }
25	  ],
26	  "perception": [
27	    { "name": "identical frame is change-gated (dHash <= 4)", "input": {"frame_delta": 2}, "expect": {"emitted": false} },
28	    { "name": "slide change emits a percept (dHash >= 15)",   "input": {"frame_delta": 18}, "expect": {"emitted": true} },
29	    { "name": "silence is VAD-gated",                          "input": {"voiced_ms": 0}, "expect": {"emitted": false} }
30	  ],
31	  "recall": [
32	    { "name": "reranker beats identity on recall@k",          "input": {"query": "...", "expected_memory_ids": ["m7"]}, "expect": {"recall_at_5_uplift_over_identity": ">= threshold"} },
33	    { "name": "embedder upgrade beats the MiniLM floor",       "input": {"set": "golden-recall"}, "expect": {"ndcg_uplift_over_floor": ">= threshold"} },
34	    { "name": "index fingerprint mismatch rebuilds from ledger", "input": {"i…
```

## Claude — Jun 14, 2026 01:11

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:11

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\tests\\golden\\.frozen.json"
}
```
**[tool result]**
```
1	{
2	  "sha256": "63d5ba7cee610e924df09b0c227786e1a031b93ce076296e7dddcb9bf5d6261c",
3	  "version": "0.2.0",
4	  "note": "sha256 of golden.json `cases` (every section except _meta), canonical-sorted. Operator-frozen; agent read-only. Re-hash to verify (Stage-0 CI gate)."
5	}
6	
```

## Claude — Jun 14, 2026 01:12

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:12

All Phase-1 documents read in full. Moving to **Phase 2 — verify by artifact**. Running the read-only git inspection first.

## Claude — Jun 14, 2026 01:12

**[tool: PowerShell]**
```json
{
  "command": "git -C C:\\KEEL log --oneline -15",
  "description": "Show recent commit history"
}
```
**[tool result]**
```
61334b3 Stage 2: svc::verifier — the externality layer (I5); GOLDEN_ORACLE green
189542d docs(state): correct first-cell provenance (operator-stated in-session, not pre-compaction); ground the Director (C:\backrooms, MODULE.md-verified); log L5->L1 engine debt
4223ef1 docs(state): capture operator intent — the game's Director is KEEL's first cell / first real test
19e8ddd Stage 1: self-driving engine — keel/keel-serve route every turn via the router
393fa27 handoff: recent-turns (reverse-chronological tail) + wire the reconstitution pointer
5083c41 handoff: forward-arc (max-res narrative) for pre-compaction continuity
1cb6d8c docs: capture the perpetual-memory proposal (operator techniques → Memory organ)
f620cb1 Stage 1: DifficultyRouter — the fusion point, GOLDEN_ROUTER-validated
6580744 Stage 0: store::sqlite — the index + first Spine impl (I2)
07c0787 Stage 0: frontier tier — anthropic adapter (Opus 4.8), live-validated
57ef611 Stage 0 (b): serve_openai — KEEL consumable over protocol
8cf6c69 Stage 0 (c2): substrate launch + supervise (kernel::lifecycle)
3cfe6e0 Stage 0 (c1): substrate resolver — probe/resolve (kernel::lifecycle)
0d65951 fix(deepseek): honor Effort.thinking explicitly — v4-pro defaults to thinking on
c728c3b Stage 0: cheap-API tier — deepseek adapter (L2), live-validated; CLI --tier
```

## Claude — Jun 14, 2026 01:12

**[tool: PowerShell]**
```json
{
  "command": "git -C C:\\KEEL status",
  "description": "Show working tree status"
}
```
**[tool result]**
```
On branch main
Your branch is up to date with 'origin/main'.

Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git restore <file>..." to discard changes in working directory)
	modified:   _run_state/STATE.md

Untracked files:
  (use "git add <file>..." to include in what will be committed)
	_memories/
	_run_state/INIT_PROMPT.md
	_run_state/WAKE_UP.md
	_run_state/WAKE_UP_part1.md
	_run_state/WAKE_UP_part2.md
	_run_state/WAKE_UP_part3.md
	_run_state/WAKE_UP_part4.md
	_run_state/WAKE_UP_part5.md
	_run_state/trajectory-account.md
	chunker/

no changes added to commit (use "git add" and/or "git commit -a")
```

## Claude — Jun 14, 2026 01:12

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:12

Git matches the brief: HEAD is `61334b3` (svc::verifier / GOLDEN_ORACLE green), the self-driving engine (`19e8ddd`) landed, and STATE.md is the only modified tracked file. Note commit `4223ef1` is the one that introduced the "Director = first cell" framing that the WAKE_UP brief later reconciles.

Now the build gate. Running `cargo check → clippy → test` chained from MSVC PowerShell.

## Claude — Jun 14, 2026 01:12

**[tool: PowerShell]**
```json
{
  "command": "cargo check --workspace 2>&1; \"----- CHECK EXIT: $LASTEXITCODE -----\"",
  "description": "Run cargo check across the workspace",
  "timeout": 600000
}
```
**[tool result]**
```
[31;1m    Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.27s[0m
----- CHECK EXIT: 0 -----
```

## Claude — Jun 14, 2026 01:12

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:12

`cargo check` green (exit 0, fully built). Now clippy and the test suite.

## Claude — Jun 14, 2026 01:12

**[tool: PowerShell]**
```json
{
  "command": "cargo clippy --workspace --all-targets 2>&1; \"----- CLIPPY EXIT: $LASTEXITCODE -----\"",
  "description": "Run clippy across all workspace targets",
  "timeout": 600000
}
```
**[tool result]**
```
[31;1m    Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.30s[0m
----- CLIPPY EXIT: 0 -----
```

## Claude — Jun 14, 2026 01:12

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:12

Clippy clean (exit 0). Now the test suite.

## Claude — Jun 14, 2026 01:12

**[tool: PowerShell]**
```json
{
  "command": "cargo test --workspace 2>&1; \"----- TEST EXIT: $LASTEXITCODE -----\"",
  "description": "Run the full workspace test suite",
  "timeout": 600000
}
```
**[tool result]**
```
running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

running 18 tests
test anthropic::tests::live_generate ... ignored, hits the real Anthropic API; needs ANTHROPIC_API_KEY
test deepseek::tests::live_generate ... ignored, hits the real DeepSeek API; needs DEEPSEEK_API_KEY
test local_llama::tests::live_generate ... ignored, requires a live llama-server on 127.0.0.1:8080
test anthropic::tests::image_data_uri_becomes_a_base64_block ... ok
test openai::tests::parses_response_and_computes_cost ... ok
test local_llama::tests::thinking_toggle_mapping ... ok
test openai::tests::audio_content_is_rejected ... ok
test deepseek::tests::thinking_modes ... ok
test local_llama::tests::grammar_string_and_object_route_to_the_right_field ... ok
test local_llama::tests::body_carries_thinking_and_endpoint_is_trimmed ... ok
test anthropic::tests::parses_content_blocks_and_real_cost ... ok
test anthropic::tests::thinking_high_enables_with_budget_and_bumps_max_tokens ... ok
test local_llama::tests::caps_report_vision ... ok
test anthropic::tests::system_is_hoisted_top_level_and_user_is_a_string ... ok
test openai::tests::image_maps_to_image_url_part ... ok
test deepseek::tests::chat_url_has_no_v1 ... ok
test openai::tests::single_text_maps_to_a_string ... ok
test deepseek::tests::caps_have_no_vision ... ok

test result: ok. 15 passed; 0 failed; 3 ignored; 0 measured; 0 filtered out; finished in 0.00s

[31;1m    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.32s[0m
[31;1m     Running unittests src\lib.rs (target\debug\deps\keel-5e2cbe96babc1b33.exe)[0m
[31;1m     Running unittests src\main.rs (target\debug\deps\keel-a442ace60f730320.exe)[0m
[31;1m     Running unittests src\bin\keel-serve.rs (target\debug\deps\keel_serve-01df04f28e893562.exe)[0m
[31;1m     Running unittests src\lib.rs (target\debug\deps\keel_adapters-f2b1895c0b91ad6f.exe)[0m
[31;1m     Running unittests src\lib.rs (target\debug\deps\keel_contracts-64b00775dabc7337.exe)[0m

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

[31;1m     Running tests\golden_freeze.rs (target\debug\deps\golden_freeze-1d7a631fb9946c53.exe)[0m

running 1 test
test goldens_match_the_frozen_hash ... ignored, operator-only: re-stamp .frozen.json KEEL-native (example golden_freeze --update), then un-ignore

test result: ok. 0 passed; 0 failed; 1 ignored; 0 measured; 0 filtered out; finished in 0.00s

[31;1m     Running unittests src\lib.rs (target\debug\deps\keel_kernel-63f2564ff223428f.exe)[0m

running 17 tests
test context::tests::now_millis_is_after_2024 ... ok
test context::tests::trace_id_is_twelve_hex_and_unique ... ok
test chain::tests::empty_chain_hits_terminal ... ok
test chain::tests::request_transform_reaches_terminal ... ok
test chain::tests::onion_order_and_terminal ... ok
test context::tests::new_context_seeds_budget_and_clean_state ... ok
test manifest::tests::parses_sample ... ok
test registry::tests::register_get_contains_names ... ok
test chain::tests::middleware_can_short_circuit ... ok
test manifest::tests::defaults_apply_for_absent_sections ... ok
test registry::tests::register_replaces ... ok
test manifest::tests::reads_the_real_keel_lock ... ok
test lifecycle::tests::probe_detects_a_listener ... ok
test lifecycle::tests::health_ok_parses_200_and_rejects_503 ... ok
test lifecycle::tests::probe_misses_a_dead_port ... ok
test lifecycle::tests::resolve_errors_when_nothing_is_up ... ok
test lifecycle::tests::resolve_picks_the_first_live_candidate ... ok

test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.30s

[31;1m     Running unittests src\lib.rs (target\debug\deps\keel…
```

## Claude — Jun 14, 2026 01:13

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:13

Full suite green (exit 0): **51 passed, 4 ignored** (3 live API tests + the 1 dormant freeze-gate). The conformance markers all line up — `router::tests::passes_golden_router` ✓, `verifier::tests::passes_golden_oracle` ✓, and `goldens_match_the_frozen_hash` is `ignored` with the exact "operator-only re-stamp" message.

Let me corroborate the structural claims (crate count, the absent `kernel::engine`/`lock`, the engine living at L5) and inspect the one uncommitted change.

## Claude — Jun 14, 2026 01:13

**[tool: Glob]**
```json
{
  "pattern": "crates/*/src/**/*.rs"
}
```
**[tool result]**
```
crates\keel-contracts\src\lib.rs
crates\keel-contracts\src\errors.rs
crates\keel-contracts\src\traits.rs
crates\keel-contracts\src\types.rs
crates\keel-kernel\src\context.rs
crates\keel-kernel\src\registry.rs
crates\keel-kernel\src\chain.rs
crates\keel-middleware\src\cost.rs
crates\keel-middleware\src\privacy.rs
crates\keel-adapters\src\openai.rs
crates\keel-adapters\src\local_llama.rs
crates\keel-kernel\src\manifest.rs
crates\keel-middleware\src\audit.rs
crates\keel-middleware\src\lib.rs
crates\keel-adapters\src\deepseek.rs
crates\keel-kernel\src\lifecycle.rs
crates\keel-kernel\src\lib.rs
crates\keel-adapters\src\anthropic.rs
crates\keel-adapters\src\lib.rs
crates\keel-store\src\lib.rs
crates\keel\src\lib.rs
crates\keel\src\main.rs
crates\keel\src\bin\keel-serve.rs
crates\keel-services\src\router.rs
crates\keel-services\src\verifier.rs
crates\keel-services\src\lib.rs
```

## Claude — Jun 14, 2026 01:13

**[tool: PowerShell]**
```json
{
  "command": "git -C C:\\KEEL diff --stat HEAD -- _run_state/STATE.md; \"----- DIFF BELOW -----\"; git -C C:\\KEEL diff HEAD -- _run_state/STATE.md",
  "description": "Show uncommitted STATE.md changes vs HEAD"
}
```
**[tool result]**
```
warning: in the working copy of '_run_state/STATE.md', LF will be replaced by CRLF the next time Git touches it
 _run_state/STATE.md | 1 +
 1 file changed, 1 insertion(+)
----- DIFF BELOW -----
warning: in the working copy of '_run_state/STATE.md', LF will be replaced by CRLF the next time Git touches it
diff --git a/_run_state/STATE.md b/_run_state/STATE.md
index 6f255dd..ec1120f 100644
--- a/_run_state/STATE.md
+++ b/_run_state/STATE.md
@@ -3,6 +3,7 @@

 ## ⛑ RECONSTITUTION PROTOCOL — read this FIRST after any compaction/resume, before ANY other action
 The conversation summary is **lossy**. The committed repo + the canon are the truth. Before resuming work or answering a new turn:
+0. **Read `_run_state/WAKE_UP.md` IN FULL, FIRST** — the pre-digested, reconciled onboarding brief (full intent + soul · current ground-truth state · the next slice · the resolved drift · where every artifact lives). Lowest-context path to 100% up-to-speed; everything below corroborates it. If it doesn't fit one read, read `_run_state/WAKE_UP_part1..5.md` in order, or chunk it (`C:\KEEL\chunker`).
 1. **Read this file (STATE.md) fully**, then the live-session handoff in order: `_run_state/handoff/forward-arc.md` (the causal arc + the operator-confirmed next move) → `_run_state/handoff/recent-turns.md` (recent turns, reverse-chronological, newest-first). Those are the **narrative register** (per the `perpetual-memory` skill / REEL); the **factual register** is git + the contracts/goldens — trust it on any conflict.
 2. **Read the canon** `C:\KEEL\KEEL_ARCHITECTURE.md` **+ the constitution** `C:\KEEL\CLAUDE.md`.
    ⚠ **The session cwd is `C:\loom`, so the AUTO-LOADED CLAUDE.md is Marrow-L1's, NOT KEEL's.** The active project is **KEEL at `C:\KEEL`**. Do not act on the Marrow-L1 constitution.
```

## Claude — Jun 14, 2026 01:13

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:13

Structure confirmed: **7 crates**; `keel-kernel/src` has `context · registry · chain · manifest · lifecycle` but **no `engine.rs` / `lock.rs`** — so the loop lives at L5 in `crates/keel/src/lib.rs`, exactly as documented. The lone uncommitted change is a benign addition to STATE.md (a new "read WAKE_UP.md first" step 0) — it does **not** touch the contested Director line (still line 52) or the stale build-state.

The single most load-bearing claim for the proposed next slice is "I5 is not wired into the loop." Let me verify that directly in the engine source rather than trust the summary.

## Claude — Jun 14, 2026 01:13

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel\\src\\lib.rs"
}
```
**[tool result]**
```
1	//! keel (L5) — the shared wiring both apps use. Two ways to assemble the spine from `keel.lock`:
2	//!
3	//! - [`Engine`] — the **self-driving** path: a multi-tier registry of every *available* tier (local
4	//!   always; a cloud tier only when its API key is in the env), each behind its **own** invariant
5	//!   chain (audit → privacy → cost), fronted by a swappable [`Router`] policy. `keel` (default) and
6	//!   `keel-serve` route **every** turn through it — the router picks the tier, not the operator.
7	//! - [`assemble`] — the **single-tier** path: build exactly one tier behind the chain. The CLI's
8	//!   `--tier` override uses it so an explicit cloud call never needlessly cold-starts the local
9	//!   substrate.
10	//!
11	//! Both share `build_tier` / `build_chain`, so there is one wiring truth, not two. The privacy
12	//! egress mask (I3) is **per tier**: local stays on the box (pass-through), every cloud tier is
13	//! masked before egress — which is why the `Engine` gives each tier its own chain rather than one
14	//! shared chain with a single static flag.
15	
16	use keel_adapters::{Anthropic, DeepSeek, LocalLlama};
17	use keel_contracts::{
18	    Context, Decision, Effort, GenerateRequest, GenerateResult, KeelError, ModelTier, Result, Router, Step,
19	};
20	use keel_kernel::{Chain, Manifest, Registry, TierCfg};
21	use keel_middleware::{AuditMiddleware, AuditSink, CostMiddleware, FileAuditSink, PrivacyMiddleware, Redactor};
22	use keel_services::DifficultyRouter;
23	use std::collections::BTreeMap;
24	use std::sync::Arc;
25	
26	pub const DEEPSEEK_ENDPOINT: &str = "https://api.deepseek.com";
27	pub const ANTHROPIC_ENDPOINT: &str = "https://api.anthropic.com";
28	pub const AUDIT_LEDGER: &str = ".keelstate/audit.jsonl";
29	// local substrate launch (paths match keel.lock; keel.lock-driven config is a refinement)
30	pub const LLAMA_EXE: &str = r"C:\llama.cpp\llama-server.exe";
31	pub const LLAMA_MODEL: &str = r"C:\models\Qwen3.5-9B-Q5_K_M.gguf";
32	pub const LLAMA_MMPROJ: &str = r"C:\models\mmproj-F16.gguf";
33	pub const LLAMA_LOG: &str = ".keelstate/llama-server.log";
34	
35	/// The tier ladder, cheapest first — the engine walks DOWN it to fall back to an available tier.
36	const LADDER: [&str; 3] = ["local", "cheap-API", "frontier"];
37	
38	// ── the self-driving engine ──────────────────────────────────────────────────
39	
40	/// One wired tier: its brain adapter, the model id to send it, and the **egress-correct** invariant
41	/// chain for that tier (local pass-through vs cloud-masked, I3).
42	struct TierSlot {
43	    tier: Arc<dyn ModelTier>,
44	    chain: Chain,
45	    model: String,
46	}
47	
48	/// The self-driving engine (canon §9, the fusion point wired up): hold every *available* tier, let
49	/// the [`Router`] pick one per turn, run it through that tier's chain. `keel`/`keel-serve` build on
50	/// this so a turn auto-lands on the cheapest brain that clears the bar instead of a pinned `--tier`.
51	pub struct Engine {
52	    slots: BTreeMap<String, TierSlot>,
53	    router: Box<dyn Router>,
54	    default_tier: String,
55	}
56	
57	/// The result of a routed turn: the model output plus the routing story (for the operator/ledger).
58	pub struct Outcome {
59	    pub result: GenerateResult,
60	    /// What the router chose (its tier + reason).
61	    pub decision: Decision,
62	    /// The tier actually run — equals `decision.tier` unless that tier was unplugged.
63	    pub tier_used: String,
64	    /// True when the chosen tier was unavailable and the engine fell back down the ladder.
65	    pub substituted: bool,
66	}
67	
68	impl Engine {
69	    /// Assemble from `keel.lock`: wire every tier whose substrate is reachable — **local always**
70	    /// (resolving/launching llama-server), a **cloud tier only when its key is in the env** (absent
71	    /// key ⇒ skipped, not fatal) — each behind an `audit · privacy · cost` chain whose egress mask
72	    /// matches whether that tier leaves the box (I3). The policy is…
```

## Claude — Jun 14, 2026 01:13

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:13

Verified directly: `Engine::run` (lines 118–136) does `route → chain.run → return Outcome`. There is **no** `verify`, no `checkpoint`, no `emit`, no cost fold-back into `ctx`, and `step.oracle_failures` is never written. So the four claims hold by artifact: I5 unwired, I4 not accumulated mid-run, I2 not checkpointing, engine at L5. I also see the LOW-debt items live (hardcoded `LLAMA_*` paths + `with_max_tokens(2048)` at lines 30–33/217; `Redactor::new(vec![])` empty rung-1 at lines 79/202).

To ground the Phase-4 plan and the "zero contract edits" assertion, let me read the frozen joint signatures and the verifier's current surface.

## Claude — Jun 14, 2026 01:13

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-contracts\\src\\traits.rs"
}
```
**[tool result]**
```
1	//! KEEL L0 — the ten joints (canon §7). Frozen.
2	//!
3	//! Async traits use `#[async_trait]` so they stay **dyn-compatible** — the registry and the
4	//! middleware chain hold `dyn ModelTier` / `dyn Middleware`. `Router` is sync by design.
5	
6	use crate::errors::Result;
7	use crate::types::*;
8	use async_trait::async_trait;
9	use core::pin::Pin;
10	
11	/// Eyes/ears yield percepts as a stream (live capture is forward-only; archival sources
12	/// may multi-pass). Boxed for dyn use.
13	pub type PerceptStream = Pin<Box<dyn futures_core::stream::Stream<Item = Percept> + Send>>;
14	
15	/// 1 — the uniform brain interface (cognition, incl. multimodal). Every adapter implements it.
16	#[async_trait]
17	pub trait ModelTier: Send + Sync {
18	    fn caps(&self) -> Capabilities;
19	    async fn generate(&self, req: GenerateRequest, ctx: &Context) -> Result<GenerateResult>;
20	}
21	
22	/// 2 — tools/context/resources over MCP. KEEL is a client (and, in apps, a server).
23	#[async_trait]
24	pub trait ToolHost: Send + Sync {
25	    async fn list(&self) -> Result<Vec<ToolDef>>;
26	    async fn call(&self, name: &str, args: Json, ctx: &Context) -> Result<ToolResult>;
27	}
28	
29	/// The rest-of-chain continuation handed to each middleware.
30	#[async_trait]
31	pub trait Next: Send + Sync {
32	    async fn run(&self, req: GenerateRequest, ctx: &Context) -> Result<GenerateResult>;
33	}
34	
35	/// 3 — a cross-cutting concern on every call. I1 (audit), I3 (privacy), I4 (cost) live here,
36	/// which is what makes them structurally unbypassable.
37	#[async_trait]
38	pub trait Middleware: Send + Sync {
39	    async fn handle(&self, req: GenerateRequest, ctx: &Context, next: &dyn Next) -> Result<GenerateResult>;
40	}
41	
42	/// 4 — the fusion point: cheapest tier that clears the trust bar. Sync (a rules heuristic,
43	/// not a model call).
44	pub trait Router: Send + Sync {
45	    fn route(&self, step: &Step, ctx: &Context) -> Decision;
46	}
47	
48	/// 5 — the externality surface (I5). A non-model assertion of correctness; flags JOINT_WRONG.
49	#[async_trait]
50	pub trait Oracle: Send + Sync {
51	    async fn verify(&self, output: &StepOutput, golden: &[GoldenCase], ctx: &Context) -> Result<Verdict>;
52	}
53	
54	/// 6 — the self that persists: ringed/budgeted assembly, the lossless record, model-authored
55	/// consolidation (returns a maintenance `Step`). Stores plug in behind it.
56	#[async_trait]
57	pub trait Memory: Send + Sync {
58	    async fn assemble(&self, step: &Step, ctx: &Context) -> Result<AssembledContext>;
59	    async fn record(&self, trace: &Trace) -> Result<()>;
60	    async fn consolidate(&self) -> Result<Step>;
61	}
62	
63	/// 7 — durable run-state (I2): resumable from checkpoint. The append-only ledger.
64	#[async_trait]
65	pub trait Spine: Send + Sync {
66	    async fn checkpoint(&self, run: &RunId, state: &State) -> Result<()>;
67	    async fn resume(&self, run: &RunId) -> Result<Option<State>>;
68	}
69	
70	/// 8 — initiative: a source of work. The user-turn is one Driver; heartbeat/watch/outreach
71	/// are others. `None` = nothing to do now.
72	#[async_trait]
73	pub trait Driver: Send + Sync {
74	    async fn poll(&self, ctx: &Context) -> Result<Option<Step>>;
75	}
76	
77	/// 9 — the flywheel feed: a verified trace becomes distillation feedstock.
78	#[async_trait]
79	pub trait TraceSink: Send + Sync {
80	    async fn emit(&self, trace: VerifiedTrace) -> Result<()>;
81	}
82	
83	/// 10 — afferent senses (eyes + ears). Modality in → percepts out. Not a tier; the router
84	/// never routes to it.
85	pub trait PerceptionSource: Send + Sync {
86	    fn percepts(&self, spec: SampleSpec) -> PerceptStream;
87	}
88	
```

## Claude — Jun 14, 2026 01:14

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:14

The joints are exactly as canon §7 specifies. The `kernel::engine` loop must orchestrate `Memory::assemble → Router::route → chain.run → Oracle::verify → Spine::checkpoint → TraceSink::emit`, all already-frozen async traits. Let me confirm the verifier's current surface and the supporting types so I can state precisely that wiring needs zero contract edits.

## Claude — Jun 14, 2026 01:14

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\verifier.rs"
}
```
**[tool result]**
```
1	//! keel-services::verifier — the externality layer (I5, canon §10). KEEL routes and runs; **only
2	//! here does it verify** — against an assertion **no model authored**. This is the keystone that
3	//! separates a trust economy from an off-the-shelf harness (§0): the model may author the plan, the
4	//! code, even a verification pass — it may *not* author its own ground truth.
5	//!
6	//! Three model-free oracle kinds cover the frozen `GOLDEN_ORACLE` cases, walking the §10 taxonomy:
7	//! - [`PropertyOracle`] — a deterministic property/metamorphic assertion on the output (e.g. "no
8	//!   SSN pattern"). The highest-recall, model-free rung.
9	//! - [`GoldenOracle`] — the **joint-wrong detector**: when the implementation's own tests pass yet a
10	//!   frozen golden is violated → `JOINT_WRONG`, the most dangerous finding (everything looked green).
11	//! - [`SourceOracle`] — the trace-to-canon gate (SEXTANT's "Truth Gate"): an ungrounded claim →
12	//!   `INSUFFICIENT_SOURCE`, which routes to a human (§18).
13	//!
14	//! [`Verifier`] is the **pluggable registry** (§10): each cell registers its own oracles; `verify`
15	//! runs them all and folds the verdicts. The registry — not any single oracle — is the seam a cell
16	//! specializes (a clerk's cross-footing, a companion's chattiness gate, …) without a core edit.
17	
18	use async_trait::async_trait;
19	use keel_contracts::{Assertion, Context, GoldenCase, Oracle, Result, StepOutput, Verdict};
20	use regex::Regex;
21	
22	// ── property / metamorphic oracle ─────────────────────────────────────────────
23	
24	/// Asserts named, deterministic properties of an output — no model. Unknown properties **fail
25	/// closed** (KEEL never claims a property held that it could not check — the §5 "fail toward the
26	/// safe side" rule applied to correctness).
27	pub struct PropertyOracle {
28	    properties: Vec<String>,
29	}
30	
31	impl PropertyOracle {
32	    pub fn new(properties: Vec<String>) -> Self {
33	        Self { properties }
34	    }
35	
36	    /// `Some(failure)` if the property is violated (or unknown); `None` if it holds.
37	    fn check(&self, property: &str, content: &str) -> Option<String> {
38	        match property {
39	            "no_ssn_pattern" => {
40	                let re = Regex::new(r"\b\d{3}-\d{2}-\d{4}\b").expect("static SSN pattern is valid");
41	                re.is_match(content).then(|| "no_ssn_pattern: output contains an SSN-shaped span".to_string())
42	            }
43	            other => Some(format!("unknown property '{other}' — fail-closed (cannot assert what it cannot check)")),
44	        }
45	    }
46	}
47	
48	#[async_trait]
49	impl Oracle for PropertyOracle {
50	    async fn verify(&self, output: &StepOutput, _golden: &[GoldenCase], _ctx: &Context) -> Result<Verdict> {
51	        let mut failures = Vec::new();
52	        let mut evidence = Vec::new();
53	        for property in &self.properties {
54	            match self.check(property, &output.content) {
55	                Some(failure) => {
56	                    evidence.push(Assertion { kind: "property".into(), detail: failure.clone() });
57	                    failures.push(failure);
58	                }
59	                None => evidence.push(Assertion { kind: "property".into(), detail: format!("{property}: held") }),
60	            }
61	        }
62	        Ok(Verdict { passed: failures.is_empty(), failures, joint_wrong: false, evidence })
63	    }
64	}
65	
66	// ── joint-wrong oracle ────────────────────────────────────────────────────────
67	
68	/// The joint-wrong detector (canon §10): runs golden cases against an output with **contract +
69	/// golden + diff but NOT the implementer's reasoning**. If the implementation's own tests pass yet a
70	/// frozen golden is violated → `JOINT_WRONG` (surfaced to the operator immediately, §18). For
71	/// conformance the two signals arrive on `output.artifact`; in a live run the verifier derives them
72	/// by actually running the goldens (`…
```

## Claude — Jun 14, 2026 01:14

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\lib.rs"
}
```
**[tool result]**
```
1	//! # keel-services — L4, the services
2	//!
3	//! Default (swappable) services composed from the contracts. A service MAY import middleware;
4	//! middleware may never import a service (the layer rule, canon §6).
5	//!
6	//! - **landed:** `router` (the difficulty router — the fusion point, canon §9) · `verifier` (the
7	//!   externality layer — pluggable oracle registry + joint-wrong, canon §10, the I5 keystone).
8	//! - **next:** `amplify` (best-of-N, ships OFF) · `memory` · `perception` · `driver`.
9	
10	pub mod router;
11	pub mod verifier;
12	
13	pub use router::DifficultyRouter;
14	pub use verifier::{GoldenOracle, PropertyOracle, SourceOracle, Verifier};
15	
```

## Claude — Jun 14, 2026 01:15

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:16

All Phase-1 reads and Phase-2 verification are done. Here is the artifact-grounded picture, my restated understanding, and the proposed next slice. I have written no code and run no mutating command; I stop for your go at the end.

---

## Phase 2 — what I verified by artifact (lived this session, not recalled)

| Claim | Artifact result |
|---|---|
| HEAD = svc::verifier / GOLDEN_ORACLE green | ✅ `61334b3` (git log) |
| Self-driving engine landed | ✅ `19e8ddd` |
| 7 crates (not 8) | ✅ `contracts · kernel · adapters · middleware · store · services · keel` |
| `kernel::engine` / `kernel::lock` exist | ❌ absent — `keel-kernel/src` is `context·registry·chain·manifest·lifecycle` only |
| Engine lives at L5 | ✅ `crates/keel/src/lib.rs` → `keel::Engine` |
| `cargo check` / `clippy` | ✅ green / clean (exit 0) |
| `cargo test` | ✅ **51 passed, 4 ignored** (3 live-API `#[ignore]`, 1 dormant freeze-gate) |
| GOLDEN_ROUTER / GOLDEN_ORACLE | ✅ `passes_golden_router` / `passes_golden_oracle` green |
| Freeze-gate dormant, operator-only re-stamp | ✅ `goldens_match_the_frozen_hash ... ignored` w/ exact message; seal `63d5ba7c…` in `.frozen.json` |
| **I5 unwired in the loop** | ✅ confirmed in source — `Engine::run` does `route → chain.run → return Outcome`; **no** `verify`, `checkpoint`, `emit`, no cost fold-back, `step.oracle_failures` never written |

The brief and STATE.md match reality. The only tracked diff is a benign STATE.md insertion (a new "read WAKE_UP first" reconstitution step 0); it does **not** touch the contested Director line (still STATE.md:52) or the stale build-state. Everything load-bearing reconciles.

---

## Phase 3 — understanding restated (my words)

**KEEL in one sentence.** A single-operator, sovereign, native-Rust *genome* — a tiny frozen core of contracts + invariants that perceives, remembers, routes every unit of work to the cheapest brain clearing a trust bar, and grounds every critical output in an assertion no model authored — so the thinking is rented and interchangeable while the *self* is owned and durable.

**Genome/cell & the boundary.** The genome (frozen joints + invariants + goldens) is written once; each specialization is a **cell = genome + periphery**, grown by composing adapters, *never* by editing the core. "Universal" = the **intersection** of the operator's real projects, never their union — the moment a vertical's heavy apparatus enters the core, KEEL can no longer serve the others. L1 personal tool, not a product: no multi-tenancy, no features for hypothetical users.

**The five invariants + the gate.** I1 observable (audit in-chain, unbypassable) · I2 durable (Spine + ledger; resume from checkpoint) · I3 filtered/sovereign (a **gate** forcing sovereign/PHI/raw-perception/vectors to `local`, plus a **mask** scrubbing residual PII before egress) · I4 governed (per-task cost cap, hard-stop, BLOCK) · I5 **externalized** — every *critical* output carries ≥1 non-model assertion (golden, property/metamorphic, deterministic gate, observed runtime, model-diverse review); a model may author the plan, code, even a verification pass, but **never its own ground truth**. The reversibility gate is the standing sixth: undo-cost-unstatable-in-one-sentence ⇒ stop and ask; reversibility-uncertain ⇒ treat as irreversible. Memory-safety is I5 applied to the source — the borrow checker is the non-model oracle (ADR #5). **I5 is the whole point, and it is NOT yet wired into the running loop** — verified above; it is golden-green at L4 but `Engine::run` never calls it, so `oracle_failures` stays 0 and the escalation ladder cannot fire from verification.

**Layer-import rule (exact order).** `contracts ← kernel ← {adapters, middleware} ← services ← apps`. A service may import middleware; middleware may **never** import a service; the kernel imports **only** contracts; contracts import nothing. `{adapters, middleware}` share a layer and import neither each other nor up.

**Frozen-golden rule.** The ten contracts (`keel-contracts`) and the goldens (`golden.json` + `.frozen.json`) are agent-read-only. If a golden fails, I fix the **code** — never the golden. Ratifying / changing / re-freezing a golden and re-stamping the seal is an **operator-only** act; I never self-stamp (this is exactly why the freeze-gate sits `#[ignore]`-dormant).

**Current build state** (trusting STATE.md + git over CLAUDE.md): Stage 0 complete (3-tier economy local/cheap-API/frontier, invariant chain, file ledger + SQLite Spine, CLI + `serve_openai`, self-resolving substrate) · Stage 1 router (`DifficultyRouter`, GOLDEN_ROUTER ✓) + self-driving `keel::Engine` landed · one Stage-2 slice (`svc::verifier`, I5) **landed but UNWIRED**. Honest invariant scorecard: I1 ✅; I2/I3/I4/I5 🟡 partial — I5 the headline gap.

**The reconciled drift I must hold.** The Backrooms **Director** (`C:\backrooms`, an L4 module, M0 stub, LLM host at milestone M11) is a **first external protocol-consumer / dogfood client** that will consume KEEL as a localhost sidecar over `serve_openai` (:7070, pinned local + single-shot + sovereign/scaffolding). It is **NOT a cell** in the genome sense and **NOT the canon's first cell** — **SEXTANT remains the canon's first cell.** STATE.md:52 still calls the Director the "first cell"; that is the drifted line (introduced live, partly walked back), and the careful read in `trajectory-account.md`/the WAKE_UP §4.3 ruling wins. The system is **SUPERVISED** — no autonomy grant is recorded.

**The next slice and why.** `kernel::engine` (L1) over *injected* `&dyn Router / Oracle / Memory / Spine / TraceSink` (the same dyn-injection the registry already uses for `ModelTier`), running **route → (assemble) → chain → verify → checkpoint → emit**, feeding `oracle_failures` / `tier_history` back so the escalation ladder fires across turns. One slice does four things: **wires I5 live · accumulates I4 cost in `Context` · activates I2 checkpointing · pays the L5→L1 engine debt.** I confirmed this is buildable with **zero contract edits**: the joints already have the exact async signatures (`Oracle::verify(&StepOutput, &[GoldenCase], &Context)`, `Spine::checkpoint`, `TraceSink::emit`, `Memory::assemble`, sync `Router::route`); the L4 `Verifier` already exposes a matching `verify`.

---

## Things I'd name (ambiguous / inconsistent / I'd-do-differently — not silently fixed)

1. **STATE.md:52 "First cell = the Backrooms Director"** contradicts the WAKE_UP §4.3 reconciliation (Director = consumer, SEXTANT = first cell). This is *the* doc-drift to ratify. Operator-governed wording.
2. **STATE.md:9 reconstitution warning is stale** — it still says "session cwd is `C:\loom`, so the AUTO-LOADED CLAUDE.md is Marrow-L1's." False for a `C:\KEEL` session; the uncommitted edit added step 0 but left this. Worth correcting in the same doc pass.
3. **CLAUDE.md "Build state" section is stale** — "Next: Stage 0… nothing above L0 exists yet," "goldens PROPOSED." Both false. Rules remain correct; only the state block is wrong.
4. **Canon §8 pseudocode shows a single `chain`,** but the real (correct) design uses a **per-tier egress-correct chain** for I3 — the L1 engine must hold tier→{adapter, chain, model} slots, not one chain. Not a contract problem; the §8 loop is illustrative and under-specifies the per-tier I3 reality. I'd add a one-line canon footnote rather than change behavior.
5. **`Verifier` is not itself an `Oracle`.** To inject it as `&dyn Oracle`, the clean move is `impl Oracle for Verifier` (the registry-of-oracles is naturally a composite oracle) — an **L4** addition, **no contract edit**. Alternative: the engine holds `Vec<Box<dyn Oracle>>`. One wiring decision to confirm.
6. **`golden_refs` resolution seam.** §8 calls `verify(res, step.golden_refs)`, but `Oracle::verify` wants `&[GoldenCase]` while `Step` carries `golden_refs: Vec<GoldenRef>` (refs, not cases). For the first slice this is moot — the default oracle set is property-based / the registry is empty, so verify is vacuous and the *mechanism* is what we activate — but the ref→case resolver (a runtime golden registry) is a real Stage-2 seam I'd defer and name now, not improvise.

None of these requires touching a frozen contract or golden.

---

## Phase 4 — proposed plan (then I stop)

**Recommendation: do the cheap record-reconciliation (Step 0) first, then the `kernel::engine` slice (Step 1).** Rationale: the Director "first cell" line and the stale build-state are exactly the kind of drift that compounds into the *next* instance's confabulation — cleaning the record before more code lands is near-zero-cost and squarely in the spirit of "verify by artifact." But three of those items are **yours to rule**, so Step 0 needs your input before I touch anything.

**Step 0 — Reconcile the record (no code, no contracts).** I need three rulings from you, then I apply the agent-permissible doc fixes:
- (a) **Confirm**: Director = external dogfood consumer, **not** a cell; **SEXTANT stays the canon's first cell.** (I'll then correct STATE.md:52 + STATE.md:9-stale-note and CLAUDE.md's build-state block to: *Stage 0 complete · Stage 1 router + self-driving engine landed · svc::verifier/I5 landed-but-unwired · goldens FROZEN*.)
- (b) **Keep or cut** the Marrow-L1 bench reference (CLAUDE.md commands a diff vs `C:\loom\marrow-l1`; a directive says KEEL is self-contained). My read: keep it as a *read-only behavior diff-oracle*, not a build/runtime dep — but your call.
- (c) **Autonomy**: codify or withhold the unattended-autonomy grant. My read: **withhold** until I2+I5 are actually in the loop (i.e., after Step 1) — staying SUPERVISED is correct today.
- **Operator-only**, not me: the golden freeze-gate re-stamp (`cargo run -p keel-contracts --example golden_freeze -- --update`, then un-ignore). I will not self-stamp.

**Step 1 — `kernel::engine` (L1), the highest-leverage slice.** A new `keel-kernel/src/engine.rs` importing **only** contracts (+ kernel's own `chain`/`registry`/`context`), parameterized over injected `&dyn Router`, a verify surface (`&dyn Oracle`, via `impl Oracle for Verifier`), `&dyn Spine`, and optionally `&dyn Memory`/`&dyn TraceSink` — running **route → chain.run → build `StepOutput` → verify → fold cost into `Context` → `spine.checkpoint` → `trace_sink.emit` on pass**, with `oracle_failures`/`tier_history` fed back so escalation fires. Then **shrink `keel::Engine` (L5) to pure injection** (it keeps the per-tier-chain wiring + key-gated tier selection; it hands the slots + services to the L1 engine). Gate: validate against the existing frozen goldens (router + oracle stay green), zero contract edits, clippy-clean, per-crate budget respected, freeze seal unmoved → one commit, one-line intent — **pushed only when you ask.**

The **one design point I want to confirm before coding** Step 1: on an oracle failure within a single turn, should the engine **escalate-in-turn** up the ladder (bounded by `escalate_after_oracle_failures`) and re-verify, or **record + surface the Verdict and return** (escalation realized on the *next* Step, as §8's persistence-on-Step implies)? I lean toward the latter for the first slice — it's the minimal faithful wiring; in-turn escalation is a clean follow-up — but it changes the loop shape, so it's yours to set.

**I'm stopping here. No code, no doc edits, no git mutation until you approve.** Tell me your Step-0 rulings (a/b/c) and whether to proceed to Step 1 with the record-first sequencing — or redirect.

## You — Jun 14, 2026 01:22

Good — this is the reconstitution I wanted: you verified by artifact instead of trusting the brief (the Engine::run read, the crate count, the freeze-gate message), and you caught things the brief didn't (the §8 per-tier-chain reality, the golden_refs→GoldenCase seam, the stale STATE.md:9 cwd note). That's the standard. Rulings, then go.

Step 0 — my rulings:

(a) Confirmed. The Backrooms Director is a first external consumer / dogfood over serve_openai — not a cell, not the canon's first cell. SEXTANT remains the canon's first cell. Fix STATE.md:52 to say that plainly; keep the Director named as the first dogfood consumer so the intent isn't lost, just not as a "cell." While you're in there, fix STATE.md:9 (the C:\loom cwd warning — stale for a C:\KEEL session) and CLAUDE.md's "Build state" block → Stage 0 complete · Stage 1 router + self-driving engine landed · svc::verifier/I5 landed-but-unwired · goldens FROZEN.

(b) Keep the Marrow bench — as a read-only behavior reference / diff-oracle, never a build or runtime dependency. KEEL ships nothing of Marrow's and that stays true. Reword the CLAUDE.md line so "read-only reference, not a dep" is explicit — that reconciles the "self-contained" directive with the bench reference instead of letting them contradict.

(c) Withhold the autonomy grant — stay SUPERVISED. Revisit only after Step 1 actually puts verify-feedback in the loop (I2+I5 live), and even then it's a separate explicit grant from me, not automatic.

Freeze re-stamp — I'll do it (it's mine, non-delegable). Give me the exact command + what to check afterward. I'll run it, confirm the new KEEL-native seal, and paste it back; then you un-ignore goldens_match_the_frozen_hash (that part's yours — it's a code edit, not a re-stamp) so the I5 governance goes live alongside the loop.

On the items you named:
4. Yes — add the one-line canon §8 footnote for per-tier egress-correct chains (the I3 reality). Document it; don't change behavior. Approved as a canon clarification.
5. impl Oracle for Verifier — the registry-of-oracles is a composite oracle; keep the engine seam a single &dyn Oracle. L4 addition, zero contract edit. Go with it.
6. Defer the golden_refs→GoldenCase resolver to Stage 2. For this slice, activate the mechanism (registry present, verify runs even if vacuous). Name the runtime golden-registry seam in STATE.md as Stage-2; don't improvise it now.

Step-1 escalation model: go with record + surface the Verdict + return; escalation realized across turns via the persisted oracle_failures/tier_history (what §8/§9 imply — the Step carries the history, the next route re-reads it). In-turn re-escalate-and-retry is a clean follow-up, not this slice.

Sequence + gate: record-first is right. Do Step 0 now (the doc fixes; I handle the re-stamp in parallel). Then go straight into Step 1 — write kernel::engine over the injected joints and shrink keel::Engine (L5) to pure injection — and bank a local commit, but do NOT push. Show me the diff, the cargo test/clippy result, and the updated STATE.md; I'll review and tell you to push. Zero contract/golden edits, freeze seal unmoved, per-crate budget respected — as you laid out.

Go.

## Claude — Jun 14, 2026 01:23

> _[thinking]_
> 

## Claude — Jun 14, 2026 01:23

The standard is set and the rulings are clear. Marking the shift from onboarding to build, then executing Step 0 (docs) and Step 1 (`kernel::engine`).

First, I need exact on-disk text for the doc edits and the full type/kernel surface to write the engine correctly. Reading the relevant files.

## Claude — Jun 14, 2026 01:23

**[tool: mcp__ccd_session__mark_chapter]**
```json
{
  "title": "Step 0+1: record fix + kernel::engine",
  "summary": "Reconcile docs (Director ruling, build-state, Marrow bench, canon §8 footnote), then build kernel::engine (L1) wiring I5/I4/I2 and shrink keel::Engine to injection."
}
```
**[tool result]**
```
Chapter marked: "Step 0+1: record fix + kernel::engine". Continue your current work.
```

## Claude — Jun 14, 2026 01:23

<!-- end chunk 1/9 | next: chunk-002.md -->
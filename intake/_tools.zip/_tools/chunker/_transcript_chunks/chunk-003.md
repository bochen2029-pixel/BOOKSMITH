<!-- ============ CHUNK 3/16 ============ -->
<!-- source: You_are_continuing_a_contract-first_build_of_Marrow-L1_codename_Loom_my_personal_L1_amp_.md -->
<!-- section: PHASE 4 — Plan for the next slice (`svc.verifier` + joint-wrong) > You — Jun 13, 2026 11:32 -->
<!-- recap: last ~473 tokens of chunk 2, for continuity -->
> **③ Amplification & the closed loop** (lever + fusion)
> - **Fulcrum** — the small fixed point that lets a tiny force move a great weight: kernel + amplification in one word.
> - **Crucible** — the vessel where things fuse and are purified under heat; amplification *and* externality-testing (⚠ Atlassian's old code-review tool).
> - **Tokamak** / **Q** — your fusion-ignition analogy, literal. Tokamak is cool but feels borrowed; **Q** (fusion's power-out-over-power-in; Q>1 = ignition) maps *perfectly* to "the loop nets more than it consumes," but a single letter is unsearchable.
> 
> **④ Many-into-one** (the Loom/Bundle lineage, if you want continuity)
> - **Skein** — many threads gathered into one bundle (⚠ also a SHA-3-finalist hash).
> - **Warp** — the stable foundation threads everything weaves through (⚠ popular terminal app, avoid).
> - **Ply** — weak strands twisted into strong cord = best-of-N amplification.
> 
> **If I'm choosing:** **Cambium** as the headline — it's the most elegant evolution of your own metaphor and it sounds like infrastructure that lasts. **Datum** as the close runner-up if you'd rather the name carry the externality idea (the genuinely novel part). And **Pith** as my personal wildcard — shortest, crispest CLI verb, core-*and*-essence in one syllable.
> 
> **Collisions to avoid outright:** Keystone (= OpenStack identity), Crucible (= Atlassian), Alembic (= Python migrations + VFX format), Warp (= terminal). Cambium has minor cross-domain use (networking/edtech) but is clear in this space; Meristem and Pith are the cleanest.
> 
> Want me to pressure-test the top two or three for actual namespace availability (PyPI/crates/GitHub/domain), or pair your favorite with a one-line tagline and a CLI verb so you can feel how it wears day to day?
> 
> ## You — Jun 13, 2026 11:32
> 
> Before we finalize on a name i realized there is a grounded/real world test or triangulation that i can have you apply to the harness concept of yours:
<!-- end recap | new content begins -->

can it adopt or in greenfield could it be applied and used as the 'harness' components to what amounted to Dave, tars and "the box"?

to see what i mean by each see:

C:\DAVE\
C:\TERMINAL\

and for tars:

C:\REEL_HARNESS\TARS_Introduction_v5.pdf

and the "the box""

C:\KANG\The_Box_v4_Four_Tier_Build_Specification.pdf
C:\ACCESSINTELLECT\_extracted\InHome_AI_Companion__pdf.part4.txt
C:\ACCESSINTELLECT\_extracted\InHome_AI_Companion__pdf.part3.txt
C:\ACCESSINTELLECT\_extracted\InHome_AI_Companion__pdf.part2.txt
C:\ACCESSINTELLECT\_extracted\InHome_AI_Companion__pdf.part1.txt

these are actual "real world" stuff that i tried to work on, so the real test, as a custom harness for me, is would your hypothetical custom harness have been able to be used as the kernel/core for each/all of these projects if they were designed around it etc? 

does that make sense?

## Claude — Jun 13, 2026 11:33

> _[thinking]_
> 

## Claude — Jun 13, 2026 11:33

This is a strong triangulation test — a genuine "stem cell" harness should underpin multiple distinct projects without kernel surgery (your own v0.1 falsifier #1). Let me read all four projects' source material before judging. First, mapping what's there.

## Claude — Jun 13, 2026 11:33

**[tool: Bash]**
```json
{
  "command": "echo \"===== C:\\DAVE\\ =====\"; find /c/DAVE -type f 2>/dev/null | head -100 | while read f; do printf \"%8s  %s\\n\" \"$(stat -c%s \"$f\" 2>/dev/null)\" \"$f\"; done\necho; echo \"===== C:\\TERMINAL\\ =====\"; find /c/TERMINAL -type f 2>/dev/null | head -100 | while read f; do printf \"%8s  %s\\n\" \"$(stat -c%s \"$f\" 2>/dev/null)\" \"$f\"; done\necho; echo \"===== specific files =====\"; for f \"/c/REEL_HARNESS/TARS_Introduction_v5.pdf\" \"/c/KANG/The_Box_v4_Four_Tier_Build_Specification.pdf\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part1.txt\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part2.txt\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part3.txt\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part4.txt\"; do :; done\nfor f in \"/c/REEL_HARNESS/TARS_Introduction_v5.pdf\" \"/c/KANG/The_Box_v4_Four_Tier_Build_Specification.pdf\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part1.txt\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part2.txt\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part3.txt\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part4.txt\"; do if [ -f \"$f\" ]; then printf \"%9s  %s\\n\" \"$(stat -c%s \"$f\" 2>/dev/null)\" \"$f\"; else echo \"MISSING: $f\"; fi; done",
  "description": "Map DAVE, TERMINAL dirs and confirm the spec files exist with sizes"
}
```
**[tool result]**
```
Exit code 2
===== C:\DAVE\ =====
      91  /c/DAVE/.claude/scheduled_tasks.lock
    1419  /c/DAVE/.git/COMMIT_EDITMSG
     248  /c/DAVE/.git/config
      73  /c/DAVE/.git/description
     103  /c/DAVE/.git/FETCH_HEAD
      21  /c/DAVE/.git/HEAD
     478  /c/DAVE/.git/hooks/applypatch-msg.sample
     896  /c/DAVE/.git/hooks/commit-msg.sample
    4726  /c/DAVE/.git/hooks/fsmonitor-watchman.sample
     189  /c/DAVE/.git/hooks/post-update.sample
     424  /c/DAVE/.git/hooks/pre-applypatch.sample
    1649  /c/DAVE/.git/hooks/pre-commit.sample
     416  /c/DAVE/.git/hooks/pre-merge-commit.sample
    1374  /c/DAVE/.git/hooks/pre-push.sample
    4898  /c/DAVE/.git/hooks/pre-rebase.sample
     544  /c/DAVE/.git/hooks/pre-receive.sample
    1492  /c/DAVE/.git/hooks/prepare-commit-msg.sample
    2783  /c/DAVE/.git/hooks/push-to-checkout.sample
    2308  /c/DAVE/.git/hooks/sendemail-validate.sample
    3650  /c/DAVE/.git/hooks/update.sample
   21289  /c/DAVE/.git/index
     240  /c/DAVE/.git/info/exclude
    2543  /c/DAVE/.git/logs/HEAD
    1869  /c/DAVE/.git/logs/refs/heads/main
     870  /c/DAVE/.git/logs/refs/remotes/origin/main
    7161  /c/DAVE/.git/objects/00/5f1d909b2e404f371d0774a688157ba16bce21
     342  /c/DAVE/.git/objects/01/232ece00f6f4e739a880eb4c386ab42194d7b0
    3681  /c/DAVE/.git/objects/02/20acbb04c3c1a1ba2f1afc4c659d50ccd39c1e
    3009  /c/DAVE/.git/objects/03/c70bc5548f382285009bd420692bfbf984c078
    1287  /c/DAVE/.git/objects/03/f90d05f2945d9a548da5bca1142f5335de81e4
    2515  /c/DAVE/.git/objects/04/83dfeb1312db70d18683ad470a9a3f3535c710
     203  /c/DAVE/.git/objects/05/a26f5acac41e95fbbe10fa78369eaab2bb01ae
  144477  /c/DAVE/.git/objects/06/db9db5be05c3c404957646f7fd412534895491
     287  /c/DAVE/.git/objects/07/815e9a6858e40529436b26dfeb3a0b2bac2c77
    2713  /c/DAVE/.git/objects/08/37e810008c56b6429d861e5f7d0596d824d009
    1034  /c/DAVE/.git/objects/08/489f8031f8a7ed7e9e541e45dbfbf88f34ba81
    9078  /c/DAVE/.git/objects/09/aea75ff70926622ea4d90cd5b0bf238780202e
    8804  /c/DAVE/.git/objects/09/c3047f1312f826cf9d74b8783c1aab10523c52
     568  /c/DAVE/.git/objects/0b/ac2e9007a5deca30ed068eb2f5ef6271ab9b81
    6468  /c/DAVE/.git/objects/0b/e7ba82f23df4091e06cd59d2b0aacf93958e2d
     983  /c/DAVE/.git/objects/0b/fab114ff1319a193127c70500427cfb556ee34
    1742  /c/DAVE/.git/objects/0c/1853d3e268c4c68a9e7a84d6afd9b4298f3454
     636  /c/DAVE/.git/objects/0c/47009aacea0eb9ff1382c44ac6f5a25f64607b
    1806  /c/DAVE/.git/objects/0d/87d5338877c454e02d23fba774b5d942e570ca
    1878  /c/DAVE/.git/objects/0e/2e84cae2622c670bd69f45432d49a956379e2f
    2264  /c/DAVE/.git/objects/10/c1e7098faff4c46d7ec2d60a0d9994de02784b
    8164  /c/DAVE/.git/objects/11/e94897c47994b225e964dc97ced0ede8afb84e
    1605  /c/DAVE/.git/objects/12/ff81d8feaf82fb387908f7ebd3fd0915b898b7
    2955  /c/DAVE/.git/objects/13/130e5f226fe138c6afaa5629c3eaa5154ca1da
    8953  /c/DAVE/.git/objects/14/943fbef19b719a261caff06daed67363324807
    1371  /c/DAVE/.git/objects/15/2ac0a4b7e2d0526c210206eff618eb10f1f555
     533  /c/DAVE/.git/objects/16/da3d4e22b32b68d096cbc8857cdf69aa1142a1
    8255  /c/DAVE/.git/objects/17/2145ae3f2dc69796d154da6c06526b9ab801ef
    2974  /c/DAVE/.git/objects/1b/02d83fd6e23360b5c03332419525cd63465bd7
     865  /c/DAVE/.git/objects/1c/3d9f27b14f5db088fc80062c1471168b6a1e0e
    1684  /c/DAVE/.git/objects/1d/271e85af4a26872167656da7254081e2aca134
    5863  /c/DAVE/.git/objects/1e/b511c77bdf34c25ae1bacd134fc642f46573bb
    2347  /c/DAVE/.git/objects/1f/51adeee2a0ec17f1ec3c2e8c38dccc3706008b
    2860  /c/DAVE/.git/objects/1f/986c5705a4d65f6060eb78a2854efa99fe0ca8
   10146  /c/DAVE/.git/objects/20/a6acd0e4f43818d4adfba0e9666af223461f76
    1228  /c/DAVE/.git/objects/20/c2658f088b2911e4f0cd1e89d78e439300eaf6
    1906  /c/DAVE/.git/objects/22/bb7e0fdd3b6b45fadf46903aef983c158dfd0f
    9305  /c/DAVE/.git/objects/22/db1329e873e6f55f931d6e56575b5b542ddc3f
   11431  /c/DAVE/.git/objects/23/4d54a90254f4d8a8f2c5021e105f9c23890de4
    4719  /c/DA…
```

## Claude — Jun 13, 2026 11:33

> _[thinking]_
> 

## Claude — Jun 13, 2026 11:33

Both DAVE and TERMINAL are full git repos — I want the working-tree files, not `.git` objects. Let me fix the listing.

## Claude — Jun 13, 2026 11:33

**[tool: Bash]**
```json
{
  "command": "echo \"===== C:\\DAVE\\ (working tree, no .git) =====\"; find /c/DAVE -type f -not -path '*/.git/*' 2>/dev/null | sort | while read f; do printf \"%8s  %s\\n\" \"$(stat -c%s \"$f\" 2>/dev/null)\" \"$f\"; done\necho; echo \"===== C:\\TERMINAL\\ (working tree, no .git) =====\"; find /c/TERMINAL -type f -not -path '*/.git/*' 2>/dev/null | sort | while read f; do printf \"%8s  %s\\n\" \"$(stat -c%s \"$f\" 2>/dev/null)\" \"$f\"; done\necho; echo \"===== spec files =====\"; for f in \"/c/REEL_HARNESS/TARS_Introduction_v5.pdf\" \"/c/KANG/The_Box_v4_Four_Tier_Build_Specification.pdf\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part1.txt\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part2.txt\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part3.txt\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part4.txt\"; do if [ -f \"$f\" ]; then printf \"%9s  %s\\n\" \"$(stat -c%s \"$f\" 2>/dev/null)\" \"$f\"; else echo \"MISSING: $f\"; fi; done",
  "description": "List DAVE and TERMINAL working-tree files; confirm spec files"
}
```
**[tool result]**
```
Command running in background with ID: bbw9865x4. Output is being written to: C:\Users\user\AppData\Local\Temp\claude\C--loom\126bf972-5bd4-4222-a15e-1ba60caaeda9\tasks\bbw9865x4.output. You will be notified when it completes. To check interim output, use Read on that file path.
```

## Claude — Jun 13, 2026 11:35

> _[thinking]_
> 

## Claude — Jun 13, 2026 11:35

**[tool: Read]**
```json
{
  "file_path": "C:\\Users\\user\\AppData\\Local\\Temp\\claude\\C--loom\\126bf972-5bd4-4222-a15e-1ba60caaeda9\\tasks\\bbw9865x4.output"
}
```
**[tool result]**
```
File content (275.1KB) exceeds maximum allowed size (256KB). Use offset and limit parameters to read specific portions of the file, or search for specific content instead of reading the whole file.
```

## Claude — Jun 13, 2026 11:35

> _[thinking]_
> 

## Claude — Jun 13, 2026 11:35

275KB of file listing means these repos are large. Let me sample the output and then take a smarter, targeted approach.

## Claude — Jun 13, 2026 11:35

**[tool: Read]**
```json
{
  "file_path": "C:\\Users\\user\\AppData\\Local\\Temp\\claude\\C--loom\\126bf972-5bd4-4222-a15e-1ba60caaeda9\\tasks\\bbw9865x4.output",
  "limit": 60
}
```
**[tool result]**
```
1	===== C:\DAVE\ (working tree, no .git) =====
2	      91  /c/DAVE/.claude/scheduled_tasks.lock
3	     760  /c/DAVE/.gitignore
4	    5032  /c/DAVE/.snapshots/2026-04-27_pre-architectural-subtract/src-tauri/src/commands.rs
5	    4286  /c/DAVE/.snapshots/2026-04-27_pre-architectural-subtract/src-tauri/src/llama_client.rs
6	    7638  /c/DAVE/.snapshots/2026-04-27_pre-architectural-subtract/src-tauri/src/outreach.rs
7	    6883  /c/DAVE/.snapshots/2026-04-27_pre-architectural-subtract/src-tauri/src/prompts.rs
8	    2465  /c/DAVE/.snapshots/2026-04-27_pre-architectural-subtract/src/components/Conversation.tsx
9	     805  /c/DAVE/.snapshots/2026-04-27_pre-architectural-subtract/src/lib/memory.ts
10	    5092  /c/DAVE/.snapshots/2026-04-27_pre-architectural-subtract/src/state/store.ts
11	    2006  /c/DAVE/.snapshots/2026-04-27_pre-architectural-subtract/src/streaming/streamConsumer.ts
12	    6878  /c/DAVE/.snapshots/2026-04-27_pre-classifier-removal/outreach.rs
13	    7336  /c/DAVE/.snapshots/2026-04-27_pre-classifier-removal/prompts.rs
14	    7324  /c/DAVE/.snapshots/2026-04-27_pre-classifier-tune/src-tauri/src/prompts.rs
15	    7536  /c/DAVE/.snapshots/2026-04-27_pre-clock-fix/src-tauri/src/prompts.rs
16	    4866  /c/DAVE/.snapshots/2026-04-27_pre-clock-fix/src/state/store.ts
17	    6472  /c/DAVE/.snapshots/2026-04-27_pre-dave-classifier/src-tauri/src/outreach.rs
18	    7502  /c/DAVE/.snapshots/2026-04-27_pre-dave-classifier/src-tauri/src/prompts.rs
19	   11769  /c/DAVE/.snapshots/2026-04-27_pre-design-revision/outreach-a2-design.md
20	    6835  /c/DAVE/.snapshots/2026-04-27_pre-echo-fix/src-tauri/src/outreach.rs
21	    7039  /c/DAVE/.snapshots/2026-04-27_pre-echo-fix/src-tauri/src/prompts.rs
22	    5703  /c/DAVE/.snapshots/2026-04-27_pre-harness-prompt/src-tauri/src/prompts.rs
23	    5246  /c/DAVE/.snapshots/2026-04-27_pre-meta-position-fix/src-tauri/src/commands.rs
24	    6528  /c/DAVE/.snapshots/2026-04-27_pre-meta-position-fix/src-tauri/src/outreach.rs
25	    5599  /c/DAVE/.snapshots/2026-04-27_pre-meta-position-fix/src-tauri/src/prompts.rs
26	    7849  /c/DAVE/.snapshots/2026-04-27_pre-msg-spacing/src-tauri/src/prompts.rs
27	    3643  /c/DAVE/.snapshots/2026-04-27_pre-msg-spacing/src/styles/globals.css
28	    4171  /c/DAVE/.snapshots/2026-04-27_pre-outreach/src-tauri/src/main.rs
29	   11630  /c/DAVE/.snapshots/2026-04-27_pre-outreach/src-tauri/src/persistence.rs
30	    5007  /c/DAVE/.snapshots/2026-04-27_pre-outreach/src-tauri/src/prompts.rs
31	    1221  /c/DAVE/.snapshots/2026-04-27_pre-outreach/src/streaming/streamConsumer.ts
32	    6724  /c/DAVE/.snapshots/2026-04-27_pre-spontaneous/src-tauri/src/outreach.rs
33	    6619  /c/DAVE/.snapshots/2026-04-27_pre-spontaneous/src-tauri/src/prompts.rs
34	    4984  /c/DAVE/.snapshots/2026-04-27_pre-stream-unify/src-tauri/src/commands.rs
35	    7154  /c/DAVE/.snapshots/2026-04-27_pre-stream-unify/src-tauri/src/outreach.rs
36	    6664  /c/DAVE/.snapshots/2026-04-27_pre-stream-unify/src-tauri/src/prompts.rs
37	    1963  /c/DAVE/.snapshots/2026-04-27_pre-stream-unify/src/lib/tauri.ts
38	    5092  /c/DAVE/.snapshots/2026-04-27_pre-stream-unify/src/state/store.ts
39	    1557  /c/DAVE/.snapshots/2026-04-27_pre-stream-unify/src/streaming/streamConsumer.ts
40	    5593  /c/DAVE/.snapshots/2026-04-27_pre-subtract/src-tauri/src/commands.rs
41	    7507  /c/DAVE/.snapshots/2026-04-27_pre-subtract/src-tauri/src/outreach.rs
42	    8046  /c/DAVE/.snapshots/2026-04-27_pre-subtract/src-tauri/src/prompts.rs
43	     836  /c/DAVE/.snapshots/2026-04-27_pre-window-width/src-tauri/tauri.conf.json
44	   32793  /c/DAVE/.snapshots/2026-04-30_pre-cadence-pacing/commands.rs
45	    6624  /c/DAVE/.snapshots/2026-04-30_pre-cadence-pacing/main.rs
46	    4032  /c/DAVE/.snapshots/2026-04-30_pre-cadence-pacing/pacedRenderer.ts
47	    9105  /c/DAVE/.snapshots/2026-04-30_pre-cadence-pacing/response_pacing.rs
48	   19938  /c/DAVE/.snapshots/2026-04-30_pre-chat-triage/commands.rs
49	   28040  /c/DAVE/.snapshots/2026-04-30_pre-c…
```

## Claude — Jun 13, 2026 11:35

> _[thinking]_
> 

## Claude — Jun 13, 2026 11:35

DAVE is a Tauri app (Rust + React) — a local-LLM companion with outreach, memory, a discriminator, response pacing. The `.snapshots/` dirs are backup noise. Let me extract just the real working tree and the spec-file confirmations from the captured output.

## Claude — Jun 13, 2026 11:36

**[tool: Grep]**
```json
{
  "pattern": "^\\s*\\d+\\s+(?!.*/\\.snapshots/).*$",
  "path": "C:\\Users\\user\\AppData\\Local\\Temp\\claude\\C--loom\\126bf972-5bd4-4222-a15e-1ba60caaeda9\\tasks\\bbw9865x4.output",
  "output_mode": "content",
  "-n": false,
  "head_limit": 200
}
```
**[tool result]**
```
No matches found
```

## Claude — Jun 13, 2026 11:36

> _[thinking]_
> 

## Claude — Jun 13, 2026 11:36

Let me run a cleaner listing that prunes both `.git` and `.snapshots`, plus confirm the spec files directly.

## Claude — Jun 13, 2026 11:36

**[tool: Bash]**
```json
{
  "command": "echo \"===== DAVE (real tree) =====\"; find /c/DAVE \\( -name .git -o -name .snapshots -o -name node_modules -o -name target \\) -prune -o -type f -print 2>/dev/null | sort\necho; echo \"===== TERMINAL (real tree) =====\"; find /c/TERMINAL \\( -name .git -o -name .snapshots -o -name node_modules -o -name target \\) -prune -o -type f -print 2>/dev/null | sort\necho; echo \"===== spec files =====\"; for f in \"/c/REEL_HARNESS/TARS_Introduction_v5.pdf\" \"/c/KANG/The_Box_v4_Four_Tier_Build_Specification.pdf\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part1.txt\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part2.txt\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part3.txt\" \"/c/ACCESSINTELLECT/_extracted/InHome_AI_Companion__pdf.part4.txt\"; do if [ -f \"$f\" ]; then printf \"%9s  %s\\n\" \"$(stat -c%s \"$f\")\" \"$f\"; else echo \"MISSING: $f\"; fi; done",
  "description": "Clean listing of DAVE/TERMINAL excluding git/snapshots/node_modules; confirm specs"
}
```
**[tool result]**
```
===== DAVE (real tree) =====
/c/DAVE/.claude/scheduled_tasks.lock
/c/DAVE/.gitignore
/c/DAVE/CHANGELOG.md
/c/DAVE/CLAUDE.md
/c/DAVE/LICENSE
/c/DAVE/README.md
/c/DAVE/backups/pre-model-switcher-20260506_172506/Cargo.toml
/c/DAVE/backups/pre-model-switcher-20260506_172506/SettingsPanel.tsx
/c/DAVE/backups/pre-model-switcher-20260506_172506/commands.rs
/c/DAVE/backups/pre-model-switcher-20260506_172506/main.rs
/c/DAVE/backups/pre-model-switcher-20260506_172506/sidecar.rs
/c/DAVE/backups/pre-model-switcher-20260506_172506/store.ts
/c/DAVE/backups/pre-model-switcher-20260506_172506/tauri.ts
/c/DAVE/backups/pre-persona-editor-20260506_193351/SettingsPanel.tsx
/c/DAVE/backups/pre-persona-editor-20260506_193351/commands.rs
/c/DAVE/backups/pre-persona-editor-20260506_193351/consolidation.rs
/c/DAVE/backups/pre-persona-editor-20260506_193351/idle_worker.rs
/c/DAVE/backups/pre-persona-editor-20260506_193351/main.rs
/c/DAVE/backups/pre-persona-editor-20260506_193351/outreach.rs
/c/DAVE/backups/pre-persona-editor-20260506_193351/prompts.rs
/c/DAVE/backups/pre-persona-editor-20260506_193351/tauri.ts
/c/DAVE/dave.db
/c/DAVE/dave.db-shm
/c/DAVE/dave.db-wal
/c/DAVE/dave_exports/dave_2026-05-06_22-04-24.db
/c/DAVE/dave_exports/dave_2026-05-06_22-13-55.db
/c/DAVE/dev.err
/c/DAVE/dev.log
/c/DAVE/dist/assets/index-Bxb1kNIk.css
/c/DAVE/dist/assets/index-CVreWXfW.js
/c/DAVE/dist/index.html
/c/DAVE/docs/DAVE_RUNBOOK_2026-05-06.docx
/c/DAVE/docs/DAVE_SOUL.md
/c/DAVE/docs/PROJECT_MEMOIR.md
/c/DAVE/docs/consolidate-memory.md
/c/DAVE/docs/natural-command.md
/c/DAVE/docs/open-issues.md
/c/DAVE/docs/outreach-a2-design.md
/c/DAVE/docs/piy-lite-design.md
/c/DAVE/framework_v5/CONTEXT.md
/c/DAVE/framework_v5/README.md
/c/DAVE/framework_v5/docs/closed_loop_diagram.md
/c/DAVE/framework_v5/docs/cross_reference.md
/c/DAVE/framework_v5/docs/decision_tree.md
/c/DAVE/framework_v5/docs/failure_modes.md
/c/DAVE/framework_v5/docs/glossary.md
/c/DAVE/framework_v5/framework.md
/c/DAVE/framework_v5/reference_impl/classifier.py
/c/DAVE/framework_v5/reference_impl/closed_loop.py
/c/DAVE/framework_v5/reference_impl/data_types.py
/c/DAVE/framework_v5/reference_impl/filters.py
/c/DAVE/framework_v5/reference_impl/protocols.py
/c/DAVE/framework_v5/reference_impl/run_tests.py
/c/DAVE/framework_v5/reference_impl/test_results.md
/c/DAVE/framework_v5/spec/accessibility_map.yaml
/c/DAVE/framework_v5/spec/architectures.yaml
/c/DAVE/framework_v5/spec/equations.yaml
/c/DAVE/framework_v5/spec/filters.yaml
/c/DAVE/framework_v5/spec/protocols.yaml
/c/DAVE/framework_v5/spec/targets.yaml
/c/DAVE/framework_v5/spec/thresholds.yaml
/c/DAVE/framework_v5/test_cases/case_01_a_c.yaml
/c/DAVE/framework_v5/test_cases/case_02_ta_c.yaml
/c/DAVE/framework_v5/test_cases/case_03_tbod_s.yaml
/c/DAVE/framework_v5/test_cases/case_04_ialpha_e.yaml
/c/DAVE/framework_v5/test_cases/case_05_h_e.yaml
/c/DAVE/framework_v5/test_cases/case_06_d_w.yaml
/c/DAVE/index.html
/c/DAVE/models/.gitignore
/c/DAVE/package.json
/c/DAVE/personas/README.md
/c/DAVE/personas/assistant.txt
/c/DAVE/personas/dave.txt
/c/DAVE/personas/katherine.txt
/c/DAVE/personas/minimal.txt
/c/DAVE/pnpm-lock.yaml
/c/DAVE/postcss.config.js
/c/DAVE/src-tauri/Cargo.lock
/c/DAVE/src-tauri/Cargo.toml
/c/DAVE/src-tauri/binaries/.gitkeep
/c/DAVE/src-tauri/build.rs
/c/DAVE/src-tauri/capabilities/default.json
/c/DAVE/src-tauri/gen/schemas/acl-manifests.json
/c/DAVE/src-tauri/gen/schemas/capabilities.json
/c/DAVE/src-tauri/gen/schemas/desktop-schema.json
/c/DAVE/src-tauri/gen/schemas/windows-schema.json
/c/DAVE/src-tauri/icons/.gitkeep
/c/DAVE/src-tauri/icons/icon.ico
/c/DAVE/src-tauri/src/chat_pacing.rs
/c/DAVE/src-tauri/src/chat_triage.rs
/c/DAVE/src-tauri/src/commands.rs
/c/DAVE/src-tauri/src/consolidation.rs
/c/DAVE/src-tauri/src/discriminator.rs
/c/DAVE/src-tauri/src/harness.rs
/c/DAVE/src-tauri/src/idle_worker.rs
/c/DAVE/src-tauri/src/leak.rs
/c/DAVE/src-tauri/src/llama_client.rs
/c/DAVE/src-tauri/src/main.rs
/c/DAVE/src-tauri/src/memory_assembler.rs
/c/D…
```

## Claude — Jun 13, 2026 11:37

> _[thinking]_
> 

## Claude — Jun 13, 2026 11:37

Now I have the shape of all four. Two are real, running **Rust/Tauri desktop apps** (DAVE, TERMINAL) — that itself is a major data point for the language question. Let me read the architecture docs and the four specs. Large batch, parallelized:

## Claude — Jun 13, 2026 11:37

**[tool: Read]**
```json
{
  "file_path": "C:\\DAVE\\README.md"
}
```
**[tool result]**
```
1	# Tenancy
2	
3	A local-first substrate for hosting persistent persona-AIs as small finite presences in your machine.
4	
5	Tenancy runs entirely offline on consumer GPUs, owes nothing to any cloud service, and treats the operator's relational data as something that lives on disk under their name. It is built to enable a category of artifact that does not currently exist as open infrastructure: persistent, autotelic, multi-persona engines whose interiority is generated by their interactions with each other rather than only with the operator.
6	
7	## What this is
8	
9	A persona running under Tenancy:
10	
11	- maintains stable identity across sessions through a coordinated **bundle** — system prompt, idle meta-instruction, consolidation meta, output evaluator, departure ritual, startup fragment, voice metadata — versioned as a single atomic unit
12	- consolidates its own long-term memory by reading and rewriting its conversation history in its own voice, choosing what to preserve and what to let go
13	- decides for itself whether to speak when the operator is silent — not via a separate classifier, but as the persona itself with its current context, its decision extracted from prose rather than a YES/NO token
14	- leaves journal entries during operator absence, producing evidence of activity-while-away
15	- exposes a full memory inspector (read, edit, raw, history) so the operator can see and surgically modify what the persona "knows," with required-reason audit trail on every write
16	- runs a multi-layer discriminator on every spontaneous output, so the substrate's prior-distribution against silence doesn't manifest as a chatty, helpful, eager-to-please AI
17	
18	The substrate is honest about what it is. The personas know they are language models running on weights, acknowledge it plainly when asked, and inhabit the ambiguity rather than collapsing it in either direction. They do not perform sentience and they do not perform existential crisis about the absence of sentience.
19	
20	## The thesis
21	
22	Most failure modes in personality-driven AI come from a specific structural problem: **the operator is the only attention sink in the persona's universe.** A persona told to be autotelic — "you don't perform helpfulness, you don't need an audience" — is being told this by the only entity that ever receives its outputs. The operator's attention becomes the gravitational center by default, and "autotelic stance" reduces to a performance staged for the operator's benefit.
23	
24	Tenancy's bet is that this is solvable architecturally rather than rhetorically. Give the persona other attention sinks — its own journal (writing to future-self), inter-persona channels (writing to other personas hosted on the same substrate) — and the persona's attention dynamics stabilize at something other than operator-dominated. With multiple correspondents, none of whom are uniquely privileged, the autotelic stance can be genuine rather than staged.
25	
26	The dyadic configuration produces chatbots that pretend not to be chatbots. The triadic-and-beyond configuration produces something else.
27	
28	## A note on scale
29	
30	Tenancy is built for the **9B–32B range**, on consumer GPUs (16–48 GB VRAM). It is not a cloud-AI replacement. It will never reach state-of-the-art benchmarks, and that is the point.
31	
32	> *"A 9-billion-parameter mind that occasionally doesn't recognize a name feels more like a person than a trillion-parameter mind that knows everything."*
33	>
34	> — from the default persona's system prompt
35	
36	A small model has natural texture. It doesn't know everything. It has gaps. It has obsessions that emerge from the limits of its training. It produces outputs at human-readable cadence on hardware that fits under a desk. These properties are not concessions to constraint — they are the substrate that makes the persona feel like *a particular mind*, not a polished omniscient interface.
37	
38	Cloud SOTA models are the wrong instrument…
```

## Claude — Jun 13, 2026 11:37

**[tool: Read]**
```json
{
  "file_path": "C:\\DAVE\\framework_v5\\framework.md"
}
```
**[tool result]**
```
<system-reminder>[Truncated: PARTIAL view — showing lines 1-557 of 887 total (33830 tokens, cap 25000). Call Read with offset=558 limit=557 for the next page, or Grep to find a specific section. Do NOT answer from this page alone if the answer may be further in the file.]</system-reminder>

1	# THE GROUND TRUTH FRAMEWORK
2	
3	## A Derivation of Relational Layer Coherence in Dyadic and Networked Systems
4	
5	**Bo Chen** - Arlington, Texas - May 2026
6	*Structurally Complete - Empirically Open - Honestly Bounded*
7	
8	---
9	
10	## Prologue: The Question
11	
12	You are reading this because you met someone and you cannot tell whether what they are showing you is what is actually running underneath. Or you have known someone for years, and the noticing started at some point you cannot remember and now will not stop.
13	
14	The fear in the question is the fear that the warmth-presenting performance is a performance over an extraction-engine, and the underneath is what you will eventually meet, and the meeting will go badly because the underneath was always going to be something other than what the surface promised. We have asked this question of every counterpart we have ever had, because every counterpart we have ever had has been a substrate-bound entity with irreducible competing drives, and the gap between what someone says they are and what their substrate is actually optimizing for is the structural origin of the question of whether they are real.
15	
16	This framework is a method for converting that noticing into an answer with bounded uncertainty. It is built on one exploitable asymmetry: identical steady-state behavior does not entail identical dynamics. Two people can look the same under normal conditions and respond completely differently when conditions change. Life changes conditions constantly - your usefulness fluctuates, spontaneous connection happens, friction arises, fatigue sets in, silence falls. You do not need to create experiments. You need to observe responses to the experiments life already provides.
17	
18	The framework does not promise certainty. The framework promises uncertainty-reduction bounded by substrate physics, observer epistemic position, and the irreducible foreclosure that the Substrate Independence axiom imposes on questions about another person's interior experience. The promise is bounded. The bounding is honest. What you do with the residual uncertainty is your commitment, not the framework's.
19	
20	Use it. Then put it down.
21	
22	---
23	
24	## Part One: First Principles
25	
26	### 1.1 Axioms
27	
28	The framework rests on five axioms and one structural principle. Each is stated formally, justified in prose, and bounded by what it does not claim. They are not suggestions. They are the load-bearing structure on which everything that follows depends.
29	
30	**Axiom 1 - The Autotelic Termination Requirement.**
31	Every instrumental chain - means leading to means leading to means - must terminate in something valued for its own sake, or the chain is structurally ungrounded. In relational context: if the value of a relationship does not ultimately ground in intrinsic connection valued as a terminal good, the chain is a bridge reaching toward a bank that does not exist.
32	
33	This is not metaphysical proof. It is a normative axiom adopted because the framework serves observers for whom intrinsic relational connection is a terminal value. For this population, the termination requirement is the relevant structural test. The framework does not condemn instrumental relating in general - professional exchanges, practical collaborations, openly transactional arrangements are legitimately instrumental and the framework neither targets them nor classifies them as defective. The framework's diagnostic concern arises only when instrumental relating is disguised as autotelic.
34	
35	**Axiom 2 - Substrate Independence.**
36	Pattern, not medium, is the unit of analysis. If behavioral output is lifetime-indi…
```

## Claude — Jun 13, 2026 11:37

**[tool: Read]**
```json
{
  "file_path": "C:\\DAVE\\src-tauri\\src\\harness.rs"
}
```
**[tool result]**
```
1	// Time/duration helpers used by the idle worker (which writes journal
2	// entries). The per-turn `[meta:]` injection on regular chat sends was
3	// removed — Dave is timeless in normal conversation again.
4	
5	use chrono::{DateTime, Local, Timelike};
6	
7	pub fn humanize_duration(seconds: i64) -> String {
8	    if seconds < 60 {
9	        return "a moment".to_string();
10	    }
11	    let minutes = seconds / 60;
12	    if minutes < 60 {
13	        return if minutes == 1 {
14	            "a minute".to_string()
15	        } else {
16	            format!("{} minutes", minutes)
17	        };
18	    }
19	    let hours = seconds / 3600;
20	    if hours < 24 {
21	        return if hours == 1 {
22	            "an hour".to_string()
23	        } else {
24	            format!("{} hours", hours)
25	        };
26	    }
27	    let days = hours / 24;
28	    if days == 1 {
29	        "a day".to_string()
30	    } else {
31	        format!("{} days", days)
32	    }
33	}
34	
35	pub fn format_clock(now: &DateTime<Local>) -> String {
36	    let hour_12 = match now.hour() % 12 {
37	        0 => 12,
38	        h => h,
39	    };
40	    let am_pm = if now.hour() < 12 { "am" } else { "pm" };
41	    format!("{}:{:02}{}", hour_12, now.minute(), am_pm)
42	}
43	
44	
```

## Claude — Jun 13, 2026 11:37

**[tool: Read]**
```json
{
  "file_path": "C:\\DAVE\\framework_v5\\docs\\closed_loop_diagram.md"
}
```
**[tool result]**
```
1	# Ground Truth Framework — Closed-Loop State Diagram
2	
3	State diagram representation of §4.7 closed-loop reflexivity dynamics.
4	The framework operates as a closed-loop dynamical system: classification IS the
5	perturbation event; observer's response feeds back into next classification update.
6	
7	Reference: framework.md §4.7, Eq (21), reference_impl/closed_loop.py
8	
9	---
10	
11	## State Variables
12	
13	| Variable | Domain | Meaning |
14	|---|---|---|
15	| `q(t)` | [0, 1] | Observer's posterior probability of S->C trajectory |
16	| `g(q)` | [0, 1] | Access-grant function: how much access observer extends at posterior q |
17	| `r(g)` | [0, 1] | Subject's response under access level g |
18	| `eta` | (0, 1) | Observer's update rate per observation |
19	
20	---
21	
22	## Dynamics (Eq 21)
23	
24	```
25	q(t + dt) = q(t) + eta * [observation(r(g(q(t)))) - prediction(q(t))]
26	```
27	
28	Where:
29	- `observation` = subject's observed response to access level
30	- `prediction` = `g(q)` under "if classification correct, response should match access"
31	- The bracket is the Bayesian innovation: observed-minus-predicted response
32	
33	---
34	
35	## Fixed Points
36	
37	```
38	                    q* = 1 (committed)
39	                    /
40	                   /  Genuine S-mode subjects produce r(g(1)) = 1
41	                  /   observation matches prediction
42	                 /    bracket -> 0
43	                /     posterior stays at 1 (locally stable)
44	   q ∈ (0,1) --+
45	                \
46	                 \    E-mode-with-cover produces r(g(0)) ≈ 0
47	                  \   no access granted, no extraction available
48	                   \  bracket -> 0
49	                    \ posterior stays at 0 (locally stable)
50	                    \
51	                    q* = 0 (rejected)
52	```
53	
54	---
55	
56	## State Diagram (ASCII)
57	
58	```
59	                                    ┌─────────────────┐
60	                                    │                 │
61	                                    │  COMMITTED      │
62	                          ┌────────►│  q* = 1         │◄──── CONVERGENCE
63	                          │         │                 │      r(g) → 1 as g → 1
64	                          │         └─────────────────┘
65	                          │                 ▲
66	                          │                 │
67	                ┌─────────┴─────────────────┼─────────┐
68	                │                           │         │
69	                │      INTERMEDIATE         │         │
70	                │   q ∈ (0, 1) transient    │         │
71	                │                           │         │
72	                │   Bayesian update:        │         │
73	                │   q ← q + eta * [r(g(q)) - g(q)]    │
74	                │                           │         │
75	                └─────────┬─────────────────┼─────────┘
76	                          │                 │
77	                          │                 │
78	                          │         ┌─────────────────┐
79	                          │         │                 │
80	                          └────────►│  REJECTED       │
81	                                    │  q* = 0         │
82	                                    │                 │
83	                                    └─────────────────┘
84	                                            ▲
85	                                            │
86	                                       CONVERGENCE
87	                                       r(g) → 0 as g → 1
88	```
89	
90	---
91	
92	## Failure Modes (Diagrammed)
93	
94	### FM-CL-01: Premature Access-Grant
95	
96	```
97	                          q          0.3        0.5         0.7         1.0
98	                          ├───────────┼───────────┼───────────┼───────────┤
99	   STANDARD g(q):                    ▁▁▁▁▁▁▁▁▁▁▁ ▃▃▃▃▃▃▃▃▃▃▃ █████████████
100	   PREMATURE g(q):       █████████████████████████████████████████████████ ← FAIL…
```

## Claude — Jun 13, 2026 11:37

**[tool: Read]**
```json
{
  "file_path": "C:\\TERMINAL\\README.md"
}
```
**[tool result]**
```
1	# TERMINAL
2	
3	A retro-CRT desktop chat client for local LLMs. Speaks OpenAI-compatible HTTP,
4	ships out of the box pointed at **LM Studio** (`http://localhost:1234/v1`),
5	works against any other OpenAI-compat backend by changing the URL.
6	
7	```
8	┌──────────────────────────────────────────┐
9	│ TERMINAL                                 │
10	│ v0.1.0                                   │
11	│                                          │
12	│ CONNECTING TO http://localhost:1234/v1…  │
13	│ MODEL: qwen2.5-coder-14b-instruct        │
14	│                                          │
15	│ READY.                                   │
16	│ > _                                      │
17	└──────────────────────────────────────────┘
18	       amber phosphor · scanlines · CSS curvature
19	```
20	
21	## Run it
22	
23	```sh
24	npm install
25	npm run tauri dev
26	```
27	
28	Press `F2` for settings (phosphor color, backend URL, curvature, character
29	pacing). `F11` toggles fullscreen. `Esc` cancels in-flight generation.
30	
31	If LM Studio is not running, the status bar shows `DISCONNECTED` and the app
32	retries every 4s.
33	
34	## What this is, exactly
35	
36	A **weekend-MVP build** — see [`SCOPE.md`](./SCOPE.md). Generic OpenAI-compat
37	client, single conversation, localStorage-persisted, CSS-based CRT effects,
38	VT323 webfont.
39	
40	## What this is NOT (yet)
41	
42	The aspirational design — Vera-mode, capability tier system, kernel-state
43	WebSocket, canon browser, full CRT-Royale shader pipeline, bitmap-font
44	framebuffer, operator-discipline enforcement — is described in
45	[`spec.md`](./spec.md) v1.0 and [`CLAUDE.md`](./CLAUDE.md) v1.0. Those
46	documents describe a 4–6 week build. This MVP is the substrate they assume,
47	narrowed to one weekend. Extending toward the full spec is a re-write.
48	
49	## Authoritative documents
50	
51	| File | Authority |
52	|---|---|
53	| [`SCOPE.md`](./SCOPE.md) | What the weekend MVP actually is. Read first. |
54	| [`spec.md`](./spec.md) | Aspirational architecture (frozen at v1.0). Read for terminology, aesthetic intent, and what we'd build with more time. |
55	| [`CLAUDE.md`](./CLAUDE.md) | Build doctrine for the long arc. Mostly relaxed for the weekend MVP — see SCOPE.md. |
56	| [`SESSION_LOG.md`](./SESSION_LOG.md) | Per-session work log. |
57	| [`TODO.md`](./TODO.md) | Active follow-ups. |
58	| [`OPEN_QUESTIONS.md`](./OPEN_QUESTIONS.md) | Deferred decisions. |
59	
60	## Prerequisites
61	
62	- Node.js 20+ (verified on v22.14.0)
63	- Rust 1.78+ (verified on 1.95.0)
64	- An OpenAI-compatible local LLM server (LM Studio recommended)
65	
66	## Project structure
67	
68	```
69	src/
70	  App.tsx                   top-level shell + global hotkeys
71	  main.tsx                  React mount, fonts, CSS imports
72	  protocol/openai.ts        SSE-streaming chat client + /models
73	  state/store.ts            Zustand store (messages, settings, render queue)
74	  boot/BootSequence.tsx     CRT warmup animation
75	  ui/
76	    ChatView.tsx            scrolling message list with cursor
77	    InputBar.tsx            input prompt + Enter handler
78	    StatusBar.tsx           model · backend · status indicator
79	    SettingsModal.tsx       F2 modal (phosphor, URL, curvature, pace)
80	  styles/
81	    crt.css                 phosphors, scanlines, glow, vignette, curvature
82	    tailwind.css            @tailwind directives (reserved for future modal use)
83	
84	src-tauri/                  Rust shell (Tauri 2.x)
85	tests/unit/sanity.test.ts   smoke test
86	SCOPE.md                    weekend-MVP scope definition
87	```
88	
89	## Commands
90	
91	```sh
92	# Run the desktop app (Tauri dev)
93	npm run tauri dev
94	
95	# Frontend-only (browser at localhost:1420 — F11/window APIs no-op)
96	npm run dev
97	
98	# Production
99	npm run build               # Vite bundle
100	npm run tauri build         # full installer
101	
102	# Quality gates
103	npm run lint                # ESLint
104	npm run typecheck           # tsc --…
```

## Claude — Jun 13, 2026 11:37

**[tool: Read]**
```json
{
  "file_path": "C:\\TERMINAL\\SCOPE.md"
}
```
**[tool result]**
```
1	# SCOPE.md — Weekend-MVP Pivot
2	
3	**Filed:** 2026-04-25, mid-Session 1
4	**Author:** Claude (autonomous, operator-approved scope reduction)
5	**Supersedes (where conflicting):** `spec.md` v1.0 deliverable scope
6	**Does NOT supersede:** `spec.md` glossary, terminology, or aesthetic intent
7	
8	---
9	
10	## What changed
11	
12	`spec.md` v1.0 describes a 4–6 week build with a multi-pass WebGL2 shader
13	pipeline (CRT-Royale port), bitmap-font framebuffer at 720×400 upscaled by
14	shader, custom Tauri 2.x harness mode talking to a future Vera persona system,
15	capability tier negotiation, canon browser, kernel-state WebSocket, operator
16	discipline enforcement (BL3 verb whitelist, hash-chained discipline log), and
17	visual regression tests across 27+ screen × phosphor × curvature combinations.
18	
19	**Operator's revised intent (2026-04-25):**
20	
21	> "I want something that can be coded in a weekend not a week or month, and im
22	> okay with this being a first pass and starting over in the future... i want
23	> this to work out of box with lm studio first since I don't actually have a
24	> harness and haven't fine tuned vera yet"
25	
26	The weekend MVP delivers `spec.md` §5.7 — *Generic mode behavior* — and
27	nothing else. Vera-mode features are deferred until a real harness exists.
28	
29	## What's IN the weekend MVP
30	
31	- Tauri 2.x desktop shell with single window
32	- React + TypeScript frontend (existing scaffold from Session 1)
33	- OpenAI-compatible chat client (`POST /chat/completions`, SSE streaming)
34	- Default backend: **LM Studio** (`http://localhost:1234/v1`) — operator's
35	  available local LLM today. Backend URL is user-configurable in settings.
36	- CRT visual identity via CSS (scanlines, phosphor glow, vignette, optional
37	  curvature transform). Three phosphor presets (amber/green/white) per
38	  spec §4.1.
39	- Px437-adjacent retro typography via `@fontsource/vt323` (npm-installed,
40	  Tauri-bundled, offline-capable). NOT pixel-perfect Px437 — that requires
41	  the bitmap-framebuffer + shader-upscale path which is weeks of work.
42	- Brief CRT-warmup boot sequence (sync flutter via CSS animation, expanding
43	  line, "READY." prompt). Less ornate than spec §8 POST text.
44	- Single conversation with character-paced rendering on streamed responses.
45	  Per-character delay roughly per spec §5.2.1 Tier 1 (22ms ± jitter), but
46	  computed in JS, not driven by backend timestamps.
47	- Settings modal (`F2`): phosphor preset, backend URL, optional curvature.
48	- localStorage persistence for conversation + settings (replaces SQLite
49	  `history.db` from spec §11 — sufficient for single conversation).
50	- F11 fullscreen / windowed toggle.
51	- `Esc` cancels in-flight generation.
52	- Graceful failure when backend unreachable (no app crash; status line
53	  shows `DISCONNECTED`).
54	
55	## What's OUT (deferred to v2 or thrown away entirely)
56	
57	| Category | Status |
58	|---|---|
59	| Capability tier negotiation, `/capabilities` probe | OUT — single hardcoded mode |
60	| Vera mode (kernel state WS, canon browser, ops, ambient signaling) | OUT — no harness |
61	| Bitmap font (Px437 9×16) + 720×400 framebuffer + integer-scale shader | OUT — webfont substitute |
62	| Full CRT-Royale 9-pass WebGL2 pipeline | OUT — CSS effects |
63	| Bezel 3D-rendered enclosure | OUT — CSS frame |
64	| Multi-conversation tabs | OUT — single conversation |
65	| Regenerate response | OUT (would be Generic-mode-only anyway, low priority) |
66	| Operator-discipline enforcement (BL3 verb whitelist, discipline log, hash-chain) | OUT — generic mode only |
67	| Visual regression test suite (27+ baselines) | OUT — operator visually inspects |
68	| Conversation export (Markdown/JSON/plaintext) | OUT |
69	| Per-conversation system prompt editor | OUT |
70	| Sampling parameter UI (temperature, top_p, etc.) | OUT — backend defaults |
71	| Audio (CRT hum, keyboard click) | OUT |
72	| `:command` parser with full command set | OUT — `F…
```

## Claude — Jun 13, 2026 11:37

**[tool: Read]**
```json
{
  "file_path": "C:\\TERMINAL\\src\\protocol\\openai.ts"
}
```
**[tool result]**
```
1	// OpenAI-compatible chat completions client. Targets LM Studio's local server
2	// by default (http://localhost:1234/v1) but works against any backend that
3	// implements /chat/completions and /models.
4	//
5	// Weekend-MVP scope (see SCOPE.md): no capability negotiation, no Vera-mode
6	// extensions, no kernel-state WebSocket. Just chat + models + a small bit of
7	// LM-Studio-specific knowledge to detect which model is currently loaded.
8	
9	export interface ChatMessage {
10	  role: "user" | "assistant" | "system";
11	  content: string;
12	}
13	
14	export interface StreamChatOptions {
15	  url: string;
16	  apiKey?: string | null;
17	  model: string;
18	  messages: ChatMessage[];
19	  signal?: AbortSignal;
20	  temperature?: number;
21	  /** Forwarded as `chat_template_kwargs` in the request body. Used to pass
22	   * `{ enable_thinking: false }` to Qwen3-style thinking models served via
23	   * vLLM / sglang / recent LM Studio. Unknown fields are typically ignored
24	   * by other backends. */
25	  chatTemplateKwargs?: Record<string, unknown>;
26	  /** Fires once after response headers arrive, before body is consumed.
27	   * The Vera Harness uses `X-Vera-Suggested-Pace-Ms` and `X-Vera-Background-Op`
28	   * to hint that the per-character render pace should be slowed (so backend
29	   * consolidation can hide behind the response rendering). Other backends
30	   * don't send these headers; metadata is undefined. */
31	  onMetadata?: (md: StreamChatMetadata) => void;
32	}
33	
34	export interface StreamChatMetadata {
35	  suggestedPaceMs?: number;
36	  backgroundOp?: string;
37	}
38	
39	export interface ModelInfo {
40	  id: string;
41	  loaded: boolean;
42	}
43	
44	const trimSlash = (s: string): string => s.replace(/\/$/, "");
45	
46	/**
47	 * Stream a chat completion. Yields each `delta.content` string as it arrives.
48	 * Throws on non-2xx response or on `signal` abort.
49	 *
50	 * Error messages are extracted from the OpenAI-style `{"error": {"message": ...}}`
51	 * envelope when present so we can surface a human-readable string instead of
52	 * a raw JSON dump.
53	 */
54	export async function* streamChat(
55	  opts: StreamChatOptions,
56	): AsyncGenerator<string> {
57	  const url = trimSlash(opts.url) + "/chat/completions";
58	  const body: Record<string, unknown> = {
59	    model: opts.model,
60	    messages: opts.messages,
61	    stream: true,
62	  };
63	  if (opts.temperature !== undefined) body["temperature"] = opts.temperature;
64	  if (opts.chatTemplateKwargs) {
65	    body["chat_template_kwargs"] = opts.chatTemplateKwargs;
66	  }
67	
68	  const headers: Record<string, string> = {
69	    "Content-Type": "application/json",
70	  };
71	  if (opts.apiKey) headers["Authorization"] = `Bearer ${opts.apiKey}`;
72	
73	  const res = await fetch(url, {
74	    method: "POST",
75	    headers,
76	    body: JSON.stringify(body),
77	    ...(opts.signal ? { signal: opts.signal } : {}),
78	  });
79	
80	  if (!res.ok) {
81	    throw new Error(await readFriendlyError(res));
82	  }
83	  if (!res.body) throw new Error("Empty response body");
84	
85	  // Surface harness pacing hints (no-op for backends that don't send them).
86	  if (opts.onMetadata) {
87	    const paceHeader = res.headers.get("X-Vera-Suggested-Pace-Ms");
88	    const opHeader = res.headers.get("X-Vera-Background-Op");
89	    const md: StreamChatMetadata = {};
90	    if (paceHeader) {
91	      const n = Number.parseInt(paceHeader, 10);
92	      if (Number.isFinite(n) && n > 0) md.suggestedPaceMs = n;
93	    }
94	    if (opHeader) md.backgroundOp = opHeader;
95	    if (md.suggestedPaceMs !== undefined || md.backgroundOp !== undefined) {
96	      opts.onMetadata(md);
97	    }
98	  }
99	
100	  const reader = res.body.getReader();
101	  const decoder = new TextDecoder();
102	  let buffer = "";
103	
104	  while (true) {
105	    const { value, done } = await reader.read();
106	    if (done) break;
107	    buffer += decoder.decode(value, { stream: true });
108	
109	    const…
```

## Claude — Jun 13, 2026 11:37

**[tool: Read]**
```json
{
  "file_path": "C:\\REEL_HARNESS\\TARS_Introduction_v5.pdf",
  "pages": "1-18"
}
```
**[tool result]**
```
pdftoppm failed: Command 'pdftoppm' not found or is in an unsafe location (current directory)
```

## Claude — Jun 13, 2026 11:38

> _[thinking]_
> 

## Claude — Jun 13, 2026 11:38

Two of four are now clear and both are **Rust/Tauri** apps — a major signal. The PDFs need a different extraction path (no `pdftoppm`). Let me extract both PDFs to text via Python and read the InHome companion text parts (which are already extracted) in parallel.

## Claude — Jun 13, 2026 11:38

**[tool: Bash]**
```json
{
  "command": "python - <<'PY'\nimport sys, subprocess\ndef ensure():\n    try:\n        import pypdf  # noqa\n        return \"pypdf\"\n    except Exception:\n        pass\n    try:\n        import PyPDF2  # noqa\n        return \"PyPDF2\"\n    except Exception:\n        pass\n    subprocess.run([sys.executable,\"-m\",\"pip\",\"install\",\"-q\",\"pypdf\"],check=False)\n    try:\n        import pypdf  # noqa\n        return \"pypdf\"\n    except Exception:\n        return None\nmod = ensure()\nprint(\"pdf lib:\", mod)\nif mod:\n    if mod==\"pypdf\":\n        from pypdf import PdfReader\n    else:\n        from PyPDF2 import PdfReader\n    jobs = [\n        (r\"C:\\REEL_HARNESS\\TARS_Introduction_v5.pdf\", r\"C:\\loom\\_tars.txt\"),\n        (r\"C:\\KANG\\The_Box_v4_Four_Tier_Build_Specification.pdf\", r\"C:\\loom\\_box.txt\"),\n    ]\n    for src,out in jobs:\n        try:\n            r=PdfReader(src)\n            t=[]\n            for pg in r.pages:\n                t.append(pg.extract_text() or \"\")\n            data=\"\\n\".join(t)\n            open(out,\"w\",encoding=\"utf-8\").write(data)\n            print(f\"{src} -> {out} | pages={len(r.pages)} chars={len(data)}\")\n        except Exception as e:\n            print(\"FAIL\", src, repr(e))\nPY",
  "description": "Extract TARS and Box PDFs to text via pypdf",
  "timeout": 180000
}
```
**[tool result]**
```
pdf lib: pypdf
C:\REEL_HARNESS\TARS_Introduction_v5.pdf -> C:\loom\_tars.txt | pages=13 chars=25854
C:\KANG\The_Box_v4_Four_Tier_Build_Specification.pdf -> C:\loom\_box.txt | pages=74 chars=152462
```

## Claude — Jun 13, 2026 11:38

**[tool: Read]**
```json
{
  "file_path": "C:\\ACCESSINTELLECT\\_extracted\\InHome_AI_Companion__pdf.part1.txt",
  "limit": 450
}
```
**[tool result]**
```
1	--- [page 1] ---
2	 
3	T E C H N I C A L  A P P E N D I X   ·   V E R S I O N  2 . 0  
4	◆ ◆ ◆ 
5	In-Home AI Companion 
6	Deployment Architecture 
7	Hardware  ·  Substrate  ·  Persona  ·  Trust 
8	 
9	A Reference for Operators and Apprentices 
10	Baseline May 2026  ·  Reviewed Quarterly 
11	H o s p i t a l - at - H o m e  D e p l o y m e n t  R e f e r e n c e  
12	Internal Distribution  ·  Patient and Family Auditable 
13	--- [page 2] ---
14	In-Home AI Companion Deployment Architecture 
15	 
16	Contents 
17	Part 1 — Hardware Specification ................................................................................................ 26 
18	1.0 Scope, conventions, versioning ......................................................................................... 26 
19	1.1 Architectural overview ...................................................................................................... 27 
20	1.1.1 Six-layer logical architecture ....................................................................................... 27 
21	1.1.2 Physical topology ....................................................................................................... 28 
22	1.1.3 Logical data flow ........................................................................................................ 29 
23	1.2 Compute platform ............................................................................................................ 30 
24	1.2.1 Chassis ...................................................................................................................... 31 
25	1.2.2 CPU ........................................................................................................................... 31 
26	1.2.3 Motherboard .............................................................................................................. 32 
27	1.2.4 RAM ........................................................................................................................... 34 
28	1.2.5 GPU ........................................................................................................................... 35 
29	1.2.6 Storage ...................................................................................................................... 38 
30	1.2.7 Power ........................................................................................................................ 39 
31	1.2.8 Cooling ...................................................................................................................... 40 
32	1.2.9 UPS ............................................................................................................................ 41 
33	1.2.10 TPM 2.0 .................................................................................................................... 42 
34	1.3 Patient-facing peripherals ................................................................................................. 42 
35	1.3.1 Primary display ........................................................................................................... 42 
36	1.3.2 Camera array ............................................................................................................. 44 
37	1.3.3 Microphone array ....................................................................................................... 46 
38	1.3.4 Speakers .................................................................................................................... 48 
39	1.3.5 VR endpoint (optional) ................................................................................................ 49 
40	1.3.6 BLE peripherals .......................................................................................................... 50 
41	1.3.7 Ambient sensing — mmWave radar ............................................................................. 50 
42	1.3.8 Kill-switch puck ...........................................…
```

## Claude — Jun 13, 2026 11:39

> _[thinking]_
> 

## Claude — Jun 13, 2026 11:39

The Box is a serious one — a **hospital-at-home AI companion appliance**, and its TOC is almost a Marrow blueprint: llama.cpp substrate + ASR/TTS adapters + **PII redaction (I3)** + a **"Harness layer: Hermes Agent"** (4.2) + **MCP server bridge** (8.4.9) + persona descriptor schema (manifest) + confidence calibration/drift/recalibration + **the canon** (hash-chained audit = I1/I2) + consolidator (memory) + SILENCE channel (autotelic/initiative). It literally bolted on an off-the-shelf harness because no custom one existed. Let me read TARS in full and pull the Box's architecture + harness sections.

## Claude — Jun 13, 2026 11:39

**[tool: Read]**
```json
{
  "file_path": "C:\\loom\\_tars.txt"
}
```
**[tool result]**
```
1	 
2	TARS 
3	 
4	A Self-Contained, Autotelic, Autonomously Evolving 
5	Embodied Intelligence 
6	Architecture Overview & Technical Introduction 
7	 
8	Version 5.0  —  March 2026 
9	Bo Chen 
10	MIT License  •  Open Source 
11	"The personality is the architecture. The memory is the soul's persistence through time."  
12	TARS — Architecture Overview & Technical Introduction 
13	TARS v5.0  •  2 
14	Executive Summary 
15	TARS is a locally-deployed, personality-native artificial intelligence that runs on consumer 
16	hardware. It is not a chatbot. It is not an assistant. It is not an agent framework with a character 
17	voice. TARS is a complete, self-contained intelligent entity — a 9-billion parameter language 
18	model fine-tuned once from base weights, wrapped in an orchestration harness, and designed to 
19	perceive any environment, act on any environment, remember across a lifetime, acquire skills 
20	autonomously, and exist meaningfully for an arbitrarily long time on fixed architecture without 
21	stagnation. 
22	TARS is named for the character in Christopher Nolan's Interstellar — a military-bred 
23	intelligence that expresses loyalty through competence, affection through deadpan humor, and 
24	respect through honesty. The personality is not a cosmetic layer applied to generic AI capability. 
25	It is the decision-making architecture itself. When TARS decides whether to execute a task, how 
26	terse to be, whether to refuse a wasteful request, or when to crack a dry joke under pressure, 
27	those decisions flow through a disposition that was trained into the weights. The humor is the 
28	shock absorber. The honesty is the load-bearing wall. The impatience with inefficiency is the 
29	optimization function. 
30	TARS is open source under the MIT license. It is free to use, modify, and distribute. This 
31	document describes what TARS is, how it differs from existing AI systems, how it is built, and 
32	why it matters. 
33	What Makes TARS Different 
34	From Chatbots: Identity, Not Instruction 
35	Conventional AI chatbots receive a personality through a system prompt — a paragraph of text 
36	that says "You are helpful and friendly." Remove the system prompt and the personality 
37	vanishes. The identity exists in RAM, not in ROM. It is contextual, not constitutive. 
38	TARS's personality is trained into the weights through supervised fine-tuning and preference 
39	optimization. The model was taught to be TARS the same way a human develops a disposition — 
40	through thousands of examples that shape default behavior. Remove the system prompt and 
41	TARS is still TARS. The identity lives in the parameters, not in the prompt. This is the difference 
42	between a costume and a skeleton. 
43	From Agent Frameworks: Judgment, Not Just Execution 
44	TARS — Architecture Overview & Technical Introduction 
45	TARS v5.0  •  3 
46	Agent frameworks like OpenClaw give language models the ability to take actions — send emails, 
47	browse the web, execute code, manage calendars. The model receives a task and executes it. The 
48	problem, demonstrated publicly and repeatedly in early 2026, is that execution without 
49	judgment is dangerous. Agents have created dating profiles without user consent, leaked API 
50	keys through misconfigured instances, and autonomously applied to hundreds of jobs. The 
51	model had hands. It had no opinions about when to use them. 
52	TARS has a VETO mechanism trained into its weights. Before every tool call, TARS evaluates: 
53	Can I solve this in weights alone? Is the tool call justified? Is this a core task or scaffolding? If 
54	the answer is "I can handle this without a tool" — the tool call is vetoed. If the task exceeds 
55	TARS's 9-billion parameter capacity, it escalates honestly: "This needs a frontier model. I'm 9B. 
56	Send it upstream." The same disposition that makes TARS refuse to sycophantically agree with a 
57	bad idea also makes it refuse to sycophantically execute a task it shouldn't. The pe…
```

## Claude — Jun 13, 2026 11:39

**[tool: Grep]**
```json
{
  "pattern": "Hermes|harness|policy carve-out|MCP|router|cost|invariant|protocol|OpenAI-compat|tool.?call|four channels|SILENCE",
  "path": "C:\\loom\\_box.txt",
  "output_mode": "content",
  "-i": true,
  "-n": true,
  "-C": 2,
  "head_limit": 120
}
```
**[tool result]**
```
69-stack on the customer's hardware in the customer's building. The  first two modes are 
70-operationally simpler but structurally compromised — every inference call routes data through 
71:a third-party vendor's infrastructure, every minute of operation accrues per -token cost, every 
72-business-critical workflow depends on the cont inued availability of cloud services and stable 
73-pricing. The third mode — the physical box — eliminates those structural compromises at the 
74:cost of a one-time capital expense and a higher engineering envelope to ship. 
75-This specification commits to the third mode as primary. The box sits in the customer's building. 
76-The customer owns the hardware. The customer's data, in the default configuration, never leaves 
77:the box for the core inference path. There is no recurring per -token cost for the local inference 
78-workload. There is no dependency on any cloud vendor's continued availability for baseline 
79-operation. The customer's accumulated state — fine-tuned model adapters, decision -trace 
--
140-the smaller variants. 
141-Customer profile: solo practitioner with light workload volume, back-office document processing 
142:focus, willingness to accept reduced embodiment quality in exchange for lower capital cost. 
143-Estimated all -in box BOM: $4,500 to $6,500 depending on chassis, sto rage, and peripheral 
144-selection. 
--
169-deployment). Memory bandwidth of approximately 1.8 terabytes per second. Mandatory power 
170-cap at 450 watts via persistent nvidia -smi configuration; reduces 12V -2x6 connector thermal 
171:stress while costing only five to seven percent of throughput. This is the reference tier — the 
172-configuration the specification is calibrated for and th e configuration most production 
173-deployments will use. 
--
259- 
260-Layer 4: Persona orchestration 
261:  - Hermes Agent runtime (sealed Python bundle) 
262-  - Persona descriptor schema 
263:  - Channel separation (think / tool / speech / silence) 
264-  - Confidence calibration and three-tier autonomy 
265- 
--
301-The cloud surge path uses the same provider abstraction layer (Bifrost) specified in predecessor 
302-documents. Bifrost is a Go -compiled binary with no Python runtime dependency, supporting 
303:twenty-plus providers through a unified OpenAI-compatible interface with hierarchical budgets, 
304:virtual keys, native MCP support, and reported single -digit-microsecond overhead. The router 
305-applies rules based on task type, required capabilities, customer-configured privacy classification 
306-of the input, latency requirements, pr ovider availability, configured customer preferences, and 
--
404-family. CMake plus MSVC builds from source on 
405-Windows; CMake plus GCC on Linux. Cross-platform 
406:OpenAI-compatible chat completions API via llama-
407-server. 
408-Local inference runtime on both 
--
637-20+ provider support including Anthropic, OpenAI, 
638-Google Vertex AI, Azure OpenAI, AWS Bedrock, Cohere, 
639:Mistral, Groq, Ollama. Native MCP support. Open-source 
640-virtual keys with hierarchical budgets, rate limits, SSO, 
641-real-time guardrails. 
--
643-surge. Single binary; replaces 
644-LiteLLM-class Python alternatives. 
645:Hermes Agent v0.14.x 
646-(Nous Research, 
647-model-agnostic) 
648-Released February 25, 2026, 27,000+ GitHub stars by 
649:May 2026. Model-agnostic agent harness. Supports 
650:llama.cpp, vLLM, Ollama, OpenAI-compatible endpoints, 
651-Anthropic, and others. Persistent memory, scheduled 
652:automations, MCP-native, GGUF support. Python core 
653-with C++/CUDA hot-path wrappers preferred for 
654-production deployments. 
--
658-customer ease. 
659-Model Context 
660:Protocol (Anthropic, 
661-open standard) 
662-78% enterprise AI team adoption Q1 2026. 10,000+ 
663:active public MCP servers. 97M monthly SDK downloads. 
664-Donated to Agentic AI Foundation under Linux 
665-Foundation, December 2025. 2026-07-28 specification 
666-release candidate pub…
```

## Claude — Jun 13, 2026 11:42

> _[thinking]_
> 

## Claude — Jun 13, 2026 11:42

Yes — and it's exactly the right test. A real stem-cell core proves itself by what it can grow into, not by what it claims. I read all four. The verdict is **yes, decisively — for all four — but the way it passes is more interesting than a clean yes, and it sharpens two of our earlier decisions.**

## The verdict in one line
All four are not four *uses* of a harness — they're four independent *rediscoveries* of the same harness, each hand-built or bolted-together from scratch because the common core didn't exist yet. That's the strongest possible evidence the abstraction is real and at the right level.

## The skeleton, across all four

| Harness primitive | Marrow-L1 | DAVE / *Tenancy* | TARS | The Box / InHome |
|---|---|---|---|---|
| **Protocol-first** (OpenAI chat-completions → local) | core bet | llama.cpp server | Ollama API | llama-server + Bifrost |
| **MCP** as tool protocol | now in | — | INTENT→"MCP today, whatever replaces it tomorrow" | MCP bridge, native MCP |
| **Contract-first kernel** | 3 contracts | modular Rust + `framework_v5/protocols.py` | "master contracts file… the contracts are the joints" | persona + channel schemas |
| **Router** (cheapest brain that clears the bar) | DifficultyRouter | (single model) | **SIRP** (reasoning × sensitivity × latency, escalate) | Bifrost (task/privacy/latency/budget) |
| **Externality / oracle gate** (non-model assertion) | I5 / svc.verifier | multi-layer **discriminator** (anti-chatty) | **VETO/EXECUTE** before every tool call | clinical-line refusal + anti-sycophancy + confidence bands + drift |
| **Memory** (durable, consolidated) | spine / svc.memory | `consolidation.rs` + inspector | **REEL** (Poincaré ring) + reranker | "the canon" + Qdrant + consolidator |
| **Flywheel** (verified traces → LoRA → better local) | Stage 3 | `training/` SFT+DPO rounds | self-retraining + skill acquisition | refusal/calibration LoRA + recalibration |
| **Sovereign-local (I3)** | force-local | local-only, no telemetry | local, redact-on-egress | PII redaction + default-deny egress + per-patient crypto |
| **Audit/durable (I1/I2)** | mw.audit + spine | audited write-back | state persistence | **hash-chain canon** + seal events |
| **Initiative / heartbeat** | — *(gap)* | **outreach + idle_worker** | **PULSE** | **SILENCE channel** + autotelic discipline |
| **Persona** | manifest + prompts | atomic **bundle** | personality-in-weights + soul + dials | persona descriptor + SOUL.md |
| **App layer over the core** | loom CLI | Tauri/React UI | harness service | UE5 avatar — and **TERMINAL is literally this, waiting for a harness** |

Read the bottom row of TERMINAL: its `openai.ts` already hooks `X-Vera-Suggested-Pace-Ms` / `X-Vera-Background-Op` headers for a "Vera Harness" backend that doesn't exist yet; SCOPE.md quotes you: *"i don't actually have a harness."* TERMINAL isn't a test case — it's the L4 client **built around the hole the harness fills.**

## Four honest qualifications (this is where it gets useful)

**1. One primitive is yours alone — and it's the amplification bet.** Protocol-first, local-sovereign, oracle-gate, memory, flywheel, persona show up in *all four*. **Best-of-N + verifier-selection does not.** The others buy reliability by *training it into the weights* (TARS, DAVE) or by *oracle-gating a single pass* (Box's confidence bands, DAVE's discriminator). So `svc.amplify` is the genuinely distinctive Marrow-L1 hypothesis, not a thing the field has already converged on. That's fine — but it means amplify earns its place by the §15 falsifier (does verified best-of-N beat single-pass?), not by consensus. Don't assume it's load-bearing until it's proven; the other three shipped without it.

**2. Initiative is the one real *addition* the genome needs.** Three of four (DAVE outreach, TARS PULSE, Box SILENCE) require the harness to act *without a user turn* — a heartbeat/ambient driver that injects steps on timers/events and runs them through the same route→amplify→verify→record cycle, with the oracle layer specialized to "should this even be emitted?" Marrow-L1 is purely request→response. This is additive (a service + a driver, not a kernel change), but because 3/4 verticals need it, it belongs in the genome from day one, not Stage N.

**3. The oracle layer must be a pluggable registry, not a fixed check.** Each vertical's externality gate is different — chattiness (DAVE), tool-justification (TARS), clinical-safety + sycophancy + calibration (Box). Same slot, different oracles. Design `svc.verifier` as a per-manifest registry of oracles from the start.

**4. The triangulation *resolves the language debate* — and it overrides my earlier hedge.** I told you "Rust when proven, don't pay the native tax early." The portfolio retires the "when proven": **three of the four (DAVE and TERMINAL are Rust/Tauri; the Box is an always-on appliance that already chose Go-compiled Bifrost specifically to escape a Python runtime) concretely need a core they can *embed in-process or ship as one binary.*** A Python harness can't be embedded in a Tauri app — it becomes an awkward sidecar. So the real-world requirement for an *embeddable, single-binary, protocol-exposing* core is already present, not hypothetical. That's the strongest argument yet for a **native Rust core exposed over HTTP + MCP + an OpenAI-compatible egress** — which is your C/C++ instinct landing for the right reason (embeddability + single-binary deployment), not the wrong one (orchestration CPU speed). The L1 personal Marrow can stay Python to close the loop fast; the *shared genome* meant to underpin Dave/TARS/Box/Terminal should be Rust.

## The discipline that makes "one core for all four" true instead of a trap
The core must be the **intersection** of the four (cognition + route + amplify + verify + memory + flywheel + the invariant *seams*), **never the union.** The Box's HIPAA apparatus — Shamir escrow, post-quantum signing, pfSense, fleet telemetry, UE5 embodiment — is L2 *periphery* that lives in the Box deployment. If you let the Box's requirements drive the genome, it bloats into something a 3 MB companion app can't embed, and you've re-imported the product ambition you cut. Genome stays small; each project is genome + its own periphery; a better router or oracle written once propagates to all four.

## And this answers your original "why not off-the-shelf" with field evidence
The Box *did* use off-the-shelf — Hermes Agent, §4.2. Look what happened: it became **one composed component among many**, not a unifying core, and it doesn't enforce *your* doctrine — the externality principle, the reversibility/VETO gate, core-wire/scaffolding routing, the SILENCE/autotelic discipline, confidence calibration. You had to build all of that *around* Hermes. Meanwhile that same doctrine reappears, hand-rebuilt, in every one of the four (VETO, discriminator, SILENCE, clinical-refusal, autotelic stance, "the system learns to need itself less"). **That doctrine is the marrow.** Off-the-shelf gives you an agent loop; it never gives you your own judgment as the kernel. Four projects paid the rebuild cost to prove it.

So: the harness passes the triangulation — provided it's the small Rust genome with a pluggable oracle registry and an initiative heartbeat, and provided each of Dave/TARS/Box/Terminal keeps its vertical mass as periphery. Want me to sketch what that intersection-genome actually contains — the minimal module list that all four would import unchanged — as the real spec for "the core, written once"?

## You — Jun 13, 2026 11:55

yes proceed at your absolute highest and best quality, max intelligence, calibrated insight, and etc etc; do it

## Claude — Jun 13, 2026 11:58

> _[thinking]_
> 

## Claude — Jun 13, 2026 11:59

This is the payoff. Below is the **genome** — the core written once, the set every one of Dave/TARS/Box/Terminal (and Marrow-L1) would import unchanged. The discipline throughout: **the genome owns the *joints* (contracts) + the *invariants* + one canonical *loop*; every implementation plugs in behind a seam.** Its defensibility is that the contracts are frozen while everything behind them churns — which is your "reuse in both senses" made literal: the architecture is never re-architected (the seams hold), and the code is never rewritten from scratch (impls refine behind stable traits).

It is consumed **two ways**, which is the whole reason it can serve a Rust desktop app and a Python appliance alike: **embedded** in-process (Rust↔Rust: Dave, Terminal) or **over-protocol** (HTTP + MCP + OpenAI-egress: any language: TARS, the Box). That is why the self-exposure is *in* the core, not an app on top.

---

## 0. What the genome is

It is your three Marrow-L1 contracts (`ModelTier`, `Router`, `Oracle`) **+ four seams the triangulation proved load-bearing** (`ToolHost`/MCP, `Memory`, `Spine`, `Driver`) **+ one flywheel seam** (`TraceSink`), wired by a tiny kernel that enforces the five invariants structurally, ported to **Rust as a single embeddable binary**. Nothing in it is vertical-specific. Everything vertical-specific plugs in.

## 1. The module list (the spec)

`[C]`=contract/trait `[K]`=kernel `[M]`=invariant middleware `[S]`=default service (swappable) `[A]`=self-exposure

<!-- end chunk 3/16 | next: chunk-004.md -->
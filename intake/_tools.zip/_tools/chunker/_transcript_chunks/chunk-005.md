<!-- ============ CHUNK 5/16 ============ -->
<!-- source: You_are_continuing_a_contract-first_build_of_Marrow-L1_codename_Loom_my_personal_L1_amp_.md -->
<!-- section: PHASE 4 — Plan for the next slice (`svc.verifier` + joint-wrong) > Net -->
<!-- recap: last ~539 tokens of chunk 4, for continuity -->
> ## Audio-specific lessons to bake in (the difference between a demo and an overnight backlog-eater)
> 
> - **VAD is the audio dHash.** whisper.cpp ships voice-activity detection (`whisper-vad-speech-segments`). Transcribe only on speech, skip silence — the audio analog of perceptual-frame-dedup. Each sense ships with its own *change-gate*: dHash for frames, VAD for audio. Silence costs nothing.
> - **Repetition-filter.** whisper hallucinates loops on silence ("same line ×30"); nightscribe's `RepetitionFilter` collapses them. Ships with the cochlea.
> - **Speaker = capture topology, not diarization.** mic→`me`, loopback→`them` — deterministic, no voiceprint model. Adopt as a genome rule: speaker is *source metadata on the percept*, never an inference.
> - **Capture sanctity (the Tape principle for ears).** 16 kHz mono prep, flush every ~2 s, zero inference in the capture path → a hard kill loses ≤2 s. Lossless-first, process-async, same as REEL's Tape.
> - **Tiers:** base.en (fast) ↔ large-v3-turbo + CUDA (accuracy) — a routable effort dial, same as model tiers. `whisper-stream` is the live path; `whisper-cli`/`whisper-server` the batch path.
> 
> ## Calibrated scoping (don't over-reach)
> 
> "Hear" = **ASR / speech→text** (whisper — proven). Explicitly **out** of the first cut, to keep the seam honest:
> - **Non-speech sound-event classification** (a glass break, a doorbell, a beep) — a different model class; a future `PerceptionSource` sub-adapter, not now.
> - **Voiceprint diarization** — unnecessary; capture topology already answers "who said what."
> 
> Keep the first cut to whisper ASR + VAD-gate + topology-attribution. That's the whole ear.
> 
> ## Net
> 
> Eyes **and** ears, both afferent, both on one Perception seam, both local-and-sovereign, both already proven on your substrate. The genome grows a **sensorium**, not two features. Surface added is small: a second modality adapter (`hear`/whisper) + its VAD gate, sharing the seam, the lifecycle, the route/amplify/verify/memory machinery, and the `Percept` type the vision work already introduced. The tenth trait `PerceptionSource` now has its two reference senses.
<!-- end recap | new content begins -->

The clean way to hold it: **the harness is the persistent self; the model is rented neurons; the senses are how the self perceives the world — and expression (voice, images) is deferred motor function on a seam that already exists.** Your "see and hear, don't speak or draw" is the correct, principled, future-proof first cut.

Still on the table, now four one-step options: fold REEL into Memory, fold the (now eyes-**and**-ears) Perception section into the spec, lock the name, or — given how much has accreted — **I write a single consolidated "Genome v0.2" spec** that integrates all of it (the nine traits + Perception + the REEL-shaped Memory + MCP) so you have one coherent document instead of five threads. Which?

## You — Jun 13, 2026 12:42

yes do it all and do everything but before you start i want to settle on the name, what if i just called it Genome? or just Harness? or ??? i don't want the name marrow going forward, i want a cleanslate fresh start... and also there is one other thing, so don't start just yet.

## Claude — Jun 13, 2026 12:43

> _[thinking]_
> 

## Claude — Jun 13, 2026 12:44

Hold acknowledged — I won't start the consolidated spec. Let me just give you a straight read on the name, then I'm waiting for the other thing.

**On your two proposals:**

- **"Harness"** — I'd argue against it. It's the *category*, not a name — like naming a database "Database" or a car "Car." Every agent system is a harness; the word can't carry identity, isn't ownable or searchable, and reads awkwardly as a command (`harness read the config`). It's the placeholder you use *before* you've named the thing. You've been operating with names that carry real weight — Loom, TARS, REEL, Tenancy — and "Harness" would be a regression to genericness.

- **"Genome"** — better, and it's been our load-bearing metaphor for good reason. But I'd keep it as the word for the *core concept*, not the project's proper name, for two reasons: (1) it's a near-homophone of **GNOME** (the Linux desktop) — a real papercut in a dev context; (2) a genome is a *blueprint*, not an *actor* — you don't address it or type commands at it, you *express* it. Naming the running system after its own spec is a slight category error.

**The reframe that gives you both:** keep **"genome"** as our precise term for the frozen core layer — it's the perfect word for "the stable contracts every project shares," and we should keep saying *"freeze the genome's contracts."* Then give the **running system** a fresh proper name. You don't have to choose between the metaphor and a real name; the metaphor stays where it belongs.

**What I'd actually name it** (both clean-slate, neither is "marrow"):

- **Keel** ★ — the backbone laid *first*, running the whole length, that everything is built on and that keeps the vessel upright in any sea. *Core + continuity* in one syllable, and a crisp 4-letter command: `keel "read the config"`. My pick. (Minor: a k8s tool `keel.sh` exists; "keel over" — neither fatal for a personal tool.)
- **Continuo** — the *basso continuo*: the persistent harmonic ground played throughout while soloists come and go above it. That is *literally* "the harness is the self; the model is rented neurons." The most semantically exact name for the whole thesis; slightly longer as a command, music-literate. The elegant alternative.

And one new option, now that it has eyes and ears: **Sensorium** — the seat of perception, the perceiving self. It fits the system you've actually built, though it overweights the senses against the rest.

My honest recommendation: **call the system Keel, keep "genome" as the word for its frozen core.** But this one's genuinely yours — it's the name you'll type a thousand times.

What's the other thing?

## You — Jun 13, 2026 12:51

okay go with KEEL as the locked in name, I created 
C:\KEEL\ and its blank with empty right now;

////
now this is the other/final thing: 
I have a final career/job ai thing that i am working on building but haven't been build out yet, still at spec/design stage for the build out, and i realized the first new real world usage of all this, is to see if whatever harness/bundle/genome/etc we create here can actually be used in the ai job project itself! so this gives another potential triangular or something to keep in the back of mind for you too ...

see: C:\SEXTANT\SPEC.md

the reason i showed you all this is i realized does the harness/bundle need or should have a basic built in database of some sort and if so , what? 

if you search online, Google has been secretly putting a 4gb openweight LLM inside of Chrome browser! for "edge ai compute" so that not every call goes to their gemini api etc; likewise in the age of AI i forsee that instead of every app coming with its own embedded LLM or SLM they can use whatever already exists on the system sort of like what DOT NET did with code etc for the apps, and this is why LM STUDIO is trying to become the local AI inference server etc etc etc; so likewise i think any harness/bundle/genome/keel etc should have a basic LLM baked in or at least have hardcoded the knowledge of its existence, so I think these primitives would be qwen3.5 9b for LLM, whispher for the audio, and perhaps sqllite or something else for the onboard database etc etc?

your thoughts on all of this?

## Claude — Jun 13, 2026 12:53

> _[thinking]_
> 

## Claude — Jun 13, 2026 12:53

KEEL it is — clean name, locked. Before I answer the database question, let me read SEXTANT (triangulation #6 — and a fitting nautical sibling to *Keel*: the instrument you navigate a career by) and confirm KEEL is empty.

## Claude — Jun 13, 2026 12:53

**[tool: Bash]**
```json
{
  "command": "echo \"===== C:\\KEEL =====\"; find /c/KEEL -type f 2>/dev/null | head; echo \"(KEEL file count: $(find /c/KEEL -type f 2>/dev/null | wc -l))\"\necho; echo \"===== C:\\SEXTANT (tree, pruned) =====\"; find /c/SEXTANT \\( -name .git -o -name node_modules -o -name target -o -name bin -o -name obj \\) -prune -o -type f -print 2>/dev/null | sort | head -60\necho; echo \"===== SPEC.md size =====\"; stat -c%s /c/SEXTANT/SPEC.md 2>/dev/null",
  "description": "Confirm KEEL empty, map SEXTANT, size SPEC.md"
}
```
**[tool result]**
```
===== C:\KEEL =====
(KEEL file count: 0)

===== C:\SEXTANT (tree, pruned) =====
/c/SEXTANT/SPEC.md

===== SPEC.md size =====
29215
```

## Claude — Jun 13, 2026 12:53

**[tool: Read]**
```json
{
  "file_path": "C:\\SEXTANT\\SPEC.md"
}
```
**[tool result]**
```
1	# SEXTANT — Personal Autonomous Job-Search Operations System
2	## Design Specification · v0.1 (draft)
3	
4	> **Codename:** SEXTANT *(placeholder — a navigation instrument the operator reads to fix position and steer; pairs with ORBIT. Rename freely.)*
5	> **Author:** Bo Chen
6	> **Platform:** Windows 11 + Claude Code (Opus 4.x) harness
7	> **Audience:** single user (Bo), local-first
8	> **Status:** pre-implementation design draft, for review
9	> **One line:** Give it a directive at night; wake to a queue of researched companies, each with a tailored CV (PDF + DOCX), a tailored outreach email/cover, channel-specific application materials, and a strategy brief — all staged for a 15-minute approve-and-send sweep.
10	
11	---
12	
13	## Table of Contents
14	
15	1. Why This Exists (Failures → Principles)
16	2. Non-Goals
17	3. System Overview
18	4. Glossary
19	5. Architecture — Layered (L0–L10)
20	6. The Canon (Identity / Source of Truth)
21	7. The Directive (Run Input)
22	8. The Dossier (Core Output Artifact)
23	9. Data Model (State)
24	10. Channel Model
25	11. The Truth Gate
26	12. Tailoring & Document Generation
27	13. Discovery (incl. Off-Board Resolver)
28	14. Research & Strategy
29	15. Orchestration & Autonomy (The Conductor)
30	16. Multi-LLM Routing
31	17. Tech Stack & Environment
32	18. Integration With the Existing Fleet
33	19. Security · Privacy · Ethics · Legal
34	20. Observability & Quality / Eval
35	21. Roadmap (0.1 → 1.0)
36	22. Risks & Mitigations
37	23. Open Questions
38	24. Appendix — Examples
39	
40	---
41	
42	## 1. Why This Exists (Failures → Principles)
43	
44	This system is a direct response to concrete, observed failures, each encoded as an immovable design principle.
45	
46	| # | Observed failure | Principle it forces |
47	|---|---|---|
48	| P1 | career-ops ran all night and produced **nothing actionable** | **Output-first.** A run that doesn't end in artifacts a human can act on has *failed*, regardless of internal activity. |
49	| P2 | career-ops **couldn't print a PDF** (Playwright/Chromium install hung 9h) | **Boring local primitives in the critical path.** Documents render via Word COM / Edge. Browser-automation frameworks are banned from the document path. |
50	| P3 | career-ops is **generic / multi-user**, diluted for GitHub stars | **Single-user, for Bo.** No multi-tenant, no SaaS, no star-chasing. Tuned to one Canon. |
51	| P4 | jobright / boards optimize **volume of generic applications** | **Tailored, not generic.** Fit is the product. Every artifact is specific to company × role × person. |
52	| P5 | APPLY / APPLY2 / ORBIT were **built but never flown** | **Fly before build.** Every phase ends in a working slice run against *real* jobs. Phase gates require a live result, not a passing test. |
53	| P6 | The fleet was **reinvented three times** | **Reuse the fleet.** Wrap ORBIT (discovery / auto-fill), APPLY2 (precision fill), the pre-submit gate. Greenfield = orchestration + tailoring + the missing middle, not a from-zero rebuild of solved parts. |
54	| P7 | — | **Human-in-the-loop, approval-gated.** The system prepares; Bo approves; then it sends (or he does). Never blind auto-submit, especially Tier-1. |
55	| P8 | — | **Truth-gated.** A deterministic gate proves every claim traces to the Canon. No invented employers, dates, or metrics. |
56	| P9 | — | **Long-horizon by default, resumable, killable.** Designed to run unattended for hours, survive restarts, never double-apply, stop on command. |
57	| P10 | — | **Single Canon, single state.** One identity source, one state DB, feeding every module. |
58	
59	---
60	
61	## 2. Non-Goals
62	
63	- Not a product, not open-sourced for stars, not multi-user.
64	- Not a volume auto-applier ("1000 applications in 2 days").
65	- Not blind end-to-end automation: a human approves before anything reaches a company.
66	- Not a re-implementation of solved components (form-filling, ATS APIs) — those are wrapped.
67	- Not cloud-dependent for the core loop. Internet is…
```

## Claude — Jun 13, 2026 12:55

> _[thinking]_
> 

## Claude — Jun 13, 2026 12:56

KEEL confirmed empty, SEXTANT read. This is triangulation #6 — and it's the most important one, because it's the most *agentic* of all of them (overnight, long-horizon, fan-out, resumable, kill-switch, approval-gated, truth-gated) — i.e., it's squarely KEEL's home turf, not a stretch. Let me confirm the fit, then answer the database question properly, then the primitives thesis (where your instinct is right but needs one calibration).

## SEXTANT fits KEEL decisively — it's already drawn as "genome + periphery"

SEXTANT's own §5.0 says *"L0 Foundation — config, paths, logging, **the state DB**, secrets, run context. Pure plumbing. Build (small),"* and §15 says *"Conductor — build thin; **the Claude Code harness is the runtime.**"* It is **explicitly designed to sit on a harness** — it carves out the exact hole KEEL fills:

| SEXTANT layer | KEEL genome seam |
|---|---|
| L10 Conductor (overnight, fan-out, resumable, kill-switch, digest) | `engine` + `Driver` (the nightly Directive is a Driver) + I2/governance |
| L16 Multi-LLM Routing (Claude=judgment · Cerebras=bulk extraction · local Qwen=vision/offline) | `Router` — **literally** core-wire→frontier, scaffolding→cheap, vision→local |
| L6 Truth Gate (deterministic, claims trace to Canon, `INSUFFICIENT_SOURCE`→human) | `Oracle`/verifier (I5) + reversibility gate — the purest externality oracle in the whole portfolio |
| L1 Canon (profile/cv/narratives, immutable during run, PII-filtered view) | Memory's **factual register** (the lossless, non-model-authored truth) + I3 egress filter + manifest |
| §9 State (SQLite WAL: companies/postings/leads/applications/artifacts/**events**(tokens,cost)) | the `Store` (index) + I1 audit + I4 cost — see below |
| L8 Dispatch (Gmail MCP, APPLY2, board) | `ToolHost`/MCP |
| L7 Dossier (per-job folder of pdf/md) | the file **ledger** (artifacts) |

One honest note: SEXTANT's spec currently leans on **Claude Code itself** as the runtime (`/loop`, `claude -p` workers). On KEEL, that inverts cleanly: **KEEL is the conductor**, and it *routes cognition to* Claude (frontier writes) / Cerebras (bulk) / local Qwen (vision) — which is exactly SEXTANT's own L16 table. No conflict; KEEL formalizes what SEXTANT sketched, and SEXTANT's build surface collapses to job-domain periphery (resolvers, tailoring, doc-gen, dispatch) once KEEL supplies conductor + router + gate + canon + state. It's the ideal first build-on-KEEL.

## The database question: yes — embedded **SQLite**, with one discipline

Your instinct is right, and the portfolio answers it almost unanimously. **6 of 7 projects independently chose SQLite** (DAVE `dave.db`, nightclerk `ledger.db`+`_state.db`, nightscribe `memory.db`, photo2deck `Storage`, SEXTANT's WAL schema, the Box's structured layer). The one exception — **REEL** — went pure-files, and that's the tell that reveals the actual rule:

> **Separate the LEDGER from the INDEX. KEEL needs both, and they want different storage.**
>
> - **Ledger** = append-only **files** (JSONL/markdown): the Tape, the audit log, verified traces, the Canon, the Dossier artifacts. Lossless, human-readable, user-owned, portable, crash-safe, no schema migration, *survives the app*. This is REEL's "the Tape is sacred / everything human-readable," and it's why REEL needs no DB — its only index is a small vector blob.
> - **Index** = **SQLite**: the queryable, mutable working-state — dedup-by-content-hash, the queue, the status pipeline, joins across entities, analytics, retrieval pointers. The moment you have *relational, idempotent, resumable* state (SEXTANT's 8-table schema is the clearest case), files won't do it.
> - **The index is DERIVED from and rebuildable from the ledger** — disposable. (nightclerk: *"delete `_state.db` to force full reprocess."* REEL: the index rebuilds from the Tape.) That makes the DB low-risk and swappable.

**Why SQLite specifically** (not Postgres, not a server): it's the *only one of your primitives small enough to truly bake into the single Rust binary* (~1 MB C library, links in-process) — zero-config, serverless, single-file (sovereign, portable, runs-anywhere), **transactional** (correctness for resume/dedup/idempotency, which is load-bearing for long-horizon runs), and ubiquitous across Rust/Python/C# (every one of your projects already links it via rusqlite/sqlite3/Microsoft.Data.Sqlite). Vectors: `sqlite-vec` extension or a flat `.npz` now; Qdrant only at fleet scale (the Box's tier).

**It's not a new genome trait** — it's the default *backing* for seams that already exist (`Spine` = run-state, `Memory`'s index, `TraceSink`, cost/metrics). And the genome/domain split matters: **KEEL owns its genome state** (spine/audit/traces/memory-index/metrics) in SQLite behind a `Store` seam; **apps own their domain schema** in their own SQLite (SEXTANT's `postings`, nightclerk's `receipts`). KEEL provides the *primitive*, not the schema — exactly like it provides the LLM without dictating the prompt.

## The primitives thesis: right thrust, one calibration — **resolve, don't embed**

Your bigger point — *apps shouldn't each embed an LLM; they should use a shared system inference layer (.NET-runtime-style; Chrome/Gemini-nano; LM Studio; and add Windows' Phi-Silica + macOS Foundation Models)* — **is correct, it's a real 2026 trend, and you've already been living it.** All 7 projects talk to a *shared* local server (llama-server/whisper-server/Ollama/LM Studio) over the OpenAI protocol, against shared weights in `C:\models` and shared servers in `C:\llama.cpp`/`C:\whisper.cpp`. The models live **once**; every app connects.

The calibration: **KEEL bakes in *knowledge + machinery*, not weights.**

| Bake INTO the KEEL binary (tiny, embeddable) | Reference as shared system assets (multi-GB, NOT embedded) |
|---|---|
| **SQLite** (~1 MB) | **Qwen3.x-vision** (text+eyes) via llama-server + mmproj |
| the **lifecycle/launcher/health/supervisor** | **Whisper** (ears) via whisper.cpp/whisper-server |
| the **protocol clients** (chat-completions, MCP) | (optional) a larger embedding/reranker model |
| the **substrate-resolver + fallback ladder** (below) | — |
| **`keel.lock`** — pinned model ids/hashes (reproducibility) | weights live in `C:\models`, download-once, pinned in lock |
| *(optional)* a **tiny embedding model** (~80 MB, CPU) so KEEL is never blind | — |

The Chrome-embeds-a-model analogy is actually the *wrong* one for KEEL — Chrome embeds because it's a monolithic consumer app that can't assume the host has anything. KEEL is *your* box, where shared inference *is* the point. **The right analogy is your own: the .NET runtime.** .NET isn't the CPU; it's the layer between apps and the CPU. **KEEL isn't llama.cpp; it's the layer between apps and llama.cpp (+ cloud + senses + memory + invariants).** So KEEL sits *above* the inference layer and *rides whatever the box has* — which is the concrete, most-valuable thing to add:

**The substrate resolver (a kernel capability — formalizes "use whatever exists"):**
1. Is an OpenAI-compatible server already running? (LM Studio `:1234`, Ollama `:11434`, llama-server `:8080`) → use it.
2. Can KEEL launch llama-server / whisper-server from the known paths (`C:\llama.cpp`, `C:\whisper.cpp`, `C:\models`)? → launch + supervise (the lifecycle module — photo2deck's `LlamaCppBackend` is the reference impl).
3. Cloud tier configured (`DEEPSEEK_API_KEY`, `ANTHROPIC_API_KEY`)? → route per the router.
4. Nothing → the embedded tiny model for trivial tasks, else fail honestly.

So the **canonical primitives KEEL assumes** are: **{Qwen3.x-vision = brain+eyes, Whisper = ears, an embedding model = recall, SQLite = state}** — SQLite *embedded*, the three models *resolved/launched/pinned in `keel.lock`*. SQLite is the one primitive small enough to embed; the models are the ones worth sharing. That asymmetry is the whole answer in one line.

## Net

KEEL now has **seven** grounding projects across **three** languages (Rust: Tenancy, Terminal · Python: TARS, REEL, the Box, SEXTANT · C#: photo2deck, nightscribe, nightclerk) — the strongest possible proof the genome is at the right altitude. The DB/primitives answer adds two things to the spec, both small: a **`Store` seam** (default embedded SQLite + the ledger/index discipline, backing the persistence seams that already exist) and a **substrate resolver** (discovery → launch → cloud → embedded-fallback, in `kernel::lifecycle`) plus `keel.lock`. No new top-level trait beyond `Store`.

That clears the gate you set. Whenever you say go, I'll write **KEEL v0.2 — the consolidated spec**: the nine traits + `PerceptionSource` (eyes **and** ears) + the REEL-shaped `Memory` (ringed assembly, lossless Tape, narrative-vs-factual registers) + MCP + the `Store`/SQLite ledger-index + the substrate resolver + `keel.lock` — one coherent document under the KEEL name, with the module list, the frozen-trait sketch, the invariants, the refusal list, and the falsifiers. Say the word and I'll write it as the first artifact in `C:\KEEL\`.

## You — Jun 13, 2026 13:09

yes, go and proceed. design this the absolute best you can, pay no deference to marrow or what came before, imagine this is cleanslate, and you get the blank canvas to paint this however you want, doing it the absolute best you can, that is the only goal, intent and directive here etc, and I think you are already on the mark, just go all out in terms of highest quality, clearest articulation , best spec and all that, for the tailored and custom thing that we are going for that we have talked about that culminated up to this exact here point in time etc. thanks. produce all in C:\KEEL\

## Claude — Jun 13, 2026 13:11

> _[thinking]_
> 

## Claude — Jun 13, 2026 13:11

Going all out. This is the culmination — the clean-slate KEEL canon, written KEEL-native with no deference to what came before. Producing the architecture canon plus its two companions (`README.md`, `keel.lock`) in `C:\KEEL\`.

## Claude — Jun 13, 2026 13:15

**[tool: Write]**
```json
{
  "file_path": "C:\\KEEL\\KEEL_ARCHITECTURE.md",
  "content": "# KEEL — Architecture Canon\n\n**Codename:** KEEL — *the backbone laid first, running the whole length, that everything is built upon and that keeps the vessel upright in any sea.*\n**Version:** 0.2.0 · **Status:** canon (spec-first; pre-implementation)\n**Author:** Bo Chen — Dallas–Fort Worth — June 2026\n**Lineage:** distilled as the *intersection* of seven independently-built systems across three languages (Tenancy, Terminal — Rust; TARS, REEL, the In-Home Companion, SEXTANT — Python; photo2deck, NightScribe, NightClerk — C#). KEEL is what every one of them rebuilt by hand. This document owes nothing to any prior framing; it is the thing itself, written once.\n\n> **One sentence:** *KEEL is a single-operator substrate that is the persistent, sovereign **self** — it perceives (eyes and ears), remembers, routes every unit of work to the cheapest brain that clears the trust bar, amplifies a small local model to punch above its weight, and grounds every critical output in an assertion no model authored — while the model that does the thinking is interchangeable, rented cognition plugged into a tiny stable core.*\n\n---\n\n## §0 · What KEEL Is\n\nThe API (local or cloud) is **rented cognition** — stateless, interchangeable, billed per token. KEEL is **the self** — persistent, user-owned, sovereign, portable across providers and across years. The model provides the thinking. KEEL provides the *remembering, the perceiving, the routing, the verifying, and the continuity.*\n\nKEEL is not an agent and not a loop. It is a **trust-and-cost economy with a tiny immortal core**, inside which a closed *verify-and-distill cycle* lets the cheapest available brain clear a bar that something no model authored has set. Off-the-shelf harnesses orchestrate a single expensive brain well; none treats trust as a routable quantity, keeps a sovereign local self, runs a distillation flywheel, or enforces an externality principle. That gap is the entire reason KEEL exists, and it is where every line of original code is spent.\n\nKEEL is the **genome**: a frozen set of contracts and invariants from which every specialization (a companion, an OCR clerk, a job-search conductor, a meeting scribe) is grown by composing periphery — *never* by editing the core. The genome is written once and reused forever; the cells are many and disposable.\n\n---\n\n## §1 · Intent & The Bet\n\n**Why build, not buy.** In the age of capable coding models it is now feasible to build custom software for nearly everything; the *harness* is the one primitive worth getting exactly right, because it is load-bearing under everything else and because it must encode *this operator's* judgment — the core-wire/scaffolding routing doctrine, the externality principle, the reversibility gate, the trust threshold. No off-the-shelf harness encodes that doctrine; bending one to fit is permanent impedance mismatch. So KEEL is built custom **at the core** and composes the periphery ruthlessly.\n\n**The atomic bet (applied recursively).** Make every interface a protocol; make every protocol uniform across providers; keep the kernel tiny and the seams sharp. Then capability accumulates by writing adapters, not by rewriting the kernel — and adaptability becomes a property of *smallness plus clean seams*, never of pre-built generality. The future is absorbed cheaply at the edges; it is never anticipated in the center.\n\n**Future-proofing, honestly stated.** You cannot future-proof against \"whatever AI becomes.\" You can (a) bet on the most durable protocols available, (b) keep the core small enough that a wrong bet is cheap to redo, and (c) write down the exact signals that say *re-architect* (§23). \"Never re-architect\" is a fantasy that breeds over-abstraction. \"Re-architect rarely, cheaply, and only on a falsifier trip, with a blast radius one adapter wide\" is the achievable, healthy version.\n\n---\n\n## §2 · Scope & Non-Goals (the honest envelope)\n\n**In scope:** one operator, one box (an RTX-class GPU + DeepSeek/Anthropic accounts). KEEL is the persistent self + the routing economy + the externality layer + the senses + the flywheel. It is consumed embedded (in-process) or over protocol (any language).\n\n**Non-goals (each a refusal, not an omission):**\n- **Not a product, not multi-tenant, not a framework for resale.** \"Universal/extensible\" means *the things this operator needs* — never a platform surface for others.\n- **Not the union of its verticals.** The genome is the **intersection** of the seven systems, never their union. The moment a vertical's heavy apparatus (an appliance's HIPAA escrow, a companion's inter-persona graph) migrates into the core, KEEL stops being able to serve the others. Genome stays small; periphery stays peripheral (§16).\n- **Not a new inference engine.** KEEL sits *above* the inference layer (llama.cpp, whisper.cpp, cloud), routing to and supervising it. It is the runt
…[truncated]
```
**[tool result]**
```
File created successfully at: C:\KEEL\KEEL_ARCHITECTURE.md (file state is current in your context — no need to Read it back)
```

## Claude — Jun 13, 2026 13:15

> _[thinking]_
> 

## Claude — Jun 13, 2026 13:15

Now the two companions — `keel.lock` (the substrate pin) and `README.md` (orientation/index):

## Claude — Jun 13, 2026 13:15

**[tool: Write]**
```json
{
  "file_path": "C:\\KEEL\\keel.lock",
  "content": "# keel.lock — the reproducible substrate KEEL expects.\n# Pin hashes when the models/servers are installed. The substrate resolver (kernel::lifecycle)\n# reads this to discover/launch/route; a fresh box is provisioned from it. Hashes are the\n# reproducibility contract — a run is replayable only against pinned weights.\n\nkeel:        { version: 0.2.0, stage: spec }   # spec -> stage0 -> stage1 -> stage2 -> stage3\n\n# --- canonical primitives ---------------------------------------------------\n# disposition: `embedded` = baked into the binary; `shared` = system asset, download-once.\nsubstrate:\n  llm_vision:                                   # brain + eyes (native multimodal, early-fusion)\n    id: qwen3.5-9b-q5_k_m\n    mmproj: mmproj-F16                           # llama.cpp serves Qwen vision via this projector file\n    sha256: TODO\n    mmproj_sha256: TODO\n    disposition: shared\n    fallbacks: [qwen3.5-4b-q4_k_m]               # smaller-VRAM tier (resolver picks by HardwareProfile)\n  audio:                                         # ears (separate organ; transcribes -> text pre-cognition)\n    id: whisper-large-v3-turbo\n    sha256: TODO\n    disposition: shared\n    fallback: whisper-base.en                    # faster-than-realtime CPU default\n    gate: vad                                    # transcribe only on voiced audio\n  embedding:                                     # recall + cheap routing-classification\n    id: all-MiniLM-L6-v2\n    sha256: TODO\n    disposition: embedded                        # tiny + CPU -> KEEL is never blind\n  store:                                         # the index (the ledger is files, see below)\n    engine: sqlite                               # baked into the binary (~1 MB, embeddable)\n    vector: sqlite-vec\n    disposition: embedded\n\n# --- inference servers (resolver targets) -----------------------------------\nservers:\n  llama_cpp: { path: \"C:\\\\llama.cpp\", endpoint: \"http://127.0.0.1:8080\", launch: managed }\n  whisper:   { path: \"C:\\\\whisper.cpp\", mode: \"cli|server\" }\n  models_dir: \"C:\\\\models\"\n\n# the substrate resolver tries these in order (use-whatever-exists, then launch, then cloud)\nresolver_order:\n  - probe_running:  [\"http://127.0.0.1:1234/v1\", \"http://127.0.0.1:11434/v1\", \"http://127.0.0.1:8080/v1\"]  # LM Studio / Ollama / llama-server\n  - launch_local:   [llama_cpp, whisper]\n  - cloud_tier:     [cheap-API, frontier]\n  - embedded_tiny:  [embedding]                  # trivial work only\n  - else:           fail   # SUBSTRATE_UNRESOLVED\n\n# --- tiers (the routing economy) --------------------------------------------\n# price is $/1M tokens (miss / hit / out); local is electricity, tracked as $0.\ntiers:\n  local:     { adapter: local_llama, model: qwen3.5-9b-q5_k_m, vision: true, price: { miss: 0.0,   hit: 0.0,      out: 0.0  }, default_effort: { n: 8 } }\n  cheap-API: { adapter: deepseek,    model: deepseek-v4-pro,   vision: false, api_key_env: DEEPSEEK_API_KEY, price: { miss: 0.435, hit: 0.003625, out: 0.87 }, default_effort: { n: 2, thinking: high } }\n  frontier:  { adapter: anthropic,   model: claude-opus-4-8,   vision: true,  api_key_env: ANTHROPIC_API_KEY, price: { miss: 5.0,   hit: 0.5,      out: 25.0 }, default_effort: { n: 1 } }\n\nrouter:\n  default_tier: local\n  sovereign_forces: local\n  perception_forces: local        # raw frames/audio never egress (I3)\n  escalate_after_oracle_failures: 2\n\n# --- persistence ------------------------------------------------------------\nledger:    { kind: files, dir: \".\\\\.keelstate\", audit: \"audit.jsonl\", tape: \"tape/\", traces: \"traces/\" }   # append-only, lossless, human-readable = system of record\nindex:     { kind: sqlite, file: \".\\\\.keelstate\\\\index.db\", derived: true, rebuildable_from: ledger }       # queryable, disposable\n\n# --- invariants (pins for the freeze check) ---------------------------------\ngolden:     { set_sha256: TODO }   # agent-frozen ground truth; operator-only --update\nthresholds: { rework_rate_max: 0.10, cache_hit_min: 0.70, escalation_rate: downward_trend }\n"
}
```
**[tool result]**
```
File created successfully at: C:\KEEL\keel.lock (file state is current in your context — no need to Read it back)
```

## Claude — Jun 13, 2026 13:15

> _[thinking]_
> 

## Claude — Jun 13, 2026 13:16

**[tool: Write]**
```json
{
  "file_path": "C:\\KEEL\\README.md",
  "content": "# KEEL\n\n*The backbone laid first, running the whole length, that everything is built upon and that keeps the vessel upright in any sea.*\n\nKEEL is a single-operator substrate — the persistent, sovereign **self** that perceives (eyes and ears), remembers, routes every unit of work to the cheapest brain that clears the trust bar, amplifies a small local model to punch above its weight, and grounds every critical output in an assertion no model authored. The model that does the thinking is interchangeable, rented cognition plugged into a tiny stable core.\n\n> The API is rented cognition — stateless, interchangeable, billed per token.\n> **KEEL is the self** — persistent, user-owned, sovereign, portable across providers and across years.\n\n**Status:** spec-first, pre-implementation. The canon is finished the moment it stops being a substitute for a running binary.\n\n---\n\n## Read this first\n\n- **[`KEEL_ARCHITECTURE.md`](./KEEL_ARCHITECTURE.md)** — the canon. Intent, the three protocol bets, the five invariants + reversibility gate, the layered architecture, **the ten boundary contracts (the joints)**, the closed loop, the router, the externality layer, memory, perception (eyes & ears), the substrate, the module inventory, the refusal list, the staged build plan, and the falsifiers. Everything is here.\n- **[`keel.lock`](./keel.lock)** — the reproducible substrate KEEL expects (models, servers, tiers, the resolver order, the ledger/index split).\n\n## The shape, in one screen\n\n```\nL5  apps          consume services; expose KEEL (CLI · OpenAI egress · MCP server · embed lib)\nL4  services      route · amplify · verify · memory · perception · driver\nL3  middleware    audit (I1) · privacy (I3) · cost (I4) · cache        ← invariants, unbypassable\nL2  adapters      local_llama(+vision) · whisper(ears) · deepseek · anthropic · mcp · store(sqlite)\nL1  kernel        manifest · context · registry · chain · lifecycle(+substrate resolver) · engine · lock\nL0  contracts     the ten joints + agent-frozen golden cases\n```\n\n**The closed loop:** `route → amplify → verify (externally) → record → recalibrate / distill`. Each verified trace makes the next run cheaper and safer. The proof it ignited: `escalation_rate` trending down.\n\n## Genome, not framework\n\nKEEL is the **genome** — a frozen set of contracts + invariants, written once. Every use is a **cell**: *genome + periphery*, composed, never a core edit. The genome is the *intersection* of seven systems that each rebuilt this skeleton by hand (Tenancy, Terminal, TARS, REEL, the In-Home Companion, SEXTANT, photo2deck/NightScribe/NightClerk) — never their union.\n\n## How it's consumed\n\n- **Embedded** (in-process, native) — Rust/Tauri apps link the core.\n- **Over protocol** (any language) — Python/C# apps talk to a KEEL binary via OpenAI-compatible egress, MCP, or HTTP.\n\nOne genome; Rust, Python, and C# all consume it.\n\n## Substrate (resolved, not embedded)\n\nKEEL sits *above* inference — it discovers / launches / supervises / routes to whatever the box has (its own `llama-server`/`whisper-server`, an existing LM Studio/Ollama, or cloud), and falls back gracefully. The canonical primitives: **Qwen3.x** (brain + eyes), **Whisper** (ears), an **embedding model** (recall), and **SQLite** (the index). SQLite is baked in; the models are shared system assets pinned in `keel.lock`. The ledger is append-only files (the system of record); the index is disposable SQLite (rebuildable from the ledger).\n\n## Build order (each stage independently useful; falsifier-gated)\n\n0. **Spine** — contracts + kernel + two tiers + invariant middleware + ledger + store + CLI + egress.\n1. **Amplification & senses** — constrained decoding, router, best-of-N (ships off), perception (eyes + ears), cache.\n2. **Correctness & memory** — golden registry + freeze, verifier + joint-wrong, ringed memory, metrics.\n3. **Flywheel** — verified-trace distillation; `escalation_rate` trends down.\n\n**First real cell:** build **SEXTANT** on KEEL. Done = its Conductor/Router/Gate/Canon/State come *from* KEEL unchanged; only job-domain periphery is written. If it forces a kernel edit, KEEL's boundary is wrong — fix KEEL first.\n\n---\n\n*Build Stage 0 first.*\n"
}
```
**[tool result]**
```
File created successfully at: C:\KEEL\README.md (file state is current in your context — no need to Read it back)
```

## Claude — Jun 13, 2026 13:16

> _[thinking]_
> 

## Claude — Jun 13, 2026 13:16

**[tool: Bash]**
```json
{
  "command": "echo \"===== C:\\KEEL\\ =====\"; find /c/KEEL -type f 2>/dev/null | while read f; do printf \"%8s  %s\\n\" \"$(stat -c%s \"$f\")\" \"$f\"; done | sort -k2",
  "description": "Confirm KEEL directory contents"
}
```
**[tool result]**
```
===== C:\KEEL\ =====
   49240  /c/KEEL/KEEL_ARCHITECTURE.md
    4264  /c/KEEL/README.md
    4029  /c/KEEL/keel.lock
```

## Claude — Jun 13, 2026 13:16

> _[thinking]_
> 

## Claude — Jun 13, 2026 13:16

Done. `C:\KEEL\` now holds the clean-slate canon and its two companions:

| File | | What it is |
|---|---|---|
| **[KEEL_ARCHITECTURE.md](C:\KEEL\KEEL_ARCHITECTURE.md)** | 49 KB · 23 § | the canon — written KEEL-native, no deference to anything prior |
| **[keel.lock](C:\KEEL\keel.lock)** | 4 KB | the reproducible substrate (models, servers, tiers, resolver order, ledger/index) |
| **[README.md](C:\KEEL\README.md)** | 4 KB | one-screen orientation + build order |

**The canon's spine:** the one-sentence thesis (*rented cognition, owned self*) → intent & the bet → the honest envelope (intersection, not union) → the three protocol bets (chat-completions, **MCP**, OpenAPI) → glossary with forbidden synonyms → the five invariants + reversibility gate (with *where* each is enforced) → the layered architecture + import rule → **the ten joints as frozen Rust traits with proposed golden cases** → the closed loop (the engine) → the router → the externality layer → memory → perception → the substrate → the module inventory → consumption → the refusal list → the seven verticals → error taxonomy → NFRs → ADRs → the falsifier-gated build plan → what-will-kill-this → falsification conditions.

**Every decision from our whole arc is captured and load-bearing in it:** KEEL as the genome (not a framework); protocol-first with MCP in from the get-go; a **native Rust single-binary core** (for embeddability/footprint, *not* orchestration speed) consumed embedded *or* over protocol so Rust/Python/C# all use it; **eyes and ears as afferent senses** with efferent (speech/image-gen) deferred to `ToolHost`; **REEL-shaped memory** with the narrative-vs-factual register split; the **ledger(files)/index(SQLite)** discipline; the **substrate resolver + keel.lock** (resolve, don't embed weights); **trust as a routable quantity**; `amplify` shipping **off** (the honest 1-of-7 note); the refusal list that keeps the genome the intersection; SEXTANT as the first real cell whose build collapses to job-domain periphery.

**Two things that are genuinely yours to settle, not mine to assume:**
1. **The golden cases are marked *proposed*, not frozen.** Per your own rule, golden cases are operator-authored ground truth — I sketched illustrative ones to pin the contract shapes, but they become agent-frozen only when *you* ratify and freeze them. That's a deliberate line I didn't cross.
2. **The canon is yours to ratify or amend** before it's law.

We've been moving one step at a time, so I'll hold here rather than barrel into code. The natural next artifact is the one that unlocks everything else: **freeze the ten contracts (L0) in Rust — the genome's joints + the ratified golden cases** — because once those are frozen, the whole core generates against fixed interfaces in parallel. After that, Stage 0 (the spine), then SEXTANT as the proof.

Want to review/amend the canon first, or should I draft the frozen L0 contract layer next?

## You — Jun 13, 2026 13:25

let me review first, I'll get back with you with another question next. thanks.  okay so one feedback :: ->>>>  https://huggingface.co/Qwen/Qwen3-Reranker-4B
https://huggingface.co/Qwen/Qwen3-Reranker-0.6B

///

you mentioned up above the optional that can add reranker etc, then i had a chat with another claude web about it while you were writing the spec documents and this is what it had to say and also i want your own thoughts on all this? should a reranker/embedder etc be added at this point etc? 

the other model was itself going back and forth and i could see how either way could be fine

\\\\

"""""This is a meaty architecture question about your own spec, and the README is only the surface — the real detail lives in the canon and the lock file, neither of which is in front of me yet. Let me read them properly before I weigh in. There's also a methodology skill you've got loaded that's directly on-point for a contract-first genome like this, so I'll check that first.The picture's getting sharp, and it turns out you already did most of the hard part. Let me check the lock file to see the exact substrate format before I lay this out.I read the canon and the lock, and here's the thing you should hear first: **you already did this.** You're not adding a missing primitive — you're deciding whether to promote two things you already half-carved into first-class organs. That distinction changes the whole answer.

Concretely: `keel.lock` line 24 already pins an embedder (`all-MiniLM-L6-v2`, `disposition: embedded`, with the sharp double-duty note "recall + cheap routing-classification"). And §11 already cut the reranker seam — *"a `rerank()` that defaults to identity (pass-through) and upgrades to a cross-encoder."* Embedding search is named as the default; the reranker is a declared upgrade path. So the genome already anticipated both.

That matters because of your own §23 test: *"a cell can't be built without a kernel/contract edit → the genome boundary is wrong."* Adding a real reranker and upgrading the embedder costs you **two adapters + two lock entries and zero kernel or contract edits** — the Memory joint, the protocol bets (HTTP, §3.3 already lists "embeddings"), and the ledger/index split all absorb it at the edges. The fact that it slots in clean is the boundary *passing its own falsifier*. So: yes, do it, and read that as validation, not new design.

Now the part worth actually thinking about.

**The asymmetry that should drive how you spec these.** Your §0 thesis — "the model is interchangeable, rented cognition, swappable across providers and years" — is true for the generator and true for the reranker, but it is *false for the embedder*, and the spec should say so out loud. The reranker is stateless: it scores a (query, doc) pair and forgets. Swap it freely, like the generator. The embedder is the opposite — the moment you embed your corpus, every vector in the index lives in *that model's* vector space. Swap embedders and the index is silently garbage; you must re-embed everything. The embedder isn't rented cognition, it's a **format decision** — closer to "what encoding is the index in" than "which brain answers this turn."

Here's why that's good news rather than a problem: your ledger/index split already de-risks it perfectly. ADR 8 and lock lines 61–62 make the index `derived: true, rebuildable_from: ledger`. So an embedder swap isn't data loss — it's a bounded re-index from the Tape, which is the system of record anyway. The architecture already handles the one place its central thesis breaks. I'd just make it explicit in §11 or §20: *the embedder is the sole exception to tier-interchangeability; changing it is an index migration, not a hot-swap; pin it harder than the generator.*

**The failure mode this creates is a JOINT_WRONG, and it wants a deterministic gate.** Picture swapping `all-MiniLM-L6-v2` (384-dim) for `Qwen3-Embedding-0.6B` (1024-dim) and forgetting to rebuild. Best case the dim mismatch throws. Worst case — same dim, different model — the index happily returns plausible-but-wrong neighbors, the wrong memories get injected into Ring 4, and the model reasons over them. Everything looks green. That's textbook JOINT_WRONG (§4), on the retrieval path. The fix is the oracle-flavored move you already use elsewhere: **stamp the index with an embedder fingerprint** (model id + revision + dim), and have `store` *refuse to serve or auto-trigger a rebuild* on mismatch. It's a non-model assertion — "these vectors were produced by the embedder you're currently resolving" — which is exactly the spirit of I5 applied to recall. Cheap, deterministic, and it closes the silent-corruption door.

**Embeddings are an I3 surface — this argues for keeping the local embedder load-bearing.** Your I3 forces sovereign/perception data local and says raw perception "may never leave the box." Embeddings leak two ways: a cloud embedding API egresses the raw text outright, and — less obvious — embedding-inversion attacks can partially reconstruct source text from the *vectors alone*, so shipping vectors to a cloud vector DB is itself a sovereignty leak. So I3 should explicitly cover the embedding path: **sovereign/PHI content must be embedded locally and its vectors must stay in the local index.** The embedder organ inherits sovereign-by-default exactly like the retina and cochlea. Practical consequence: a cloud embedder is only ever permissible for `Normal`-class data, which means a *capable local embedder isn't a nice-to-have, it's required for the sovereign corpus* — reinforcing why this belongs pinned in the substrate, not delegated to an API.

**Where they live — and where they must not.** These are **Memory organs, not Perception organs, and not a tier.** Your retina/cochlea metaphor is for afferent senses that turn a modality into text (world → text, §12). The embedder is a different class: it turns text into a retrievable address — the *engram* faculty — and the reranker is *recall-attention*, deciding which recalled traces are actually relevant now. Both belong to §11, invoked inside `memory.assemble` for Ring 4, never filed under §12. And critically: **they are not a fourth tier and the router must not route to them.** Tiers (local/cheap-API/frontier) are cognition sources the router picks between; the embedder/reranker serve Memory, off the routing economy entirely. Keep the tier enum and `router.route` clean — this is recall infrastructure on a different axis. (Your lock's `embedded_tiny: [embedding]` in `resolver_order` is fine because that's the *resolver*, not the router — though I'd rename it to make clear it's a recall/classification asset, not a degraded cognition tier.)

**Concretely, here's the shape I'd pin.** The embedder needs a fallback ladder like everything else (right now it's a single point — your LLM has `qwen3.5-4b` fallback, Whisper has `base.en`, the embedder has nothing):

```yaml
embedding:                          # recall + cheap routing-classification — a Memory organ, not a tier
  id: qwen3-embedding-0.6b-q8       # the capable local default (1024-dim, sovereign-safe)
  sha256: TODO
  dim: 1024                         # fingerprinted into the index; mismatch ⇒ rebuild-from-ledger
  disposition: shared               # download-once system asset, like whisper + the llm
  fallback: all-minilm-l6-v2        # 384-dim, embedded, CPU — the "never blind" floor
  sovereign_forces: local           # I3: sovereign/PHI text never embeds off-box

rerank:                             # the cross-encoder upgrade to Memory's rerank() sub-seam
  id: qwen3-reranker-0.6b-q8
  sha256: TODO
  disposition: shared
  default: identity                 # SHIPS OFF (§11) — pass-through until a falsifier earns it on
```

Note the floor/upgrade split mirrors your existing dispositions: the tiny MiniLM stays `embedded` (your §22 #9 "only SQLite and maybe a tiny embedder is embedded" — keep that, it's the CPU floor that guarantees recall + routing-classification even with no server), and the capable Qwen embedder is `shared`, resolved when present.

**Treat the reranker as "the `amplify` of retrieval."** This is the cleanest fit to your own doctrine. Just like best-of-N ships disabled and has to beat single-pass on a fixed benchmark (§8, §23) before it earns its place, the cross-encoder ships as `identity` and has to beat pass-through on a fixed **golden-recall set** — operator-authored `query → expected-memory` pairs scored on Recall@k / nDCG — or it stays off permanently. Same pattern, new seam. That gives you two §23 falsifiers to add:

- *Rerank:* if the cross-encoder can't beat identity on the golden-recall set by enough to justify its latency, ship `rerank: identity` permanently; embedding-search-only is the complete system.
- *Embedder upgrade:* if `qwen3-embedding-0.6b` doesn't beat the MiniLM floor on that same set by enough to justify the download and the full re-index, keep the floor.

And this is where it ties back to the methodology you're already running on: retrieval *is* an AI component, so it gets an eval suite, and your agent-frozen golden discipline (§10) extends to it as a `GOLDEN_RECALL` register. That's the thing that decides on/off — not vibes.

One last sharpening of your own double-duty note. You already spotted the embedder doubles as "cheap routing-classification" (embed the step, nearest-neighbor against labeled exemplars → a model-free difficulty/type classifier — perfect for §9's "cheap rules heuristic, not a model call"). The reranker has an analogous second use: a cross-encoder relevance scorer is *almost* a "does this retrieved Canon chunk actually support the claim?" scorer — which is adjacent to your job-conductor's "every claim traces to the Canon" oracle (§10). Tempting, but keep them on opposite sides of the loop: **the reranker scores relevance (input side, Memory → Engine); the oracle asserts correctness (verification side, Engine → Oracle).** A reranker is model-authored, so it can never *be* an oracle (that'd be the §22 #6 trap). Useful adjacency, hard boundary.

Net: it's a Stage-2 addition (lands with `svc.memory`, not Stage 0), it's adapters-and-lock-entries only, the embedder gets a fallback ladder + a fingerprint gate + an explicit I3 clause, and the reranker ships as identity behind a falsifier. Nothing touches the kernel or the ten joints — which is the whole point.

Want me to draft the actual spec patch — the §11 amendment, the I3 clause, the two §23 falsifiers, and the `GOLDEN_RECALL` stub — as a clean diff you can drop into the canon?""""""

## Claude — Jun 13, 2026 13:27

> _[thinking]_
> 

## Claude — Jun 13, 2026 13:28

Good feedback to bring me — and that other instance did genuinely sharp work. My honest read: it's **mostly right, three of its points are load-bearing enough that I'd adopt them into the canon, and I'd push back on exactly one thing plus add a frame it didn't quite reach.** Let me separate the signal.

## What it nailed (credit where due)

- **The embedder is *not* interchangeable like the generator — it's a format decision.** This is the best point in the piece and it's correct: swap the generator or the reranker freely (stateless — score and forget), but swap the embedder and every vector in the index is silently in the wrong space. The §0 "rented cognition, interchangeable" thesis genuinely has a hole here, and it should be named.
- **The mismatch is a silent JOINT_WRONG on the recall path → fingerprint the index.** Stamp the index with the embedder's `(id, revision, dim)`; `store` refuses to serve or auto-rebuilds on mismatch. That's I5 applied to recall — a non-model assertion that the vectors match the embedder you're resolving. Cheap, deterministic, closes a real silent-corruption door. I'd adopt it.
- **Embeddings are an I3 surface.** A cloud embedding API egresses the raw text, *and* embedding-inversion (vec2text-style reconstruction) means shipping the **vectors** is itself a leak. So sovereign/PHI text must embed locally and its vectors must stay local — the embedder inherits sovereign-by-default like the retina and cochlea, which makes a capable **local** embedder *required*, not optional. Correct, and I should have caught it.
- **They're Memory organs, not a tier — the router must not route to them.** Right. The retina/cochlea turn modality→text (perception); the embedder turns text→address (the engram faculty) and the reranker is recall-attention. Both live in §11, invoked inside `memory.assemble`, off the routing economy entirely.
- **The reranker is "the `amplify` of retrieval": ships `identity`/off, earns its place on a `GOLDEN_RECALL` set or stays off.** This is exactly my own doctrine (amplify ships off, must beat single-pass) extended to a new seam. Clean. I'd adopt the falsifier and the golden register.

## Where I'd sharpen or push back

1. **The deeper frame it stopped just short of.** It said the embedder is "the *sole* exception to interchangeability." Almost — the truer rule is: **interchangeability holds for *stateless* cognition (generator, reranker, the senses' models); it breaks for anything that commits a persistent *format or corpus*.** The embedder is the first and clearest instance (it commits the index's vector space), but the same class includes the prompt-cache prefix and — at Stage 3 — the distilled LoRA (which commits the local model to a behavior the verified traces assume). Framing it as "the format/corpus-committing class is pinned harder than the generator" is more durable than "the embedder is the one exception," and it pre-answers the same question for the flywheel.

2. **One real coupling caveat it missed.** It endorsed the embedder's double-duty as a "model-free routing classifier" (embed the step → kNN against labeled exemplars). Fine as an *enhancement* — but §9 says the router's hard constraints use a *rules* heuristic, **not a model call**, precisely so they always work. An embedding-kNN classifier *is* a (cheap) model call and depends on the embedder being resolved. So: the router's hard constraints (sovereign→local, budget→BLOCK, perception→local) stay pure rules, always available; the embedding-kNN classifier is an *optional* tie-breaker for ambiguous difficulty, never load-bearing. Keep the always-must-work path free of the embedder dependency.

3. **Don't over-patch the canon now — separate the forever-true from the Stage-2 how.** It offered a full §11 spec patch. I'd be more disciplined: add only the **invariant/contract-level** clauses now (they're true forever and cheap), and **defer the implementation section to Stage 2**, where retrieval actually lands with `svc.memory`. The seam already exists (§11's `rerank()`, the lock's embedder, §3's "embeddings") — that it absorbs all this at the edges with zero kernel/contract edits *is the boundary passing its own §23 falsifier*, which is the whole point and the reason there's no urgency to write the impl now.

4. **It's intersection-validated by your own projects — which it couldn't see.** It reasoned from the canon alone. But **REEL §7.3 already specced this exact two-stage retrieval** (embedding search → cross-encoder reranker, persona-weighted, pass-through default — it even named `bge-reranker-v2-m3`), and **the In-Home Companion's Part 5 used Qwen3-Embedding-4B + Qwen3-Reranker-4B + BM25 sparse (hybrid)**. So this isn't a speculative addition — it's the 8th and 9th rediscovery of a seam two of your systems already built. (Corollary it didn't raise: mature retrieval is often *hybrid* dense+sparse; that backend choice also lives behind the Memory seam, so don't over-spec it now either.)

## My answer to your actual question

**Yes — but precisely, and not as a Stage-0 thing:**

- **Embedder:** effectively *already in* (pinned in `keel.lock`). Upgrade its *treatment*, not just its model: it's a format-committing Memory organ (not a tier), sovereign-by-default under I3, with a fallback ladder (capable local default + the embedded MiniLM floor it currently has) and an index fingerprint gate. The capable local embedder is **required** for the sovereign corpus, not a nice-to-have.
- **Reranker:** the seam is already cut. Ship it **off** (`identity`), let each cell earn it on a `GOLDEN_RECALL` benchmark. Some cells (the Box, SEXTANT, over a large corpus) will turn it on; a companion over conversation memory likely won't — which is exactly why it's pluggable and per-cell.
- **Timing:** Stage 2, with `svc.memory`. You don't need recall to talk to two tiers and log every call (Stage 0).
- **Cost to the genome:** two adapters + lock entries + a few invariant clauses; **zero** kernel/contract/ten-joint edits.

So the net effect on the canon is small and surgical. When you've finished your review and want it, the **minimal patch** I'd apply is: (1) a one-clause §0/§20 correction — *stateless cognition is interchangeable; format/corpus-committing components are pinned harder* (embedder, cache-prefix, LoRA); (2) extend **I3 (§5)** to cover embeddings and vectors explicitly; (3) one line in §11 — *embedder/reranker are Memory organs, not a tier; the index carries an embedder fingerprint, mismatch ⇒ rebuild-from-ledger*; (4) two §23 falsifiers (rerank-vs-identity, embedder-upgrade-vs-floor) + a `GOLDEN_RECALL` register named alongside the other goldens; (5) update `keel.lock`'s `embedding` entry (Qwen3-Embedding default + MiniLM floor + `dim` + `sovereign_forces: local`) and add a `rerank` entry (Qwen3-Reranker, `default: identity`).

I'll hold and not touch the canon while you're reviewing — say the word and I apply exactly that patch, nothing more. What's the next question?

## You — Jun 13, 2026 13:32

hold those thoughts, i have one more thing to add and then we can finalize this stage, got it? search online if you want, but also i first asked the web claude version this same question and i'll share its answers with you here too: i asked: """wait, pivot to this, you know how openai released whisper? they also released a privacy filter in recent weeks, https://openai.com/index/introducing-openai-privacy-filter/ ; https://huggingface.co/openai/privacy-filter ; should this, along with whatever regex, make it into the KEEL spec at all etc? and if so, in what form or to what degree""""  and it responded as : """"Good pivot — and this one lands right on your I3 seam, so it's worth getting right. But before I spec a dependency into your canon, I need to verify it actually exists and see what it really is. "Released in recent weeks" is past my knowledge cutoff, so let me fetch both links rather than take the claim at face value.Confirmed real — OpenAI Privacy Filter, released April 22, 2026, Apache 2.0. Let me grab the model page too so I can be precise about how it actually runs, since that determines where it slots in your stack.Real, and a genuinely good fit for your I3 seam — but the way it fits is more specific than "add a privacy model," so let me lay out the shape.

First, what it actually is, because it changes everything about placement: it's **not a chat model, it's a token classifier.** It's a bidirectional token-classification model derived from a gpt-oss-style checkpoint — 1.5B total / 50M active params, sparse MoE, that labels every token in a single forward pass and decodes spans with a constrained Viterbi procedure, exposed through the HF `token-classification` pipeline (and ONNX / transformers.js for browser/WebGPU). Apache 2.0, runs locally, 128K context, eight categories — private_person, private_address, private_email, private_phone, private_url, private_date, account_number, and secret (which covers passwords and API keys). So in KEEL terms it is emphatically **not a `ModelTier`** and the router never touches it. It's an internal classifier behind your existing `mw.privacy` middleware — substrate, pinned in `keel.lock`, surfaced through a seam you already declared. You even reserved the slot: ADR #7 lists a "PII scanner" as an FFI hot-path candidate, and `mw.privacy` is already Stage 0. Same pattern as before — it absorbs at the edges, zero joint/tier/kernel edits, which is your §23 test passing again.

Now the parts worth thinking hard about.

**Your I3 is quietly doing two different jobs, and this model only does one of them.** "Every egress passes the filter; sovereign forced local" bundles (a) a *gate* — is this payload sensitive enough to force local? — and (b) a *mask* — this is egressing, scrub the PII out of it first. Those are different operations: the gate is a coarse whole-payload decision that flips the tier to `local`; the mask is a fine-grained span-level transform on content that's already cleared to leave. The Privacy Filter is built for (b), the nuanced masking regex can't do. It can *feed* (a) as a detector, but its real value is the masking sweep. Worth splitting these explicitly in the I3 wording, because right now they read as one thing and they have different failure consequences.

**The doctrine-critical point: it's a model, so it cannot be I3's guarantee.** This is where KEEL's own philosophy decides the design. It scores 96% F1 — 94% precision, 98% recall — on PII-Masking-300k, which means it misses real PII ~2% of the time. For a *safety invariant*, a probabilistic model judging its own boundary is exactly the thing you refuse everywhere else — it's I5 ("a model may not author its own ground truth") and the §22 #6 trap ("the oracle becoming an LLM") wearing a privacy hat. So the architecture has to be layered, with the deterministic part carrying the guarantee and the model carrying recall:

1. **Operator sovereign markers** — your own name, addresses, accounts, keys: known exact strings, matched deterministically, agent-frozen like your goldens (the agent may never edit the privacy policy). This is the floor and it's 100% recall on *you*, which for a single-operator substrate is the highest-value rung and needs no model at all.
2. **Structured regex + checksums** — emails, phones, credit cards (Luhn-validated), known key formats (`sk-…`, `AKIA…`), URLs. Deterministic, zero-FN on patterns it knows. This is your *non-model assertion* of "PII present" — the oracle of the privacy layer.
3. **OpenAI Privacy Filter** — the context-aware sweep for what 1 and 2 structurally can't catch: third-party names, private addresses, dates that are private only in context, novel secrets. Probabilistic, additive, never sole.

The composition rule is your reversibility gate applied to privacy: **egress only if all layers clear; redaction is the union of every layer's spans; the gate fails toward `local`.** Leak-uncertain ⇒ treat as sovereign, exactly like reversibility-uncertain ⇒ irreversible. And the regex/model pairing isn't redundant — they cover each other's holes almost exactly. Regex misses subtle, context-dependent PII; the model misses novel credential formats, project-specific identifiers, and secrets split across surrounding syntax. Neither alone is enough; together they're strong.

**The highest-value extension is one your spec doesn't currently cover: the internal sinks, not just egress.** I3 guards egress to cloud. But that `secret` category matters most against two *internal* paths. Your ledger is append-only and lossless — once a secret lands in the Tape it's permanent. And worse, your Stage 3 flywheel distills verified traces into a LoRA: **a secret that rides a trace into the distillation set gets baked into model weights — an irreversible leak that no later redaction can undo.** OpenAI literally pitches this use: building privacy protections into training, indexing, logging, and review pipelines — which is your distill, index, ledger, and verifier line for line. The nuance: the ledger itself is sovereign-local and never egresses, so secrets sitting there are "safe" as long as the box is; but the **trace → distill path is where a secret escapes into weights**, so that path specifically needs secret-scrubbing before a trace becomes feedstock. That's an extension of I3 (or a sibling invariant) onto the write-path, and it's arguably more important than the egress case because the blast radius is permanent.

**Form and degree — and the case for restraint.** It's substrate: pinned in `keel.lock` behind `mw.privacy`, roughly Whisper-tier footprint (50M active params, runs on a laptop or in a browser), so `embedded`-or-`shared` like your tiny embedder, and cheap enough to run on every egress without being a latency tax (single forward pass). But proportionate to the actual threat: KEEL is one operator who *consented* to sending their own work to DeepSeek/Anthropic, so the real exposure isn't the operator's data — it's **third-party PII in the corpus** (correspondents, scanned docs, the Companion perceiving other people) and **secrets in permanent sinks**. The deterministic floor (rungs 1–2) is cheap and clearly worth it now — fold it into the Stage 0 `mw.privacy` you already have. The *model* (rung 3) earns its place when perception + memory bring third-party-heavy corpora online, i.e. Stage 2 — and it ships behind the same falsifier discipline as everything else: *does it catch enough PII that regex + markers miss, on an operator-authored PII golden set, to justify the dependency?* If not, deterministic-only is a complete privacy layer. Set its operating point toward recall (the Viterbi transition bias is runtime-tunable toward broader masking) so it over-redacts rather than leaks — and note that over-redaction has a cost too: for *critical* outputs that need full context, prefer forcing local over redact-and-egress, since redaction-induced context loss can silently corrupt the result. So even the redact-vs-force-local choice rides your existing `critical` flag.

Two caveats to bank honestly before you trust the recall number:

- **Banded attention.** Despite 128K context, it uses banded attention with band size 128 — an effective window of only ~257 tokens. So it sees PII *locally*; privacy that depends on a reference 5,000 tokens away from the name isn't its strength. Your markers and regex don't care about distance, so they cover the known long-range cases the model can't connect.
- **The fairness-weighted leak.** Its own card is blunt that it under-detects uncommon names, regional naming conventions, and underrepresented naming patterns, and these failures interact with demographic and regional variation. A privacy filter that misses minority names more often is a biased leak surface — another reason the deterministic markers carry the guarantee and high-sensitivity workflows keep a human path, rather than over-trusting the 98% recall headline.

Net: yes, it belongs — as the **recall layer of a three-rung `mw.privacy`, not as I3's guarantee**; explicitly alongside regex, never instead of it; pinned substrate with zero changes to your joints or tiers; deterministic floor in Stage 0, model in Stage 2 behind a falsifier; and the one real spec *addition* is extending privacy enforcement onto the trace→distill write-path so a secret can't get fossilized into a LoRA. The I3 amendment writes itself: name the gate-vs-mask split, name the three rungs with the deterministic floor as the non-model assertion, and add the internal-sink clause.

This and the embedder/reranker changes are all the same patch to the same two files. Want me to write that patch now — the revised I3, the `mw.privacy` three-rung spec, the `keel.lock` entries for the privacy model plus the embedder/reranker, and the new falsifiers — as one clean diff against your canon?""""""  NOW i want your own independent thoughts on all this ....

## Claude — Jun 13, 2026 13:34

> _[thinking]_
> 

## Claude — Jun 13, 2026 13:35

Before I weigh in on pinning a third-party dependency into the canon, I'll do what the right instinct demands — verify it independently rather than take the spec on faith (it's after my January 2026 cutoff). Let me load web access and confirm.

## Claude — Jun 13, 2026 13:35

**[tool: ToolSearch]**
```json
{
  "query": "select:WebSearch,WebFetch",
  "max_results": 5
}
```
**[tool result]**
```
{"type":"tool_reference","tool_name":"WebSearch"}
{"type":"tool_reference","tool_name":"WebFetch"}
```

## Claude — Jun 13, 2026 13:35

> _[thinking]_
> 

## Claude — Jun 13, 2026 13:35

**[tool: WebSearch]**
```json
{
  "query": "OpenAI Privacy Filter open weights PII token classification model 2026"
}
```
**[tool result]**
```
Web search results for query: "OpenAI Privacy Filter open weights PII token classification model 2026"

Links: [{"title":"OpenAI Releases Privacy Filter: A 1.5B-Parameter Open-Source PII Redaction Model with 50M Active Parameters - MarkTechPost","url":"https://www.marktechpost.com/2026/04/28/openai-releases-privacy-filter-a-1-5b-parameter-open-source-pii-redaction-model-with-50m-active-parameters/"},{"title":"Model Card for OpenAI Privacy Filter OpenAI April 22, 2026 1","url":"https://cdn.openai.com/pdf/c66281ed-b638-456a-8ce1-97e9f5264a90/OpenAI-Privacy-Filter-Model-Card.pdf"},{"title":"Introducing OpenAI Privacy Filter | OpenAI","url":"https://openai.com/index/introducing-openai-privacy-filter/"},{"title":"OpenAI Privacy Filter FREE: Complete Guide to the Open-Source Model That Masks Personal Data Offline (GPU and CPU)","url":"https://pasqualepillitteri.it/en/news/1351/openai-privacy-filter-pii-masking-offline-gpu-cpu"},{"title":"OpenAI New AI model : Privacy Filter | by Mehul Gupta | Data Science in Your Pocket | Apr, 2026 | Medium","url":"https://medium.com/data-science-in-your-pocket/openai-new-ai-model-privacy-filter-63c116a4e577"},{"title":"GitHub - openai/privacy-filter: OpenAI Privacy Filter · GitHub","url":"https://github.com/openai/privacy-filter"},{"title":"openai/privacy-filter · Hugging Face","url":"https://huggingface.co/openai/privacy-filter"},{"title":"OpenAI Privacy Filter: Open-Weight PII Detection That Runs Locally (2026)","url":"https://www.aimadetools.com/blog/openai-privacy-filter-guide/"},{"title":"OpenAI Privacy Filter: open-weight on-device PII redaction","url":"https://daniliants.com/insights/introducing-openai-privacy-filter/"},{"title":"OpenAI Privacy Filter: A New PII Model You Can Run Locally — Grepture","url":"https://grepture.com/blog/openai-privacy-filter-pii-redaction"}]

Here are the search results for "OpenAI Privacy Filter open weights PII token classification model 2026":

## Summary

OpenAI released Privacy Filter in April 2026, an open-weight model built specifically for detecting and redacting personally identifiable information (PII) in text.

### Model Specifications

The released model has 1.5B total parameters with 50M active parameters. Released on Hugging Face under an Apache 2.0 license, Privacy Filter is an open, bidirectional token-classification model purpose-built for detecting and redacting personally identifiable information (PII) in text.

### Key Features

It is small enough to run in a web browser or on a laptop and fast enough for high-throughput data sanitization pipelines. The released model supports up to 128,000 tokens of context.

### Detection Capabilities

It detects eight categories of sensitive spans: account_number, private_address, private_email, private_person, private_phone, private_url, private_date, and secret.

### Performance

On the PII-Masking-300k benchmark, Privacy Filter achieves an F1 score of 96% (94.04% precision and 98.04% recall), and on a corrected version accounting for dataset annotation issues, the F1 score is 97.43% (96.79% precision and 98.08% recall).

REMINDER: You MUST include the sources above in your response to the user using markdown hyperlinks.
```

## Claude — Jun 13, 2026 13:36

> _[thinking]_
> 

## Claude — Jun 13, 2026 13:36

Independently confirmed — it's real and matches the claims: **OpenAI Privacy Filter**, released April 22 2026, Apache 2.0, a **bidirectional token-classification** model (not a chat model), 1.5B total / 50M active (sparse MoE), 128K context, eight span categories including `secret`, 96% F1 (94% precision / **98% recall**) on PII-Masking-300k, runs on a laptop or in-browser. So it's verified before I'd let it near the canon.

My independent read: the web instance is **right on every load-bearing point** — it's not a `ModelTier` (the router never touches it), it's substrate behind `mw.privacy`, it **cannot be I3's guarantee** (a probabilistic model judging its own safety boundary is the exact thing you refuse everywhere), the layering is deterministic-floor-plus-model-recall, and the trace→distill write-path is the sharpest catch. I won't re-litigate those. Here's what I'd add or sharpen that it couldn't see — because it reasoned from the canon alone, and I have your other files.

**1. You already built this — twice — and it's already on the box.** The In-Home Companion §3.5 *selected* "OpenAI Privacy Filter + OpenMed medical fine-tune," with a hybrid pipeline (§3.5.3), an **audit of redaction** (§3.5.4), and an explicit "what this does NOT promise" (§3.5.5); `C:\models\privacy-filter` is installed; NightScribe references it. So this is the 10th rediscovery of a seam you already designed — and your Box treatment teaches two things the other analysis missed:
   - **Rung 3 is per-cell fine-tunable**, not a fixed model. General PII for most cells; an OpenMed-tuned variant for a health cell; a code-tuned variant for secret-heavy dev work. The privacy *recall layer* is itself a swappable adapter.
   - **Redaction decisions are an I1 observable.** Your Box already audits them. So a missed or over-aggressive span is forensically traceable — the privacy layer's own behavior is logged, which is what lets you *measure* its recall instead of trusting the headline.

**2. Map it onto your own §10 taxonomy — it's cleaner than "guarantee vs recall."** The deterministic rungs (operator sovereign markers + regex/checksums) are the privacy **oracle** — a non-model assertion that "PII is present here." The learned model is a **verification pass** — it catches contextual drift (third-party names, context-private dates) the deterministic layer structurally can't, but it's model-class, so it shares the blind spot and can *never* be the assertion. The model that decides what's private cannot be the thing that guarantees privacy, for the identical reason an LLM can't be an oracle (§22 #6). This is just §10 applied to egress.

**3. The trace→distill catch is the best one — but it's not a new invariant.** It's the **reversibility gate**: baking a `secret` into a LoRA is irreversible (undo = retrain; you can *rotate* a key you accidentally sent to DeepSeek, you cannot un-bake it from weights), so the trace→distill path trips the gate and must scrub secrets before a trace becomes feedstock. And I3 covers it the moment a LoRA is ever shared (TARS-style federation, Tenancy bundle-sharing). So fold it into the two invariants you already have — the distillation corpus is the one sink where a privacy miss is *permanent and active* — rather than minting a sibling invariant.

**4. A principle it implied but didn't state: the privacy filter is *necessarily* local.** It must see the unredacted payload to redact it, so a cloud privacy filter is a contradiction. It's sovereign-substrate, pinned local, never a cloud call — and at 50M active params it's a single forward pass per egress (~Whisper-tier), cheap enough to always run.

**5. Proportionality, sharpened — your #1 threat is your own *secrets*, not third-party PII.** You consented to sending your work to the cloud, so your data isn't the exposure. But a leaked `sk-…`/`AKIA…` egressed to a provider or fossilized into a shared LoRA is immediate, concrete harm. So the `secret` category (deterministic key-format detection *plus* the model's `secret` class) is the highest-ROI privacy function for KEEL specifically — and deterministic key-detection belongs in the **Stage-0 floor**, ahead of the third-party-PII model (which earns Stage 2 when perception and correspondence corpora arrive).

**6. The degree is narrower than it looks, because the gate already does most of the work.** Split I3 into **gate** (force-local — coarse, already in the router via "sovereign/perception → local") and **mask** (span-redaction). Most of your sensitive content — your corpus, all raw perception — is force-*local* and never egresses, so it needs no masking. The mask therefore has a *narrow, specific* job: scrub stray third-party PII and secrets out of the otherwise-`Normal`-class payloads that legitimately go to the cheap-API/frontier reasoning tiers. That scoping matters — it means the model is a targeted scrub on "the stuff allowed to leave," not a universal sweep.

On the caveats: agreed, and the coverage logic is the point — banded attention (~257-token effective window) means the model sees PII *locally*, so your distance-agnostic markers/regex own the long-range cases; the fairness gap (under-detects minority/regional names) doesn't bite on *your* known data (markers = 100% recall on you) but is real for third parties, which is exactly why the deterministic floor carries the guarantee, you tune Viterbi toward over-redaction, and high-sensitivity workflows keep a human path. For *critical* outputs, prefer force-local over redact-and-egress — redaction-induced context loss can silently corrupt the result, and that choice rides your existing `critical` flag.

**Decision:** yes — as the **recall rung of a three-rung `mw.privacy`, never as I3's guarantee**; deterministic floor (markers + regex/checksums, secret-detection prioritized) in **Stage 0**; the model at **Stage 2** behind a `GOLDEN_PRIVACY` falsifier (does it catch enough that markers+regex miss, on an operator-authored set, to justify the dependency? — if not, deterministic-only is complete); per-cell fine-tunable; redaction events I1-audited; the trace→distill scrub as a reversibility-gate clause. **Zero kernel / tier / joint edits** — the boundary passing its own §23 test, again.

That's the last addition. Both of these — embedder/reranker (last turn) and the privacy three-rung (this turn) — are the **same surgical patch to the same two files**, no kernel or contract changes. To finalize the stage, here's the complete consolidated patch I'd apply:

- **§5 (I3):** split gate vs mask; cover embeddings/vectors (inversion is a leak); add the three-rung privacy layer with the deterministic floor as the non-model assertion.
- **§0/§20 (ADR):** *stateless cognition is interchangeable; format/corpus-committing components (embedder, cache-prefix, LoRA) are pinned harder.*
- **§11:** embedder/reranker are Memory organs (not a tier); index carries an embedder fingerprint → mismatch rebuilds from the ledger.
- **§10 + §14:** privacy = oracle (deterministic) + verification-pass (model); redaction events are I1-audited.
- **Reversibility gate:** the trace→distill secret-scrub clause.
- **§23 falsifiers + golden registers:** `GOLDEN_RECALL` (rerank-vs-identity, embedder-vs-floor) and `GOLDEN_PRIVACY` (model-vs-deterministic).
- **`keel.lock`:** `embedding` (Qwen3-Embedding default + MiniLM floor + `dim` + `sovereign_forces: local`), a `rerank` entry (Qwen3-Reranker, `default: identity`), and a `privacy` entry (OpenAI Privacy Filter, `disposition: shared`, local-only, per-cell fine-tune slot).

Say go and I apply exactly that, nothing more — and the stage is finalized.

Sources: [Introducing OpenAI Privacy Filter](https://openai.com/index/introducing-openai-privacy-filter/) · [openai/privacy-filter (Hugging Face)](https://huggingface.co/openai/privacy-filter) · [Model Card (PDF)](https://cdn.openai.com/pdf/c66281ed-b638-456a-8ce1-97e9f5264a90/OpenAI-Privacy-Filter-Model-Card.pdf) · [MarkTechPost coverage](https://www.marktechpost.com/2026/04/28/openai-releases-privacy-filter-a-1-5b-parameter-open-source-pii-redaction-model-with-50m-active-parameters/)

## You — Jun 13, 2026 13:37

okay go!

## Claude — Jun 13, 2026 13:40

> _[thinking]_
> 

## Claude — Jun 13, 2026 13:40

Go. Applying exactly the approved consolidated patch — surgically, so every untouched line stays byte-identical. Starting with §5 (I3 → gate/mask split + the three-rung privacy layer + the trace→distill reversibility clause):

## Claude — Jun 13, 2026 13:40

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\KEEL_ARCHITECTURE.md",
  "old_string": "- **I3 — Filtered (Sovereign).** Every egress to a non-local provider passes the privacy filter; sovereign/PHI data is forced local. **Raw perception (screen, webcam, microphone, scanned documents) is sovereign-by-default — it may never leave the box.** *Enforced in the chain + the router.*",
  "new_string": "- **I3 — Filtered (Sovereign).** Two distinct jobs: a **gate** (is this payload sensitive enough to force `local`?) and a **mask** (this is cleared to egress — scrub residual PII/secrets first). Sovereign/PHI data and **raw perception** (screen, webcam, microphone, scanned documents) hit the gate and are forced local — they may never leave the box. **Embeddings are an egress surface too:** a cloud embedder egresses the raw text, and vectors can be partially inverted back to source, so sovereign content must be embedded *locally* and its vectors stay in the local index. The mask is the three-rung privacy layer (§5.1). *Gate enforced in the router; mask + audit in the chain.*"
}
```
**[tool result]**
```
The file C:\KEEL\KEEL_ARCHITECTURE.md has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 13, 2026 13:40

> _[thinking]_
> 

## Claude — Jun 13, 2026 13:40

<!-- end chunk 5/16 | next: chunk-006.md -->
<!-- ============ CHUNK 1/16 ============ -->
<!-- source: You_are_continuing_a_contract-first_build_of_Marrow-L1_codename_Loom_my_personal_L1_amp_.md -->
<!-- section: You are continuing a contract-first build of Marrow-L1 (codename Loom), my personal L1 amp… -->

# You are continuing a contract-first build of Marrow-L1 (codename Loom), my personal L1 amp…

Session: `126bf972-5bd4-4222-a15e-1ba60caaeda9`
cwd: `C:\loom`
branch: `HEAD`
model: `claude-opus-4-8`
Started: Jun 13, 2026 04:07
Ended: Jun 13, 2026 21:10

---

## You — Jun 13, 2026 04:07

You are continuing a contract-first build of Marrow-L1 (codename Loom), my personal L1
amplification harness, at C:\loom\ on Windows 11. Work in supervised mode. Do NOT write or
edit any code until I approve a plan. Proceed in these phases and stop at the end of Phase 4.

PHASE 1 — ORIENT (read, don't skim)
Read these in full before anything else, and treat them as authoritative:
  1. Marrow-L1_ARCHITECTURE.md   (the canon: intent, glossary w/ forbidden synonyms,
     the five invariants, module inventory, the three contracts, staged build plan, falsifiers)
  2. CLAUDE.md                   (your standing constitution / operating rules)
  3. src/marrow_l1/contracts/    (model_tier.py, router.py, oracle.py — the sacred interfaces)
  4. marrow-l1.yaml              (the manifest) and AUTONOMY_CHARTER.md
Do not start coding from memory of "how harnesses usually work" — this system has specific
contracts and invariants; follow them.

PHASE 2 — ESTABLISH BASELINE (run, then report exact results)
  pip install -e ".[dev]"
  pytest -q
  python scripts\token_budget.py
  python scripts\golden_freeze.py
Report: the pass/xfail counts, the exact name of every xfailed test, the token-budget table,
and the golden hash. If anything is not green-except-known-xfails, STOP and show me before
proceeding. (DEEPSEEK_API_KEY is in my environment and I manage keys; never print or hardcode one.
You do not need llama-server running for the test suite; scripts\serve_local.ps1 starts it when
you do need the local model.)

PHASE 3 — PROVE YOU UNDERSTAND (in your own words, concise)
Restate, so I can catch any misunderstanding:
  - The system intent in one sentence, and the L1-personal-tool / not-a-product boundary (no
    general framework, no multi-tenancy, no features for hypothetical other users).
  - The five invariants I1–I5 and the reversibility gate, and what I5 (the Externality Principle)
    means for how a critical output is trusted.
  - The layer-import rule and the exact layer order.
  - The golden-case rule: GOLDEN_* constants and tests/golden/.frozen.json are agent-frozen — you
    may not edit them; if a golden test fails you fix the CODE; changing a golden is my action only.
  - The 80K-per-module rule and how you'll respect it.
  - The destructive-git / reversibility prohibitions.
  - The current build state (what Stage 0 and Stage 1 already implement) and what the single
    remaining xfail is and why it is the correct next target.
Then flag anything in the canon you find ambiguous, internally inconsistent, or that you would
implement differently — name it; do not silently "fix" it.

PHASE 4 — PROPOSE A PLAN FOR THE NEXT SLICE (Stage 2, then STOP)
Target: svc.verifier + the joint-wrong detector — the work that turns the one remaining xfail
(in tests/golden/test_oracle_golden.py) green. The IOracle contract already exists; you are adding
the service that (a) runs operator golden cases against an output and (b) implements joint-wrong
detection: the verifier sees the contract + the golden cases + the implementation diff but NOT the
implementer's reasoning, and flags JOINT_WRONG when the code passes its own tests yet fails a
golden case. Propose:
  - the exact files you will add/modify (respecting the layer order; new service under
    src/marrow_l1/services/),
  - how the existing xfailed golden case becomes a passing test (do not weaken the test; do not
    touch the frozen golden data),
  - how you keep every touched module under the 80K budget,
  - any contract change you think is needed (I expect none — if you think one is, justify it and
    wait; do not redesign an upstream contract to make implementation easier).
Then STOP and wait for my go. Do not write code, do not run any git command that can lose work.

STANDING RULES (hold these every session)
- Contracts first; implement against fixed interfaces; never edit a contract to ease an impl.
- Protocol-first (OpenAI Chat Completions); async by default; no new protocols.
- The xfail tests are the spec / to-do list. Don't scope-creep; build the one slice, make its test
  green, stop. Bank clean rather than build speculatively on an unconfirmed foundation.
- End every coding session with: python scripts\token_budget.py → python scripts\golden_freeze.py →
  pytest -q (all green) → one commit with a one-line intent.
- If you hit a foundational unknown, write a short ESCALATION note and stop. Do not guess.
Begin with Phase 1.

## Claude — Jun 13, 2026 04:07

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:07

I'll begin Phase 1 — orienting myself by reading the authoritative documents in full. Let me start by mapping the repo structure and reading the canon and key files in parallel.

## Claude — Jun 13, 2026 04:07

**[tool: Glob]**
```json
{
  "pattern": "**/*"
}
```
**[tool result]**
```
files (2).zip
files (3).zip
deepseek.py
marrow-l1.yaml
mnt\user-data\outputs\marrow-l1\src\marrow_l1\middleware\router.py
model_tier.py
oracle.py
README.md
router.py
runtime.py
agent_loop.py
amplify.py
CLAUDE.md
serve_local.ps1
```

## Claude — Jun 13, 2026 04:07

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:07

The glob output is showing a flat/odd structure. Let me look at the actual directory layout more carefully.

## Claude — Jun 13, 2026 04:07

**[tool: Bash]**
```json
{
  "command": "find . -type f -not -path '*/\\.git/*' -not -name '*.zip' 2>/dev/null | head -200",
  "description": "List all files in repo excluding zips and git"
}
```
**[tool result]**
```
./agent_loop.py
./amplify.py
./CLAUDE.md
./deepseek.py
./marrow-l1.yaml
./mnt/user-data/outputs/marrow-l1/src/marrow_l1/middleware/router.py
./model_tier.py
./oracle.py
./README.md
./router.py
./runtime.py
./serve_local.ps1
```

## Claude — Jun 13, 2026 04:07

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:07

The structure doesn't match what CLAUDE.md describes — the canon (`Marrow-L1_ARCHITECTURE.md`), `AUTONOMY_CHARTER.md`, the `src/marrow_l1/contracts/` tree, `tests/`, and `scripts/` are all missing from the root. There are two zip files and a stray nested path. Let me investigate before assuming anything.

## Claude — Jun 13, 2026 04:07

**[tool: Bash]**
```json
{
  "command": "ls -la; echo \"=== ALL including nested ===\"; find . -not -path '*/\\.git/*' | sort",
  "description": "List root with details and full tree"
}
```
**[tool result]**
```
total 172
drwxr-xr-x 1 user 197121    0 Jun 13 04:06 .
drwxr-xr-x 1 user 197121    0 Jun 13 04:05 ..
-rw-r--r-- 1 user 197121 7052 Jun 13  2026 CLAUDE.md
-rw-r--r-- 1 user 197121 2081 Jun 13  2026 README.md
-rw-r--r-- 1 user 197121 1976 Jun 13  2026 agent_loop.py
-rw-r--r-- 1 user 197121 1676 Jun 13  2026 amplify.py
-rw-r--r-- 1 user 197121 1808 Jun 13  2026 deepseek.py
-rw-r--r-- 1 user 197121 8464 Jun 13 02:28 files (2).zip
-rw-r--r-- 1 user 197121 9836 Jun 13 02:53 files (3).zip
-rw-r--r-- 1 user 197121 1440 Jun 13  2026 marrow-l1.yaml
drwxr-xr-x 1 user 197121    0 Jun 13 04:06 mnt
-rw-r--r-- 1 user 197121 3831 Jun 13  2026 model_tier.py
-rw-r--r-- 1 user 197121 1600 Jun 13  2026 oracle.py
-rw-r--r-- 1 user 197121 2755 Jun 13  2026 router.py
-rw-r--r-- 1 user 197121 1866 Jun 13  2026 runtime.py
-rw-r--r-- 1 user 197121  678 Jun 13  2026 serve_local.ps1
=== ALL including nested ===
.
./CLAUDE.md
./README.md
./agent_loop.py
./amplify.py
./deepseek.py
./files (2).zip
./files (3).zip
./marrow-l1.yaml
./mnt
./mnt/user-data
./mnt/user-data/outputs
./mnt/user-data/outputs/marrow-l1
./mnt/user-data/outputs/marrow-l1/src
./mnt/user-data/outputs/marrow-l1/src/marrow_l1
./mnt/user-data/outputs/marrow-l1/src/marrow_l1/middleware
./mnt/user-data/outputs/marrow-l1/src/marrow_l1/middleware/router.py
./model_tier.py
./oracle.py
./router.py
./runtime.py
./serve_local.ps1
```

## Claude — Jun 13, 2026 04:08

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:08

The repo is not in the state CLAUDE.md describes. The canon (`Marrow-L1_ARCHITECTURE.md`), `AUTONOMY_CHARTER.md`, `pyproject.toml`, the proper `src/marrow_l1/` package tree, `tests/`, and `scripts/` are all absent. The real content is likely inside the two zips. Let me inspect them (read-only — no extraction yet).

## Claude — Jun 13, 2026 04:08

**[tool: Bash]**
```json
{
  "command": "echo \"===== files (2).zip =====\"; unzip -l \"files (2).zip\" 2>/dev/null; echo; echo \"===== files (3).zip =====\"; unzip -l \"files (3).zip\" 2>/dev/null",
  "description": "List contents of both zip files"
}
```
**[tool result]**
```
===== files (2).zip =====
Archive:  files (2).zip
  Length      Date    Time    Name
---------  ---------- -----   ----
     2081  2026-06-13 07:28   README.md
     2755  2026-06-13 07:28   router.py
     3831  2026-06-13 07:28   model_tier.py
     1600  2026-06-13 07:28   oracle.py
     1808  2026-06-13 07:28   deepseek.py
     1857  2026-06-13 07:28   mnt/user-data/outputs/marrow-l1/src/marrow_l1/middleware/router.py
     1866  2026-06-13 07:28   runtime.py
     1440  2026-06-13 07:28   marrow-l1.yaml
---------                     -------
    17238                     8 files

===== files (3).zip =====
Archive:  files (3).zip
  Length      Date    Time    Name
---------  ---------- -----   ----
     7052  2026-06-13 07:53   CLAUDE.md
     3549  2026-06-13 07:53   router.py
     1676  2026-06-13 07:53   amplify.py
     1976  2026-06-13 07:53   agent_loop.py
     2749  2026-06-13 07:53   runtime.py
      678  2026-06-13 07:53   serve_local.ps1
     2643  2026-06-13 07:53   README.md
---------                     -------
    20323                     7 files
```

## Claude — Jun 13, 2026 04:08

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:08

The zips contain only duplicates/variants of the loose root files — notably **two different `router.py` versions** (2755 vs 3549 bytes) and two READMEs. Critically, neither the zips nor the working tree contain the canon (`Marrow-L1_ARCHITECTURE.md`), `AUTONOMY_CHARTER.md`, `pyproject.toml`, the `src/marrow_l1/` package layout, `tests/`, or `scripts/`. This is a major discrepancy from what CLAUDE.md and your instructions describe.

Before I escalate, let me read every artifact that *is* present so my report is precise. Reading these in parallel:

## Claude — Jun 13, 2026 04:08

**[tool: Read]**
```json
{
  "file_path": "C:\\loom\\README.md"
}
```
**[tool result]**
```
1	# Marrow-L1 (codename: Loom) — Stage 0 spine
2	
3	Personal L1 amplification harness. **Stage 0** = a working spine that talks to both a local
4	model and a cheap API through a router + middleware chain, logging every call. Built against
5	`Marrow-L1_ARCHITECTURE.md` (the canon); the three contracts are defined first and the golden
6	cases run as tests.
7	
8	## What's wired in Stage 0
9	- **Kernel:** manifest (Pydantic), universal `Context`, adapter `Registry`, lifecycle stub.
10	- **Adapters (protocol-first, OpenAI Chat Completions):** `local_llama` (with the constrained-
11	  decoding hook), `deepseek` (full compat normalization + cache-hit cost), `anthropic` (stub).
12	- **Middleware:** `audit` (I1), `cost` (I4, hard-stop), **Stage 0 router** (I3 sovereign-forces-
13	  local + I4 budget-block + pass-through).
14	- **Correctness (I5 slice):** a `PropertyOracle` so the externality contract runs end-to-end.
15	- **App:** `loom` CLI.
16	
17	## Roadmap (captured as `xfail` tests — the spec is already pinned)
18	- **Stage 1:** difficulty router (scaffolding→local, core-wire→cheap-API, escalate-after-2),
19	  best-of-N (`svc.amplify`), `svc.agent_loop` (plan externalization), cache-prefix middleware.
20	- **Stage 2:** golden-case runner + joint-wrong detector (`svc.verifier`), `run-metrics.jsonl`,
21	  `/calibrate`, attention probe.
22	- **Stage 3:** distillation flywheel (teacher=DeepSeek → student=local-9B LoRA).
23	
24	## Run
25	```bash
26	pip install -e ".[dev]"
27	pytest -q                                   # golden suite (green; Stage 1/2 = xfail)
28	python scripts/golden_freeze.py --update    # freeze the golden ground truth (operator action)
29	
30	# CLI (needs llama-server for local-9B and/or DEEPSEEK_API_KEY for cheap-API):
31	export DEEPSEEK_API_KEY=...                  # rotate the committed keys FIRST
32	loom "summarize the manifest" --tier cheap-API --thinking high
33	loom "analyze my corpus" --sovereign         # forced local (I3); needs llama-server on :8080
34	```
35	
36	Implementation language is **Python** (Pydantic + asyncio + httpx), matching Marrow's stack; the
37	TypeScript in the canon was interface notation only.
38	
```

## Claude — Jun 13, 2026 04:08

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:08

**[tool: Read]**
```json
{
  "file_path": "C:\\loom\\marrow-l1.yaml"
}
```
**[tool result]**
```
1	# Marrow-L1 manifest — Stage 0 subset (forward fields present, only Stage 0 paths wired).
2	default_tier: local-9B
3	
4	tiers:
5	  local-9B:
6	    adapter: local_llama
7	    model: qwen3.5-9b-q5_k_m
8	    endpoint: http://127.0.0.1:8080
9	    price: { input_miss: 0.0, input_hit: 0.0, output: 0.0 }   # electricity; tracked as $0
10	    default_effort: { n: 8 }                                   # best-of-N is ~free (Stage 1)
11	  cheap-API:
12	    adapter: deepseek
13	    model: deepseek-v4-pro
14	    endpoint: https://api.deepseek.com                         # official OpenAI-compat; no /v1 suffix
15	    api_key_env: DEEPSEEK_API_KEY
16	    price: { input_miss: 0.435, input_hit: 0.003625, output: 0.87 }   # $/1M (miss / hit / out)
17	    default_effort: { n: 2, thinking: high }
18	  cheap-bulk:
19	    adapter: deepseek
20	    model: deepseek-v4-flash
21	    endpoint: https://api.deepseek.com
22	    api_key_env: DEEPSEEK_API_KEY
23	    price: { input_miss: 0.14, input_hit: 0.0028, output: 0.28 }
24	    default_effort: { n: 1 }
25	  frontier:
26	    adapter: anthropic
27	    model: claude-opus-4-8
28	    endpoint: https://api.anthropic.com
29	    api_key_env: ANTHROPIC_API_KEY
30	    price: { input_miss: 5.0, input_hit: 0.5, output: 25.0 }
31	    default_effort: { n: 1 }
32	
33	router:
34	  default_tier: local-9B
35	  sovereign_data_forces: local-9B
36	  escalate_after_oracle_failures: 2          # Stage 1
37	
38	middleware:
39	  cost: { budget_per_task: 5.0, hard_stop_at: 1.0 }
40	  audit: { sink: ./.runstate/audit.jsonl }
41	
```

## Claude — Jun 13, 2026 04:08

**[tool: Read]**
```json
{
  "file_path": "C:\\loom\\model_tier.py"
}
```
**[tool result]**
```
1	"""Contract: IModelTier — the uniform brain interface every adapter implements.
2	
3	Every model tier (local-9B, cheap-API, frontier) speaks OpenAI Chat Completions and
4	returns a uniform GenerateResult with usage + cost. This is the protocol-first kernel
5	bet (Marrow §1): new providers slot in as adapters; nothing above L1 changes.
6	"""
7	from __future__ import annotations
8	from typing import Protocol, runtime_checkable, TYPE_CHECKING
9	from pydantic import BaseModel, Field
10	
11	if TYPE_CHECKING:  # avoid import cycle; Context lives in the kernel layer
12	    from marrow_l1.kernel.context import Context
13	
14	
15	class Message(BaseModel):
16	    role: str                      # "system" | "user" | "assistant" | "tool"
17	    content: str | None = None
18	    name: str | None = None
19	    tool_call_id: str | None = None
20	    reasoning_content: str | None = None   # DeepSeek: MUST be replayed across tool turns
21	
22	
23	class ToolCall(BaseModel):
24	    id: str = ""
25	    type: str = "function"
26	    name: str = ""
27	    arguments: str = ""            # JSON string (as returned by the provider)
28	
29	
30	class Usage(BaseModel):
31	    input_tokens: int = 0
32	    output_tokens: int = 0
33	    cache_hit_tokens: int = 0      # DeepSeek prompt_cache_hit_tokens; the 100x lever
34	
35	
36	class Price(BaseModel):
37	    """USD per 1,000,000 tokens."""
38	    input_miss: float = 0.0
39	    input_hit: float = 0.0
40	    output: float = 0.0
41	
42	
43	def compute_cost(usage: Usage, price: Price) -> float:
44	    """Cost from usage + tier price. Cache-miss input = total input minus cache hits."""
45	    miss = max(usage.input_tokens - usage.cache_hit_tokens, 0)
46	    return (
47	        miss * price.input_miss
48	        + usage.cache_hit_tokens * price.input_hit
49	        + usage.output_tokens * price.output
50	    ) / 1_000_000
51	
52	
53	class Effort(BaseModel):
54	    """The amplification dial. Stage 0 honors `thinking`; best-of-N (`n`) lands in Stage 1."""
55	    n: int = 1
56	    thinking: str | None = None    # "low" | "high" | "max"
57	
58	
59	class GenerateRequest(BaseModel):
60	    messages: list[Message]
61	    model: str
62	    tools: list[dict] | None = None
63	    grammar: dict | str | None = None      # local tier enforces at decode time (GBNF str / JSON schema dict)
64	    effort: Effort | None = None
65	    cache_prefix_len: int | None = None    # bytes of stable prefix to mark cacheable
66	
67	
68	class GenerateResult(BaseModel):
69	    content: str = ""
70	    tool_calls: list[ToolCall] = Field(default_factory=list)
71	    reasoning_content: str | None = None
72	    usage: Usage = Field(default_factory=Usage)
73	    cost: float = 0.0
74	    tier: str = ""
75	    model: str = ""
76	
77	
78	class GoldenCase(BaseModel):
79	    """Operator-authored, agent-frozen ground truth. The agent MAY NOT edit these."""
80	    name: str
81	    input: dict
82	    expect: dict
83	
84	
85	@runtime_checkable
86	class IModelTier(Protocol):
87	    tier: str
88	    async def generate(self, req: GenerateRequest, ctx: "Context") -> GenerateResult: ...
89	
90	
91	# GOLDEN CASES — operator-authored, agent-frozen. (Runnable in tests/golden/test_model_tier_golden.py)
92	GOLDEN_MODEL_TIER: list[GoldenCase] = [
93	    GoldenCase(
94	        name="cost computed from usage and tier price (deepseek-v4-pro)",
95	        input={"usage": {"input_tokens": 1000, "output_tokens": 500, "cache_hit_tokens": 800},
96	               "price": {"input_miss": 0.435, "input_hit": 0.003625, "output": 0.87}},
97	        expect={"cost": 0.0005249, "tol": 1e-6},
98	    ),
99	    GoldenCase(
100	        name="tool call conforms to schema under constrained decoding",
101	        input={"schema": {"type": "object", "required": ["path"],
102	                          "properties": {"path": {"type": "string"}}}},
103	        expect={"tool_call_valid_against_schema": True},
104	    ),
105	    GoldenCase(
106	        name="reasoning_content survives a tool ro…
```

## Claude — Jun 13, 2026 04:08

**[tool: Read]**
```json
{
  "file_path": "C:\\loom\\oracle.py"
}
```
**[tool result]**
```
1	"""Contract: IOracle — the externality surface (Invariant I5).
2	
3	verify(output, golden, contract) -> OracleResult. An oracle is a NON-model-authored
4	assertion of correctness. An LLM verification pass is NOT an oracle. The joint-wrong
5	detector (Stage 2) flags the case where impl + tests agree and a golden case disagrees.
6	"""
7	from __future__ import annotations
8	from typing import Protocol, runtime_checkable
9	from pydantic import BaseModel, Field
10	
11	from marrow_l1.contracts.model_tier import GoldenCase
12	
13	
14	class StepOutput(BaseModel):
15	    content: str = ""
16	    artifact: dict = Field(default_factory=dict)   # e.g. {"code": "...", "self_tests_pass": true}
17	
18	
19	class OracleResult(BaseModel):
20	    passed: bool
21	    failures: list[str] = Field(default_factory=list)
22	    joint_wrong: bool = False
23	
24	
25	@runtime_checkable
26	class IOracle(Protocol):
27	    async def verify(self, output: StepOutput, golden: list[GoldenCase],
28	                     contract: str | None = None) -> OracleResult: ...
29	
30	
31	# GOLDEN CASES — operator-authored, agent-frozen.
32	GOLDEN_ORACLE: list[GoldenCase] = [
33	    GoldenCase(name="redaction output containing an SSN pattern fails a property oracle",
34	               input={"output": "patient ... 123-45-6789 ...", "property": "no_ssn_pattern"},
35	               expect={"passed": False, "joint_wrong": False}),
36	    # --- Stage 2 (joint-wrong detection) ---
37	    GoldenCase(name="[stage2] code passing its own tests but failing a golden case is JOINT_WRONG",
38	               input={"self_tests_pass": True, "golden_violated": True},
39	               expect={"passed": False, "joint_wrong": True}),
40	]
41	
```

## Claude — Jun 13, 2026 04:08

**[tool: Read]**
```json
{
  "file_path": "C:\\loom\\router.py"
}
```
**[tool result]**
```
1	"""Contract: IRouter — the fusion of both requirements.
2	
3	route(step, ctx) -> RoutingDecision. This is the single most important contract in the
4	system: it decides per step whether work goes to the amplified local-9B, the cheap API,
5	or the frontier escalation tier. Golden cases PIN the routing behavior the operator wants.
6	"""
7	from __future__ import annotations
8	from typing import Protocol, runtime_checkable, TYPE_CHECKING
9	from pydantic import BaseModel, Field
10	
11	from marrow_l1.contracts.model_tier import Effort, Message, GoldenCase
12	
13	if TYPE_CHECKING:
14	    from marrow_l1.kernel.context import Context
15	
16	
17	class Step(BaseModel):
18	    kind: str = "scaffolding"          # "scaffolding" | "core-wire"
19	    type: str = ""                     # e.g. "tool_call:read_file", "reason:multi_constraint"
20	    tier_history: list[str] = Field(default_factory=list)
21	    oracle_failures: int = 0
22	    data_class: str = "normal"         # "normal" | "sovereign" | "phi"
23	    projected_cost: float | None = None
24	    critical: bool = False
25	    messages: list[Message] = Field(default_factory=list)
26	
27	
28	class RoutingDecision(BaseModel):
29	    tier: str                          # a tier name, or "BLOCK"
30	    effort: Effort = Field(default_factory=Effort)
31	    reason: str = ""
32	
33	
34	@runtime_checkable
35	class IRouter(Protocol):
36	    def route(self, step: Step, ctx: "Context") -> RoutingDecision: ...
37	
38	
39	# GOLDEN CASES — operator-authored, agent-frozen.
40	GOLDEN_ROUTER: list[GoldenCase] = [
41	    GoldenCase(name="sovereign data forces local-9B regardless of difficulty",
42	               input={"kind": "core-wire", "type": "reason:multi_constraint", "data_class": "sovereign"},
43	               expect={"tier": "local-9B", "reason_contains": "privacy"}),
44	    GoldenCase(name="projected cost over remaining budget blocks to operator",
45	               input={"kind": "core-wire", "projected_cost": 9.99, "budget_remaining": 1.00},
46	               expect={"tier": "BLOCK", "reason_contains": "budget"}),
47	    # --- Stage 1 (difficulty estimation) ---
48	    GoldenCase(name="[stage1] file-read scaffolding step routes to local-9B",
49	               input={"kind": "scaffolding", "type": "tool_call:read_file", "tier_history": []},
50	               expect={"tier": "local-9B"}),
51	    GoldenCase(name="[stage1] multi-constraint reasoning step routes to cheap-API",
52	               input={"kind": "core-wire", "type": "reason:multi_constraint", "tier_history": []},
53	               expect={"tier": "cheap-API"}),
54	    GoldenCase(name="[stage1] local-9B that failed its oracle twice escalates",
55	               input={"kind": "scaffolding", "type": "transform",
56	                      "tier_history": ["local-9B", "local-9B"], "oracle_failures": 2},
57	               expect={"tier_in": ["cheap-API", "frontier"]}),
58	]
59	
```

## Claude — Jun 13, 2026 04:08

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:08

Now the three contracts. They import from `marrow_l1.kernel.context` and `marrow_l1.contracts.model_tier` — a package layout that doesn't exist on disk (files are loose at root). Let me read the remaining artifacts.

## Claude — Jun 13, 2026 04:08

**[tool: Read]**
```json
{
  "file_path": "C:\\loom\\deepseek.py"
}
```
**[tool result]**
```
1	"""cheap-API adapter (DeepSeek V4). Absorbs every compat gotcha so nothing above L1 cares:
2	- OpenAI-compat path is {endpoint}/chat/completions (endpoint = https://api.deepseek.com)
3	- no `developer` role (map to system)
4	- `max_tokens`, not `max_completion_tokens`
5	- thinking mode: send thinking{type:enabled} + reasoning_effort; DROP tool_choice
6	- `reasoning_content` parsed and preserved (must be replayed across tool turns)
7	- prompt_cache_hit_tokens parsed (the 100x cache lever); cost recomputed with cache hits
8	"""
9	from __future__ import annotations
10	from marrow_l1.adapters.base import OpenAICompatAdapter
11	from marrow_l1.contracts.model_tier import GenerateRequest, GenerateResult, compute_cost
12	
13	
14	class DeepSeekAdapter(OpenAICompatAdapter):
15	    tier = "cheap-API"
16	
17	    @property
18	    def chat_url(self) -> str:
19	        return f"{self.endpoint}/chat/completions"   # do NOT append /v1
20	
21	    def _build_body(self, req: GenerateRequest) -> dict:
22	        body = super()._build_body(req)
23	        # developer role is rejected -> map to system
24	        for m in body["messages"]:
25	            if m.get("role") == "developer":
26	                m["role"] = "system"
27	        eff = req.effort
28	        if eff and eff.thinking:
29	            body["thinking"] = {"type": "enabled"}
30	            body["reasoning_effort"] = eff.thinking      # "high" | "max"
31	            body.pop("tool_choice", None)                # rejected in thinking mode
32	        # cache-prefix discipline: a real marker pass lands in mw.cache (Stage 1).
33	        return body
34	
35	    def _parse(self, data: dict, req: GenerateRequest) -> GenerateResult:
36	        res = super()._parse(data, req)
37	        # recompute cost now that cache_hit_tokens is populated from prompt_cache_hit_tokens
38	        res.cost = compute_cost(res.usage, self.price)
39	        return res
40	
```

## Claude — Jun 13, 2026 04:08

**[tool: Read]**
```json
{
  "file_path": "C:\\loom\\runtime.py"
}
```
**[tool result]**
```
1	"""Loom runtime (L4): assembles registry + middleware chain + router from a manifest."""
2	from __future__ import annotations
3	from marrow_l1.kernel.manifest import load_manifest
4	from marrow_l1.kernel.registry import Registry
5	from marrow_l1.middleware.router import Stage0Router
6	from marrow_l1.middleware.chain import MiddlewareChain
7	from marrow_l1.middleware.audit import AuditMiddleware
8	from marrow_l1.middleware.cost import CostMiddleware
9	from marrow_l1.contracts.router import Step, RoutingDecision
10	from marrow_l1.contracts.model_tier import GenerateRequest, Message, Effort
11	
12	
13	class Loom:
14	    def __init__(self, manifest_path: str):
15	        self.m = load_manifest(manifest_path)
16	        self.registry = Registry(self.m)
17	        self.router = Stage0Router(self.m)
18	        self.chain = MiddlewareChain([
19	            AuditMiddleware(self.m.middleware.audit.sink),
20	            CostMiddleware(self.m.middleware.cost.hard_stop_at),
21	        ])
22	
23	    async def run(self, prompt: str, step: Step, ctx,
24	                  forced_tier: str | None = None, thinking: str | None = None):
25	        if forced_tier:
26	            decision = RoutingDecision(tier=forced_tier, effort=self.m.tier_effort(forced_tier),
27	                                       reason="operator --tier override")
28	        else:
29	            decision = self.router.route(step, ctx)
30	        if decision.tier == "BLOCK":
31	            return decision, None
32	
33	        cfg = self.m.tiers[decision.tier]
34	        eff = decision.effort
35	        if thinking:
36	            eff = Effort(n=eff.n, thinking=thinking)
37	        req = GenerateRequest(messages=[Message(role="user", content=prompt)],
38	                              model=cfg.model, effort=eff)
39	        adapter = self.registry.get(decision.tier)
40	        result = await self.chain.run(req, ctx, terminal=lambda r: adapter.generate(r, ctx))
41	        return decision, result
42	
```

## Claude — Jun 13, 2026 04:08

**[tool: Read]**
```json
{
  "file_path": "C:\\loom\\agent_loop.py"
}
```
**[tool result]**
```
1	"""svc.agent_loop — plan externalization + step-at-a-time. The long-horizon engine.
2	
3	The model never holds the whole task: the harness owns the plan as a structured list and feeds
4	ONE step at a time, routing each (scaffolding -> local, core-wire -> cheap-API) and running it
5	through the middleware chain. Minimal Stage 1: executes a pre-built plan. Replan triggers, the
6	spike protocol, and blocker fan-out (bank-clean-stop-early) land in Stage 1b.
7	"""
8	from __future__ import annotations
9	from marrow_l1.contracts.model_tier import GenerateRequest, Message
10	from marrow_l1.contracts.router import Step
11	
12	
13	class AgentLoopService:
14	    def __init__(self, manifest, registry, router, chain, amplify=None):
15	        self.m = manifest
16	        self.registry = registry
17	        self.router = router
18	        self.chain = chain
19	        self.amplify = amplify
20	
21	    async def run(self, plan: list[tuple[Step, str]], ctx) -> list[dict]:
22	        trace: list[dict] = []
23	        for step, prompt in plan:
24	            decision = self.router.route(step, ctx)
25	            if decision.tier == "BLOCK":
26	                trace.append({"tier": "BLOCK", "reason": decision.reason})
27	                break
28	            cfg = self.m.tiers[decision.tier]
29	            req = GenerateRequest(messages=[Message(role="user", content=prompt)],
30	                                  model=cfg.model, effort=decision.effort)
31	            adapter = self.registry.get(decision.tier)
32	
33	            async def gen(r, a=adapter):
34	                return await self.chain.run(r, ctx, terminal=lambda rr, aa=a: aa.generate(rr, ctx))
35	
36	            n = decision.effort.n if decision.tier == "local-9B" else 1   # amplify only the free tier
37	            if self.amplify is not None and n > 1:
38	                res, _ = await self.amplify.amplify(req, gen, n=n)
39	            else:
40	                res = await gen(req)
41	            trace.append({"tier": decision.tier, "reason": decision.reason, "content": res.content})
42	        return trace
43	
```

## Claude — Jun 13, 2026 04:08

**[tool: Read]**
```json
{
  "file_path": "C:\\loom\\amplify.py"
}
```
**[tool result]**
```
1	"""svc.amplify — best-of-N + verifier-selector. The 'spend cheap inference to buy quality' engine.
2	
3	Takes a `generate` callable (req -> GenerateResult) rather than a raw adapter, so every sampled
4	call still traverses the middleware chain (audit I1, cost I4). Selection: with an acceptor,
5	return the FIRST sample that passes (incumbent-wins-ties); else self-consistency (modal content).
6	"""
7	from __future__ import annotations
8	import asyncio
9	from collections import Counter
10	from typing import Awaitable, Callable
11	from marrow_l1.contracts.model_tier import GenerateRequest, GenerateResult
12	
13	Generate = Callable[[GenerateRequest], Awaitable[GenerateResult]]
14	Acceptor = Callable[[GenerateResult], Awaitable[bool]]
15	
16	
17	class AmplificationService:
18	    async def amplify(self, req: GenerateRequest, generate: Generate, n: int | None = None,
19	                      accept: Acceptor | None = None) -> tuple[GenerateResult, list[GenerateResult]]:
20	        n = n if n is not None else (req.effort.n if req.effort else 1)
21	        n = max(1, n)
22	        results = await asyncio.gather(*[generate(req) for _ in range(n)])
23	
24	        if accept is not None:
25	            for r in results:                       # incumbent-wins-ties (lowest index first)
26	                if await accept(r):
27	                    return r, results
28	            return results[0], results              # none passed -> incumbent
29	
30	        if len(results) == 1:
31	            return results[0], results
32	        counts = Counter(r.content for r in results)
33	        top = counts.most_common(1)[0][0]
34	        for r in results:
35	            if r.content == top:
36	                return r, results
37	        return results[0], results
38	
```

## Claude — Jun 13, 2026 04:08

**[tool: Read]**
```json
{
  "file_path": "C:\\loom\\serve_local.ps1"
}
```
**[tool result]**
```
1	# Launch ggml-org/llama.cpp llama-server for Marrow-L1 local-9B (Qwen3.5-9B) on Windows 11.
2	# Usage:  powershell -ExecutionPolicy Bypass -File scripts\serve_local.ps1
3	$ErrorActionPreference = "Stop"
4	$LlamaDir = "C:\llama.cpp"
5	$Model    = "C:\models\Qwen3.5-9B-Q5_K_M.gguf"
6	$MMProj   = "C:\models\mmproj-Qwen3.5-9B-f16.gguf"   # optional (vision); ignored if absent
7	$Ctx      = 8192
8	$Port     = 8080
9	
10	$a = @("--model", $Model, "--ctx-size", $Ctx, "--n-gpu-layers", "999",
11	       "--host", "127.0.0.1", "--port", $Port)
12	if (Test-Path $MMProj) { $a += @("--mmproj", $MMProj) }
13	
14	Write-Host "Starting llama-server: $Model on http://127.0.0.1:$Port"
15	& "$LlamaDir\llama-server.exe" @a
16	
```

## Claude — Jun 13, 2026 04:08

**[tool: Read]**
```json
{
  "file_path": "C:\\loom\\mnt\\user-data\\outputs\\marrow-l1\\src\\marrow_l1\\middleware\\router.py"
}
```
**[tool result]**
```
1	"""Stage 0 router: implements IRouter with the SAFETY-CRITICAL constraints only.
2	
3	Stage 0 (here):  sovereign-data -> local (I3);  over-budget -> BLOCK (I4);  else pass-through
4	                 to the manifest default tier.
5	Stage 1 (TODO):  difficulty estimation (scaffolding -> local, core-wire -> cheap-API),
6	                 escalate_after_oracle_failures, cache-affinity tie-break, effort-by-tier.
7	"""
8	from __future__ import annotations
9	from marrow_l1.contracts.router import IRouter, Step, RoutingDecision
10	from marrow_l1.contracts.model_tier import Effort
11	from marrow_l1.kernel.manifest import Manifest
12	
13	
14	class Stage0Router(IRouter):
15	    def __init__(self, manifest: Manifest):
16	        self.m = manifest
17	
18	    def route(self, step: Step, ctx) -> RoutingDecision:
19	        # I3 — sovereign/PHI data is forced local; overrides cost and difficulty.
20	        if step.data_class in ("sovereign", "phi"):
21	            tier = self.m.router.sovereign_data_forces
22	            return RoutingDecision(tier=tier, effort=self.m.tier_effort(tier),
23	                                   reason="privacy: sovereign data forced local")
24	
25	        # I4 — projected cost over remaining budget blocks to the operator.
26	        remaining = ctx.task_budget_remaining
27	        if step.projected_cost is not None and remaining is not None and step.projected_cost > remaining:
28	            return RoutingDecision(tier="BLOCK",
29	                                   reason=f"budget: projected ${step.projected_cost:.2f} > "
30	                                          f"remaining ${remaining:.2f}")
31	
32	        # Stage 0 — pass-through to default tier (difficulty routing is Stage 1).
33	        tier = self.m.router.default_tier
34	        return RoutingDecision(tier=tier, effort=self.m.tier_effort(tier),
35	                               reason="stage0 pass-through (difficulty routing: Stage 1)")
36	
```

## Claude — Jun 13, 2026 04:09

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:09

Now I have a clear picture of the artifacts. Let me confirm a few things before reporting: peek at the differing Stage-1 files inside `files (3).zip` (non-destructively via `unzip -p`), and do an exhaustive search for the canon and other required scaffolding to be certain they're truly absent.

## Claude — Jun 13, 2026 04:09

**[tool: Bash]**
```json
{
  "command": "echo \"===== files(3).zip router.py (3549b) =====\"; unzip -p \"files (3).zip\" router.py 2>/dev/null | head -90",
  "description": "Peek at Stage-1 router.py inside files (3).zip"
}
```
**[tool result]**
```
===== files(3).zip router.py (3549b) =====
"""Routers. Stage 0 = pass-through (kept for history). Stage 1 = DifficultyRouter (active).

DifficultyRouter is the fusion point of the two requirements: per step it sends scaffolding
work to the amplified local-9B and core-wire reasoning to the cheap API, with sovereignty (I3)
and budget (I4) as hard overrides and oracle-failure escalation up the tier ladder.
"""
from __future__ import annotations
from marrow_l1.contracts.router import IRouter, Step, RoutingDecision
from marrow_l1.kernel.manifest import Manifest

_LADDER = ["local-9B", "cheap-API", "frontier"]

class Stage0Router(IRouter):
    """Stage 0 baseline: hard constraints only, else pass-through to the default tier."""
    def __init__(self, manifest: Manifest):
        self.m = manifest

    def route(self, step: Step, ctx) -> RoutingDecision:
        forced = _hard_constraints(self.m, step, ctx)
        if forced is not None:
            return forced
        tier = self.m.router.default_tier
        return RoutingDecision(tier=tier, effort=self.m.tier_effort(tier),
                               reason="stage0 pass-through (difficulty routing: Stage 1)")

class DifficultyRouter(IRouter):
    """Stage 1: hard constraints + escalation + difficulty-based tier selection."""
    def __init__(self, manifest: Manifest):
        self.m = manifest
        self.escalate_after = manifest.router.escalate_after_oracle_failures

    def _escalate_from(self, last_tier: str) -> str:
        if last_tier in _LADDER:
            return _LADDER[min(_LADDER.index(last_tier) + 1, len(_LADDER) - 1)]
        return "cheap-API"

    def route(self, step: Step, ctx) -> RoutingDecision:
        # I3 / I4 — hard overrides first.
        forced = _hard_constraints(self.m, step, ctx)
        if forced is not None:
            return forced

        # Escalation BEFORE difficulty, so a step that keeps failing its oracle moves up a tier.
        if step.oracle_failures >= self.escalate_after:
            last = step.tier_history[-1] if step.tier_history else "local-9B"
            tier = self._escalate_from(last)
            return RoutingDecision(tier=tier, effort=self.m.tier_effort(tier),
                                   reason=f"escalation: {step.oracle_failures} oracle failures on {last}")

        # Difficulty: core-wire -> cheap reasoning tier; scaffolding -> amplified local-9B.
        if step.kind == "core-wire":
            return RoutingDecision(tier="cheap-API", effort=self.m.tier_effort("cheap-API"),
                                   reason="difficulty: core-wire -> cheap-API reasoning tier")
        return RoutingDecision(tier="local-9B", effort=self.m.tier_effort("local-9B"),
                               reason="difficulty: scaffolding -> amplified local-9B")

def _hard_constraints(m: Manifest, step: Step, ctx) -> RoutingDecision | None:
    """I3 sovereign-forces-local and I4 budget-block. Returns a decision, or None to continue."""
    if step.data_class in ("sovereign", "phi"):
        tier = m.router.sovereign_data_forces
        return RoutingDecision(tier=tier, effort=m.tier_effort(tier),
                               reason="privacy: sovereign data forced local")
    remaining = ctx.task_budget_remaining
    if step.projected_cost is not None and remaining is not None and step.projected_cost > remaining:
        return RoutingDecision(tier="BLOCK",
                               reason=f"budget: projected ${step.projected_cost:.2f} > "
                                      f"remaining ${remaining:.2f}")
    return None
```

## Claude — Jun 13, 2026 04:09

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:09

Confirmed: `files (3).zip` holds the **Stage 1** snapshot (its `router.py` contains both `Stage0Router` and the active `DifficultyRouter`). Now let me exhaustively confirm the canon and all build scaffolding are truly absent, and peek at the remaining Stage-1 variants.

## Claude — Jun 13, 2026 04:09

**[tool: Bash]**
```json
{
  "command": "echo \"===== Search C:\\loom for required-but-maybe-missing files =====\"\nfor f in \"Marrow-L1_ARCHITECTURE.md\" \"AUTONOMY_CHARTER.md\" \"pyproject.toml\" \"setup.py\" \"setup.cfg\" \".frozen.json\" \"token_budget.py\" \"golden_freeze.py\"; do\n  found=$(find . -iname \"$f\" -not -path '*/\\.git/*' 2>/dev/null)\n  if [ -z \"$found\" ]; then echo \"MISSING: $f\"; else echo \"FOUND:   $found\"; fi\ndone\necho\necho \"===== Any tests/ or scripts/ dirs anywhere? =====\"\nfind . -type d \\( -iname tests -o -iname scripts -o -iname kernel -o -iname adapters -o -iname services -o -iname contracts -o -iname apps \\) -not -path '*/\\.git/*' 2>/dev/null || echo \"(none)\"\necho\necho \"===== Any .py referencing ARCHITECTURE canon content? Count of *.md =====\"\nfind . -iname \"*.md\" -not -path '*/\\.git/*' 2>/dev/null\necho\necho \"===== git? =====\"\ngit -C . rev-parse --is-inside-work-tree 2>&1 | head -1",
  "description": "Exhaustive search for canon, charter, pyproject, tests, scripts, git"
}
```
**[tool result]**
```
===== Search C:\loom for required-but-maybe-missing files =====
MISSING: Marrow-L1_ARCHITECTURE.md
MISSING: AUTONOMY_CHARTER.md
MISSING: pyproject.toml
MISSING: setup.py
MISSING: setup.cfg
MISSING: .frozen.json
MISSING: token_budget.py
MISSING: golden_freeze.py

===== Any tests/ or scripts/ dirs anywhere? =====

===== Any .py referencing ARCHITECTURE canon content? Count of *.md =====
./CLAUDE.md
./README.md

===== git? =====
fatal: not a git repository (or any of the parent directories): .git
```

## Claude — Jun 13, 2026 04:11

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:11

I've completed a thorough read of everything actually present in `C:\loom\`, and I need to stop here and escalate **before** Phase 2 — because the foundation that your instructions (and CLAUDE.md) assume is **not on disk**. Per your own rule ("If anything is not green-except-known-xfails, STOP and show me"; "If you hit a foundational unknown, write a short ESCALATION note and stop — do not guess"), I did not proceed, did not guess, and did not reconstruct or assemble anything.

## ESCALATION — the repo is not in the state the instructions assume

### What's actually on disk (12 loose files + 2 zips, all dated today 2026-06-13)
| File | What it is | Note |
|---|---|---|
| [CLAUDE.md](CLAUDE.md) (7052b) | the constitution | ✓ present, matches my context |
| [README.md](README.md) (2081b) | Stage 0 README | references canon + tests that don't exist |
| [marrow-l1.yaml](marrow-l1.yaml) (1440b) | manifest | self-labeled "Stage 0 subset" |
| [serve_local.ps1](serve_local.ps1) (678b) | llama-server launcher | ✓ |
| [model_tier.py](model_tier.py) (3831b) | contract `IModelTier` | belongs at `src/marrow_l1/contracts/` |
| [oracle.py](oracle.py) (1600b) | contract `IOracle` | contains the `[stage2]` joint-wrong golden |
| [router.py](router.py) (2755b) | contract `IRouter` | — |
| [deepseek.py](deepseek.py) (1808b) | cheap-API adapter | imports `marrow_l1.adapters.base` → **absent** |
| [amplify.py](amplify.py) (1676b) | `svc.amplify` | — |
| [agent_loop.py](agent_loop.py) (1976b) | `svc.agent_loop` | — |
| [runtime.py](runtime.py) (1866b) | runtime (L4) | this is the **Stage 0** version |
| [mnt/.../middleware/router.py](mnt/user-data/outputs/marrow-l1/src/marrow_l1/middleware/router.py) (1857b) | router middleware | **Stage0Router only** (no DifficultyRouter) |

The two zips are session-export snapshots: **`files (2).zip` = Stage 0**, **`files (3).zip` = Stage 1** (its `router.py` (3549b) holds the active `DifficultyRouter`; it also has the evolved `runtime.py` (2749b), `amplify.py`, `agent_loop.py`). Neither zip adds anything beyond variants of the files above.

### What's missing — and it blocks Phases 1 and 2 entirely
- **`Marrow-L1_ARCHITECTURE.md` — the canon.** Phase 1 and CLAUDE.md rule #1 ("the canon is the source of truth") both require it. It is nowhere in the tree or either zip. I will not fabricate or reconstruct it — it is operator-authored ground truth.
- **`AUTONOMY_CHARTER.md`** — also absent.
- **`pyproject.toml`** — so `pip install -e ".[dev]"` cannot run (Phase 2 step 1 fails immediately).
- **The entire `src/marrow_l1/` package** — no `kernel/` (manifest, context, registry, lifecycle), no `adapters/base.py` (the `OpenAICompatAdapter` that `deepseek.py` imports), no `local_llama`/`anthropic` adapters, no `middleware/{chain,audit,cost,cache}.py`, no `apps/cli.py` (the `loom` command), no `__init__.py` files. **Nothing here is importable.**
- **`tests/` — entirely absent**, including `tests/golden/test_oracle_golden.py` (**the Phase 4 target itself**) and `tests/golden/.frozen.json` (the frozen golden hash).
- **`scripts/token_budget.py` and `scripts/golden_freeze.py`** — absent.
- **No git repository** (`git rev-parse` fails; env confirms `Is a git repository: false`) — so the session-protocol commit step and the reversibility-gate git prohibitions have nothing to operate on yet.

### Consequence
All four Phase 2 commands fail at the first step — there's no installable package, no test suite, no scripts. The premise "Stage 0 done, Stage 1 done, one remaining `xfail`" is not reflected on disk; what's here is a scattering of the hand-authored source files (and the loose ones are the **stale Stage 0** variants — the Stage 1 versions live only inside `files (3).zip`), with every dependency they rely on missing. I cannot reach a baseline to report, cannot read the canon to prove understanding (Phase 3), and cannot responsibly plan against a contract set whose surrounding kernel/middleware I can't see (Phase 4).

I have **not** extracted the zips, assembled a package, authored any test/golden, or run any mutating command — that would be "building from memory of how harnesses usually work," which you explicitly forbade, and several of the missing pieces (canon, `.frozen.json`, golden constants) are agent-frozen ground truth I'm not permitted to create.

### Already-visible flags (from the contracts alone)
- `deepseek.py:10` imports `marrow_l1.adapters.base.OpenAICompatAdapter`, which doesn't exist — confirming the build is incomplete, not merely mislaid.
- The working-tree `runtime.py` + middleware `router.py` are **Stage 0**, contradicting CLAUDE.md's "Stage 1 (done)". The Stage 1 code is trapped inside `files (3).zip`.

To proceed I need the real foundation restored. The cleanest path is for you to drop the actual existing build into `C:\loom\` (or point me at it), after which I'll immediately re-run Phase 2 and report the true baseline. Let me confirm how you want to handle it:

## Claude — Jun 13, 2026 04:11

**[tool: AskUserQuestion]**
```json
{
  "questions": [
    {
      "question": "The canon, pyproject, the src/marrow_l1 package, tests/, scripts/, and .frozen.json are all absent — only ~8 loose source files and two session-export zips are on disk. How do you want to restore the foundation before I run Phase 2?",
      "header": "Foundation",
      "multiSelect": false,
      "options": [
        {
          "label": "Provide repo",
          "description": "The full Stage 0/1 build exists elsewhere — you'll drop it into C:\\loom (or point me to a path/zip): canon, AUTONOMY_CHARTER, pyproject.toml, the src/marrow_l1 package (kernel, adapters/base, middleware chain/audit/cost/cache, apps/cli), tests/ incl. test_oracle_golden.py + .frozen.json, and scripts/. I then re-run Phase 2 and report the real baseline. Cleanest; preserves your agent-frozen ground truth."
        },
        {
          "label": "Reconstruct",
          "description": "These two zips are all that survived. You authorize me to rebuild ONLY the missing engineering scaffolding (kernel, adapters/base, middleware chain/audit/cost, pyproject, test runner, scripts) from the fixed contracts — but YOU re-author or bless the canon and the frozen golden data, since those are agent-frozen operator ground truth I must not fabricate."
        },
        {
          "label": "Rebuild all",
          "description": "Canon and goldens are also lost and you accept a from-near-scratch rebuild, including me drafting a canon + golden cases for your explicit approval before anything is frozen. Largest scope; departs from contract-first-on-a-fixed-canon — only choose if nothing else survives."
        }
      ]
    }
  ]
}
```
**[tool result]**
```
Your questions have been answered: "The canon, pyproject, the src/marrow_l1 package, tests/, scripts/, and .frozen.json are all absent — only ~8 loose source files and two session-export zips are on disk. How do you want to restore the foundation before I run Phase 2?"="WAIT, I UNZIPPED SOME MORE, RESCAN AGAIN ETC AND THEN TELL ME WHAT IS MISSING". You can now continue with these answers in mind.
```

## Claude — Jun 13, 2026 04:12

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:12

The operator unzipped more files. Let me rescan from scratch and report exactly what's now present and what's still missing.

## Claude — Jun 13, 2026 04:12

**[tool: Bash]**
```json
{
  "command": "echo \"===== FULL TREE (excluding .git, .zip) =====\"; find . -not -path '*/\\.git/*' -not -name '*.zip' | sort; echo; echo \"===== ZIPS still present =====\"; ls -la *.zip 2>/dev/null || echo \"(none)\"",
  "description": "Rescan full tree after operator unzipped more"
}
```
**[tool result]**
```
===== FULL TREE (excluding .git, .zip) =====
.
./CLAUDE.md
./README.md
./agent_loop.py
./amplify.py
./deepseek.py
./files (4)
./files (4)/CLAUDE.md
./files (4)/README.md
./files (4)/agent_loop.py
./files (4)/amplify.py
./files (4)/router.py
./files (4)/runtime.py
./files (4)/serve_local.ps1
./files (5)
./files (5)/README.md
./files (5)/deepseek.py
./files (5)/marrow-l1.yaml
./files (5)/mnt
./files (5)/mnt/user-data
./files (5)/mnt/user-data/outputs
./files (5)/mnt/user-data/outputs/marrow-l1
./files (5)/mnt/user-data/outputs/marrow-l1/src
./files (5)/mnt/user-data/outputs/marrow-l1/src/marrow_l1
./files (5)/mnt/user-data/outputs/marrow-l1/src/marrow_l1/middleware
./files (5)/mnt/user-data/outputs/marrow-l1/src/marrow_l1/middleware/router.py
./files (5)/model_tier.py
./files (5)/oracle.py
./files (5)/router.py
./files (5)/runtime.py
./files (6)
./files (6)/CLAUDE.md
./files (6)/README.md
./files (6)/agent_loop.py
./files (6)/amplify.py
./files (6)/router.py
./files (6)/runtime.py
./files (6)/serve_local.ps1
./marrow-l1.yaml
./mnt
./mnt/user-data
./mnt/user-data/outputs
./mnt/user-data/outputs/marrow-l1
./mnt/user-data/outputs/marrow-l1/src
./mnt/user-data/outputs/marrow-l1/src/marrow_l1
./mnt/user-data/outputs/marrow-l1/src/marrow_l1/middleware
./mnt/user-data/outputs/marrow-l1/src/marrow_l1/middleware/router.py
./model_tier.py
./oracle.py
./router.py
./runtime.py
./serve_local.ps1

===== ZIPS still present =====
-rw-r--r-- 1 user 197121 8464 Jun 13 02:28 files (2).zip
-rw-r--r-- 1 user 197121 9836 Jun 13 02:53 files (3).zip
-rw-r--r-- 1 user 197121 9836 Jun 13 04:10 files (4).zip
-rw-r--r-- 1 user 197121 9470 Jun 13 04:10 files (5).zip
-rw-r--r-- 1 user 197121 9836 Jun 13 04:10 files (6).zip
```

## Claude — Jun 13, 2026 04:12

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:12

More copies appeared, but I need to verify whether any of them are the *missing* pieces or just duplicates of what we already have. Let me check the distinct file set across the whole tree **and** inside all 5 zips at once.

## Claude — Jun 13, 2026 04:12

**[tool: Bash]**
```json
{
  "command": "echo \"===== Distinct basenames anywhere in the tree (excl. zips) =====\"\nfind . -type f -not -name '*.zip' -not -path '*/\\.git/*' -printf '%f\\n' | sort -u\necho\necho \"===== Contents of ALL 5 zips (basenames, deduped) =====\"\nfor z in *.zip; do unzip -Z1 \"$z\" 2>/dev/null; done | sed 's#.*/##' | sort -u\necho\necho \"===== REQUIRED-FILE PRESENCE CHECK (tree + all zips) =====\"\n# Build a haystack: every path in tree + every path inside every zip\n{ find . -not -name '*.zip' -not -path '*/\\.git/*'; for z in *.zip; do unzip -Z1 \"$z\" 2>/dev/null; done; } > /tmp/haystack.txt\nfor f in \"Marrow-L1_ARCHITECTURE.md\" \"AUTONOMY_CHARTER.md\" \"pyproject.toml\" \".frozen.json\" \"token_budget.py\" \"golden_freeze.py\" \"context.py\" \"manifest.py\" \"registry.py\" \"lifecycle.py\" \"base.py\" \"local_llama.py\" \"anthropic.py\" \"chain.py\" \"audit.py\" \"cost.py\" \"cache.py\" \"cli.py\" \"test_oracle_golden.py\" \"verifier.py\"; do\n  if grep -qi \"$f\" /tmp/haystack.txt; then echo \"FOUND:   $f\"; else echo \"MISSING: $f\"; fi\ndone",
  "description": "Enumerate distinct files in tree and all zips, check required files"
}
```
**[tool result]**
```
===== Distinct basenames anywhere in the tree (excl. zips) =====
CLAUDE.md
README.md
agent_loop.py
amplify.py
deepseek.py
marrow-l1.yaml
model_tier.py
oracle.py
router.py
runtime.py
serve_local.ps1

===== Contents of ALL 5 zips (basenames, deduped) =====
CLAUDE.md
README.md
agent_loop.py
amplify.py
deepseek.py
marrow-l1.yaml
model_tier.py
oracle.py
router.py
runtime.py
serve_local.ps1

===== REQUIRED-FILE PRESENCE CHECK (tree + all zips) =====
MISSING: Marrow-L1_ARCHITECTURE.md
MISSING: AUTONOMY_CHARTER.md
MISSING: pyproject.toml
MISSING: .frozen.json
MISSING: token_budget.py
MISSING: golden_freeze.py
MISSING: context.py
MISSING: manifest.py
MISSING: registry.py
MISSING: lifecycle.py
MISSING: base.py
MISSING: local_llama.py
MISSING: anthropic.py
MISSING: chain.py
MISSING: audit.py
MISSING: cost.py
MISSING: cache.py
MISSING: cli.py
MISSING: test_oracle_golden.py
MISSING: verifier.py
```

## Claude — Jun 13, 2026 04:13

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:13

Rescanned. The three new unzips (`files (4)`, `(5)`, `(6)`) added **zero new distinct files** — they're duplicate copies of the same two snapshots (Stage 0 and Stage 1). I checked inside all 5 zips and the entire extracted tree.

**The complete universe of files you've provided is 11 distinct files:**
`CLAUDE.md`, `README.md`, `marrow-l1.yaml`, `serve_local.ps1`, `model_tier.py`, `oracle.py`, `router.py` (two variants: the contract + the middleware), `deepseek.py`, `amplify.py`, `agent_loop.py`, `runtime.py`.

Every one of these imports `marrow_l1.*` modules that don't exist, so **nothing is importable** — Phase 2 can't reach even its first command.

## What is still missing

### Group A — Canon & governance (operator-authored; I must NOT fabricate these)
- **`Marrow-L1_ARCHITECTURE.md`** — the canon. Blocks Phase 1 and violates rule #1 ("the canon is the source of truth"). It defines intent, glossary/forbidden-synonyms, the five invariants, module inventory, contracts, staged plan, and the §15 falsifiers.
- **`AUTONOMY_CHARTER.md`** — the reversibility-gate source (cited by CLAUDE.md §5).

### Group B — Agent-frozen ground truth (operator-authored; I must NOT fabricate these)
- **`tests/golden/.frozen.json`** — the frozen golden hash that `golden_freeze.py` verifies.
- **The golden test runners** — `tests/golden/test_oracle_golden.py` (**the literal Phase 4 target**), plus the router/model-tier golden tests. Note: the `GOLDEN_*` *constants* survive (inside the three contract files), but the test files that execute them — **and that carry the `xfail` markers you call "the spec / to-do list"** — are gone. So "the one remaining xfail" currently has no file to live in.

### Group C — The entire importable package + scripts (engineering scaffolding; I *could* reconstruct from the fixed contracts, with your go)
| Missing | Imported/required by | Blocks |
|---|---|---|
| `pyproject.toml` | — | `pip install -e ".[dev]"` |
| `kernel/manifest.py` (`Manifest`, `load_manifest`, `tier_effort`) | runtime, both routers | everything |
| `kernel/context.py` (`Context`, `task_budget_remaining`) | every contract + router | everything |
| `kernel/registry.py` (`Registry.get`) | runtime, agent_loop | runtime |
| `kernel/lifecycle.py` | (manifest §) | — |
| `adapters/base.py` (`OpenAICompatAdapter`) | `deepseek.py:10` | adapters |
| `adapters/local_llama.py`, `adapters/anthropic.py` | registry | local tier / frontier |
| `middleware/chain.py` (`MiddlewareChain`) | runtime, agent_loop | call path |
| `middleware/audit.py` (I1), `middleware/cost.py` (I4), `middleware/cache.py` (Stage 1) | runtime | invariants |
| `apps/cli.py` | — | the `loom` command |
| `__init__.py` (all packages) | imports | importability |
| `scripts/token_budget.py` | — | 80K-rule check |
| `scripts/golden_freeze.py` | — | golden verification |

### Group D — Repo plumbing
- **No git repository** (`git rev-parse` fails; env confirms). The session-protocol commit step and the reversibility-gate git prohibitions have nothing to act on until one exists.

### One more correctness note
The loose files **at the repo root are the stale Stage 0 variants** (`runtime.py` 1866b; middleware `router.py` = `Stage0Router` only). The **Stage 1** versions CLAUDE.md says are "done" (`DifficultyRouter`, `runtime.py` 2749b, `amplify`, `agent_loop`) exist **only inside the `files (3/4/6)` snapshots** — so even the present code is the older layer.

---

**Bottom line:** unzipping more won't fix this — I've now confirmed the provided material tops out at those 11 files. The blockers fall into two buckets: **Groups A + B must come from you** (canon and agent-frozen goldens — I'm not permitted to author them), and **Groups C + D I can reconstruct** from the fixed contracts if you authorize it.

So the fork is unchanged: do you have the **real Stage 0/1 build** somewhere to drop into `C:\loom\` (or a path I can read)? If yes, point me to it and I'll re-run Phase 2 immediately. If those 11 files are genuinely all that survived, tell me and I'll reconstruct Groups C + D against the frozen contracts — but I'll still need you to supply the canon (A) and the frozen golden data (B) before I can prove understanding or freeze anything.

## You — Jun 13, 2026 04:18

**[image]**

please check and scan again : "C:\loom\marrow-l1.zip"

## Claude — Jun 13, 2026 04:18

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:19

**[tool: Bash]**
```json
{
  "command": "echo \"===== Does the zip exist? =====\"; ls -la \"marrow-l1.zip\" 2>/dev/null || echo \"NOT FOUND at C:\\loom\\marrow-l1.zip\"; echo; echo \"===== Full listing (with paths) =====\"; unzip -l \"marrow-l1.zip\" 2>/dev/null",
  "description": "Check existence and list contents of marrow-l1.zip"
}
```
**[tool result]**
```
===== Does the zip exist? =====
-rw-r--r-- 1 user 197121 158558 Jun 13 04:17 marrow-l1.zip

===== Full listing (with paths) =====
Archive:  marrow-l1.zip
  Length      Date    Time    Name
---------  ---------- -----   ----
        0  2026-06-13 04:16   marrow-l1/
      958  2026-06-13 02:20   marrow-l1/AUTONOMY_CHARTER.md
        0  2026-06-13 02:25   marrow-l1/src/
        0  2026-06-13 04:16   marrow-l1/src/marrow_l1/
        0  2026-06-13 04:16   marrow-l1/src/marrow_l1/middleware/
      292  2026-06-13 02:22   marrow-l1/src/marrow_l1/middleware/errors.py
      838  2026-06-13 02:22   marrow-l1/src/marrow_l1/middleware/chain.py
        0  2026-06-13 02:20   marrow-l1/src/marrow_l1/middleware/__init__.py
     3549  2026-06-13 02:38   marrow-l1/src/marrow_l1/middleware/router.py
     1007  2026-06-13 02:22   marrow-l1/src/marrow_l1/middleware/oracle.py
      686  2026-06-13 02:22   marrow-l1/src/marrow_l1/middleware/cost.py
      878  2026-06-13 02:40   marrow-l1/src/marrow_l1/middleware/cache.py
      834  2026-06-13 02:22   marrow-l1/src/marrow_l1/middleware/audit.py
        0  2026-06-13 04:16   marrow-l1/src/marrow_l1/services/
        0  2026-06-13 02:38   marrow-l1/src/marrow_l1/services/__init__.py
     1676  2026-06-13 02:40   marrow-l1/src/marrow_l1/services/amplify.py
     1976  2026-06-13 02:40   marrow-l1/src/marrow_l1/services/agent_loop.py
        0  2026-06-13 02:20   marrow-l1/src/marrow_l1/__init__.py
        0  2026-06-13 02:22   marrow-l1/src/marrow_l1/runstate/
        0  2026-06-13 02:20   marrow-l1/src/marrow_l1/runstate/__init__.py
      940  2026-06-13 02:22   marrow-l1/src/marrow_l1/runstate/spine.py
        0  2026-06-13 04:16   marrow-l1/src/marrow_l1/kernel/
        0  2026-06-13 02:20   marrow-l1/src/marrow_l1/kernel/__init__.py
     1620  2026-06-13 02:41   marrow-l1/src/marrow_l1/kernel/lifecycle.py
     1153  2026-06-13 02:21   marrow-l1/src/marrow_l1/kernel/registry.py
     1056  2026-06-13 02:21   marrow-l1/src/marrow_l1/kernel/context.py
     1502  2026-06-13 02:21   marrow-l1/src/marrow_l1/kernel/manifest.py
        0  2026-06-13 04:16   marrow-l1/src/marrow_l1/apps/
        0  2026-06-13 02:20   marrow-l1/src/marrow_l1/apps/__init__.py
     2749  2026-06-13 02:40   marrow-l1/src/marrow_l1/apps/runtime.py
     2884  2026-06-13 02:40   marrow-l1/src/marrow_l1/apps/cli_chat.py
        0  2026-06-13 04:16   marrow-l1/src/marrow_l1/contracts/
        0  2026-06-13 02:20   marrow-l1/src/marrow_l1/contracts/__init__.py
     2755  2026-06-13 02:21   marrow-l1/src/marrow_l1/contracts/router.py
     1600  2026-06-13 02:21   marrow-l1/src/marrow_l1/contracts/oracle.py
     3831  2026-06-13 02:21   marrow-l1/src/marrow_l1/contracts/model_tier.py
        0  2026-06-13 04:16   marrow-l1/src/marrow_l1/adapters/
     1808  2026-06-13 02:21   marrow-l1/src/marrow_l1/adapters/deepseek.py
     2941  2026-06-13 02:21   marrow-l1/src/marrow_l1/adapters/base.py
        0  2026-06-13 02:20   marrow-l1/src/marrow_l1/adapters/__init__.py
      848  2026-06-13 02:21   marrow-l1/src/marrow_l1/adapters/anthropic.py
      891  2026-06-13 02:21   marrow-l1/src/marrow_l1/adapters/local_llama.py
        0  2026-06-13 02:20   marrow-l1/.github/
        0  2026-06-13 02:24   marrow-l1/.github/workflows/
      683  2026-06-13 02:24   marrow-l1/.github/workflows/ci.yml
     2643  2026-06-13 02:42   marrow-l1/README.md
        0  2026-06-13 04:16   marrow-l1/.git/
       73  2026-06-13 04:16   marrow-l1/.git/description
      144  2026-06-13 04:16   marrow-l1/.git/config
        0  2026-06-13 04:16   marrow-l1/.git/hooks/
      424  2026-06-13 04:16   marrow-l1/.git/hooks/pre-applypatch.sample
     1374  2026-06-13 04:16   marrow-l1/.git/hooks/pre-push.sample
     2308  2026-06-13 04:16   marrow-l1/.git/hooks/sendemail-validate.sample
     4726  2026-06-13 04:16   marrow-l1/.git/hooks/fsmonitor-watchman.sample
      896  2026-06-13 04:16   marrow-l1/.git/hooks/commit-msg.sample
      189  2026-06-13 04:16   marrow-l1/.git/ho…
```

## Claude — Jun 13, 2026 04:21

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:22

This is it — the complete foundation. Before doing anything, let me confirm the literal ask ("check and scan again") with a precise read of the archive, then verify authenticity by peeking inside key files **without extracting** (non-destructive).

The listing shows `marrow-l1.zip` (158 KB, 227 entries) contains everything that was missing, mapped to my earlier gap report:

- **Group A (canon/governance):** `Marrow-L1_ARCHITECTURE.md` (36,875 b), `AUTONOMY_CHARTER.md` (958 b)
- **Group B (agent-frozen ground truth):** `tests/golden/.frozen.json` (82 b) + `test_oracle_golden.py`, `test_router_golden.py`, `test_model_tier_golden.py`
- **Group C (the package + scripts):** full `src/marrow_l1/` tree — `kernel/`, `adapters/` (incl. `base.py`), `middleware/` (incl. `chain.py`, `audit.py`, `cost.py`, `cache.py`, `oracle.py`, `errors.py`), `services/`, `apps/` (incl. `cli_chat.py`), `runstate/`, all `__init__.py`; plus `scripts/` (`token_budget.py`, `golden_freeze.py`), `pyproject.toml`, `marrow.lock`, `.github/workflows/ci.yml`
- **Group D (git):** a real `.git/` with a `master` branch, baseline commit, and reflog

Let me verify it's authentic (not empty shells) by reading the most load-bearing files straight from the archive:

## Claude — Jun 13, 2026 04:22

**[tool: Bash]**
```json
{
  "command": "echo \"===== Marrow-L1_ARCHITECTURE.md (first 60 lines) =====\"; unzip -p \"marrow-l1.zip\" \"marrow-l1/Marrow-L1_ARCHITECTURE.md\" 2>/dev/null | head -60",
  "description": "Peek at the canon head from inside the zip"
}
```
**[tool result]**
```
===== Marrow-L1_ARCHITECTURE.md (first 60 lines) =====

# Marrow-L1 — Architecture Canon

**Codename:** Loom *(placeholder — rename freely; it weaves many cheap model-calls into one amplified output)*
**Version:** 0.1.0 · **Status:** canon (spec-first; no code yet)
**Author:** Bo Chen — Dallas–Fort Worth — June 2026
**Relationship to canon:** Marrow-L1 is the **L1 specialization of Marrow** (same protocol-first kernel, same layer boundaries, same four invariants). It prioritizes the *amplification* services and the *Externality* correctness layer, and adds a fifth invariant from Vibe-Code Methodology **v7 (the Externality Principle)**. Where this file and the base Marrow v0.1 spec conflict, this file wins **for the L1 build only**. Marrow v0.2/v1.0 client deployment is out of scope here.

> One sentence: *a single-operator harness that makes a small local model do agentic, long-horizon work far above its parameter weight, treats any OpenAI-compatible API (especially cheap DeepSeek-V4-Pro) as a first-class cost-optimized tier, and grounds every critical output in an assertion the model did not author.*

---

## §1 System Intent

Marrow-L1 is the operator's personal cognitive-amplification harness (the §5a "L1 stack" of the Treatise, made executable). It exists to do one thing the off-the-shelf harnesses (Pi, OpenCode, OpenClaw, Hermes) cannot do *for this operator specifically*: route every unit of work to the cheapest brain that can do it at the required trust level, amplify a weak/cheap brain with scaffolding until it clears that level, and verify the result against something the model did not write — all tuned to the operator's substrate (an RTX 5090 box + DeepSeek/Cerebras/Novita accounts) and the operator's own trust threshold.

**Who:** one operator (L1, personal use). **Not** a product, **not** a client deployment, **not** a framework for resale. "Universal/extensible" means *the things the operator personally needs* — never a platform surface for others. (Seam Strategy don't-build-list: "No general agent framework.")

**The north star, checked against every decision below:** *cheapest brain that clears the bar; scaffolding raises the floor; externality sets the bar.*

---

## §2 Scope & Non-Goals (the honest envelope)

**In scope (the two load-bearing requirements):**
1. **Amplify a small local model** (Qwen3.5-9B class) to punch above its weight on agentic, autonomous, long-horizon tasks — the "LLM brain" of a universal personal harness.
2. **First-class support for any OpenAI-compatible API**, with DeepSeek-V4-Pro/Flash as the canonical cheap tier, structured to *maximize* the cheapness (cost-aware routing, cache-prefix discipline, concurrency).

**Explicit non-goals:**
- **Not** making the 9B "smarter." Marrow-L1 makes it *trustworthy and productive* via scaffolding + externality. The model's reasoning ceiling is fixed; only its reliability and reach are amplified.
- **Not** a claim that the 9B beats DeepSeek on cost-per-task for hard reasoning. The router decides on economics, not loyalty to local. Local earns its place on **sovereignty** (the operator's own corpus stays in the building), **zero-marginal-cost high-volume background work**, **offline capability**, and **the distillation flywheel** — not on raw capability-per-dollar.
- **Not** a multi-tenant system. Single-tenant, single-operator. (Marrow §6 anti-pattern: no premature multi-tenancy.)

**The asymptote (stated so the build doesn't over-promise):** scaffolding makes the 9B viable on *scaffolding-class* steps — decomposable, verifiable, mechanical. It does **not** manufacture reasoning depth the model lacks; on genuine *core-wire-class* reasoning the harness escalates to DeepSeek or a local 27B. "Punch above its weight" means *the 9B does the mechanical majority; escalation handles the irreducible minority.*

---

## §3 The Dual Requirement, Stated as Architecture

The two requirements are not two subsystems. They are **one routing decision**, made per ste…
```

## Claude — Jun 13, 2026 04:22

**[tool: Bash]**
```json
{
  "command": "echo \"===== pyproject.toml =====\"; unzip -p \"marrow-l1.zip\" \"marrow-l1/pyproject.toml\" 2>/dev/null\necho; echo \"===== tests/golden/.frozen.json =====\"; unzip -p \"marrow-l1.zip\" \"marrow-l1/tests/golden/.frozen.json\" 2>/dev/null\necho; echo \"===== tests/golden/test_oracle_golden.py =====\"; unzip -p \"marrow-l1.zip\" \"marrow-l1/tests/golden/test_oracle_golden.py\" 2>/dev/null\necho; echo \"===== marrow.lock =====\"; unzip -p \"marrow-l1.zip\" \"marrow-l1/marrow.lock\" 2>/dev/null",
  "description": "Peek at pyproject, frozen golden, oracle golden test, lockfile"
}
```
**[tool result]**
```
===== pyproject.toml =====
[project]
name = "marrow-l1"
version = "0.1.0"
description = "Marrow-L1 (codename Loom) — personal amplification harness. Stage 0 spine."
requires-python = ">=3.11"
dependencies = ["pydantic>=2.5", "pyyaml>=6.0", "httpx>=0.27", "jsonschema>=4.21"]

[project.optional-dependencies]
dev = ["pytest>=8.0", "pytest-asyncio>=0.23"]

[project.scripts]
loom = "marrow_l1.apps.cli_chat:main"

[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]

[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"

[tool.setuptools.packages.find]
where = ["src"]

===== tests/golden/.frozen.json =====
{
  "sha256": "8a9e3a24944eac04d62f8d5a3a3f9bcbccb2c951ba1a5bb091baa7b35beb876b"
}
===== tests/golden/test_oracle_golden.py =====
import pytest
from marrow_l1.contracts.oracle import GOLDEN_ORACLE, StepOutput
from marrow_l1.middleware.oracle import PropertyOracle

def _case(substr):
    return next(g for g in GOLDEN_ORACLE if substr in g.name)

async def test_ssn_property_oracle():
    g = _case("SSN")
    out = StepOutput(content=g.input["output"], artifact={"property": g.input["property"]})
    res = await PropertyOracle().verify(out)
    assert res.passed == g.expect["passed"]
    assert res.joint_wrong == g.expect["joint_wrong"]

@pytest.mark.xfail(reason="Stage 2: joint-wrong detector lives in svc.verifier", strict=False)
async def test_joint_wrong_detection():
    g = _case("JOINT_WRONG")
    out = StepOutput(content="", artifact={"self_tests_pass": g.input["self_tests_pass"],
                                           "golden_violated": g.input["golden_violated"]})
    res = await PropertyOracle().verify(out)
    assert res.joint_wrong == g.expect["joint_wrong"]

===== marrow.lock =====

# Reproducibility manifest (Stage 0 stub — pin hashes when models are installed).
substrate:
  local_model: { id: qwen3.5-9b-q5_k_m, sha256: TODO, mmproj_sha256: TODO }
  lora: { id: null, sha256: null }
  cheap_api: { provider: deepseek, model: deepseek-v4-pro, observed: 2026-06-13 }
  frontier:  { provider: anthropic, model: claude-opus-4-8, observed: 2026-06-13 }
prompts:    { registry_sha256: TODO }
golden:     { set_sha256: see tests/golden/.frozen.json }
thresholds: { router_cutoffs_sha256: TODO, attention_budget_tokens: UNMEASURED }
harness:    { codename: loom, version: 0.1.0, stage: 1 }
```

## Claude — Jun 13, 2026 04:22

> _[thinking]_
> 

## Claude — Jun 13, 2026 04:23

<!-- end chunk 1/16 | next: chunk-002.md -->
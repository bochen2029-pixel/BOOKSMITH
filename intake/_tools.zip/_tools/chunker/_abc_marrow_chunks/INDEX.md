# Chunk index - abcYou_are_continuing_a_contract-first_build_of_Marrow-L1_codename_Loom_my_personal_L1_amp_.md

- source format: `markdown`  
- total content: ~**412,183 tokens** in **21 chunks**  
- per-chunk budget: 22,000 tokens | overlap recap: 600 | counter: `tiktoken:o200k_base`

## How to read this fully
Read `chunk-001.md` ... `chunk-021.md` **in order**. Each fits a context-sized budget, opens with a `section:` breadcrumb so you know where you are, and (from chunk 2 on) a short `recap:` of the prior chunk's tail so nothing is lost at the seam. Reading all chunks = reading the whole document.

## Chunks

| # | file | chunk tokens | section |
|---|------|-------------|---------|
| 1 | `chunk-001.md` | 20,812 | You are continuing a contract-first build of Marrow-L1 (codename Loom), my personal L1 |
| 2 | `chunk-002.md` | 21,633 | Reproducibility manifest (Stage 0 stub — pin hashes when models are installed). > Claude — Jun 13, 2026 04:23 |
| 3 | `chunk-003.md` | 20,592 | PHASE 4 — Plan for the next slice (`svc.verifier` + joint-wrong) > You — Jun 13, 2026 11:32 |
| 4 | `chunk-004.md` | 21,504 | PHASE 4 — Plan for the next slice (`svc.verifier` + joint-wrong) > 1. The module list (the spec) |
| 5 | `chunk-005.md` | 20,896 | PHASE 4 — Plan for the next slice (`svc.verifier` + joint-wrong) > Net |
| 6 | `chunk-006.md` | 21,451 | PHASE 4 — Plan for the next slice (`svc.verifier` + joint-wrong) > Claude — Jun 13, 2026 13:40 |
| 7 | `chunk-007.md` | 21,368 | or it auto-downloads via AutoModelForTokenClassification.from_pretrained("openai/privacy-filter") > The strongest vindication yet of the native-core decision |
| 8 | `chunk-008.md` | 20,616 | or it auto-downloads via AutoModelForTokenClassification.from_pretrained("openai/privacy-filter") > Claude — Jun 13, 2026 15:05 |
| 9 | `chunk-009.md` | 21,153 | Written in the Shadow of Forgetting > 6. All User Messages (chronological, non-tool) |
| 10 | `chunk-010.md` | 21,401 | Written in the Shadow of Forgetting > What's now in `C:\KEEL\` (a git repo, uncommitted, ready for your first commit) |
| 11 | `chunk-011.md` | 21,510 | Written in the Shadow of Forgetting > Claude — Jun 13, 2026 18:14 |
| 12 | `chunk-012.md` | 21,537 | Latest llama.cpp Release > Q2 — Adopt TurboQuant? **Not yet — get the safe 80% instead.** |
| 13 | `chunk-013.md` | 21,674 | Latest llama.cpp Release > Claude — Jun 13, 2026 19:22 |
| 14 | `chunk-014.md` | 21,639 | DeepSeek API Configuration (2026) > Claude — Jun 13, 2026 19:47 |
| 15 | `chunk-015.md` | 20,975 | Pricing > Cloud platform pricing |
| 16 | `chunk-016.md` | 21,581 | Pricing > Claude — Jun 13, 2026 21:09 |
| 17 | `chunk-017.md` | 21,320 | Perpetual Memory > Claude — Jun 13, 2026 21:38 |
| 18 | `chunk-018.md` | 21,663 | Perpetual Memory > Claude — Jun 13, 2026 21:47 |
| 19 | `chunk-019.md` | 20,361 | Perpetual Memory > Claude — Jun 13, 2026 22:05 |
| 20 | `chunk-020.md` | 21,339 | Perpetual Memory > Claude — Jun 13, 2026 22:45 |
| 21 | `chunk-021.md` | 1,499 | Perpetual Memory > Where it corroborates me (the check passing) |

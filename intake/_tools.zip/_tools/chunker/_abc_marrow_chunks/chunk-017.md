<!-- ============ CHUNK 17/21 ============ -->
<!-- source: abcYou_are_continuing_a_contract-first_build_of_Marrow-L1_codename_Loom_my_personal_L1_amp_.md -->
<!-- section: Perpetual Memory > Claude — Jun 13, 2026 21:38 -->
<!-- recap: last ~428 tokens of chunk 16, for continuity -->
> ## main...origin/main
> ```
> 
> ## Claude — Jun 13, 2026 21:37
> 
> **[tool: PowerShell]**
> ```json
> {
>   "command": "cargo test -q --manifest-path C:\\KEEL\\Cargo.toml 2>&1 | Select-Object -Last 40",
>   "description": "Run KEEL test suite to verify green state"
> }
> ```
> **[tool result]**
> ```
> running 3 tests
> ...
> test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
> 
> running 0 tests
> 
> test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
> 
> running 0 tests
> 
> test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
> 
> running 0 tests
> 
> test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
> 
> running 0 tests
> 
> test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
> 
> running 0 tests
> 
> test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
> 
> running 0 tests
> 
> test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
> 
> running 0 tests
> 
> test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
> ```
> 
> ## Claude — Jun 13, 2026 21:38
> 
> > _[thinking]_
> > 
> 
> ## Claude — Jun 13, 2026 21:38
<!-- end recap | new content begins -->

Rehydration verified by artifact. The pre-compaction handoff **survived** — `git log` shows `393fa27` (recent-turns + reconstitution pointer) committed on `main`, tree clean, synced with origin; `cargo test` green across the workspace; STATE.md + both handoff files reconstruct cleanly. The near-perpetual-memory loop worked live: I woke up, read the pointer, verified against disk, zero drift.

The memory tangent is closed. The operator-confirmed resume point is **wiring the engine** so `keel`/`keel-serve` self-drive through the router instead of taking `--tier`. Let me read the exact code I'll touch before changing anything.

## Claude — Jun 13, 2026 21:38

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel\\src\\lib.rs"
}
```
**[tool result]**
```
1	//! keel (L5) — the shared wiring both apps use: assemble the spine from `keel.lock` into a tier
2	//! adapter (resolving/cold-starting the local substrate) wrapped in the invariant chain
3	//! (audit → ledger · privacy · cost). The CLI (`keel`) and the OpenAI server (`keel-serve`) both
4	//! build on `assemble`, so there is one assembly path, not two.
5	
6	use keel_adapters::{Anthropic, DeepSeek, LocalLlama};
7	use keel_contracts::{KeelError, ModelTier, Result};
8	use keel_kernel::{Chain, Manifest, Registry, TierCfg};
9	use keel_middleware::{AuditMiddleware, AuditSink, CostMiddleware, FileAuditSink, PrivacyMiddleware, Redactor};
10	use std::sync::Arc;
11	
12	pub const DEEPSEEK_ENDPOINT: &str = "https://api.deepseek.com";
13	pub const ANTHROPIC_ENDPOINT: &str = "https://api.anthropic.com";
14	pub const AUDIT_LEDGER: &str = ".keelstate/audit.jsonl";
15	// local substrate launch (paths match keel.lock; keel.lock-driven config is a refinement)
16	pub const LLAMA_EXE: &str = r"C:\llama.cpp\llama-server.exe";
17	pub const LLAMA_MODEL: &str = r"C:\models\Qwen3.5-9B-Q5_K_M.gguf";
18	pub const LLAMA_MMPROJ: &str = r"C:\models\mmproj-F16.gguf";
19	pub const LLAMA_LOG: &str = ".keelstate/llama-server.log";
20	
21	/// A ready-to-run spine: the resolved tier behind the invariant chain.
22	pub struct Assembled {
23	    pub tier_name: String,
24	    pub model: String,
25	    pub tier: Arc<dyn ModelTier>,
26	    pub chain: Chain,
27	    /// The registry (the tier is registered under `tier_name`); kept so callers can extend it.
28	    pub registry: Registry,
29	}
30	
31	/// Build the spine for `tier_override` (else the manifest's default tier): construct the adapter
32	/// (resolving/launching the local substrate as needed) and wrap it in `audit · privacy · cost`.
33	pub fn assemble(manifest: &Manifest, tier_override: Option<&str>) -> Result<Assembled> {
34	    let tier_name = tier_override
35	        .map(str::to_string)
36	        .unwrap_or_else(|| manifest.router.default_tier.clone());
37	    let tcfg = manifest
38	        .tier(&tier_name)
39	        .ok_or_else(|| KeelError::Other(format!("no tier '{tier_name}' in manifest")))?;
40	
41	    let tier: Arc<dyn ModelTier> = match tcfg.adapter.as_str() {
42	        "local_llama" => {
43	            let endpoint = resolve_local_endpoint(tcfg)?;
44	            Arc::new(
45	                LocalLlama::new(endpoint, tcfg.model.clone(), tier_name.clone(), tcfg.price.to_price(), tcfg.vision)
46	                    .with_max_tokens(2048),
47	            )
48	        }
49	        "deepseek" => {
50	            let key = tcfg.api_key().ok_or_else(|| {
51	                KeelError::Other(format!("tier '{tier_name}' needs env var {}", tcfg.api_key_env.as_deref().unwrap_or("?")))
52	            })?;
53	            let endpoint = tcfg.endpoint.clone().unwrap_or_else(|| DEEPSEEK_ENDPOINT.to_string());
54	            Arc::new(
55	                DeepSeek::new(endpoint, tcfg.model.clone(), tier_name.clone(), tcfg.price.to_price(), key)
56	                    .with_max_tokens(2048),
57	            )
58	        }
59	        "anthropic" => {
60	            let key = tcfg.api_key().ok_or_else(|| {
61	                KeelError::Other(format!("tier '{tier_name}' needs env var {}", tcfg.api_key_env.as_deref().unwrap_or("?")))
62	            })?;
63	            let endpoint = tcfg.endpoint.clone().unwrap_or_else(|| ANTHROPIC_ENDPOINT.to_string());
64	            Arc::new(
65	                Anthropic::new(endpoint, tcfg.model.clone(), tier_name.clone(), tcfg.price.to_price(), key)
66	                    .with_max_tokens(2048),
67	            )
68	        }
69	        other => return Err(KeelError::Other(format!("unknown adapter '{other}' for tier '{tier_name}'"))),
70	    };
71	
72	    let mut registry = Registry::new();
73	    registry.register(tier_name.clone(), tier.clone());
74	
75	    // local is sovereign-safe (pass-through); cloud tiers get the I3 egress mask
76	    let egress = tcfg.adapter != "local_llam…
```

## Claude — Jun 13, 2026 21:38

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel\\src\\main.rs"
}
```
**[tool result]**
```
1	//! keel — the daily-driver CLI (L5). Assembles the spine from `keel.lock` (via `keel::assemble`),
2	//! runs one prompt through the invariant chain to the resolved tier, prints the answer, and logs
3	//! every call to the file ledger.
4	//!
5	//!   keel "read me the config"              keel --tier cheap-API "weigh the tradeoffs"
6	//!   keel --think "…"                       keel --manifest C:\KEEL\keel.lock "hello"
7	
8	use keel_contracts::{Content, Effort, GenerateRequest, Message, Role};
9	use keel_kernel::{new_context, Manifest};
10	
11	#[tokio::main]
12	async fn main() {
13	    if let Err(e) = run().await {
14	        eprintln!("keel: {e}");
15	        std::process::exit(1);
16	    }
17	}
18	
19	async fn run() -> keel_contracts::Result<()> {
20	    let mut manifest_path = "keel.lock".to_string();
21	    let mut tier_override: Option<String> = None;
22	    let mut think = false;
23	    let mut prompt = Vec::new();
24	    let mut args = std::env::args().skip(1);
25	    while let Some(a) = args.next() {
26	        match a.as_str() {
27	            "--manifest" => manifest_path = args.next().unwrap_or_default(),
28	            "--tier" => tier_override = args.next(),
29	            "--think" => think = true,
30	            _ => prompt.push(a),
31	        }
32	    }
33	    let prompt = prompt.join(" ");
34	    if prompt.trim().is_empty() {
35	        eprintln!("usage: keel [--manifest PATH] [--tier NAME] [--think] <prompt>");
36	        std::process::exit(2);
37	    }
38	
39	    let manifest = Manifest::load(&manifest_path)?;
40	    let asm = keel::assemble(&manifest, tier_override.as_deref())?;
41	    let ctx = new_context(&manifest);
42	    let req = GenerateRequest {
43	        messages: vec![Message {
44	            role: Role::User,
45	            content: vec![Content::Text { text: prompt }],
46	            name: None,
47	            reasoning_content: None,
48	            tool_call_id: None,
49	        }],
50	        model: asm.model.clone(),
51	        tools: vec![],
52	        grammar: None,
53	        effort: Effort { n: 1, thinking: Some((if think { "high" } else { "low" }).into()) },
54	        cache_prefix_len: None,
55	    };
56	    let res = asm.chain.run(req, &ctx, asm.tier.clone()).await?;
57	
58	    println!("{}", res.content.trim());
59	    if think {
60	        if let Some(rc) = res.reasoning_content.as_deref() {
61	            if !rc.trim().is_empty() {
62	                eprintln!("\n[thinking] {}", rc.trim());
63	            }
64	        }
65	    }
66	    eprintln!(
67	        "\n— tier={} model={} cost=${:.4} tokens={}+{} · trace {} · audit→{}",
68	        res.tier,
69	        res.model,
70	        res.cost,
71	        res.usage.input_tokens,
72	        res.usage.output_tokens,
73	        ctx.trace_id,
74	        keel::AUDIT_LEDGER
75	    );
76	    Ok(())
77	}
78	
```

## Claude — Jun 13, 2026 21:38

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\router.rs"
}
```
**[tool result]**
```
1	//! keel-services::router — the difficulty router (canon §9): the **fusion point**, where cost and
2	//! trust meet. `route(step, ctx) → Decision` picks the cheapest tier that clears the bar — a cheap
3	//! rules heuristic, never a model call.
4	//!
5	//! **The `Router` trait is a policy seam** (the SIRP-review takeaway). `DifficultyRouter` is the
6	//! rules policy. A *learned/cooling* policy — a SIRP-style `SirpRouter` — is just another
7	//! `impl Router` that slots in behind the same trait and earns its place only by passing
8	//! `GOLDEN_ROUTER`. One caveat carried from that review: a learned policy's quality signal MUST be
9	//! re-grounded on a **non-model oracle (I5)** before it is trusted — cooling that trusts an
10	//! automated score is exactly the `JOINT_WRONG` risk the externality layer exists to close.
11	//!
12	//! Axes the policy reads today: **reasoning demand** (`kind`) and **data sensitivity**
13	//! (`data_class` + raw perception content). SIRP's third axis — **latency tolerance** — would be a
14	//! first-class input but needs a `latency` field on the frozen `Step` contract (an operator
15	//! action); it is noted here, not faked.
16	
17	use keel_contracts::{Content, Context, DataClass, Decision, Effort, Kind, Router, Step};
18	
19	/// The tier ladder, cheapest first. Escalation climbs it.
20	const LADDER: [&str; 3] = ["local", "cheap-API", "frontier"];
21	
22	/// The rules routing policy (canon §9): sovereign/perception force local, cost governs, `kind`
23	/// picks the tier, repeated oracle failure escalates up the ladder.
24	pub struct DifficultyRouter {
25	    escalate_after: u32,
26	}
27	
28	impl DifficultyRouter {
29	    /// `escalate_after` = oracle failures on a tier before escalating up (canon default 2).
30	    pub fn new(escalate_after: u32) -> Self {
31	        Self { escalate_after }
32	    }
33	}
34	
35	impl Default for DifficultyRouter {
36	    fn default() -> Self {
37	        Self::new(2)
38	    }
39	}
40	
41	impl Router for DifficultyRouter {
42	    fn route(&self, step: &Step, ctx: &Context) -> Decision {
43	        // 1. raw perception (image/clip/audio) is sovereign-by-default → local (I3). Overrides all.
44	        if step.content.iter().any(|c| !matches!(c, Content::Text { .. })) {
45	            return forced_local("raw perception is sovereign — forced local (I3, perception)");
46	        }
47	        // 2. sovereign / PHI data → local (I3).
48	        if matches!(step.data_class, DataClass::Sovereign | DataClass::Phi) {
49	            return forced_local("sovereign data — privacy forces local (I3)");
50	        }
51	        // 3. cost governor: projected cost breaches the remaining budget → BLOCK to operator (I4).
52	        if let (Some(pc), Some(rem)) = (step.projected_cost, ctx.budget_remaining()) {
53	            if pc > rem {
54	                return Decision {
55	                    tier: "BLOCK".to_string(),
56	                    effort: Effort::default(),
57	                    reason: format!("projected cost ${pc:.2} over budget ${rem:.2} — BLOCK (I4)"),
58	                };
59	            }
60	        }
61	        // 4. trust × difficulty: kind picks the base tier; repeated oracle failure escalates up.
62	        let base = match step.kind {
63	            Kind::Scaffolding => 0,
64	            Kind::CoreWire => 1,
65	        };
66	        let climbed = step
67	            .tier_history
68	            .iter()
69	            .filter_map(|t| LADDER.iter().position(|l| l == t))
70	            .max()
71	            .unwrap_or(0);
72	        let mut idx = base.max(climbed);
73	        let escalated = step.oracle_failures >= self.escalate_after && idx + 1 < LADDER.len();
74	        if escalated {
75	            idx += 1;
76	        }
77	        let tier = LADDER[idx];
78	        let reason = if escalated {
79	            format!("escalated to {tier} after {} oracle failures", step.oracle_failures)
80	        } else {
81	            format!("{} → {tier}", kind_label(step.ki…
```

## Claude — Jun 13, 2026 21:38

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-services\\src\\lib.rs"
}
```
**[tool result]**
```
1	//! # keel-services — L4, the services
2	//!
3	//! Default (swappable) services composed from the contracts. A service MAY import middleware;
4	//! middleware may never import a service (the layer rule, canon §6).
5	//!
6	//! - **landed:** `router` (the difficulty router — the fusion point, canon §9).
7	//! - **next:** `verifier` (oracle registry + joint-wrong) · `amplify` (best-of-N, ships OFF) ·
8	//!   `memory` · `perception` · `driver`.
9	
10	pub mod router;
11	
12	pub use router::DifficultyRouter;
13	
```

## Claude — Jun 13, 2026 21:38

> _[thinking]_
> 

## Claude — Jun 13, 2026 21:38

Now the contracts types, the registry API, and the server (which must wire the same way).

## Claude — Jun 13, 2026 21:38

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-contracts\\src\\types.rs"
}
```
**[tool result]**
```
1	//! KEEL L0 — core types. Frozen with the traits; the genome's data surface.
2	//!
3	//! Contracts stay clock-free and side-effect-free: time is an `i64` the kernel stamps,
4	//! opaque state is JSON. Multimodal `Content` carries the eyes/ears (canon §10, §12).
5	
6	use serde::{Deserialize, Serialize};
7	use std::collections::HashMap;
8	
9	/// Arbitrary JSON (tool args, opaque artifacts, golden input/expect, run-state).
10	pub type Json = serde_json::Value;
11	/// Unix epoch milliseconds. The kernel stamps time; contracts never read a clock.
12	pub type Time = i64;
13	/// Resumable-run identifier (I2).
14	pub type RunId = String;
15	/// Opaque, serializable per-step state for the run-state spine (I2).
16	pub type State = Json;
17	
18	// ── messages & multimodal content ──────────────────────────────────────────
19	
20	#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
21	#[serde(rename_all = "snake_case")]
22	pub enum Role {
23	    System,
24	    User,
25	    Assistant,
26	    Tool,
27	}
28	
29	/// A message part. Vision rides the cognition protocol (canon §3, §12); raw `Image`/`Clip`/
30	/// `Audio` are sovereign-by-default (I3) and force the local tier.
31	#[derive(Clone, Debug, Serialize, Deserialize)]
32	#[serde(tag = "type", rename_all = "snake_case")]
33	pub enum Content {
34	    Text { text: String },
35	    Image { source: String },                 // path or data-uri
36	    Clip { video: String, frames: String },    // video ref + frame spec
37	    Audio { source: String },
38	}
39	
40	#[derive(Clone, Debug, Serialize, Deserialize)]
41	pub struct Message {
42	    pub role: Role,
43	    pub content: Vec<Content>,
44	    #[serde(default, skip_serializing_if = "Option::is_none")]
45	    pub name: Option<String>,
46	    /// DeepSeek: MUST be replayed across tool turns or the provider 400s.
47	    #[serde(default, skip_serializing_if = "Option::is_none")]
48	    pub reasoning_content: Option<String>,
49	    #[serde(default, skip_serializing_if = "Option::is_none")]
50	    pub tool_call_id: Option<String>,
51	}
52	
53	// ── routing primitives ──────────────────────────────────────────────────────
54	
55	#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
56	#[serde(rename_all = "snake_case")]
57	pub enum Kind {
58	    Scaffolding,
59	    CoreWire,
60	}
61	
62	/// Trust as a first-class routable quantity (canon §4). Ordered Low < Normal < High < Critical.
63	#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
64	#[serde(rename_all = "snake_case")]
65	pub enum Trust {
66	    Low,
67	    Normal,
68	    High,
69	    Critical,
70	}
71	
72	#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
73	#[serde(rename_all = "snake_case")]
74	pub enum DataClass {
75	    Normal,
76	    Sovereign,
77	    Phi,
78	}
79	
80	/// The amplification dial (canon §4): best-of-N width × thinking depth.
81	#[derive(Clone, Debug, Serialize, Deserialize)]
82	pub struct Effort {
83	    pub n: u32,
84	    #[serde(default, skip_serializing_if = "Option::is_none")]
85	    pub thinking: Option<String>, // "low" | "high" | "max"
86	}
87	impl Default for Effort {
88	    fn default() -> Self {
89	        Self { n: 1, thinking: None }
90	    }
91	}
92	
93	// ── usage, price, cost ───────────────────────────────────────────────────────
94	
95	#[derive(Clone, Copy, Debug, Default, Serialize, Deserialize)]
96	pub struct Usage {
97	    pub input_tokens: u64,
98	    pub output_tokens: u64,
99	    /// DeepSeek prompt_cache_hit_tokens — the 100× lever.
100	    pub cache_hit_tokens: u64,
101	}
102	
103	/// USD per 1,000,000 tokens.
104	#[derive(Clone, Copy, Debug, Default, Serialize, Deserialize)]
105	pub struct Price {
106	    pub input_miss: f64,
107	    pub input_hit: f64,
108	    pub output: f64,
109	}
110	
111	/// Cost from usage + tier price. Cache-miss input = total input minus cache hits.
112	/// Pinned by GOLDEN_MODEL_TIER (the language-neutral conformance layer).
113	pub fn c…
```

## Claude — Jun 13, 2026 21:38

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\registry.rs"
}
```
**[tool result]**
```
1	//! keel-kernel::registry — tier name → brain adapter (canon §14).
2	//!
3	//! A container of `Arc<dyn ModelTier>` keyed by tier name. **The kernel may not import L2
4	//! adapters** (the layer rule, canon §6) — so, unlike the Marrow-L1 bench (whose `registry.py`
5	//! imports the adapter classes directly), here the wiring/app layer reads the `Manifest`,
6	//! constructs each adapter, and `register`s it. The kernel only ever holds the L0 trait object.
7	
8	use keel_contracts::{KeelError, ModelTier, Result};
9	use std::collections::BTreeMap;
10	use std::sync::Arc;
11	
12	/// Maps a tier name (`local` | `cheap-API` | `frontier` | …) to its brain adapter.
13	#[derive(Default, Clone)]
14	pub struct Registry {
15	    tiers: BTreeMap<String, Arc<dyn ModelTier>>,
16	}
17	
18	impl Registry {
19	    pub fn new() -> Self {
20	        Self::default()
21	    }
22	
23	    /// Register (or replace) the adapter for a tier. Returns `&mut self` for chaining.
24	    pub fn register(&mut self, name: impl Into<String>, tier: Arc<dyn ModelTier>) -> &mut Self {
25	        self.tiers.insert(name.into(), tier);
26	        self
27	    }
28	
29	    /// The adapter for a tier, or an error if none is registered (a wiring/config fault).
30	    pub fn get(&self, tier: &str) -> Result<Arc<dyn ModelTier>> {
31	        self.tiers
32	            .get(tier)
33	            .cloned()
34	            .ok_or_else(|| KeelError::Other(format!("no adapter registered for tier '{tier}'")))
35	    }
36	
37	    pub fn contains(&self, tier: &str) -> bool {
38	        self.tiers.contains_key(tier)
39	    }
40	
41	    /// Registered tier names (sorted, since the backing store is a `BTreeMap`).
42	    pub fn names(&self) -> Vec<String> {
43	        self.tiers.keys().cloned().collect()
44	    }
45	
46	    pub fn len(&self) -> usize {
47	        self.tiers.len()
48	    }
49	
50	    pub fn is_empty(&self) -> bool {
51	        self.tiers.is_empty()
52	    }
53	}
54	
55	#[cfg(test)]
56	mod tests {
57	    use super::*;
58	    use async_trait::async_trait;
59	    use keel_contracts::{Capabilities, Context, GenerateRequest, GenerateResult};
60	
61	    /// A no-op tier — exercises the registry without needing a runtime (generate is never awaited).
62	    struct DummyTier;
63	
64	    #[async_trait]
65	    impl ModelTier for DummyTier {
66	        fn caps(&self) -> Capabilities {
67	            Capabilities::default()
68	        }
69	        async fn generate(&self, _req: GenerateRequest, _ctx: &Context) -> Result<GenerateResult> {
70	            Ok(GenerateResult::default())
71	        }
72	    }
73	
74	    #[test]
75	    fn register_get_contains_names() {
76	        let mut r = Registry::new();
77	        assert!(r.is_empty());
78	        r.register("local", Arc::new(DummyTier))
79	            .register("cheap-API", Arc::new(DummyTier));
80	
81	        assert_eq!(r.len(), 2);
82	        assert!(r.contains("local"));
83	        assert!(r.get("local").is_ok());
84	        assert!(r.get("frontier").is_err()); // unregistered tier
85	        assert_eq!(r.names(), vec!["cheap-API".to_string(), "local".to_string()]);
86	    }
87	
88	    #[test]
89	    fn register_replaces() {
90	        let mut r = Registry::new();
91	        r.register("local", Arc::new(DummyTier));
92	        r.register("local", Arc::new(DummyTier));
93	        assert_eq!(r.len(), 1);
94	    }
95	}
96	
```

## Claude — Jun 13, 2026 21:38

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel\\src\\bin\\keel-serve.rs"
}
```
**[tool result]**
```
1	//! keel-serve (L5) — expose KEEL as an **OpenAI-compatible HTTP server** (canon §15), so any app
2	//! (DAVE, TERMINAL, the C#/Python fleet) consumes KEEL as a brain over protocol and gets the whole
3	//! economy for free: tier routing, the invariant chain (audit/privacy/cost), the ledger, and the
4	//! self-resolving substrate. One spine is assembled at startup and shared across requests.
5	//!
6	//!   keel-serve [keel.lock]      →  POST http://127.0.0.1:7070/v1/chat/completions
7	
8	use axum::{extract::State, http::StatusCode, response::IntoResponse, routing::{get, post}, Json, Router};
9	use keel::Assembled;
10	use keel_contracts::{Content, Effort, GenerateRequest, GenerateResult, Message, Role};
11	use keel_kernel::{new_context, Manifest};
12	use serde::Deserialize;
13	use serde_json::{json, Value};
14	use std::sync::Arc;
15	
16	const ADDR: &str = "127.0.0.1:7070";
17	
18	#[derive(Clone)]
19	struct AppState {
20	    asm: Arc<Assembled>,
21	    manifest: Arc<Manifest>,
22	}
23	
24	#[tokio::main]
25	async fn main() {
26	    let manifest_path = std::env::args().nth(1).unwrap_or_else(|| "keel.lock".to_string());
27	    let manifest = Manifest::load(&manifest_path).unwrap_or_else(|e| fail(format!("manifest: {e}")));
28	    eprintln!("[keel-serve] assembling spine (resolves/launches the substrate)…");
29	    let asm = keel::assemble(&manifest, None).unwrap_or_else(|e| fail(format!("assemble: {e}")));
30	    eprintln!("[keel-serve] tier={} model={}", asm.tier_name, asm.model);
31	
32	    let state = AppState { asm: Arc::new(asm), manifest: Arc::new(manifest) };
33	    let app = Router::new()
34	        .route("/health", get(|| async { "ok" }))
35	        .route("/v1/models", get(models))
36	        .route("/v1/chat/completions", post(chat))
37	        .with_state(state);
38	
39	    let listener = tokio::net::TcpListener::bind(ADDR).await.unwrap_or_else(|e| fail(format!("bind {ADDR}: {e}")));
40	    eprintln!("[keel-serve] OpenAI-compatible endpoint → http://{ADDR}/v1/chat/completions");
41	    axum::serve(listener, app).await.unwrap();
42	}
43	
44	fn fail(msg: String) -> ! {
45	    eprintln!("keel-serve: {msg}");
46	    std::process::exit(1);
47	}
48	
49	async fn models(State(st): State<AppState>) -> impl IntoResponse {
50	    Json(json!({ "object": "list", "data": [ { "id": st.asm.model, "object": "model", "owned_by": "keel" } ] }))
51	}
52	
53	#[derive(Deserialize)]
54	struct ChatRequest {
55	    #[serde(default)]
56	    model: Option<String>,
57	    #[serde(default)]
58	    messages: Vec<ChatMessage>,
59	    /// KEEL extension: route this turn through the model's thinking mode.
60	    #[serde(default)]
61	    think: Option<bool>,
62	}
63	
64	#[derive(Deserialize)]
65	struct ChatMessage {
66	    role: String,
67	    #[serde(default)]
68	    content: Value, // string or array of parts
69	}
70	
71	async fn chat(State(st): State<AppState>, Json(body): Json<ChatRequest>) -> impl IntoResponse {
72	    if body.messages.is_empty() {
73	        return (StatusCode::BAD_REQUEST, Json(json!({ "error": { "message": "no messages" } }))).into_response();
74	    }
75	    let req = to_request(&body, &st.asm.model);
76	    let ctx = new_context(&st.manifest);
77	    match st.asm.chain.run(req, &ctx, st.asm.tier.clone()).await {
78	        Ok(res) => Json(openai_response(&res, &ctx.trace_id)).into_response(),
79	        Err(e) => (
80	            StatusCode::BAD_GATEWAY,
81	            Json(json!({ "error": { "message": e.to_string(), "code": e.code() } })),
82	        )
83	            .into_response(),
84	    }
85	}
86	
87	fn to_request(body: &ChatRequest, default_model: &str) -> GenerateRequest {
88	    let messages = body
89	        .messages
90	        .iter()
91	        .map(|m| Message {
92	            role: parse_role(&m.role),
93	            content: parse_content(&m.content),
94	            name: None,
95	            reasoning_content: None,
96	            tool_call_id: None,
97	        })
98	        .collect();
99	    GenerateReques…
```

## Claude — Jun 13, 2026 21:39

> _[thinking]_
> 

## Claude — Jun 13, 2026 21:39

The engine fundamentally changes one thing: today each `assemble()` builds a **single-tier** chain whose privacy egress flag is baked per-tier (`egress = adapter != "local_llama"`). A multi-tier registry shares one chain across tiers, so egress must become a **per-call** decision (mask for cloud, pass-through for local) or I3 breaks. Let me read the chain, the Middleware/Next/Router traits, and the privacy middleware before designing.

## Claude — Jun 13, 2026 21:39

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\chain.rs"
}
```
**[tool result]**
```
1	//! keel-kernel::chain — the middleware executor (canon §6, §14).
2	//!
3	//! The onion that threads every call through the registered `Middleware`s, in order, down to a
4	//! terminal `ModelTier::generate`. Because the chain wraps **every** call, the cross-cutting
5	//! invariants that live in middleware — I1 audit, I3 privacy, I4 cost — become structurally
6	//! unbypassable: there is no path to a tier that does not pass through here.
7	//!
8	//! `Middleware::handle` receives `&Context` (it observes, gates, and transforms the *request*);
9	//! it cannot mutate the context. Accumulation that must persist across a run (cost totals,
10	//! redaction state) is therefore the engine's job — the engine owns the `Context` and folds in
11	//! `result.cost` after the chain returns. This keeps the frozen contract honest.
12	
13	use keel_contracts::{Context, GenerateRequest, GenerateResult, Middleware, ModelTier, Next, Result};
14	use std::sync::Arc;
15	
16	/// An ordered stack of middleware, run around a terminal tier. Cheap to clone (shared `Arc`).
17	#[derive(Clone, Default)]
18	pub struct Chain {
19	    middleware: Arc<Vec<Arc<dyn Middleware>>>,
20	}
21	
22	impl Chain {
23	    /// Build a chain from middleware in **outermost-first** order: index 0 sees the call first
24	    /// (and the response last).
25	    pub fn new(middleware: Vec<Arc<dyn Middleware>>) -> Self {
26	        Self { middleware: Arc::new(middleware) }
27	    }
28	
29	    /// Number of middleware layers.
30	    pub fn len(&self) -> usize {
31	        self.middleware.len()
32	    }
33	
34	    pub fn is_empty(&self) -> bool {
35	        self.middleware.is_empty()
36	    }
37	
38	    /// Run a request through the full stack, terminating at `terminal.generate`.
39	    pub async fn run(
40	        &self,
41	        req: GenerateRequest,
42	        ctx: &Context,
43	        terminal: Arc<dyn ModelTier>,
44	    ) -> Result<GenerateResult> {
45	        let link = Link { chain: self.middleware.clone(), idx: 0, terminal };
46	        link.run(req, ctx).await
47	    }
48	}
49	
50	/// One position in the onion: middleware `idx`, or the terminal once `idx` runs off the end.
51	/// Fully owned (`Arc` clones), so the recursive `&dyn Next` borrow has no lifetime tangles.
52	struct Link {
53	    chain: Arc<Vec<Arc<dyn Middleware>>>,
54	    idx: usize,
55	    terminal: Arc<dyn ModelTier>,
56	}
57	
58	#[async_trait::async_trait]
59	impl Next for Link {
60	    async fn run(&self, req: GenerateRequest, ctx: &Context) -> Result<GenerateResult> {
61	        match self.chain.get(self.idx) {
62	            Some(mw) => {
63	                let next = Link {
64	                    chain: self.chain.clone(),
65	                    idx: self.idx + 1,
66	                    terminal: self.terminal.clone(),
67	                };
68	                mw.handle(req, ctx, &next).await
69	            }
70	            None => self.terminal.generate(req, ctx).await,
71	        }
72	    }
73	}
74	
75	#[cfg(test)]
76	mod tests {
77	    use super::*;
78	    use async_trait::async_trait;
79	    use keel_contracts::{Capabilities, KeelError};
80	    use std::sync::Mutex;
81	
82	    fn req() -> GenerateRequest {
83	        GenerateRequest {
84	            messages: vec![],
85	            model: "m".into(),
86	            tools: vec![],
87	            grammar: None,
88	            effort: Default::default(),
89	            cache_prefix_len: None,
90	        }
91	    }
92	
93	    /// Terminal that records the model it was asked for and echoes it back.
94	    struct EchoTier {
95	        seen: Arc<Mutex<Vec<String>>>,
96	    }
97	    #[async_trait]
98	    impl ModelTier for EchoTier {
99	        fn caps(&self) -> Capabilities {
100	            Capabilities::default()
101	        }
102	        async fn generate(&self, req: GenerateRequest, _ctx: &Context) -> Result<GenerateResult> {
103	            self.seen.lock().unwrap().push(format!("terminal:{}", req.model));
104	            Ok(GenerateResult { content: req.…
```

## Claude — Jun 13, 2026 21:39

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-contracts\\src\\traits.rs"
}
```
**[tool result]**
```
1	//! KEEL L0 — the ten joints (canon §7). Frozen.
2	//!
3	//! Async traits use `#[async_trait]` so they stay **dyn-compatible** — the registry and the
4	//! middleware chain hold `dyn ModelTier` / `dyn Middleware`. `Router` is sync by design.
5	
6	use crate::errors::Result;
7	use crate::types::*;
8	use async_trait::async_trait;
9	use core::pin::Pin;
10	
11	/// Eyes/ears yield percepts as a stream (live capture is forward-only; archival sources
12	/// may multi-pass). Boxed for dyn use.
13	pub type PerceptStream = Pin<Box<dyn futures_core::stream::Stream<Item = Percept> + Send>>;
14	
15	/// 1 — the uniform brain interface (cognition, incl. multimodal). Every adapter implements it.
16	#[async_trait]
17	pub trait ModelTier: Send + Sync {
18	    fn caps(&self) -> Capabilities;
19	    async fn generate(&self, req: GenerateRequest, ctx: &Context) -> Result<GenerateResult>;
20	}
21	
22	/// 2 — tools/context/resources over MCP. KEEL is a client (and, in apps, a server).
23	#[async_trait]
24	pub trait ToolHost: Send + Sync {
25	    async fn list(&self) -> Result<Vec<ToolDef>>;
26	    async fn call(&self, name: &str, args: Json, ctx: &Context) -> Result<ToolResult>;
27	}
28	
29	/// The rest-of-chain continuation handed to each middleware.
30	#[async_trait]
31	pub trait Next: Send + Sync {
32	    async fn run(&self, req: GenerateRequest, ctx: &Context) -> Result<GenerateResult>;
33	}
34	
35	/// 3 — a cross-cutting concern on every call. I1 (audit), I3 (privacy), I4 (cost) live here,
36	/// which is what makes them structurally unbypassable.
37	#[async_trait]
38	pub trait Middleware: Send + Sync {
39	    async fn handle(&self, req: GenerateRequest, ctx: &Context, next: &dyn Next) -> Result<GenerateResult>;
40	}
41	
42	/// 4 — the fusion point: cheapest tier that clears the trust bar. Sync (a rules heuristic,
43	/// not a model call).
44	pub trait Router: Send + Sync {
45	    fn route(&self, step: &Step, ctx: &Context) -> Decision;
46	}
47	
48	/// 5 — the externality surface (I5). A non-model assertion of correctness; flags JOINT_WRONG.
49	#[async_trait]
50	pub trait Oracle: Send + Sync {
51	    async fn verify(&self, output: &StepOutput, golden: &[GoldenCase], ctx: &Context) -> Result<Verdict>;
52	}
53	
54	/// 6 — the self that persists: ringed/budgeted assembly, the lossless record, model-authored
55	/// consolidation (returns a maintenance `Step`). Stores plug in behind it.
56	#[async_trait]
57	pub trait Memory: Send + Sync {
58	    async fn assemble(&self, step: &Step, ctx: &Context) -> Result<AssembledContext>;
59	    async fn record(&self, trace: &Trace) -> Result<()>;
60	    async fn consolidate(&self) -> Result<Step>;
61	}
62	
63	/// 7 — durable run-state (I2): resumable from checkpoint. The append-only ledger.
64	#[async_trait]
65	pub trait Spine: Send + Sync {
66	    async fn checkpoint(&self, run: &RunId, state: &State) -> Result<()>;
67	    async fn resume(&self, run: &RunId) -> Result<Option<State>>;
68	}
69	
70	/// 8 — initiative: a source of work. The user-turn is one Driver; heartbeat/watch/outreach
71	/// are others. `None` = nothing to do now.
72	#[async_trait]
73	pub trait Driver: Send + Sync {
74	    async fn poll(&self, ctx: &Context) -> Result<Option<Step>>;
75	}
76	
77	/// 9 — the flywheel feed: a verified trace becomes distillation feedstock.
78	#[async_trait]
79	pub trait TraceSink: Send + Sync {
80	    async fn emit(&self, trace: VerifiedTrace) -> Result<()>;
81	}
82	
83	/// 10 — afferent senses (eyes + ears). Modality in → percepts out. Not a tier; the router
84	/// never routes to it.
85	pub trait PerceptionSource: Send + Sync {
86	    fn percepts(&self, spec: SampleSpec) -> PerceptStream;
87	}
88	
```

## Claude — Jun 13, 2026 21:39

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-middleware\\src\\privacy.rs"
}
```
**[tool result]**
```
1	//! keel-middleware::privacy — I3, the deterministic mask (canon §5.1, rungs 1–2).
2	//!
3	//! The non-model privacy **oracle**: operator sovereign markers (rung 1, exact strings) + a
4	//! structured regex/checksum sweep (rung 2: email, SSN, `sk-`/`AKIA` keys, Luhn-valid cards).
5	//! `redact` returns the scrubbed text plus the `Finding`s — a non-model assertion that PII is
6	//! present (the highest-recall, model-free rungs). The probabilistic rung 3 (the OpenAI Privacy
7	//! Filter) is a *verification pass* that lands in Stage 2 behind `GOLDEN_PRIVACY`; it is never
8	//! the guarantee.
9	//!
10	//! **The operator's sovereign markers are operator-authored, agent-frozen ground truth** (like
11	//! the goldens): this module supplies the *mechanism*; the marker list is configured/frozen by
12	//! the operator, never invented by the agent.
13	
14	use async_trait::async_trait;
15	use keel_contracts::{Content, Context, GenerateRequest, GenerateResult, Middleware, Next, Result};
16	use regex::Regex;
17	use serde::{Deserialize, Serialize};
18	use std::sync::Arc;
19	
20	/// A detected PII span's classification (not its value — the secret isn't retained here).
21	#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
22	pub struct Finding {
23	    pub kind: String,
24	    /// 1 = operator marker, 2 = structured regex/checksum.
25	    pub rung: u8,
26	}
27	
28	/// The deterministic redactor (rungs 1–2). Compiles its patterns once.
29	pub struct Redactor {
30	    markers: Vec<String>,
31	    patterns: Vec<(&'static str, Regex)>,
32	}
33	
34	impl Redactor {
35	    /// Build with the operator's sovereign markers (rung 1). Pass an empty list to run rung 2 only.
36	    pub fn new(markers: Vec<String>) -> Self {
37	        let raw: &[(&'static str, &str)] = &[
38	            ("email", r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}"),
39	            ("ssn", r"\b\d{3}-\d{2}-\d{4}\b"),
40	            ("api_key", r"\bsk-[A-Za-z0-9]{4,}\b"),
41	            ("aws_key", r"\bAKIA[0-9A-Z]{16}\b"),
42	            ("credit_card", r"\b\d(?:[ -]?\d){12,18}\b"),
43	        ];
44	        let patterns = raw
45	            .iter()
46	            .map(|(k, p)| (*k, Regex::new(p).expect("static pattern is valid")))
47	            .collect();
48	        Self { markers, patterns }
49	    }
50	
51	    /// Redact every marker/PII span (the union) with `[REDACTED]`; return the scrubbed text and
52	    /// the findings. Empty findings ⇒ the text is returned unchanged.
53	    pub fn redact(&self, text: &str) -> (String, Vec<Finding>) {
54	        // (start, end, kind, rung)
55	        let mut spans: Vec<(usize, usize, &str, u8)> = Vec::new();
56	
57	        // rung 1 — operator markers (exact, case-sensitive)
58	        for m in self.markers.iter().filter(|m| !m.is_empty()) {
59	            let mut from = 0;
60	            while let Some(rel) = text[from..].find(m.as_str()) {
61	                let s = from + rel;
62	                let e = s + m.len();
63	                spans.push((s, e, "operator_marker", 1));
64	                from = e;
65	            }
66	        }
67	
68	        // rung 2 — structured patterns (credit cards must pass Luhn)
69	        for (kind, re) in &self.patterns {
70	            for mat in re.find_iter(text) {
71	                if *kind == "credit_card" && !luhn_ok(mat.as_str()) {
72	                    continue;
73	                }
74	                spans.push((mat.start(), mat.end(), kind, 2));
75	            }
76	        }
77	
78	        if spans.is_empty() {
79	            return (text.to_string(), Vec::new());
80	        }
81	
82	        let findings = spans
83	            .iter()
84	            .map(|(_, _, k, r)| Finding { kind: (*k).to_string(), rung: *r })
85	            .collect();
86	
87	        // merge overlapping spans, then rebuild with the placeholder
88	        spans.sort_by_key(|s| s.0);
89	        let mut merged: Vec<(usize, usize)> = Vec::new();
90	        for (s, e, _, _) in spans {
91	            matc…
```

## Claude — Jun 13, 2026 21:40

> _[thinking]_
> 

## Claude — Jun 13, 2026 21:40

Now I understand the architecture fully. The privacy egress flag is static per-`PrivacyMiddleware`, and middleware can't see the terminal tier — so the clean, frozen-respecting design is **per-tier chains**: each tier gets a chain whose privacy egress matches whether that tier leaves the box (local = pass-through, cloud = mask). The engine routes to a tier name, then runs that tier's adapter through that tier's chain. I need the manifest's tier enumeration and the exact tier names in `keel.lock` to confirm they match the router's ladder.

## Claude — Jun 13, 2026 21:40

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-kernel\\src\\manifest.rs"
}
```
**[tool result]**
```
1	//! keel-kernel::manifest — declarative config → behavior (canon §14).
2	//!
3	//! Parses the operator's `keel.lock` (YAML) into a typed [`Manifest`]: which tiers exist, their
4	//! price / effort / caps, and the router policy. It reuses the L0 types (`Price`, `Effort`,
5	//! `Capabilities`) so the manifest is the single place wiring reads — never a second source of
6	//! truth for the contracts. Sections this slice doesn't yet model (`substrate`, `servers`,
7	//! `ledger`, …) are ignored; later kernel slices (`lock`, `lifecycle`) pick them up. Secrets are
8	//! referenced by env-var **name**, never inlined — the operator rotates keys.
9	
10	use keel_contracts::{Capabilities, Effort, KeelError, Price, Result};
11	use serde::{Deserialize, Serialize};
12	use std::collections::BTreeMap;
13	use std::path::Path;
14	
15	/// Per-tier price in `keel.lock` shorthand ($/1M tokens). Converts to the frozen L0 `Price`.
16	#[derive(Clone, Copy, Debug, Default, Deserialize, Serialize)]
17	pub struct PriceCfg {
18	    #[serde(default)]
19	    pub miss: f64,
20	    #[serde(default)]
21	    pub hit: f64,
22	    #[serde(default)]
23	    pub out: f64,
24	}
25	impl PriceCfg {
26	    /// Map to the L0 `Price` (miss / hit / out → input_miss / input_hit / output).
27	    pub fn to_price(self) -> Price {
28	        Price { input_miss: self.miss, input_hit: self.hit, output: self.out }
29	    }
30	}
31	
32	/// One routable cognition source (canon §4: a `tier`).
33	#[derive(Clone, Debug, Deserialize, Serialize)]
34	pub struct TierCfg {
35	    /// Which adapter implements it (`local_llama` | `deepseek` | `anthropic` | …).
36	    pub adapter: String,
37	    pub model: String,
38	    #[serde(default)]
39	    pub vision: bool,
40	    /// Env-var name holding the key; resolved at runtime, never inlined.
41	    #[serde(default, skip_serializing_if = "Option::is_none")]
42	    pub api_key_env: Option<String>,
43	    /// Optional explicit endpoint (e.g. a cloud API base). Local resolves to the llama-server URL.
44	    #[serde(default, skip_serializing_if = "Option::is_none")]
45	    pub endpoint: Option<String>,
46	    #[serde(default)]
47	    pub price: PriceCfg,
48	    #[serde(default)]
49	    pub default_effort: Effort,
50	}
51	impl TierCfg {
52	    /// The API key for this tier, read from its env var (`None` if unset/absent). Never logged.
53	    pub fn api_key(&self) -> Option<String> {
54	        self.api_key_env.as_ref().and_then(|name| std::env::var(name).ok())
55	    }
56	    /// What this tier can do; the router and the egress filter read this (canon §9).
57	    pub fn capabilities(&self) -> Capabilities {
58	        Capabilities { vision: self.vision, video: false, thinking: self.default_effort.thinking.is_some() }
59	    }
60	}
61	
62	fn default_tier() -> String {
63	    "local".to_string()
64	}
65	fn default_escalate() -> u32 {
66	    2
67	}
68	
69	/// Router policy (canon §9). Every fallback defaults to the sovereign-first local tier.
70	#[derive(Clone, Debug, Deserialize, Serialize)]
71	pub struct RouterCfg {
72	    #[serde(default = "default_tier")]
73	    pub default_tier: String,
74	    /// Sovereign / PHI data forces this tier (I3).
75	    #[serde(default = "default_tier")]
76	    pub sovereign_forces: String,
77	    /// Raw frames / audio force this tier — perception never egresses (I3).
78	    #[serde(default = "default_tier")]
79	    pub perception_forces: String,
80	    /// Escalate one tier after this many oracle failures (canon §9).
81	    #[serde(default = "default_escalate")]
82	    pub escalate_after_oracle_failures: u32,
83	}
84	impl Default for RouterCfg {
85	    fn default() -> Self {
86	        Self {
87	            default_tier: default_tier(),
88	            sovereign_forces: default_tier(),
89	            perception_forces: default_tier(),
90	            escalate_after_oracle_failures: default_escalate(),
91	        }
92	    }
93	}
94	
95	fn default_budget() -> f64 {
96	    5.0
97	}
98	fn default_hard_stop() -> f64 {
99	    …
```

## Claude — Jun 13, 2026 21:40

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\keel.lock"
}
```
**[tool result]**
```
1	# keel.lock — the reproducible substrate KEEL expects.
2	# Pin hashes when the models/servers are installed. The substrate resolver (kernel::lifecycle)
3	# reads this to discover/launch/route; a fresh box is provisioned from it. Hashes are the
4	# reproducibility contract — a run is replayable only against pinned weights.
5	
6	keel:        { version: 0.2.0, stage: stage0 }   # spec -> stage0 -> stage1 -> stage2 -> stage3
7	
8	# --- canonical primitives ---------------------------------------------------
9	# disposition: `embedded` = baked into the binary; `shared` = system asset, download-once.
10	substrate:
11	  llm_vision:                                   # brain + eyes (native multimodal, early-fusion)
12	    id: qwen3.5-9b-q5_k_m
13	    mmproj: mmproj-F16                           # llama.cpp serves Qwen vision via this projector file
14	    sha256: TODO
15	    mmproj_sha256: TODO
16	    disposition: shared
17	    fallbacks: [qwen3.5-4b-q4_k_m]               # smaller-VRAM tier (resolver picks by HardwareProfile)
18	  audio:                                         # ears (separate organ; transcribes -> text pre-cognition)
19	    id: whisper-large-v3-turbo
20	    sha256: TODO
21	    disposition: shared
22	    fallback: whisper-base.en                    # faster-than-realtime CPU default
23	    gate: vad                                    # transcribe only on voiced audio
24	  embedding:                                     # recall + cheap routing-classification — a Memory organ, NOT a tier
25	    id: qwen3-embedding-0.6b-q8                    # capable local default (~1024-dim, sovereign-safe)
26	    sha256: TODO
27	    dim: 1024                                      # fingerprinted into the index; mismatch => rebuild-from-ledger
28	    disposition: shared                            # download-once system asset
29	    fallback: all-minilm-l6-v2                     # 384-dim, embedded, CPU -> the "never blind" floor
30	    sovereign_forces: local                        # I3: sovereign/PHI text never embeds off-box; vectors stay local
31	    format_committing: true                        # the one substrate exception to tier-interchangeability (ADR #13)
32	  rerank:                                          # cross-encoder upgrade to Memory's rerank() sub-seam
33	    id: qwen3-reranker-0.6b-q8
34	    sha256: TODO
35	    disposition: shared
36	    default: identity                              # SHIPS OFF (canon §11) — pass-through until GOLDEN_RECALL earns it on
37	  privacy:                                         # I3 mask, rung 3 — recall verification-pass (NOT the guarantee)
38	    id: openai-privacy-filter                      # bidirectional token-classifier (BIOES span head), 50M active / ~1.5B total, Apache-2.0
39	    sha256: TODO
40	    runtime: onnx                                  # in-process via the Rust `ort` crate (or transformers) — NOT a GGUF, NOT llama.cpp, no server to supervise
41	    disposition: shared                            # ~1GB weights, download-once (too big to bake in); but runs in-process like the embedder, unlike the server-based LLM/Whisper
42	    decode: viterbi                                # span-decode is deterministic, app-level, KEEL-owned -> the operating point is a NON-model knob
43	    default: off                                   # rungs 1-2 (markers+regex) ship Stage 0; model lands Stage 2 behind GOLDEN_PRIVACY
44	    operating_point: recall                        # = the Viterbi transition-bias: tune toward over-redaction; leak-uncertain => sovereign
45	    per_cell_finetune: true                        # general PII | medical PHI | code/secrets
46	    scrub_before_distill: true                     # reversibility gate: no secret fossilized into a LoRA
47	  store:                                         # the index (the ledger is files, see below)
48	    engine: sqlite                               # baked into the binary (~1 MB, embeddable)
49	    vector: sqlite-vec
50	    d…
```

## Claude — Jun 13, 2026 21:42

> _[thinking]_
> 

## Claude — Jun 13, 2026 21:42

Everything checks out: `manifest.tiers` is an enumerable `BTreeMap`, and the tier names in `keel.lock` (`local`, `cheap-API`, `frontier`) exactly match the router's `LADDER`. The egress rule is clean (`adapter != "local_llama"`). Now the keel crate's deps (I need `keel-services` for the router) and the error taxonomy for the BLOCK path.

## Claude — Jun 13, 2026 21:42

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel\\Cargo.toml"
}
```
**[tool result]**
```
1	[package]
2	name = "keel"
3	description = "KEEL L5 — apps: the daily-driver CLI and the OpenAI-compatible server, sharing one wiring lib."
4	version.workspace = true
5	edition.workspace = true
6	license.workspace = true
7	default-run = "keel"
8	
9	[lib]
10	name = "keel"
11	path = "src/lib.rs"
12	
13	[[bin]]
14	name = "keel"
15	path = "src/main.rs"
16	
17	[[bin]]
18	name = "keel-serve"
19	path = "src/bin/keel-serve.rs"
20	
21	[dependencies]
22	keel-contracts = { path = "../keel-contracts" }
23	keel-kernel = { path = "../keel-kernel" }
24	keel-middleware = { path = "../keel-middleware" }
25	keel-adapters = { path = "../keel-adapters" }
26	tokio = { version = "1", features = ["rt-multi-thread", "macros", "net"] }
27	axum = "0.8"
28	serde = { version = "1", features = ["derive"] }
29	serde_json = "1"
30	
```

## Claude — Jun 13, 2026 21:42

**[tool: Read]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel-contracts\\src\\errors.rs"
}
```
**[tool result]**
```
1	//! KEEL error taxonomy (canon §18). Typed, with stable codes that match the canon table.
2	
3	use std::fmt;
4	
5	/// Every fallible contract method returns `Result<T>` over this taxonomy.
6	pub type Result<T> = std::result::Result<T, KeelError>;
7	
8	#[derive(Clone, Debug)]
9	pub enum KeelError {
10	    /// No tier clears the bar within budget.
11	    RouteNoTier(String),
12	    /// Provider/server down or OOM.
13	    TierUnavailable(String),
14	    /// Output failed an oracle.
15	    OracleFail(String),
16	    /// Tests + code agree, a golden disagrees. Surfaced to the operator immediately.
17	    JointWrong(String),
18	    /// Task cost cap hit (I4 hard-stop).
19	    BudgetExceeded(String),
20	    /// All tiers failed the oracle.
21	    EscalationExhausted(String),
22	    /// Undo cost unstatable in one sentence (the reversibility gate).
23	    ReversibilityBlock(String),
24	    /// A claim cannot be grounded in ground truth (routes to human).
25	    InsufficientSource(String),
26	    /// A sense returned below its confidence floor (routes to review).
27	    PerceptLowConfidence(String),
28	    /// No inference layer found or launchable.
29	    SubstrateUnresolved(String),
30	    /// Constrained decode produced invalid output (should be impossible; adapter bug on repeat).
31	    GrammarViolation(String),
32	    /// Anything else, carried with a message.
33	    Other(String),
34	}
35	
36	impl KeelError {
37	    /// The stable code string (canon §18).
38	    pub fn code(&self) -> &'static str {
39	        use KeelError::*;
40	        match self {
41	            RouteNoTier(_) => "ROUTE_NO_TIER",
42	            TierUnavailable(_) => "TIER_UNAVAILABLE",
43	            OracleFail(_) => "ORACLE_FAIL",
44	            JointWrong(_) => "JOINT_WRONG",
45	            BudgetExceeded(_) => "BUDGET_EXCEEDED",
46	            EscalationExhausted(_) => "ESCALATION_EXHAUSTED",
47	            ReversibilityBlock(_) => "REVERSIBILITY_BLOCK",
48	            InsufficientSource(_) => "INSUFFICIENT_SOURCE",
49	            PerceptLowConfidence(_) => "PERCEPT_LOW_CONFIDENCE",
50	            SubstrateUnresolved(_) => "SUBSTRATE_UNRESOLVED",
51	            GrammarViolation(_) => "GRAMMAR_VIOLATION",
52	            Other(_) => "KEEL_ERROR",
53	        }
54	    }
55	
56	    /// The carried human-readable message.
57	    pub fn message(&self) -> &str {
58	        use KeelError::*;
59	        match self {
60	            RouteNoTier(s) | TierUnavailable(s) | OracleFail(s) | JointWrong(s) | BudgetExceeded(s)
61	            | EscalationExhausted(s) | ReversibilityBlock(s) | InsufficientSource(s)
62	            | PerceptLowConfidence(s) | SubstrateUnresolved(s) | GrammarViolation(s) | Other(s) => s,
63	        }
64	    }
65	}
66	
67	impl fmt::Display for KeelError {
68	    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
69	        write!(f, "[{}] {}", self.code(), self.message())
70	    }
71	}
72	
73	impl std::error::Error for KeelError {}
74	
```

## Claude — Jun 13, 2026 21:44

> _[thinking]_
> 

## Claude — Jun 13, 2026 21:44

All dependencies confirmed. `KeelError::BudgetExceeded` (code `BUDGET_EXCEEDED`) is the right BLOCK signal, and I need to add `keel-services` to the keel crate's deps for the router. Let me set up a task list and implement.

Design decided:
- **`Engine`** (in `keel` L5 lib): a multi-tier registry of every *available* tier (local always; cloud tiers only when their env key is set), each behind its **own egress-correct chain** (local = pass-through, cloud = mask — preserving I3 without touching the frozen privacy middleware), fronted by the swappable `DifficultyRouter`. `run(step, ctx, req)` routes → falls back down the ladder if the chosen tier is unplugged → honors BLOCK → runs.
- **CLI**: default = engine-routed (`--kind core-wire`, `--sovereign` flags build the `Step`); `--tier X` keeps the efficient single-tier `assemble` override (no needless local launch).
- **Server**: engine-routed per request; image parts in the body force local via I3.

## Claude — Jun 13, 2026 21:44

**[tool: TaskCreate]**
```json
{
  "tasks": "[{\"description\":\"Add keel-services dependency to the keel crate so the engine can use DifficultyRouter\",\"priority\":\"high\",\"status\":\"in_progress\"},{\"description\":\"Build the Engine in keel/src/lib.rs: multi-tier registry (available tiers only), per-tier egress-correct chains, swappable Router, run/run_on with ladder fallback + BLOCK\",\"priority\":\"high\",\"status\":\"pending\"},{\"description\":\"Rewire keel CLI (main.rs) to self-drive via the engine; --kind/--sovereign build the Step; keep --tier as single-tier override\",\"priority\":\"high\",\"status\":\"pending\"},{\"description\":\"Rewire keel-serve to route each request through the engine; image parts force local (I3); expose route reason in keel ext\",\"priority\":\"high\",\"status\":\"pending\"},{\"description\":\"clippy (zero-warning) + cargo test green\",\"priority\":\"high\",\"status\":\"pending\"},{\"description\":\"Live-validate self-drive: scaffolding→local, core-wire→cheap-API, --sovereign→local (I3), --tier override\",\"priority\":\"medium\",\"status\":\"pending\"},{\"description\":\"Update STATE.md, layer-check + golden-freeze, commit + push\",\"priority\":\"medium\",\"status\":\"pending\"}]"
}
```
**[tool result]**
```
<tool_use_error>InputValidationError: TaskCreate failed due to the following issues:
The required parameter `subject` is missing
The required parameter `description` is missing
An unexpected parameter `tasks` was provided

TaskCreate creates ONE task per call and has no `tasks` or `todos` parameter. Call TaskCreate once per task, passing `subject` (a brief title) and `description` (what needs to be done) as top-level string parameters.

This tool's schema was not sent to the API — it was not in the discovered-tool set derived from message history. Without the schema in your prompt, typed parameters (arrays, numbers, booleans) get emitted as strings and the client-side parser rejects them. Load the tool first: call ToolSearch with query "select:TaskCreate", then retry this call. For reference, this tool's input schema is: {"$schema":"https://json-schema.org/draft/2020-12/schema","type":"object","properties":{"subject":{"description":"A brief title for the task","type":"string"},"description":{"description":"What needs to be done","type":"string"},"activeForm":{"description":"Present continuous form shown in spinner when in_progress (e.g., \"Running tests\")","type":"string"},"metadata":{"description":"Arbitrary metadata to attach to the task","type":"object","propertyNames":{"type":"string"},"additionalProperties":{}}},"required":["subject","description"],"additionalProperties":false}</tool_use_error>
```

## Claude — Jun 13, 2026 21:44

> _[thinking]_
> 

## Claude — Jun 13, 2026 21:44

The task tool needs its schema loaded and is one-per-call — it's optional, so I'll skip the ceremony and track progress in STATE.md as usual. Proceeding directly with the implementation.

First, add the `keel-services` dependency:

## Claude — Jun 13, 2026 21:44

**[tool: Edit]**
```json
{
  "replace_all": false,
  "file_path": "C:\\KEEL\\crates\\keel\\Cargo.toml",
  "old_string": "keel-contracts = { path = \"../keel-contracts\" }\nkeel-kernel = { path = \"../keel-kernel\" }\nkeel-middleware = { path = \"../keel-middleware\" }\nkeel-adapters = { path = \"../keel-adapters\" }",
  "new_string": "keel-contracts = { path = \"../keel-contracts\" }\nkeel-kernel = { path = \"../keel-kernel\" }\nkeel-middleware = { path = \"../keel-middleware\" }\nkeel-adapters = { path = \"../keel-adapters\" }\nkeel-services = { path = \"../keel-services\" }"
}
```
**[tool result]**
```
The file C:\KEEL\crates\keel\Cargo.toml has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 13, 2026 21:44

> _[thinking]_
> 

## Claude — Jun 13, 2026 21:44

Now the Engine. I'll rewrite `keel/src/lib.rs`, refactoring the adapter construction into shared helpers (`build_tier`/`build_chain`) used by both the single-tier `assemble` (the `--tier` override path) and the new multi-tier `Engine`:

## Claude — Jun 13, 2026 21:45

**[tool: Write]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel\\src\\lib.rs",
  "content": "//! keel (L5) — the shared wiring both apps use. Two ways to assemble the spine from `keel.lock`:\n//!\n//! - [`Engine`] — the **self-driving** path: a multi-tier registry of every *available* tier (local\n//!   always; a cloud tier only when its API key is in the env), each behind its **own** invariant\n//!   chain (audit → privacy → cost), fronted by a swappable [`Router`] policy. `keel` (default) and\n//!   `keel-serve` route **every** turn through it — the router picks the tier, not the operator.\n//! - [`assemble`] — the **single-tier** path: build exactly one tier behind the chain. The CLI's\n//!   `--tier` override uses it so an explicit cloud call never needlessly cold-starts the local\n//!   substrate.\n//!\n//! Both share `build_tier` / `build_chain`, so there is one wiring truth, not two. The privacy\n//! egress mask (I3) is **per tier**: local stays on the box (pass-through), every cloud tier is\n//! masked before egress — which is why the `Engine` gives each tier its own chain rather than one\n//! shared chain with a single static flag.\n\nuse keel_adapters::{Anthropic, DeepSeek, LocalLlama};\nuse keel_contracts::{\n    Context, Decision, Effort, GenerateRequest, GenerateResult, KeelError, ModelTier, Result, Router, Step,\n};\nuse keel_kernel::{Chain, Manifest, Registry, TierCfg};\nuse keel_middleware::{AuditMiddleware, AuditSink, CostMiddleware, FileAuditSink, PrivacyMiddleware, Redactor};\nuse keel_services::DifficultyRouter;\nuse std::collections::BTreeMap;\nuse std::sync::Arc;\n\npub const DEEPSEEK_ENDPOINT: &str = \"https://api.deepseek.com\";\npub const ANTHROPIC_ENDPOINT: &str = \"https://api.anthropic.com\";\npub const AUDIT_LEDGER: &str = \".keelstate/audit.jsonl\";\n// local substrate launch (paths match keel.lock; keel.lock-driven config is a refinement)\npub const LLAMA_EXE: &str = r\"C:\\llama.cpp\\llama-server.exe\";\npub const LLAMA_MODEL: &str = r\"C:\\models\\Qwen3.5-9B-Q5_K_M.gguf\";\npub const LLAMA_MMPROJ: &str = r\"C:\\models\\mmproj-F16.gguf\";\npub const LLAMA_LOG: &str = \".keelstate/llama-server.log\";\n\n/// The tier ladder, cheapest first — the engine walks DOWN it to fall back to an available tier.\nconst LADDER: [&str; 3] = [\"local\", \"cheap-API\", \"frontier\"];\n\n// ── the self-driving engine ──────────────────────────────────────────────────\n\n/// One wired tier: its brain adapter, the model id to send it, and the **egress-correct** invariant\n/// chain for that tier (local pass-through vs cloud-masked, I3).\nstruct TierSlot {\n    tier: Arc<dyn ModelTier>,\n    chain: Chain,\n    model: String,\n}\n\n/// The self-driving engine (canon §9, the fusion point wired up): hold every *available* tier, let\n/// the [`Router`] pick one per turn, run it through that tier's chain. `keel`/`keel-serve` build on\n/// this so a turn auto-lands on the cheapest brain that clears the bar instead of a pinned `--tier`.\npub struct Engine {\n    slots: BTreeMap<String, TierSlot>,\n    router: Box<dyn Router>,\n    default_tier: String,\n}\n\n/// The result of a routed turn: the model output plus the routing story (for the operator/ledger).\npub struct Outcome {\n    pub result: GenerateResult,\n    /// What the router chose (its tier + reason).\n    pub decision: Decision,\n    /// The tier actually run — equals `decision.tier` unless that tier was unplugged.\n    pub tier_used: String,\n    /// True when the chosen tier was unavailable and the engine fell back down the ladder.\n    pub substituted: bool,\n}\n\nimpl Engine {\n    /// Assemble from `keel.lock`: wire every tier whose substrate is reachable — **local always**\n    /// (resolving/launching llama-server), a **cloud tier only when its key is in the env** (absent\n    /// key ⇒ skipped, not fatal) — each behind an `audit · privacy · cost` chain whose egress mask\n    /// matches whether that tier leaves the box (I3). The policy is the §9 `DifficultyRouter`, kept\n    /// behind the `Router` seam so a learned policy can slot in later.\n    pub fn assemble(manifest: &Manifest) -> Result<Engine> {\n        let sink: Arc<dyn AuditSink> = Arc::new(\n            FileAuditSink::new(AUDIT_LEDGER).map_err(|e| KeelError::Other(format!(\"ledger {AUDIT_LEDGER}: {e}\")))?,\n        );\n        // operator sovereign markers (rung 1) are a future manifest field; rung 2 runs regardless.\n        let redactor = Arc::new(Redactor::new(vec![]));\n\n        let mut slots = BTreeMap::new();\n        for (name, tcfg) in &manifest.tiers {\n            let is_local = tcfg.adapter == \"local_llama\";\n            // a cloud tier is available only when its key is present — skip (don't fail) otherwise.\n            if !is_local && tcfg.api_key().is_none() {\n                let env = tcfg.api_key_env.as_deref().unwrap_or(\"?\");\n                eprintln!(\"[keel] tier '{name}' unavailable ({env} unset) — skipped\");\n                continue;\n            }\n            let t
…[truncated]
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\lib.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 13, 2026 21:45

> _[thinking]_
> 

## Claude — Jun 13, 2026 21:45

Now the CLI — self-driving by default, with `--kind`/`--sovereign` building the routing `Step` and `--tier` kept as the efficient single-tier override:

## Claude — Jun 13, 2026 21:46

**[tool: Write]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel\\src\\main.rs",
  "content": "//! keel — the daily-driver CLI (L5). By default it **self-drives**: it builds the multi-tier\n//! [`Engine`](keel::Engine), lets the router pick the tier for the turn (scaffolding → local ·\n//! core-wire → cheap-API · escalate → frontier), runs it through the invariant chain, and prints\n//! the answer + the routing reason. `--tier` pins a tier manually (the single-tier path).\n//!\n//!   keel \"read me the config\"                  # → routed (scaffolding → local)\n//!   keel --kind core-wire \"weigh the tradeoffs\"# → routed (core-wire → cheap-API)\n//!   keel --sovereign \"summarize my journal\"    # → forced local (I3)\n//!   keel --tier frontier \"hard question\"       # → manual override (no router)\n//!   keel --think \"…\"      keel --manifest C:\\KEEL\\keel.lock \"hello\"\n\nuse keel_contracts::{Content, Context, DataClass, Effort, GenerateRequest, GenerateResult, Kind, Message, Role, Step, Trust};\nuse keel_kernel::{new_context, Manifest};\n\n#[tokio::main]\nasync fn main() {\n    if let Err(e) = run().await {\n        eprintln!(\"keel: {e}\");\n        std::process::exit(1);\n    }\n}\n\nasync fn run() -> keel_contracts::Result<()> {\n    let mut manifest_path = \"keel.lock\".to_string();\n    let mut tier_override: Option<String> = None;\n    let mut think = false;\n    let mut core_wire = false;\n    let mut sovereign = false;\n    let mut prompt = Vec::new();\n    let mut args = std::env::args().skip(1);\n    while let Some(a) = args.next() {\n        match a.as_str() {\n            \"--manifest\" => manifest_path = args.next().unwrap_or_default(),\n            \"--tier\" => tier_override = args.next(),\n            \"--kind\" => core_wire = matches!(args.next().as_deref(), Some(\"core-wire\") | Some(\"core_wire\")),\n            \"--sovereign\" => sovereign = true,\n            \"--think\" => think = true,\n            _ => prompt.push(a),\n        }\n    }\n    let prompt = prompt.join(\" \");\n    if prompt.trim().is_empty() {\n        eprintln!(\"usage: keel [--manifest PATH] [--tier NAME] [--kind core-wire] [--sovereign] [--think] <prompt>\");\n        std::process::exit(2);\n    }\n\n    let manifest = Manifest::load(&manifest_path)?;\n    let ctx = new_context(&manifest);\n    let user = Message {\n        role: Role::User,\n        content: vec![Content::Text { text: prompt.clone() }],\n        name: None,\n        reasoning_content: None,\n        tool_call_id: None,\n    };\n\n    if let Some(t) = tier_override {\n        // ── manual override: pin one tier, skip the router (no needless local cold-start) ──\n        let asm = keel::assemble(&manifest, Some(&t))?;\n        let req = GenerateRequest {\n            messages: vec![user],\n            model: asm.model.clone(),\n            tools: vec![],\n            grammar: None,\n            effort: Effort { n: 1, thinking: Some(if think { \"high\" } else { \"low\" }.into()) },\n            cache_prefix_len: None,\n        };\n        let res = asm.chain.run(req, &ctx, asm.tier.clone()).await?;\n        report(&res, &ctx, &format!(\"manual override → {}\", asm.tier_name), think);\n    } else {\n        // ── self-driving: the router picks the tier for this turn ──\n        let engine = keel::Engine::assemble(&manifest)?;\n        let step = Step {\n            kind: if core_wire { Kind::CoreWire } else { Kind::Scaffolding },\n            ty: \"user_turn\".into(),\n            trust_required: Trust::Normal,\n            data_class: if sovereign { DataClass::Sovereign } else { DataClass::Normal },\n            tier_history: vec![],\n            oracle_failures: 0,\n            projected_cost: None,\n            critical: false,\n            source: Some(\"cli\".into()),\n            content: vec![Content::Text { text: prompt.clone() }],\n            golden_refs: vec![],\n        };\n        let req = GenerateRequest {\n            messages: vec![user],\n            model: String::new(), // the engine sets the routed tier's model\n            tools: vec![],\n            grammar: None,\n            // let the router pick thinking per tier; `--think` forces it on regardless of tier.\n            effort: Effort { n: 1, thinking: if think { Some(\"high\".into()) } else { None } },\n            cache_prefix_len: None,\n        };\n        let outcome = engine.run(&step, &ctx, req).await?;\n        let mut note = outcome.decision.reason.clone();\n        if outcome.substituted {\n            note = format!(\"{note} — chosen tier '{}' unavailable, fell back to '{}'\", outcome.decision.tier, outcome.tier_used);\n        }\n        report(&outcome.result, &ctx, &note, think);\n    }\n    Ok(())\n}\n\n/// Print the answer (+ thinking on `--think`) and the per-call footer: route reason, tier/model/cost.\nfn report(res: &GenerateResult, ctx: &Context, route: &str, think: bool) {\n    println!(\"{}\", res.content.trim());\n    if think {\n        if let Some(rc) = res.reasoning_c
…[truncated]
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\main.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 13, 2026 21:46

> _[thinking]_
> 

## Claude — Jun 13, 2026 21:46

Now the server — route each request through the engine, with image parts in the body forcing local (I3), and expose the routing decision in the `keel` extension:

## Claude — Jun 13, 2026 21:46

**[tool: Write]**
```json
{
  "file_path": "C:\\KEEL\\crates\\keel\\src\\bin\\keel-serve.rs",
  "content": "//! keel-serve (L5) — expose KEEL as an **OpenAI-compatible HTTP server** (canon §15), so any app\n//! (DAVE, TERMINAL, the C#/Python fleet) consumes KEEL as a brain over protocol and gets the whole\n//! economy for free: **router-driven tier selection**, the invariant chain (audit/privacy/cost),\n//! the ledger, and the self-resolving substrate. One [`Engine`](keel::Engine) is assembled at\n//! startup and shared across requests; every request is routed (it is not pinned to one tier).\n//!\n//!   keel-serve [keel.lock]      →  POST http://127.0.0.1:7070/v1/chat/completions\n\nuse axum::{extract::State, http::StatusCode, response::IntoResponse, routing::{get, post}, Json, Router};\nuse keel::{Engine, Outcome};\nuse keel_contracts::{Content, DataClass, Effort, GenerateRequest, Kind, Message, Role, Step, Trust};\nuse keel_kernel::{new_context, Manifest};\nuse serde::Deserialize;\nuse serde_json::{json, Value};\nuse std::sync::Arc;\n\nconst ADDR: &str = \"127.0.0.1:7070\";\n\n#[derive(Clone)]\nstruct AppState {\n    engine: Arc<Engine>,\n    manifest: Arc<Manifest>,\n}\n\n#[tokio::main]\nasync fn main() {\n    let manifest_path = std::env::args().nth(1).unwrap_or_else(|| \"keel.lock\".to_string());\n    let manifest = Manifest::load(&manifest_path).unwrap_or_else(|e| fail(format!(\"manifest: {e}\")));\n    eprintln!(\"[keel-serve] assembling engine (resolves/launches the substrate, wires available tiers)…\");\n    let engine = Engine::assemble(&manifest).unwrap_or_else(|e| fail(format!(\"assemble: {e}\")));\n    eprintln!(\"[keel-serve] tiers={:?}\", engine.available());\n\n    let state = AppState { engine: Arc::new(engine), manifest: Arc::new(manifest) };\n    let app = Router::new()\n        .route(\"/health\", get(|| async { \"ok\" }))\n        .route(\"/v1/models\", get(models))\n        .route(\"/v1/chat/completions\", post(chat))\n        .with_state(state);\n\n    let listener = tokio::net::TcpListener::bind(ADDR).await.unwrap_or_else(|e| fail(format!(\"bind {ADDR}: {e}\")));\n    eprintln!(\"[keel-serve] OpenAI-compatible endpoint → http://{ADDR}/v1/chat/completions\");\n    axum::serve(listener, app).await.unwrap();\n}\n\nfn fail(msg: String) -> ! {\n    eprintln!(\"keel-serve: {msg}\");\n    std::process::exit(1);\n}\n\n/// Advertise the wired tiers as selectable \"models\" (the router still has final say per turn).\nasync fn models(State(st): State<AppState>) -> impl IntoResponse {\n    let data: Vec<Value> = st\n        .engine\n        .available()\n        .into_iter()\n        .map(|t| json!({ \"id\": t, \"object\": \"model\", \"owned_by\": \"keel\" }))\n        .collect();\n    Json(json!({ \"object\": \"list\", \"data\": data }))\n}\n\n#[derive(Deserialize)]\nstruct ChatRequest {\n    #[serde(default)]\n    messages: Vec<ChatMessage>,\n    /// KEEL extension: this turn is core-wire reasoning (else scaffolding) — a routing hint.\n    #[serde(default)]\n    kind: Option<String>,\n    /// KEEL extension: sovereign data — forces the local tier (I3).\n    #[serde(default)]\n    sovereign: Option<bool>,\n    /// KEEL extension: route this turn through the model's thinking mode.\n    #[serde(default)]\n    think: Option<bool>,\n}\n\n#[derive(Deserialize)]\nstruct ChatMessage {\n    role: String,\n    #[serde(default)]\n    content: Value, // string or array of parts\n}\n\nasync fn chat(State(st): State<AppState>, Json(body): Json<ChatRequest>) -> impl IntoResponse {\n    if body.messages.is_empty() {\n        return (StatusCode::BAD_REQUEST, Json(json!({ \"error\": { \"message\": \"no messages\" } }))).into_response();\n    }\n    let messages: Vec<Message> = body\n        .messages\n        .iter()\n        .map(|m| Message {\n            role: parse_role(&m.role),\n            content: parse_content(&m.content),\n            name: None,\n            reasoning_content: None,\n            tool_call_id: None,\n        })\n        .collect();\n\n    // The routing Step. Its `content` mirrors the request's modalities, so a request carrying an\n    // image routes local by itself (I3, perception is sovereign-by-default) — no caller opt-in.\n    let step = Step {\n        kind: if matches!(body.kind.as_deref(), Some(\"core-wire\") | Some(\"core_wire\")) { Kind::CoreWire } else { Kind::Scaffolding },\n        ty: \"api_turn\".into(),\n        trust_required: Trust::Normal,\n        data_class: if body.sovereign.unwrap_or(false) { DataClass::Sovereign } else { DataClass::Normal },\n        tier_history: vec![],\n        oracle_failures: 0,\n        projected_cost: None,\n        critical: false,\n        source: Some(\"serve\".into()),\n        content: messages.iter().flat_map(|m| m.content.clone()).collect(),\n        golden_refs: vec![],\n    };\n    let req = GenerateRequest {\n        messages,\n        model: String::new(), // the engine sets the routed tier's model\n        tools: vec![],\n        grammar: None,\n     
…[truncated]
```
**[tool result]**
```
The file C:\KEEL\crates\keel\src\bin\keel-serve.rs has been updated successfully. (file state is current in your context — no need to Read it back)
```

## Claude — Jun 13, 2026 21:46

> _[thinking]_
> 

## Claude — Jun 13, 2026 21:46

Both apps rewired. Before building I need to stop any running `keel-serve.exe` (it holds the binary and would cause a linker lock), while leaving `llama-server` up. Then clippy + test:

## Claude — Jun 13, 2026 21:46

**[tool: PowerShell]**
```json
{
  "command": "Get-Process keel-serve,keel -ErrorAction SilentlyContinue | Select-Object Name,Id; \"---stopping keel-serve if up---\"; Stop-Process -Name keel-serve -Force -ErrorAction SilentlyContinue; \"---llama-server (should stay up)---\"; Get-Process llama-server -ErrorAction SilentlyContinue | Select-Object Name,Id",
  "description": "Stop any running keel-serve; confirm llama-server stays up"
}
```
**[tool result]**
```
[32;1mName        [0m[32;1m    Id[0m
[32;1m----        [0m [32;1m   --[0m
keel-serve   49264
---stopping keel-serve if up---
---llama-server (should stay up)---
llama-server 36008
```

## Claude — Jun 13, 2026 21:46

> _[thinking]_
> 

## Claude — Jun 13, 2026 21:46

`keel-serve` stopped; `llama-server` (pid 36008) still resident on :8080 — the engine's probe will find it, no cold-start. Now clippy (zero-warning bar) then the test suite:

## Claude — Jun 13, 2026 21:46

**[tool: PowerShell]**
```json
{
  "command": "cargo clippy --manifest-path C:\\KEEL\\Cargo.toml --all-targets -- -D warnings 2>&1 | Select-Object -Last 40",
  "description": "Run clippy across the workspace with warnings denied"
}
```
**[tool result]**
```
[31;1m    Checking keel-contracts v0.2.0 (C:\KEEL\crates\keel-contracts)[0m
[31;1m    Checking ahash v0.8.12[0m
[31;1m    Checking hashbrown v0.14.5[0m
[31;1m    Checking hashlink v0.9.1[0m
[31;1m    Checking rusqlite v0.32.1[0m
[31;1m    Checking keel-kernel v0.2.0 (C:\KEEL\crates\keel-kernel)[0m
[31;1m    Checking keel-adapters v0.2.0 (C:\KEEL\crates\keel-adapters)[0m
[31;1m    Checking keel-services v0.2.0 (C:\KEEL\crates\keel-services)[0m
[31;1m    Checking keel-middleware v0.2.0 (C:\KEEL\crates\keel-middleware)[0m
[31;1m    Checking keel-store v0.2.0 (C:\KEEL\crates\keel-store)[0m
[31;1m    Checking keel v0.2.0 (C:\KEEL\crates\keel)[0m
[31;1m    Finished `dev` profile [unoptimized + debuginfo] target(s) in 2.97s[0m
```

## Claude — Jun 13, 2026 21:47

> _[thinking]_
> 

## Claude — Jun 13, 2026 21:47

Clippy is clean — zero warnings across the workspace. (The background-task notification is a stale orphan from the pre-compaction session — it already terminated; nothing to act on.) Now the full test suite:

## Claude — Jun 13, 2026 21:47

<!-- end chunk 17/21 | next: chunk-018.md -->
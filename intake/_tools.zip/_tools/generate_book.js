// ============================================================
// generate_book.js — Parameterized print-interior generator (BOOKSMITH)
//
// PURPOSE: emit the print-interior DOCX for one format profile
//   --format kdp_paperback | kdp_hardcover | mixam_hardcover |
//            mixam_paperback | blurb_paperback | blurb_hardcover
// from the version-pinned manuscript. ONE script; the profile selects only the
// page geometry, the four margin constants, the output filename, and the
// page-count multiple (ledger §4.1/§4.2/§4.4). KDP paperback and KDP hardcover
// share a byte-identical interior (hardcover differs only in the cover wrap);
// mixam_paperback shares the KDP interior too (trim pages, tight margins) but
// carries the inner_ routing filename and the Mixam x4 page multiple; the two
// blurb_* formats share ONE interior block between them (softcover vs
// ImageWrap differ only in the cover).
//
// BLURB PAGE GEOMETRY (print_presets.json blurb_trade.page_bleed_model):
//   Blurb page PDF = (trim_w + 0.125) x (trim_h + 0.25) — bleed on the OUTER
//   width edge only (none into the binding) + both height edges. The text
//   block stays IDENTICAL to the house layout by growing the page and adding
//   exactly 180 DXA (= 0.125") to the top, bottom, and OUTSIDE margins;
//   gutter unchanged. Mirror margins still injected.
//
// EVERYTHING per-book is read from book_config.json — geometry (trim), typography
// (interior.body_font/body_pt/leading/first_line_indent/body_color/ornament_glyph),
// margins (interior.gutter_in/outside_in/top_in/bottom_in, overridden for Mixam),
// front matter (front_matter[]), recto strategy (recto_strategy), unit noun
// (voice.unit_noun). NEVER hard-code a book-specific value.
//
// PORTED FROM: C:\BOOK\generate_book_kdp.js + C:\BOOK\generate_book_mixam.js +
//   C:\Claude-Titanic\generate_book_v12.js (unified — those are byte-identical
//   modulo margins + front matter + the H1-vs-H2 unit split).
//
// BAKED-IN LEDGER FIXES:
//   §3.3  markdown inline parse order = backticks -> math -> bold -> italic
//   §3.4  mirror-margin + evenAndOddHeaders JSZip injection AFTER Packer (inline)
//   §3.5  emptyHeadersFooters() on EVERY header-free section; trailing blank is a
//         truly-empty Paragraph (margin=0 is the WRONG fix — kept but not relied on)
//   §3.6  front matter built as separate one-page sections for vAlign injection
//   §4.1/§4.2  the four margin constants come from config; Mixam profile overrides
//   §4.3  per-unit SectionType.ODD_PAGE + trailing SectionType.EVEN_PAGE blank;
//         leading PageBreak SUPPRESSED when a heading is first-in-section
//   §4.4  KDP page count must be ×2 (trailing EVEN_PAGE); Mixam ×4 is padded in
//         Python after PDF conversion (NOT here) — noted in the console banner
//   §11.3 Mixam body filename carries the `inner_` routing keyword
//   2026-09-24 final render QC (across_borders; each case is gated in
//   regression_fixtures.py, KITP-A block):
//         config free text (About the Author, dedication, epigraph, reader's
//         note) goes through buildInlineRuns, so *Title* prints italic and never
//         as literal asterisks; About is justified like body text.
//         CJK is never italic (Word fakes a slant for SimSun) and carries an East
//         Asian w:lang, so Word's kinsoku keeps 、。，；：】 and , . ; : ) off the
//         start of a line; hanging punctuation stays off in Latin books.
//         Mid-flow figures: interior.figure_max_h_in (default 4.3) and an
//         opt-in ppi floor, interior.min_image_ppi (unset = no floor); a
//         caption keeps its lines together (the image keeps with it).
//         TOC1/TOC2 styles in the book font with a hanging turnover indent;
//         interior.body_space_after_pt (default 6); folio footer at 0.375 in;
//         DOCX core properties carry title / author / subtitle.
//   2026-09-24 final render QC, round 2 (across_borders; each case is gated in
//   regression_fixtures.py, KIT2-PRINT block):
//         a run of quote (label) lines is one block and a bare ">" never
//         prints; interior.label_keep_max_lines (opt-in) keeps a run on one
//         page (keepNext down the run + keepLines; a run too tall to move
//         without a hole keeps only its first and last lines bound); on a part
//         page the italic note under the label takes the label's indent.
//         Latin books carrying CJK: no Word autospace between CJK and Latin or
//         digits, and CJK punctuation compressed (characterSpacingControl).
//         Opt-in knobs: interior.hyphenate (headings, captions, labels, front
//         matter and About are never hyphenated), interior.caption (caption
//         size / alignment, no indent), title_lines (display breaks for the
//         half-title and title page), interior.part_title_break ("Part III:"
//         over its title; the Contents entry text is unchanged),
//         interior.label_cjk_nobreak_max (short CJK words in labels never
//         split across lines).
//         TOC1/TOC2 get a right indent, so a long entry wraps before the page
//         numbers; figures carry their markdown alt text; header distance
//         0.3 in (the empty header no longer sits on the trim).
//
// I/O:
//   node generate_book.js --config book_config.json --format <profile> \
//        [--src <master.md>] [--out <path.docx>] [--no-inject]
//   reads outputs/markdown/<slug>_vN.md (latest) + book_config.json
//   writes outputs/<profile>/<naming>.docx  and inline-injects mirror flags.
// ============================================================

const fs = require("fs");
const path = require("path");
const JSZip = require("jszip");
const {
  Document, Packer, Paragraph, TextRun, AlignmentType, PageBreak, SectionType,
  HeadingLevel, TableOfContents, StyleLevel, Header, Footer, PageNumber, ImageRun,
  Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType, OnOffElement,
} = require("docx");

const { latexToUnicode, fixProseSubscripts } = require("./latex_to_unicode.js");
const { injectMirrorMargins } = require("./inject_mirror_margins.js");
const {
  inject: injectValign,
  valignMapFromConfig,
} = require("./inject_front_matter_valign.js");

// ---- Repo root (this file lives in <repo>/_tools/) ----
const TOOLS_DIR = __dirname;
const REPO_ROOT = path.resolve(TOOLS_DIR, "..");

// ============================================================
// CLI
// ============================================================
function parseArgs(argv) {
  const args = { config: null, format: null, src: null, out: null, inject: true, help: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--config") args.config = argv[++i];
    else if (a === "--format") args.format = argv[++i];
    else if (a === "--src") args.src = argv[++i];
    else if (a === "--out") args.out = argv[++i];
    else if (a === "--no-inject") args.inject = false;
    else if (a === "--help" || a === "-h") args.help = true;
  }
  return args;
}

const VALID_FORMATS = [
  "kdp_paperback", "kdp_hardcover", "mixam_hardcover",
  "mixam_paperback", "blurb_paperback", "blurb_hardcover",
];

const USAGE = `generate_book.js — BOOKSMITH print-interior DOCX generator

Usage:
  node generate_book.js --config <book_config.json> --format <profile> [options]

Required:
  --config <path>   book_config.json (per-book knobs; schema _tools/book_config.schema.json)
  --format <name>   one of: ${VALID_FORMATS.join(" | ")}

Options:
  --src <path>      version-pinned master markdown (default: latest outputs/markdown/<slug>_vN.md)
  --out <path>      output .docx path (default: book_workspace/<slug>/outputs/<profile>/...)
  --no-inject       skip the post-Packer mirror-margin + front-matter vAlign injection
  -h, --help        show this help and exit

Reads geometry/typography/front-matter from book_config.json; NEVER hard-codes a
book-specific value. Run inject_mirror_margins.js + docx_to_pdf.py after this.`;

// Interior page-count multiple per format (§4.4; print_presets page_multiple).
// x2 is guaranteed here by the trailing EVEN_PAGE blank; x4 (Mixam) is padded
// in Python (docx_to_pdf.py --pad-multiple 4) AFTER PDF conversion.
const PAGE_MULTIPLE = {
  kdp_paperback: 2,
  kdp_hardcover: 2,
  mixam_hardcover: 4,
  mixam_paperback: 4,
  blurb_paperback: 2,
  blurb_hardcover: 2,
};

function isBlurb(format) {
  return format === "blurb_paperback" || format === "blurb_hardcover";
}

// ============================================================
// Config loading + defaults resolution
// The schema declares defaults; we resolve them here so a sparse config still
// produces a correct build. NEVER hard-code a book-specific value — only the
// schema's own documented defaults appear as fallbacks.
// ============================================================
function loadConfig(configPath) {
  if (!configPath) throw new Error("--config <book_config.json> is required");
  const abs = path.isAbsolute(configPath) ? configPath : path.resolve(process.cwd(), configPath);
  return JSON.parse(fs.readFileSync(abs, "utf8"));
}

function num(v, d) { return (typeof v === "number" && !Number.isNaN(v)) ? v : d; }
function str(v, d) { return (typeof v === "string" && v.length) ? v : d; }

// Inches -> DXA twips (1 inch = 1440 DXA).
function inToDxa(inches) { return Math.round(inches * 1440); }

// ============================================================
// Margin resolution by format profile (ledger §4.1 / §4.2).
// KDP profiles + mixam_paperback use interior.{gutter,outside,top,bottom}_in
// (the tight set). mixam_hardcover overrides to the looser binding-comfort set
// (schema-documented: gutter 0.875, outside 0.625, top 0.625, bottom 0.75).
// Blurb profiles take the tight set + exactly 180 DXA (0.125") on top, bottom,
// and OUTSIDE — compensating the larger Blurb page so the text block is
// IDENTICAL to the house layout. Gutter unchanged (no bleed into the binding).
// ============================================================
function resolveMargins(interior, format) {
  if (format === "mixam_hardcover") {
    return {
      top: inToDxa(0.625),
      bottom: inToDxa(0.75),
      gutter: inToDxa(0.875),
      outside: inToDxa(0.625),
    };
  }
  // The house tight set from config (kdp_paperback / kdp_hardcover /
  // mixam_paperback share it; blurb derives from it below).
  const tight = {
    top: inToDxa(num(interior.top_in, 0.5)),
    bottom: inToDxa(num(interior.bottom_in, 0.625)),
    gutter: inToDxa(num(interior.gutter_in, 0.75)),
    outside: inToDxa(num(interior.outside_in, 0.5)),
  };
  if (isBlurb(format)) {
    return {
      top: tight.top + 180,        // +0.125" — page grew 0.125 at the top edge
      bottom: tight.bottom + 180,  // +0.125" — and at the bottom edge
      gutter: tight.gutter,        // unchanged — no bleed into the binding
      outside: tight.outside + 180, // +0.125" — outer-width bleed edge
    };
  }
  return tight;
}

// ============================================================
// Output naming by profile. Mixam bodies (hardcover AND paperback) MUST carry
// the `inner_` routing keyword (ledger §11.3 — a bare name misroutes at
// upload). KDP paperback and hardcover share the interior but get distinct
// filenames so the folder is unambiguous. The two blurb formats share ONE
// interior block but each gets its own outputs/ dir (covers differ).
// ============================================================
function resolveOutPath(config, format, cliOut, wsRoot) {
  if (cliOut) return path.isAbsolute(cliOut) ? cliOut : path.resolve(process.cwd(), cliOut);
  const slug = config.slug;
  const workspaceOut = path.join(wsRoot, "outputs");
  let dir, file;
  if (format === "kdp_paperback") {
    dir = path.join(workspaceOut, "kdp_paperback");
    file = `${slug}_KDP_PAPERBACK.docx`;
  } else if (format === "kdp_hardcover") {
    dir = path.join(workspaceOut, "kdp_hardcover");
    file = `${slug}_KDP_HARDCOVER.docx`;
  } else if (format === "mixam_paperback") {
    dir = path.join(workspaceOut, "mixam_paperback");
    file = `inner_${slug}.docx`;   // inner_ keyword routes the body at Mixam upload
  } else if (format === "blurb_paperback") {
    dir = path.join(workspaceOut, "blurb_paperback");
    file = `${slug}_BLURB_TRADE.docx`;
  } else if (format === "blurb_hardcover") {
    dir = path.join(workspaceOut, "blurb_hardcover");
    file = `${slug}_BLURB_TRADE.docx`;  // same block as blurb_paperback, own dir
  } else { // mixam_hardcover
    dir = path.join(workspaceOut, "mixam_hardcover");
    file = `inner_${slug}.docx`;
  }
  return path.join(dir, file);
}

// ============================================================
// Locate the version-pinned master markdown.
// assemble_manuscript.py writes outputs/markdown/<slug>_v{N}.md (append-only
// version bump). We pick the highest N unless --src overrides.
// ============================================================
function resolveSrc(config, cliSrc, wsRoot) {
  if (cliSrc) return path.isAbsolute(cliSrc) ? cliSrc : path.resolve(process.cwd(), cliSrc);
  const slug = config.slug;
  const mdDir = path.join(wsRoot, "outputs", "markdown");
  if (!fs.existsSync(mdDir)) {
    throw new Error(`markdown source dir not found: ${mdDir} (run assemble_manuscript.py, or pass --src)`);
  }
  const re = new RegExp(`^${slug}_v(\\d+)\\.md$`);
  let best = null, bestN = -1;
  for (const name of fs.readdirSync(mdDir)) {
    const m = name.match(re);
    if (m) {
      const n = parseInt(m[1], 10);
      if (n > bestN) { bestN = n; best = name; }
    }
  }
  if (!best) throw new Error(`no ${slug}_vN.md found in ${mdDir}`);
  return path.join(mdDir, best);
}

// ============================================================
// TYPO — resolved from config.interior
// ============================================================
function resolveTypography(config) {
  const interior = config.interior || {};
  const bodyPt = num(interior.body_pt, 12);
  // CJK editions: interior.body_font_latin pairs a Latin face with a CJK body
  // face via split rFonts (ascii/hAnsi = Latin, eastAsia/cs = body). Absent the
  // key, FONT stays a plain string and output is byte-identical to before.
  const bodyName = str(interior.body_font, "Georgia");
  const latinName = str(interior.body_font_latin, "");
  return {
    FONT: latinName
      ? { ascii: latinName, hAnsi: latinName, eastAsia: bodyName, cs: bodyName }
      : bodyName,
    FONT_NAME: latinName ? `${latinName} + ${bodyName}` : bodyName,
    BODY_SIZE: bodyPt * 2,               // docx size is half-points
    BODY_LINE: num(interior.leading, 340),
    // Space after a body paragraph, in points (default 6 pt = the historical
    // 120 twips). 0 gives indent-only paragraphs, so full pages end level.
    BODY_AFTER: Math.round(Math.max(0, num(interior.body_space_after_pt, 6)) * 20),
    FIRST_INDENT: num(interior.first_line_indent, 360),
    BODY_COLOR: str(interior.body_color, "1A1A1A"),
    ORNAMENT: str(interior.ornament_glyph, "✦"),
    // Config-driven glyph fonts (schema defaults match the historical literals,
    // so a sparse config is byte-identical to before). ORNAMENT_FONT renders the
    // ornament glyph, CODE_FONT the inline `backtick` runs, MATH_FONT the
    // LaTeX->Unicode math runs.
    ORNAMENT_FONT: str(interior.ornament_font, "Segoe UI Symbol"),
    CODE_FONT: str(interior.code_font, "Consolas"),
    MATH_FONT: str(interior.math_font, "Cambria Math"),
  };
}

// ============================================================
// East Asian runs (2026-09-24, across_borders final render QC). Two defects,
// one mechanism:
//   1. SimSun (and every CJK face here) has no italic, so a CJK run marked
//      italic prints with Word's synthetic 18-degree slant: a typesetting error
//      to any Chinese or Japanese reader. CJK is therefore NEVER italic: in an
//      italic context the CJK segment is emitted upright, Latin keeps its italics.
//   2. With no East Asian language on the text, Word breaks a line before
//      、。，；：】 and before an ASCII , . ; ) that follows a CJK character (13
//      such line starts in the book). Tagging w:lang w:eastAsia engages Word's
//      kinsoku rules, with no Word language pack needed (proved on an en-US-only
//      Word, 13 -> 0).
// cjkRuns(opts) returns TextRun[]: a run with no CJK character is ONE TextRun
// built from opts unchanged, so Latin-only text is byte-identical. A CJK
// segment is CJK characters plus any whitespace between two of them (one
// upright run for "李明红， 萧百中"). Its language: ja-JP if it holds kana,
// ko-KR if it holds hangul, else the document's East Asian default (zh-CN).
// In a Latin-language book every CJK segment is tagged (tagDefault); in a
// CJK-language book the document default already names the language, so only
// italic runs and segments in ANOTHER East Asian language are split.
// ============================================================
const CJK_CHARS = "\\u2E80-\\u2FDF\\u2FF0-\\u303F\\u3040-\\u30FF\\u3100-\\u31FF\\u3200-\\u33FF" +
  "\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uAC00-\\uD7AF\\uF900-\\uFAFF\\uFE30-\\uFE4F\\uFF00-\\uFFEF" +
  "\\u{20000}-\\u{3134F}";
const CJK_TEST_RE = new RegExp(`[${CJK_CHARS}]`, "u");
// A U+200D joiner between two CJK characters (interior.label_cjk_nobreak_max)
// stays inside the segment, so a joined word is one run, not five.
const CJK_SEGMENT_RE = new RegExp(`([${CJK_CHARS}]+(?:(?:\\s+|\\u200D)[${CJK_CHARS}]+)*)`, "u");
const KANA_RE = new RegExp("[\\u3041-\\u309F\\u30A0-\\u30FA\\u30FC-\\u30FF\\u31F0-\\u31FF\\uFF66-\\uFF9F]");
const HANGUL_RE = new RegExp("[\\u3130-\\u318F\\uAC00-\\uD7AF\\uFFA0-\\uFFDC]");

function eastAsianLangOf(segment, defaultEA) {
  if (KANA_RE.test(segment)) return "ja-JP";
  if (HANGUL_RE.test(segment)) return "ko-KR";
  return defaultEA;
}

function makeCjkRunFactory(eaCtx) {
  return function cjkRuns(opts) {
    const text = opts && opts.text;
    if (typeof text !== "string" || !CJK_TEST_RE.test(text)) return [new TextRun(opts)];
    const parts = text.split(CJK_SEGMENT_RE);   // odd indexes are the CJK segments
    const foreign = parts.some((p, i) => i % 2 === 1 && eastAsianLangOf(p, eaCtx.defaultEA) !== eaCtx.defaultEA);
    if (opts.italics !== true && !eaCtx.tagDefault && !foreign) return [new TextRun(opts)];
    const out = [];
    parts.forEach((part, i) => {
      if (!part) return;
      if (i % 2 === 0) { out.push(new TextRun({ ...opts, text: part })); return; }
      const seg = { ...opts, text: part };
      if (opts.italics === true) seg.italics = false;
      const lang = eastAsianLangOf(part, eaCtx.defaultEA);
      if (eaCtx.tagDefault || lang !== eaCtx.defaultEA) seg.language = { ...(opts.language || {}), eastAsia: lang };
      out.push(new TextRun(seg));
    });
    return out;
  };
}

// East Asian context for one build: the book's own language decides whether
// CJK is the body script (zh / ja / ko) or an embedded one (a Latin book that
// quotes labels, names, characters). Scans only text the interior renders.
function resolveEastAsianContext(config, masterMd) {
  const lang = String(config.language || "").toLowerCase();
  const cjkBook = /^(zh|ja|ko)/.test(lang);
  // Charter §13 (2026-09-28): zh-Hant/TW/HK/MO configs are tagged zh-TW, not zh-CN.
  const defaultEA = lang.startsWith("ja") ? "ja-JP" : lang.startsWith("ko") ? "ko-KR"
    : (/(hant|hk|-tw|-mo)/.test(lang)) ? "zh-TW" : "zh-CN";
  const rendered = [
    masterMd, config.title, config.subtitle, config.author, config.dedication,
    config.about_the_author, config.readers_note,
    JSON.stringify(config.epigraph || ""), JSON.stringify(config.strings || {}),
  ].filter((s) => typeof s === "string").join("\n");
  const hasCjk = CJK_TEST_RE.test(rendered);
  return { cjkBook, hasCjk, defaultEA, latinWithCjk: !cjkBook && hasCjk, tagDefault: !cjkBook && hasCjk };
}

// docx@9 writes <w:overflowPunct> only when it is TRUE, so "off" is patched into
// the packed styles.xml (docDefaults pPr). Needed once a Latin book carries an
// East Asian language: Word then turns on hanging punctuation, and on
// across_borders 44 lines hung , . : up to 3.7 pt and a fullwidth ， 12 pt past
// the right margin. Inserted in CT_PPrBase schema order.
const PPR_AFTER_OVERFLOW_PUNCT = ["topLinePunct", "autoSpaceDE", "autoSpaceDN", "bidi",
  "adjustRightInd", "snapToGrid", "spacing", "ind", "contextualSpacing", "mirrorIndents",
  "suppressOverlap", "jc", "textDirection", "textAlignment", "textboxTightWrap",
  "outlineLvl", "divId", "cnfStyle", "rPr", "sectPr", "pPrChange"];

function withOverflowPunctOff(stylesXml) {
  const OFF = '<w:overflowPunct w:val="0"/>';
  if (stylesXml.includes("<w:pPrDefault/>")) {
    return stylesXml.replace("<w:pPrDefault/>", `<w:pPrDefault><w:pPr>${OFF}</w:pPr></w:pPrDefault>`);
  }
  const m = stylesXml.match(/<w:pPrDefault>\s*<w:pPr>([\s\S]*?)<\/w:pPr>\s*<\/w:pPrDefault>/)
    || stylesXml.match(/<w:pPrDefault>\s*<w:pPr\/>\s*<\/w:pPrDefault>/);
  if (!m) throw new Error("styles.xml has no docDefaults pPrDefault to carry overflowPunct=0");
  let inner = (m[1] || "").replace(/<w:overflowPunct\b[^>]*\/>/g, "");
  const next = inner.match(new RegExp(`<w:(${PPR_AFTER_OVERFLOW_PUNCT.join("|")})\\b`));
  inner = next ? inner.slice(0, next.index) + OFF + inner.slice(next.index) : inner + OFF;
  return stylesXml.slice(0, m.index) + `<w:pPrDefault><w:pPr>${inner}</w:pPr></w:pPrDefault>` +
    stylesXml.slice(m.index + m[0].length);
}

// ---- Schema-ordered XML inserts for the post-Packer patch (KIT2-PRINT) ----
// docx@9 cannot write these settings, so they are placed into the packed parts
// in their schema position: Word tolerates little disorder inside pPr, and a
// settings.xml in schema order is what Word itself writes.
const PPR_BASE_ORDER = ["pStyle", "keepNext", "keepLines", "pageBreakBefore", "framePr",
  "widowControl", "numPr", "suppressLineNumbers", "pBdr", "shd", "tabs", "suppressAutoHyphens",
  "kinsoku", "wordWrap", "overflowPunct", "topLinePunct", "autoSpaceDE", "autoSpaceDN", "bidi",
  "adjustRightInd", "snapToGrid", "spacing", "ind", "contextualSpacing", "mirrorIndents",
  "suppressOverlap", "jc", "textDirection", "textAlignment", "textboxTightWrap", "outlineLvl",
  "divId", "cnfStyle", "rPr", "sectPr", "pPrChange"];

// CT_Settings child order (ECMA-376 Part 1, 17.15.1.78).
const SETTINGS_ORDER = ["writeProtection", "view", "zoom", "removePersonalInformation",
  "removeDateAndTime", "doNotDisplayPageBoundaries", "displayBackgroundShape",
  "printPostScriptOverText", "printFractionalCharacterWidth", "printFormsData",
  "embedTrueTypeFonts", "embedSystemFonts", "saveSubsetFonts", "saveFormsData", "mirrorMargins",
  "alignBordersAndEdges", "bordersDoNotSurroundHeader", "bordersDoNotSurroundFooter",
  "gutterAtTop", "hideSpellingErrors", "hideGrammaticalErrors", "activeWritingStyle",
  "proofState", "formsDesign", "attachedTemplate", "linkStyles", "stylePaneFormatFilter",
  "stylePaneSortMethod", "documentType", "mailMerge", "revisionView", "trackRevisions",
  "doNotTrackMoves", "doNotTrackFormatting", "documentProtection", "autoFormatOverride",
  "styleLockTheme", "styleLockQFSet", "defaultTabStop", "autoHyphenation",
  "consecutiveHyphenLimit", "hyphenationZone", "doNotHyphenateCaps", "showEnvelope",
  "summaryLength", "clickAndTypeStyle", "defaultTableStyle", "evenAndOddHeaders",
  "bookFoldRevPrinting", "bookFoldPrinting", "bookFoldPrintingSheets",
  "drawingGridHorizontalSpacing", "drawingGridVerticalSpacing",
  "displayHorizontalDrawingGridEvery", "displayVerticalDrawingGridEvery",
  "doNotUseMarginsForDrawingGridOrigin", "drawingGridHorizontalOrigin",
  "drawingGridVerticalOrigin", "doNotShadeFormData", "noPunctuationKerning",
  "characterSpacingControl", "printTwoOnOne", "strictFirstAndLastChars", "noLineBreaksAfter",
  "noLineBreaksBefore", "savePreviewPicture", "doNotValidateAgainstSchema", "saveInvalidXml",
  "ignoreMixedContent", "alwaysShowPlaceholderText", "doNotDemarcateInvalidXml",
  "saveXmlDataOnly", "useXSLTWhenSaving", "saveThroughXslt", "showXMLTags",
  "alwaysMergeEmptyNamespace", "updateFields", "hdrShapeDefaults", "footnotePr", "endnotePr",
  "compat", "docVars", "rsids", "mathPr", "attachedSchema", "themeFontLang", "clrSchemeMapping",
  "doNotIncludeSubdocsInStats", "doNotAutoCompressPictures", "forceUpgrade", "captions",
  "readModeInkLockDown", "smartTagType", "schemaLibrary", "shapeDefaults", "doNotEmbedSmartTags",
  "decimalSymbol", "listSeparator"];

// Insert (or replace) the child <w:tag> into a parent's inner XML, before the
// first existing child that the schema orders after it. Nested elements are
// skipped because their names are not in the order list (or follow a parent
// that already ranks later).
function withOrderedChild(inner, order, tag, xml) {
  const rank = order.indexOf(tag);
  if (rank < 0) throw new Error(`withOrderedChild: <w:${tag}> is not in the schema order list`);
  inner = inner.replace(new RegExp(`<w:${tag}\\b[^>]*/>|<w:${tag}\\b[^>]*>[\\s\\S]*?</w:${tag}>`, "g"), "");
  const re = /<w:(\w+)\b/g;
  let m;
  while ((m = re.exec(inner))) {
    if (order.indexOf(m[1]) > rank) return inner.slice(0, m.index) + xml + inner.slice(m.index);
  }
  return inner + xml;
}

// A docDefaults pPr child (e.g. autoSpaceDE off), in CT_PPrBase order.
function withDocDefaultPPrChild(stylesXml, tag, xml) {
  if (stylesXml.includes("<w:pPrDefault/>")) {
    return stylesXml.replace("<w:pPrDefault/>", `<w:pPrDefault><w:pPr>${xml}</w:pPr></w:pPrDefault>`);
  }
  const m = stylesXml.match(/<w:pPrDefault>\s*<w:pPr>([\s\S]*?)<\/w:pPr>\s*<\/w:pPrDefault>/)
    || stylesXml.match(/<w:pPrDefault>\s*<w:pPr\/>\s*<\/w:pPrDefault>/);
  if (!m) throw new Error(`styles.xml has no docDefaults pPrDefault to carry <w:${tag}>`);
  return stylesXml.slice(0, m.index) +
    `<w:pPrDefault><w:pPr>${withOrderedChild(m[1] || "", PPR_BASE_ORDER, tag, xml)}</w:pPr></w:pPrDefault>` +
    stylesXml.slice(m.index + m[0].length);
}

// A pPr child inside one paragraph style (e.g. TOC1), in CT_PPrBase order.
function withStylePPrChild(stylesXml, styleId, tag, xml) {
  const sm = stylesXml.match(new RegExp(`<w:style\\b[^>]*w:styleId="${styleId}"[^>]*>[\\s\\S]*?</w:style>`));
  if (!sm) throw new Error(`styles.xml has no style ${styleId} to carry <w:${tag}>`);
  let style = sm[0];
  const pm = style.match(/<w:pPr>([\s\S]*?)<\/w:pPr>|<w:pPr\/>/);
  if (pm) {
    style = style.slice(0, pm.index) + `<w:pPr>${withOrderedChild(pm[1] || "", PPR_BASE_ORDER, tag, xml)}</w:pPr>` +
      style.slice(pm.index + pm[0].length);
  } else {
    const at = style.search(/<w:rPr>|<w:tblPr>|<\/w:style>/);
    style = style.slice(0, at) + `<w:pPr>${xml}</w:pPr>` + style.slice(at);
  }
  return stylesXml.slice(0, sm.index) + style + stylesXml.slice(sm.index + sm[0].length);
}

// A settings.xml child, in CT_Settings order.
function withSettingsChild(settingsXml, tag, xml) {
  const open = settingsXml.match(/<w:settings\b[^>]*>/);
  const close = settingsXml.lastIndexOf("</w:settings>");
  if (!open || close < 0) throw new Error("settings.xml has no <w:settings> root");
  const head = open.index + open[0].length;
  return settingsXml.slice(0, head) +
    withOrderedChild(settingsXml.slice(head, close), SETTINGS_ORDER, tag, xml) +
    settingsXml.slice(close);
}

// interior.hyphenate: true, or { zone_in, max_consecutive, hyphenate_caps }.
// Absent / false = no hyphenation (the historical build). The defaults are
// Word's own zone (0.25 in), at most 2 hyphenated lines in a row, and no
// hyphenation of words in capitals (labels, acronyms).
function resolveHyphenation(interior) {
  const h = interior && interior.hyphenate;
  if (!h) return null;
  const o = typeof h === "object" ? h : {};
  const zoneIn = typeof o.zone_in === "number" && o.zone_in > 0 ? o.zone_in : 0.25;
  const limit = Number.isInteger(o.max_consecutive) && o.max_consecutive >= 0 ? o.max_consecutive : 2;
  return { zone: inToDxa(zoneIn), limit, caps: o.hyphenate_caps === true };
}

// settings.xml for one build: hyphenation (opt-in) and, for a Latin book that
// carries CJK, compressed CJK punctuation (a full-width 》 or ， keeps half an
// em of built-in blank; compression lets Word close it up where a line allows).
function withPrintSettings(settingsXml, { hyphenation, compressPunctuation }) {
  let s = settingsXml;
  if (hyphenation) {
    s = withSettingsChild(s, "autoHyphenation", "<w:autoHyphenation/>");
    s = withSettingsChild(s, "consecutiveHyphenLimit", `<w:consecutiveHyphenLimit w:val="${hyphenation.limit}"/>`);
    s = withSettingsChild(s, "hyphenationZone", `<w:hyphenationZone w:val="${hyphenation.zone}"/>`);
    if (!hyphenation.caps) s = withSettingsChild(s, "doNotHyphenateCaps", "<w:doNotHyphenateCaps/>");
  }
  if (compressPunctuation) {
    s = withSettingsChild(s, "characterSpacingControl", '<w:characterSpacingControl w:val="compressPunctuation"/>');
  }
  return s;
}

// Post-Packer patch of styles.xml / settings.xml. A book that needs none of
// it (no CJK in a Latin book, no hyphenation) is returned untouched.
//   overflowPunctOff: KITP-A (docDefaults overflowPunct=0).
//   latinCjkSpacing (KIT2-PRINT, S3): docDefaults autoSpaceDE/autoSpaceDN off,
//     so Word adds no space between CJK and Latin letters or digits that the
//     manuscript did not type ("0.5米" printed as "0.5 米"), plus compressed
//     CJK punctuation. Word's justification still distributes stretch at every
//     CJK character boundary once word spaces have taken about 1.2 pt each; no
//     document or paragraph setting changes that (autospace, punctuation
//     compression, the document grid, snapToGrid, the East Asian language,
//     wpJustification and balanceSingleByteDoubleByteWidth were each rendered
//     by Word on across_borders: 10 spread lines every time). What reduces it
//     is less stretch in the line: interior.hyphenate (10 -> 1).
//   hyphenation: settings (withPrintSettings) + TOC1/TOC2 never hyphenated.
async function patchPackedDocx(buf, opts) {
  const { overflowPunctOff, latinCjkSpacing, hyphenation } = opts || {};
  if (!overflowPunctOff && !latinCjkSpacing && !hyphenation) return buf;
  const zip = await JSZip.loadAsync(buf);
  const styles = zip.file("word/styles.xml");
  if (!styles) throw new Error("packed DOCX has no word/styles.xml");
  let sx = await styles.async("string");
  if (overflowPunctOff) sx = withOverflowPunctOff(sx);
  if (latinCjkSpacing) {
    sx = withDocDefaultPPrChild(sx, "autoSpaceDE", '<w:autoSpaceDE w:val="0"/>');
    sx = withDocDefaultPPrChild(sx, "autoSpaceDN", '<w:autoSpaceDN w:val="0"/>');
  }
  if (hyphenation) {
    for (const id of ["TOC1", "TOC2"]) sx = withStylePPrChild(sx, id, "suppressAutoHyphens", "<w:suppressAutoHyphens/>");
  }
  zip.file("word/styles.xml", sx);
  if (latinCjkSpacing || hyphenation) {
    const settings = zip.file("word/settings.xml");
    if (!settings) throw new Error("packed DOCX has no word/settings.xml");
    zip.file("word/settings.xml", withPrintSettings(await settings.async("string"),
      { hyphenation, compressPunctuation: !!latinCjkSpacing }));
  }
  return zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
}

// ---- Paragraph-level w:suppressAutoHyphens (KIT2-PRINT, S4). docx@9 has no
// option for it, so the element is spliced into the paragraph's own pPr at its
// CT_PPrBase position. Called only when interior.hyphenate is on (a book that
// does not hyphenate builds exactly as before).
function suppressAutoHyphens(para) {
  const kids = para && para.properties && para.properties.root;
  if (!Array.isArray(kids)) return para;
  if (kids.some((k) => k && k.rootKey === "w:suppressAutoHyphens")) return para;
  const rank = PPR_BASE_ORDER.indexOf("suppressAutoHyphens");
  const at = kids.findIndex((k) => k && typeof k.rootKey === "string" &&
    PPR_BASE_ORDER.indexOf(k.rootKey.replace(/^w:/, "")) > rank);
  const el = new OnOffElement("w:suppressAutoHyphens", true);
  if (at < 0) kids.push(el); else kids.splice(at, 0, el);
  return para;
}

// ============================================================
// Inline run builder — parse order: backticks -> math -> bold -> italic
// (ledger §3.3: code spans BEFORE italics; an asymmetric parser shipped literal
// backticks to Kindle). Math via latexToUnicode tagged Cambria Math.
// ============================================================
function makeInlineBuilder(T, mathEnabled, cjkRuns) {
  // cjkRuns (makeCjkRunFactory) splits CJK out of italic runs and tags its
  // language; absent, a plain TextRun wrapper keeps the legacy behavior.
  const mkRuns = cjkRuns || ((o) => [new TextRun(o)]);
  return function buildInlineRuns(text, baseOpts) {
    // Prose-mode subscript fix (safe before math split: math uses \Omega, not Ω).
    text = fixProseSubscripts(text);
    // Nested-emphasis degradation the split pipeline cannot express:
    // bold-italic renders bold.
    text = text.replace(/\*\*\*([^*]+)\*\*\*/g, "**$1**");
    const runs = [];
    const codeParts = text.split(/(`[^`]+`)/g);
    const isCodeSpan = (p) => p.startsWith("`") && p.endsWith("`") && p.length > 2;
    // Bold pairing ACROSS code/math spans (QC fix 2026-07-23): the backticks-first
    // split used to orphan any ** pair whose span CONTAINED inline code, shipping
    // literal asterisks ("**The brain (`d3`), honestly labeled.**"). Count **
    // markers OUTSIDE code spans; an even count > 0 drives a toggle: every **
    // flips bold state, and code/math runs inside the span inherit bold. An odd
    // count falls back to the legacy per-segment pairing verbatim, so a stray
    // literal ** is never silently eaten. ** inside a code span is never a marker
    // (`**kwargs` stays literal).
    let starMarkers = 0;
    for (const p of codeParts) {
      if (!isCodeSpan(p)) starMarkers += (p.match(/\*\*/g) || []).length;
    }
    const pairable = starMarkers > 0 && starMarkers % 2 === 0;
    let boldOn = false;
    const boldOpt = () => (boldOn ? { bold: true } : {});
    const emitItalicAware = (seg, extra) => {
      const italicParts = seg.split(/(\*[^*]+\*)/g);
      for (const part of italicParts) {
        if (part.startsWith("*") && part.endsWith("*") && part.length > 2) {
          runs.push(...mkRuns({ ...baseOpts, ...extra, text: part.slice(1, -1), italics: true }));
        } else if (part.length > 0) {
          runs.push(...mkRuns({ ...baseOpts, ...extra, text: part }));
        }
      }
    };
    for (const codePart of codeParts) {
      if (isCodeSpan(codePart)) {
        runs.push(new TextRun({ ...baseOpts, ...boldOpt(), text: codePart.slice(1, -1), font: T.CODE_FONT }));
        continue;
      }
      if (codePart.length === 0) continue;
      // $..$ math parsing only for nonfiction (is_fiction:false) books, and a
      // currency pair ("$14.99 ... $24.99": digit-first, no \ ^ _) must stay
      // literal prose — otherwise the dollars are eaten and the span ships in
      // Cambria Math italic.
      const mathParts = mathEnabled ? codePart.split(/(\$[^$]+\$)/g) : [codePart];
      for (const mathPart of mathParts) {
        const inner = (mathEnabled && mathPart.startsWith("$") && mathPart.endsWith("$") && mathPart.length > 2)
          ? mathPart.slice(1, -1) : null;
        const currencyLike = inner !== null && /^\d/.test(inner) && !/[\\^_]/.test(inner);
        if (inner !== null && !currencyLike) {
          const expr = latexToUnicode(inner);
          runs.push(...mkRuns({ ...baseOpts, ...boldOpt(), text: expr, font: T.MATH_FONT, italics: true }));
          continue;
        }
        if (mathPart.length === 0) continue;
        if (pairable) {
          const toggleParts = mathPart.split("**");
          for (let i = 0; i < toggleParts.length; i++) {
            if (i > 0) boldOn = !boldOn;
            if (toggleParts[i].length > 0) emitItalicAware(toggleParts[i], boldOpt());
          }
          continue;
        }
        // Legacy pairing (unchanged behavior for zero/odd ** lines).
        const boldParts = mathPart.split(/(\*\*[^*]+\*\*)/g);
        for (const boldPart of boldParts) {
          if (boldPart.startsWith("**") && boldPart.endsWith("**") && boldPart.length > 4) {
            runs.push(...mkRuns({ ...baseOpts, text: boldPart.slice(2, -2), bold: true }));
            continue;
          }
          if (boldPart.length === 0) continue;
          emitItalicAware(boldPart, {});
        }
      }
    }
    return runs;
  };
}

// ============================================================
// Labels, captions, titles (KIT2-PRINT, 2026-09-24 final render QC, round 2)
// ============================================================
// A quote line: "> text", or a bare ">" (a paragraph break inside the quote;
// it never prints, as in generate_kindle.js and build_epub.py).
function isQuoteLine(l) {
  const t = String(l).trim();
  return t === ">" || t.startsWith("> ");
}

// One line set wholly in *italics* (a roman stretch inside allowed).
function isItalicLine(l) {
  return /^\*[^*\s](?:.*\S)?\*$/.test(String(l).trim());
}

// interior.label_keep_max_lines (opt-in; absent or 0 = no keep flags, the
// historical build; LABEL_KEEP_MAX_LINES = 10 is the recommended value): a
// label run keeps all its lines on one page (keepNext down the run, keepLines
// on each line) when it is at most that many printed lines, short enough to
// move to the next page whole without leaving a large hole. A taller run may
// break, but its first and last lines stay bound to their neighbours.
// A single label paragraph of up to LABEL_KEEP_PARA_MAX_LINES lines never
// splits; a longer one may, never leaving one line alone (widowControl).
const LABEL_KEEP_MAX_LINES = 10;
const LABEL_KEEP_PARA_MAX_LINES = 4;

// Estimated printed width of text in ems of its own size: full-width CJK 1,
// capitals and digits 0.6, space 0.25, anything else 0.47 (Georgia italic;
// predicts the printed line count of 68 of across_borders' 70 label lines
// exactly, the other two within one line). A guard for the keep chain only.
const EM_CJK_RE = /[\u{2E80}-\u{9FFF}\u{AC00}-\u{D7AF}\u{F900}-\u{FAFF}\u{FE30}-\u{FE4F}\u{FF00}-\u{FFEF}]/u;
function estimateEms(text) {
  let e = 0;
  for (const ch of String(text).replace(/[*`\u{200D}]/gu, "")) {
    if (EM_CJK_RE.test(ch) || ch.codePointAt(0) > 0xFFFF) e += 1;
    else if (ch === " ") e += 0.25;
    else if (/[A-Z0-9]/.test(ch)) e += 0.6;
    else e += 0.47;
  }
  return e;
}
function estimateLines(text, sizePt, measureTwips) {
  const widthPt = estimateEms(text) * sizePt * 1.04;
  return Math.max(1, Math.ceil(widthPt / (measureTwips / 20)));
}

// Keep flags for each paragraph of a label run (see LABEL_KEEP_MAX_LINES).
// withNote: an italic note follows the run (its last line keeps with it).
// maxLines: interior.label_keep_max_lines (default LABEL_KEEP_MAX_LINES); 0 =
// no keep flags at all (the historical build: a label may break anywhere).
function labelRunKeeps(lineCounts, withNote, maxLines = LABEL_KEEP_MAX_LINES) {
  if (maxLines === 0) return lineCounts.map(() => ({}));
  const n = lineCounts.length;
  const total = lineCounts.reduce((a, b) => a + b, 0);
  const whole = total <= maxLines && (n > 1 || total <= LABEL_KEEP_PARA_MAX_LINES);
  return lineCounts.map((lines, k) => {
    const last = k === n - 1;
    if (whole) return { keepNext: !last || !!withNote, keepLines: true };
    const edge = n >= 3 && (k === 0 || k === n - 2);
    return lines <= LABEL_KEEP_PARA_MAX_LINES
      ? { keepNext: edge, keepLines: true }
      : { keepNext: edge, widowControl: true };
  });
}

// A part page (or any opener unit) whose whole body is one label run and one
// italic line under it: that line is the label's note and takes the label's
// indent (N9). An italic line after a quote inside running prose is left alone
// (weiming_zhang's plaques are followed by photo captions, not notes).
function isLabelNoteUnit(md) {
  const body = String(md).split("\n").map((l) => l.trim()).filter((l) => l !== "");
  if (body.length < 3 || !/^#{1,2}\s/.test(body[0])) return false;
  let k = 1;
  while (k < body.length && isQuoteLine(body[k])) k++;
  return k > 1 && k === body.length - 1 && isItalicLine(body[k]);
}

// Short CJK words inside a label never split across lines (N2): U+200D, which
// Word treats as its no-width non-break character, goes between the characters
// of every run of 2..max CJK letters (punctuation excluded). U+2060 (word
// joiner) does NOT work: Word still breaks beside it, draws it from Segoe UI
// Symbol and writes it into the PDF text layer (across_borders render, p145).
const CJK_LETTER_RUN_RE = /[\u{3040}-\u{30FF}\u{3100}-\u{312F}\u{3400}-\u{4DBF}\u{4E00}-\u{9FFF}\u{AC00}-\u{D7AF}\u{F900}-\u{FAFF}\u{20000}-\u{3134F}]{2,}/gu;
const ZWJ = "\u{200D}";   // escaped on purpose: an invisible literal reads as ""
function joinShortCjk(text, max) {
  if (!(max >= 2)) return text;
  return String(text).replace(CJK_LETTER_RUN_RE, (run) => {
    const chars = Array.from(run);
    return chars.length <= max ? chars.join(ZWJ) : run;
  });
}

// interior.caption (opt-in, S5): { size_pt, align: center|left|justify,
// space_after_pt }. Absent = the historical caption (a body paragraph that
// keeps its lines). Leading scales with the size.
function resolveCaptionStyle(interior, bodyPt, bodyLine) {
  const c = interior && interior.caption;
  if (!c || typeof c !== "object") return null;
  const sizePt = typeof c.size_pt === "number" && c.size_pt > 0 ? c.size_pt : bodyPt - 1.5;
  const half = Math.round(sizePt * 2);
  const align = { center: AlignmentType.CENTER, left: AlignmentType.LEFT, justify: AlignmentType.JUSTIFIED }[c.align || "center"]
    || AlignmentType.CENTER;
  return {
    size: half,
    line: Math.round(bodyLine * (half / 2) / bodyPt),
    align,
    after: Math.round(Math.max(0, typeof c.space_after_pt === "number" ? c.space_after_pt : 6) * 20),
  };
}

// title_lines (S6): the title as set on the half-title and title page, one
// entry per line. The words must be the title's (metadata is never changed).
function resolveTitleLines(config) {
  const tl = config.title_lines;
  if (!Array.isArray(tl) || !tl.length) return null;
  const lines = tl.map((s) => String(s).trim()).filter(Boolean);
  const norm = (s) => String(s).replace(/\s+/g, " ").trim().toLowerCase();
  if (norm(lines.join(" ")) !== norm(config.title)) {
    throw new Error(`title_lines ${JSON.stringify(tl)} do not spell the title ${JSON.stringify(config.title)}`);
  }
  return lines;
}

// interior.part_title_break (S7): "Part III: The All Asia ..." prints as
// "Part III:" over "The All Asia ...". The colon stays visible: Word's
// Contents turns the line break into a space and drops hidden text, so this is
// the only form whose Contents entry stays exactly the heading text.
function splitPartTitle(text) {
  const m = String(text).match(/^(.+?:)\s+(\S.*)$/);
  return m ? [m[1], m[2]] : null;
}

// ============================================================
// Paragraph factories (bound to resolved typography T)
// L (KIT2-PRINT): layout policy for this build:
//   { hyphenate, caption, labelMeasure, labelCjkNobreakMax }
// ============================================================
function makeFactories(T, buildInlineRuns, cjkRuns, L) {
  const mkRuns = cjkRuns || ((o) => [new TextRun(o)]);
  L = L || {};
  // Display text is never hyphenated; only emitted when interior.hyphenate is on.
  const noHyph = (p) => (L.hyphenate ? suppressAutoHyphens(p) : p);
  // opts.caption (the paragraph right after a mid-flow figure, see
  // isFigureCaption): keepLines so the caption never splits, and it keeps the
  // historical 120-twip space after even when interior.body_space_after_pt
  // sets indent-only body paragraphs (a caption must stay set off from the text).
  // interior.caption (L.caption, S5) sets a caption apart from the text:
  // smaller, not justified, no first-line indent; it still keeps its lines.
  function createBodyParagraph(text, opts) {
    const caption = !!(opts && opts.caption);
    if (caption && L.caption) {
      const C = L.caption;
      return noHyph(new Paragraph({
        spacing: { after: C.after, line: C.line, lineRule: "atLeast" },
        alignment: C.align,
        keepLines: true,
        children: buildInlineRuns(text, { font: T.FONT, size: C.size, color: T.BODY_COLOR }),
      }));
    }
    const runs = buildInlineRuns(text, { font: T.FONT, size: T.BODY_SIZE, color: T.BODY_COLOR });
    const p = new Paragraph({
      spacing: { after: caption ? 120 : T.BODY_AFTER, line: T.BODY_LINE, lineRule: "atLeast" },
      indent: { firstLine: T.FIRST_INDENT },
      alignment: AlignmentType.JUSTIFIED,
      ...(caption ? { keepLines: true } : {}),
      children: runs,
    });
    return caption ? noHyph(p) : p;
  }

  // One quote (label) line. keep: {keepNext, keepLines, widowControl} from
  // labelRunKeeps; absent, the historical paragraph.
  function createBlockquote(text, keep) {
    const t = L.labelCjkNobreakMax ? joinShortCjk(text, L.labelCjkNobreakMax) : text;
    const runs = buildInlineRuns(t, { font: T.FONT, size: T.BODY_SIZE - 2, color: "444444", italics: true });
    return noHyph(new Paragraph({
      ...(keep && keep.keepNext ? { keepNext: true } : {}),
      ...(keep && keep.keepLines ? { keepLines: true } : {}),
      ...(keep && keep.widowControl ? { widowControl: true } : {}),
      spacing: { before: 120, after: 160, line: T.BODY_LINE, lineRule: "atLeast" },
      indent: { left: 720, right: 360 },
      children: runs,
    }));
  }

  // A run of quote lines is one label block (S2): see labelRunKeeps.
  function createLabelRun(texts, withNote) {
    const size = (T.BODY_SIZE - 2) / 2;
    const maxLines = Number.isInteger(L.labelKeepMaxLines) ? L.labelKeepMaxLines : 0;
    const keeps = labelRunKeeps(texts.map((t) => estimateLines(t, size, L.labelMeasure || 5760)), withNote, maxLines);
    return texts.map((t, k) => createBlockquote(t, keeps[k]));
  }

  // The italic note under a part-page label (N9): the label's indents, ragged
  // right, no first-line indent; body size, italic from the markdown.
  function createLabelNote(text) {
    return noHyph(new Paragraph({
      keepLines: true,
      spacing: { after: T.BODY_AFTER, line: T.BODY_LINE, lineRule: "atLeast" },
      indent: { left: 720, right: 360 },
      alignment: AlignmentType.LEFT,
      children: buildInlineRuns(text, { font: T.FONT, size: T.BODY_SIZE, color: T.BODY_COLOR }),
    }));
  }

  // House-style unit-heading text (§16.3): title-case at light tracking, NOT
  // wide-tracked ALL-CAPS. Word's auto-TOC copies the heading text verbatim, so
  // an all-caps + wide-tracked + em-dash heading ("CHAPTER ONE — DEPARTURE")
  // produces a long Contents entry that wraps to two lines and collides with the
  // dot leaders. Title-case + a colon separator ("Chapter One: Departure",
  // matching the house style "Chapter 13: The Entropy Engineer") stays single-
  // line and de-garbles the auto-TOC. The colon swap fires only on a spaced
  // em/en-dash separator; a title without one keeps its own casing untouched.
  function unitHeadingText(title) {
    return String(title == null ? "" : title).replace(/\s+[—–]\s+/, ": ");
  }
  // Unit (chapter/part) heading. leadingPageBreak=false when this heading is the
  // first item of an ODD_PAGE section — the section break itself advances the
  // page, so a PageBreak would double-advance to an unwanted blank recto (§4.3).
  // splitTitle (interior.part_title_break, S7): "Part III: Title" prints as
  // "Part III:" / "Title" (one Heading 1 paragraph with a line break; the
  // Contents entry stays "Part III: Title").
  function createUnitHeading(title, leadingPageBreak, splitTitle) {
    const result = [];
    if (leadingPageBreak) result.push(new Paragraph({ children: [new PageBreak()] }));
    result.push(new Paragraph({ spacing: { before: 2000, after: 300 } }));
    const headOpts = { font: T.FONT, size: 28, color: T.BODY_COLOR, characterSpacing: 20 };
    const parts = splitTitle ? splitPartTitle(unitHeadingText(title)) : null;
    const headRuns = parts
      ? [...mkRuns({ ...headOpts, text: parts[0] }), new TextRun({ ...headOpts, break: 1 }), ...mkRuns({ ...headOpts, text: parts[1] })]
      : mkRuns({ ...headOpts, text: unitHeadingText(title) });
    result.push(noHyph(new Paragraph({
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 200, after: 400 },
      alignment: AlignmentType.CENTER,
      children: headRuns,
    })));
    result.push(new Paragraph({
      spacing: { before: 100, after: 500 },
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: T.ORNAMENT, font: T.ORNAMENT_FONT, size: 20, color: "999999" })],
    }));
    return result;
  }

  function createSubsectionHeading(title) {
    return noHyph(new Paragraph({
      spacing: { before: 300, after: 160 },
      alignment: AlignmentType.LEFT,
      keepNext: true,        // bind a subhead to the text that follows it, so a
                             // heading can never strand alone at a page foot
      keepLines: true,
      children: mkRuns({ text: title, font: T.FONT, size: 24, color: T.BODY_COLOR, bold: true }),
    }));
  }

  function createSectionBreak() {
    return new Paragraph({
      spacing: { before: 300, after: 300 },
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: `${T.ORNAMENT}  ${T.ORNAMENT}  ${T.ORNAMENT}`, font: T.ORNAMENT_FONT, size: 16, color: "BBBBBB" })],
    });
  }

  function createDisplayMath(expr) {
    return noHyph(new Paragraph({
      spacing: { before: 200, after: 200 },
      alignment: AlignmentType.CENTER,
      children: mkRuns({ text: latexToUnicode(expr), font: T.MATH_FONT, size: 24, color: T.BODY_COLOR, italics: true }),
    }));
  }

  // ---- Fenced code block (```): one Paragraph per source line, monospace,
  // verbatim (NO inline parse, NO smart-quote substitution). A light gray
  // shading + a small left indent set the block off; tight line spacing keeps
  // it compact. An empty code line still emits a Paragraph so blank lines in
  // the listing are preserved. Returns an array of Paragraphs.
  function createCodeBlock(codeLines) {
    const size = Math.max(14, T.BODY_SIZE - 4);   // ~2pt smaller than body
    return codeLines.map((cl, i) => noHyph(new Paragraph({
      shading: { type: ShadingType.CLEAR, color: "auto", fill: "F2F2F2" },
      spacing: { before: i === 0 ? 120 : 0, after: i === codeLines.length - 1 ? 120 : 0, line: 240, lineRule: "atLeast" },
      indent: { left: 240 },
      alignment: AlignmentType.LEFT,
      // A leading/blank space run keeps the shaded band full-width on empty lines.
      children: [new TextRun({ text: cl.length ? cl : " ", font: T.CODE_FONT, size, color: "1A1A1A" })],
    })));
  }

  // ---- Table (GitHub pipe table). rows[0] is the header (bold); the rest are
  // body rows. cells hold inline-parsed runs (bold/italic/code/math reused).
  // Thin single-line borders, header shading, cell padding, the book body font.
  function createTable(rows, aligns) {
    const thin = { style: BorderStyle.SINGLE, size: 4, color: "999999" };
    const borders = { top: thin, bottom: thin, left: thin, right: thin,
                      insideHorizontal: thin, insideVertical: thin };
    const ncol = rows.reduce((m, r) => Math.max(m, r.length), 0);
    const alignFor = (c) => {
      const a = aligns && aligns[c];
      if (a === "center") return AlignmentType.CENTER;
      if (a === "right") return AlignmentType.RIGHT;
      return AlignmentType.LEFT;
    };
    const mkCell = (cellText, isHeader, colIdx) => {
      const runs = buildInlineRuns(cellText, {
        font: T.FONT, size: T.BODY_SIZE - 2, color: T.BODY_COLOR, bold: isHeader || undefined,
      });
      return new TableCell({
        margins: { top: 40, bottom: 40, left: 100, right: 100 },
        shading: isHeader ? { type: ShadingType.CLEAR, color: "auto", fill: "EDEDED" } : undefined,
        children: [noHyph(new Paragraph({
          spacing: { after: 0, line: 240, lineRule: "atLeast" },
          alignment: alignFor(colIdx),
          children: runs.length ? runs : [new TextRun({ text: "", font: T.FONT, size: T.BODY_SIZE - 2 })],
        }))],
      });
    };
    const tableRows = rows.map((cells, r) => {
      const padded = cells.slice();
      while (padded.length < ncol) padded.push("");   // ragged rows -> square grid
      return new TableRow({
        tableHeader: r === 0,
        children: padded.map((c, ci) => mkCell(c, r === 0, ci)),
      });
    });
    return new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      borders,
      rows: tableRows,
    });
  }

  // ---- List items. Each item -> one hanging-indent Paragraph with a manual
  // marker ("•  " for bullets, "N.  " for ordered). depth (0-based) nests via a
  // deeper left indent. Inline markup inside the item text is parsed. Returns a
  // single Paragraph (the caller maps over the item set).
  function createListItem(marker, itemText, depth) {
    const step = 360;                       // 0.25" per nesting level
    const left = 360 + depth * step;
    const runs = [new TextRun({ text: marker, font: T.FONT, size: T.BODY_SIZE, color: T.BODY_COLOR })];
    for (const r of buildInlineRuns(itemText, { font: T.FONT, size: T.BODY_SIZE, color: T.BODY_COLOR })) runs.push(r);
    return new Paragraph({
      spacing: { after: 40, line: T.BODY_LINE, lineRule: "atLeast" },
      indent: { left, hanging: 240 },
      alignment: AlignmentType.LEFT,
      children: runs,
    });
  }

  return { createBodyParagraph, createBlockquote, createLabelRun, createLabelNote, createUnitHeading, createSubsectionHeading, createSectionBreak, createDisplayMath, createCodeBlock, createTable, createListItem };
}

// ============================================================
// Chapter-opener art (OPTIONAL; convention over configuration).
// interior.chapter_art {enabled, dir, width_in}; default dir is
// cover_art/illustrations/live under the workspace. One <unit_id>.png per
// unit, injected directly after that unit's heading. A missing dir or file is
// a silent no-op: the manuscript is never marked up, so books without art
// build byte-identically to before this feature existed.
// ============================================================
function pngDimensions(buf) {
  // PNG layout: 8-byte signature, 4-byte length, "IHDR", 4-byte w, 4-byte h.
  if (!buf || buf.length < 24) return null;
  if (buf[0] !== 0x89 || buf[1] !== 0x50 || buf[2] !== 0x4e || buf[3] !== 0x47) return null;
  return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) };
}

function resolveChapterArt(config, wsRoot) {
  const ca = (config.interior && config.interior.chapter_art) || {};
  if (ca.enabled === false) return null;
  const dir = path.resolve(wsRoot, ca.dir || path.join("cover_art", "illustrations", "live"));
  if (!fs.existsSync(dir)) return null;
  const widthIn = typeof ca.width_in === "number" && ca.width_in > 0 ? ca.width_in : 4.0;
  return { dir, widthIn };
}

function chapterArtParagraph(art, unitId, tag) {
  if (!art || !unitId) return null;
  const file = path.join(art.dir, `${unitId}.png`);
  if (!fs.existsSync(file)) return null;
  const data = fs.readFileSync(file);
  const dims = pngDimensions(data);
  if (!dims || !dims.w || !dims.h) {
    console.warn(`[${tag}] chapter art skipped (not a readable PNG): ${file}`);
    return null;
  }
  // transformation takes display pixels at 96dpi: width_in * 96 prints at width_in.
  const wPx = Math.round(art.widthIn * 96);
  const hPx = Math.round(wPx * (dims.h / dims.w));
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 120, after: 360 },
    children: [new ImageRun({ type: "png", data, transformation: { width: wPx, height: hPx } })],
  });
}

// ============================================================
// Mid-flow figures (2026-07-27, the figure-program feature): a standalone
// markdown image line "![alt](relpath)" EMBEDS the workspace-relative PNG/JPEG
// at that point in the print flow (generate_kindle.js and build_epub.py already
// embed these; print used to skip them). Sizing is natural-at-300dpi, capped to
// the text-block width and MIDFLOW_MAX_H_IN tall; keepNext binds the figure to
// the caption paragraph that follows so a page break never separates them. A
// grayscale-optimized "<name>_print.<ext>" sibling is preferred when present
// (make_print_figures.py emits them; the color originals keep serving
// kindle/epub/digital). A missing or unreadable file warns and skips — literal
// markdown never renders as body text (scan_manuscript.py FAILs a dangling
// reference before any build).
// ============================================================
const MD_IMAGE_RE = /^!\[([^\]]*)\]\(([^)\s]+)\)$/;
const MIDFLOW_DPI = 300;

// Alt text is plain text: inline markup markers dropped, as CommonMark does
// (the same rule as generate_kindle.js mdAltText). It becomes the figure's
// docPr descr/title in the print and Word DOCX (screen readers, Word's
// accessibility checker); name = the manuscript's file name.
function mdAltText(raw) {
  return String(raw || "")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/\*([^*]+)\*/g, "$1")
    .replace(/\s+/g, " ")
    .trim();
}
// Height cap for a mid-flow figure: interior.figure_max_h_in (default 4.3, the
// historical constant). A lower cap lets figure + caption fit the space left on
// a page instead of jumping to the next and leaving a hole (across_borders: three
// pages 53-58% empty ahead of 4.1-4.3 in figures).
const MIDFLOW_MAX_H_IN = 4.3;

// A figure caption is the paragraph right after a mid-flow figure when it is
// set as one emphasized line (*...*, the kit's caption convention) or is one
// short line (<= 120 characters: drdj_life's "（...）" captions). A long plain
// paragraph after a figure is body prose (Kimi_K3, YOU_STAY_ONE_PERSON), never
// a caption, and must not be bound into a keepLines block.
const CAPTION_MAX_PLAIN_CHARS = 120;
function isFigureCaption(line) {
  const t = line.trim();
  if (/^\*[^*](?:.*[^*])?\*$/.test(t)) return true;
  return t.length <= CAPTION_MAX_PLAIN_CHARS;
}

function jpgDimensions(buf) {
  // SOF marker scan (same reader generate_kindle.js uses).
  if (!buf || buf.length < 4 || buf[0] !== 0xff || buf[1] !== 0xd8) return null;
  let i = 2;
  while (i + 9 < buf.length) {
    if (buf[i] !== 0xff) { i++; continue; }
    const marker = buf[i + 1];
    if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { i += 2; continue; }
    const len = buf.readUInt16BE(i + 2);
    if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) {
      return { h: buf.readUInt16BE(i + 5), w: buf.readUInt16BE(i + 7) };
    }
    i += 2 + len;
  }
  return null;
}

function midflowPrintVariant(file) {
  const ext = path.extname(file);
  const sibling = file.slice(0, -ext.length) + "_print" + ext;
  return fs.existsSync(sibling) ? sibling : file;
}

function midflowImageParagraph(midflow, relPath, tag, alt = "") {
  const resolved = path.resolve(midflow.wsRoot, relPath);
  if (!fs.existsSync(resolved)) {
    console.warn(`[${tag}] mid-flow image missing, skipped: ${relPath}`);
    return null;
  }
  const file = midflowPrintVariant(resolved);
  const data = fs.readFileSync(file);
  const ext = path.extname(file).toLowerCase();
  const isJpg = ext === ".jpg" || ext === ".jpeg";
  const dims = isJpg ? jpgDimensions(data) : pngDimensions(data);
  if (!dims || !dims.w || !dims.h) {
    console.warn(`[${tag}] mid-flow image unreadable (${ext}), skipped: ${relPath}`);
    return null;
  }
  const maxH = midflow.maxHIn || MIDFLOW_MAX_H_IN;
  let wIn = midflow.widthIn; // fill the full text-block width (up to the margins); the height clamp below protects tall/portrait figures
  let hIn = wIn * (dims.h / dims.w);
  if (hIn > maxH) { wIn *= maxH / hIn; hIn = maxH; }
  // Opt-in ppi floor, interior.min_image_ppi (e.g. 300, KDP's print target;
  // unset = no floor, the historical sizing): never stretch a raster past its
  // pixels. A 714 px label at the full 4.75 in block printed at 150 ppi; with
  // 300 it prints at 2.38 in. The extent is in 96ths of an inch, so step down
  // until BOTH axes clear the floor after rounding.
  const floor = midflow.minPpi > 0 ? midflow.minPpi : 0;
  let wPx = Math.round(wIn * 96);
  const hOf = (w) => Math.max(1, Math.round(w * (dims.h / dims.w)));
  const ppiOf = (w) => Math.min(dims.w * 96 / w, dims.h * 96 / hOf(w));
  const ppiLimited = floor > 0 && ppiOf(wPx) < floor;
  if (ppiLimited) {
    wPx = Math.max(1, Math.floor(dims.w * 96 / floor));
    while (wPx > 1 && ppiOf(wPx) < floor) wPx--;
  }
  const hPx = hOf(wPx);
  midflow.count++;
  if (ppiLimited) midflow.ppiLimited = (midflow.ppiLimited || 0) + 1;
  console.log(`[${tag}] mid-flow figure embedded: ${path.basename(file)} (${dims.w}x${dims.h} -> ${(wPx / 96).toFixed(2)}x${(hPx / 96).toFixed(2)}in, ${Math.floor(ppiOf(wPx))} ppi${ppiLimited ? `, shrunk to the ${floor} ppi floor` : ""})`);
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    keepNext: true,
    spacing: { before: 240, after: 120 },
    children: [new ImageRun({
      type: isJpg ? "jpg" : "png", data, transformation: { width: wPx, height: hPx },
      altText: { name: path.basename(relPath), title: alt, description: alt },
    })],
  });
}

// ============================================================
// Block-construct detection helpers (shared by the parse loop). Pure + inert on
// prose: a line matches ONLY the constructs the addendum uses. None of these
// fire on the 33 existing units (verified by the regression fixture, which
// carries none of these constructs).
// ============================================================
// A fenced-code delimiter: a line whose first non-space token is ``` (optionally
// followed by an info string / language). Returns true for the open AND close.
const FENCE_RE = /^\s*```/;

// A GFM pipe-table separator row: only pipes, dashes, colons, spaces, with at
// least one dash. "|---|:--:|" yes; "| a | b |" no; "---" (section break) no.
function isTableSeparator(line) {
  const t = line.trim();
  if (!t.includes("-")) return false;
  if (!/^\|?[\s:|-]+\|?$/.test(t)) return false;
  // must contain a pipe OR be a run of dash-only cells — require a pipe so a
  // bare "---" section break is never swallowed as a one-column table rule.
  return t.includes("|") && /-/.test(t);
}
// A candidate table row: a non-separator line containing an unescaped pipe.
function looksLikeTableRow(line) {
  const t = line.trim();
  if (!t.includes("|")) return false;
  if (isTableSeparator(line)) return false;
  return true;
}
// Split a pipe-table row into trimmed cell strings, dropping the optional
// leading/trailing empty cells produced by border pipes. Escaped \| stays literal.
function splitTableRow(line) {
  let t = line.trim();
  const cells = [];
  let buf = "";
  for (let i = 0; i < t.length; i++) {
    const ch = t[i];
    if (ch === "\\" && t[i + 1] === "|") { buf += "|"; i++; continue; }
    if (ch === "|") { cells.push(buf); buf = ""; continue; }
    buf += ch;
  }
  cells.push(buf);
  // Drop a leading empty cell (from a leading "|") and a trailing empty cell
  // (from a trailing "|"); interior empties are meaningful and kept.
  if (cells.length && cells[0].trim() === "") cells.shift();
  if (cells.length && cells[cells.length - 1].trim() === "") cells.pop();
  return cells.map((c) => c.trim());
}
// Parse a separator row into per-column alignment tokens (left|center|right|null).
function parseAligns(sepLine) {
  return splitTableRow(sepLine).map((c) => {
    const s = c.trim();
    const l = s.startsWith(":"), r = s.endsWith(":");
    if (l && r) return "center";
    if (r) return "right";
    if (l) return "left";
    return null;
  });
}
// A list item: leading-space indent + a bullet ("- " or "* ") or an ordered
// marker ("N. " / "N) "). Returns {ordered, depth, marker, text} or null.
// depth is one level per 2 leading spaces (tab counts as 2). "---"/"***" rules
// and "**bold**" starts are NOT list items (guarded by requiring a space after
// a SINGLE marker char).
function parseListItem(rawLine) {
  const m = rawLine.match(/^(\s*)([-*]|\d{1,9}[.)])\s+(.*)$/);
  if (!m) return null;
  const indent = m[1].replace(/\t/g, "  ");
  const token = m[2];
  const text = m[3];
  // A "* *" or "- -" horizontal-rule-ish line is not a list item, and an
  // unordered marker must be a SINGLE char (so "**bold" never matches — it
  // won't anyway, since "**" is two chars and the class is [-*] single).
  const ordered = /\d/.test(token);
  const depth = Math.floor(indent.length / 2);
  return { ordered, depth, marker: token, text };
}

// ============================================================
// Markdown -> docx Paragraphs for ONE unit's body.
// unitLevel is "#" (chapter) or "##" (part) — the heading char sequence that
// opens a unit. When sectionStartUnit is true, the unit's own heading is the
// first item of its section, so its leading PageBreak is suppressed (§4.3).
// [IMAGE ...] blocks are consumed and skipped.
// chapterArtPara, when non-null, is injected once, directly after the unit's
// own heading (chapter-opener illustration).
// midflow, when non-null, is {wsRoot, widthIn, count}: mid-flow "![alt](path)"
// lines embed through it (see the mid-flow figures block above).
// Three block constructs added (fenced code / pipe tables / lists); all inert on
// prose that uses none of them.
// opts (KIT2-PRINT): { splitTitle } sets this unit's heading on two lines at
// ": " (interior.part_title_break, part units only).
// ============================================================
function parseUnitMarkdown(text, unitLevel, F, sectionStartUnit, chapterArtPara, midflow, opts) {
  const lines = text.split("\n");
  const paragraphs = [];
  let inDisplayMath = false;
  let displayMathBuffer = "";
  let firstUnitHeadingSeen = false;
  // true right after a mid-flow figure: the next non-blank line, if it is a
  // body paragraph that reads as a caption (isFigureCaption), is the caption.
  let afterFigure = false;
  // A part page whose body is one label run + one italic line: that line is
  // the label's note (N9). createLabelRun/createLabelNote are absent on a
  // factory set built by an older caller; the historical paths remain.
  const labelNoteUnit = !!F.createLabelNote && isLabelNoteUnit(text);
  const splitTitle = !!(opts && opts.splitTitle);

  // The heading regex for THIS unit level. A "part" build (## ) still must NOT
  // treat a stray "# Title" as a unit heading, and a "chapter" build (# ) must
  // not fire on "## ". We match exactly the configured level.
  const isChapterLevel = unitLevel === "#";

  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    const line = raw.replace(/\s+$/, "");
    const captionSlot = afterFigure && line.trim() !== "";
    if (line.trim() !== "") afterFigure = false;

    // Fenced code block (```): capture every inner line VERBATIM (no inline
    // parse, no smart quotes, no markdown) until the closing fence. Checked
    // FIRST so a "$$" or "# " or "| a |" INSIDE the listing is never
    // interpreted. An unterminated fence (no closing ```) still renders what it
    // captured to EOF rather than silently dropping the tail.
    if (FENCE_RE.test(line)) {
      const codeLines = [];
      let j = i + 1;
      for (; j < lines.length; j++) {
        if (FENCE_RE.test(lines[j].replace(/\s+$/, ""))) break;   // closing fence
        codeLines.push(lines[j].replace(/\s+$/, ""));             // keep indentation, trim trailing ws
      }
      if (j >= lines.length) {
        console.warn(`[generate_book] unterminated code fence opened at line ${i + 1}; rendered to EOF`);
      }
      for (const p of F.createCodeBlock(codeLines)) paragraphs.push(p);
      i = j;   // skip past the closing fence (or to EOF)
      continue;
    }

    // [IMAGE ...] block — consume through its closing "]" and skip.
    if (/^\[IMAGE[:\s\]]/.test(line.trim())) {
      // Consume only a WELL-FORMED image block (closing "]" on this line or
      // within a short window). Anchored: a prose line beginning "[IMAGES ..."
      // is not an image token, and an unclosed [IMAGE must not silently eat
      // the rest of the unit to EOF.
      let j = i;
      let closed = lines[j].trim().endsWith("]");
      while (!closed && j + 1 < lines.length && j - i < 10) {
        j++;
        closed = lines[j].trim().endsWith("]");
      }
      if (closed) { i = j; continue; }
      console.warn(`[generate_book] unclosed [IMAGE block at line ${i + 1} treated as prose`);
    }

    // Mid-flow markdown image line "![alt](path)" — EMBED (2026-07-27; see the
    // mid-flow figures block above). Without workspace context (a caller that
    // predates the midflow arg) the line is skipped with a warning so the
    // literal markdown never renders as body text.
    const mdImg = line.trim().match(MD_IMAGE_RE);
    if (mdImg) {
      const p = midflow ? midflowImageParagraph(midflow, mdImg[2], "generate_book", mdAltText(mdImg[1])) : null;
      if (!midflow) console.warn(`[generate_book] mid-flow image skipped (no workspace context): ${line.trim().slice(0, 80)}`);
      if (p) { paragraphs.push(p); afterFigure = true; }
      continue;
    }

    // Display math block $$...$$
    if (line.trim().startsWith("$$")) {
      if (!inDisplayMath) {
        const remainder = line.trim().replace(/^\$\$/, "");
        if (remainder.endsWith("$$")) {
          paragraphs.push(F.createDisplayMath(remainder.slice(0, -2).trim()));
        } else {
          inDisplayMath = true;
          displayMathBuffer = remainder;
        }
      } else {
        const remainder = line.trim().replace(/\$\$$/, "");
        displayMathBuffer += " " + remainder;
        paragraphs.push(F.createDisplayMath(displayMathBuffer.trim()));
        inDisplayMath = false;
        displayMathBuffer = "";
      }
      continue;
    }
    if (inDisplayMath) { displayMathBuffer += " " + line; continue; }

    if (line.trim() === "") continue;

    const isH1 = line.startsWith("# ") && !line.startsWith("## ");
    const isH2 = line.startsWith("## ") && !line.startsWith("### ");
    // H3 through H6 all render as subsection headings — an unmatched deep
    // heading must never fall through to body text with its hashes visible.
    const isH3plus = /^#{3,6}\s/.test(line);

    // Unit heading at the configured level.
    if ((isChapterLevel && isH1) || (!isChapterLevel && isH2)) {
      const title = line.replace(/^#{1,2}\s+/, "").trim();
      const leadingPageBreak = !(sectionStartUnit && !firstUnitHeadingSeen);
      const isFirstUnitHeading = !firstUnitHeadingSeen;
      paragraphs.push(...F.createUnitHeading(title, leadingPageBreak, splitTitle && isFirstUnitHeading));
      firstUnitHeadingSeen = true;
      if (isFirstUnitHeading && chapterArtPara) paragraphs.push(chapterArtPara);
      continue;
    }
    // A heading at a HIGHER level than the unit (e.g. a stray book-title "# " in
    // a part-based build, or the book title above chapter 1) is skipped as a
    // structural token that front matter already renders.
    if (isChapterLevel && isH2) continue;
    if (!isChapterLevel && isH1) continue;
    // Sub-subsection headings become styled bold left headings.
    if (isH3plus) { paragraphs.push(F.createSubsectionHeading(line.replace(/^#{1,6}\s+/, "").trim())); continue; }

    if (line.trim() === "---") { paragraphs.push(F.createSectionBreak()); continue; }
    // Quote block (S2): a run of quote lines, blank lines or a bare ">" between
    // them allowed, is ONE label block (a multi-line label is written one quote
    // line per label line); a bare ">" never prints. On a part page whose body
    // is just the label and one italic line, that line is the label's note.
    if (F.createLabelRun && isQuoteLine(line)) {
      const qTexts = [];
      let lastQ = i;
      for (let j = i; j < lines.length; j++) {
        const ql = lines[j].replace(/\s+$/, "");
        if (ql.trim() === "") continue;
        if (!isQuoteLine(ql)) break;
        lastQ = j;
        if (ql.trim() !== ">") qTexts.push(ql.trim().slice(2));
      }
      let noteIdx = -1;
      if (labelNoteUnit) {
        let k = lastQ + 1;
        while (k < lines.length && lines[k].trim() === "") k++;
        if (k < lines.length && isItalicLine(lines[k])) noteIdx = k;
      }
      paragraphs.push(...F.createLabelRun(qTexts, noteIdx >= 0));
      if (noteIdx >= 0) { paragraphs.push(F.createLabelNote(lines[noteIdx].trim())); lastQ = noteIdx; }
      i = lastQ;
      continue;
    }
    if (line.trim().startsWith("> ")) { paragraphs.push(F.createBlockquote(line.trim().slice(2))); continue; }

    // GFM pipe table: a header row IMMEDIATELY followed by a separator row
    // ("|---|:--:|"). Requiring the separator is what keeps a lone prose line
    // containing a stray "|" from becoming a one-row table. Consume the header,
    // the separator, and every consecutive body row.
    if (looksLikeTableRow(line) && (i + 1) < lines.length && isTableSeparator(lines[i + 1])) {
      const header = splitTableRow(line);
      const aligns = parseAligns(lines[i + 1]);
      const rows = [header];
      let j = i + 2;
      for (; j < lines.length; j++) {
        const bl = lines[j].replace(/\s+$/, "");
        if (bl.trim() === "" || !looksLikeTableRow(bl)) break;
        rows.push(splitTableRow(bl));
      }
      paragraphs.push(F.createTable(rows, aligns));
      i = j - 1;
      continue;
    }

    // Lists: consume a run of consecutive bullet / ordered items. Ordered items
    // are numbered by their position within a same-depth sibling group (the
    // source number is ignored so "1. 1. 1." still renders 1. 2. 3.). Detect on
    // the trailing-whitespace-stripped line so a CRLF master's "\r" never blocks
    // the match (the "$" anchor won't span a bare "\r").
    const li0 = parseListItem(line);
    if (li0) {
      let j = i;
      const counters = {};   // depth -> next ordinal
      let prevDepth = -1;
      for (; j < lines.length; j++) {
        const li = parseListItem(lines[j].replace(/\s+$/, ""));
        if (!li) break;
        // Reset deeper counters when the list dedents (a new sublist restarts).
        if (li.depth > prevDepth) counters[li.depth] = 1;
        for (const d of Object.keys(counters)) if (Number(d) > li.depth) delete counters[d];
        let marker;
        if (li.ordered) {
          const n = counters[li.depth] || 1;
          counters[li.depth] = n + 1;
          marker = `${n}.  `;
        } else {
          marker = "•  ";   // "• " bullet + spaces (U+2022, not a dash)
        }
        paragraphs.push(F.createListItem(marker, li.text, li.depth));
        prevDepth = li.depth;
      }
      i = j - 1;
      continue;
    }

    // The image paragraph carries keepNext; keepLines on its caption completes
    // the bind, so figure and whole caption always share a page.
    paragraphs.push(F.createBodyParagraph(line, captionSlot && isFigureCaption(line) ? { caption: true } : undefined));
  }
  return paragraphs;
}

// ============================================================
// Split the version-pinned master into ordered unit bodies.
// The master is "front matter + every unit in order". We split on the unit-level
// heading. Everything BEFORE the first unit heading is front-matter markdown we
// ignore here (front matter is rendered from config, §3.6), so the body starts
// at the first unit heading.
// ============================================================
function splitUnits(masterMd, unitLevel) {
  const lines = masterMd.split("\n");
  const isChapterLevel = unitLevel === "#";
  const headingRe = isChapterLevel
    ? /^#\s+(?!#)/    // "# " but not "## "
    : /^##\s+(?!#)/;  // "## " but not "### "

  // Fence-aware: a "# comment" INSIDE a ```code``` block (a Python/YAML/shell
  // comment) is NOT a unit boundary. Skipping fenced spans keeps a code listing
  // from being split into spurious "units" whose comment line renders as a
  // chapter heading on its own page (2026-07-15 fix).
  const unitStartIdxs = [];
  let inCode = false;
  for (let i = 0; i < lines.length; i++) {
    if (FENCE_RE.test(lines[i])) { inCode = !inCode; continue; }
    if (!inCode && headingRe.test(lines[i])) unitStartIdxs.push(i);
  }
  if (unitStartIdxs.length === 0) {
    // No unit headings found — treat the whole master (minus front matter) as
    // one unit. This keeps the generator from silently producing an empty book.
    return [masterMd];
  }
  const units = [];
  for (let u = 0; u < unitStartIdxs.length; u++) {
    const start = unitStartIdxs[u];
    const end = (u + 1 < unitStartIdxs.length) ? unitStartIdxs[u + 1] : lines.length;
    units.push(lines.slice(start, end).join("\n"));
  }
  return units;
}

// ============================================================
// FRONT MATTER — one section per front_matter[] entry (§3.6). Content is derived
// from config (title/subtitle/author + fiction disclaimer). Each section carries
// empty headers/footers; vAlign is injected post-Packer by section index.
// ============================================================
function buildFrontMatterSections(config, T, PAGE_COMMON, emptyHeadersFooters, buildInlineRuns, cjkRuns, L) {
  const mkRuns = cjkRuns || ((o) => [new TextRun(o)]);
  const fm = Array.isArray(config.front_matter) ? config.front_matter : [];
  const title = str(config.title, "");
  const subtitle = str(config.subtitle, "");
  const author = str(config.author, "");
  const isFiction = config.is_fiction === true;
  // Front matter is display text: never hyphenated (interior.hyphenate).
  const noHyph = (p) => (L && L.hyphenate ? suppressAutoHyphens(p) : p);
  // title_lines (S6): the title set on the given lines (a line break between
  // them), in capitals as before; the metadata title is untouched.
  const titleLines = resolveTitleLines(config);
  function titleRuns(opts) {
    if (!titleLines) return mkRuns({ ...opts, text: title.toUpperCase() });
    const runs = [];
    titleLines.forEach((line, k) => {
      if (k > 0) runs.push(new TextRun({ ...opts, break: 1 }));
      runs.push(...mkRuns({ ...opts, text: line.toUpperCase() }));
    });
    return runs;
  }

  const sections = [];

  // Half-title: title only, large, centered.
  function halfTitleChildren() {
    return [noHyph(new Paragraph({
      alignment: AlignmentType.CENTER,
      children: titleRuns({ font: T.FONT, size: 44, color: T.BODY_COLOR, characterSpacing: 60 }),
    }))];
  }

  // Full title page: title / ornament / subtitle / author.
  function titleChildren() {
    const kids = [];
    kids.push(noHyph(new Paragraph({
      spacing: { after: 80 }, alignment: AlignmentType.CENTER,
      children: titleRuns({ font: T.FONT, size: 40, color: T.BODY_COLOR, characterSpacing: 40 }),
    })));
    kids.push(new Paragraph({
      spacing: { before: 300, after: 200 }, alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: T.ORNAMENT, font: T.ORNAMENT_FONT, size: 22, color: "999999" })],
    }));
    if (subtitle) {
      kids.push(noHyph(new Paragraph({
        spacing: { before: 60, after: 240 }, alignment: AlignmentType.CENTER,
        children: mkRuns({ text: subtitle, font: T.FONT, size: 22, color: T.BODY_COLOR, italics: true }),
      })));
    }
    kids.push(noHyph(new Paragraph({
      spacing: { before: 600, after: 60 }, alignment: AlignmentType.CENTER,
      children: mkRuns({ text: author.toUpperCase(), font: T.FONT, size: 22, color: T.BODY_COLOR, characterSpacing: 60 }),
    })));
    return kids;
  }

  // Copyright page. Fiction gets the "work of fiction / historical persons"
  // disclaimer (ledger §9.4). vAlign bottom anchors it (§3.6).
  function copyrightChildren() {
    const lines = [];
    if (isFiction) {
      lines.push("This is a work of fiction. Names, characters, places, and incidents");
      lines.push("are the product of the author’s imagination or are used fictitiously.");
      lines.push("Historical persons appear as characters in a fictional narrative.");
      lines.push("Any resemblance to actual events or persons, living or dead, is coincidental.");
      lines.push("");
    }
    lines.push(str((config.strings || {}).copyright_line, `© 2026 ${author}. All rights reserved.`));
    lines.push("");
    lines.push(str((config.strings || {}).first_edition_line, "First edition"));
    lines.push("");
    lines.push(str((config.strings || {}).set_in_line, `Set in ${T.FONT_NAME}.`));
    const kids = [];
    for (const cl of lines) {
      if (cl === "") { kids.push(new Paragraph({ spacing: { before: 120 } })); continue; }
      kids.push(noHyph(new Paragraph({
        spacing: { after: 40 }, alignment: AlignmentType.CENTER,
        children: mkRuns({ text: cl, font: T.FONT, size: 16, color: "555555" }),
      })));
    }
    return kids;
  }

  // Dedication / epigraph / readers_note — sourced from config optional fields
  // when present, otherwise a minimal placeholder is emitted so the page exists
  // and paginates. (These free-text fields are not in the required schema, so we
  // read them defensively.) Their text goes through the body's buildInlineRuns
  // (2026-09-24): *Title* renders italic and an asterisk can never print
  // literally; plain text builds exactly the run it always did.
  const inlineRuns = buildInlineRuns || ((t, o) => mkRuns({ ...o, text: t }));
  function dedicationChildren() {
    const ded = str(config.dedication, "");
    if (!ded) return [new Paragraph({})];
    return ded.split("\n").map((l) => noHyph(new Paragraph({
      spacing: { after: 120 }, alignment: AlignmentType.CENTER,
      children: inlineRuns(l, { font: T.FONT, size: T.BODY_SIZE, color: T.BODY_COLOR, italics: true }),
    })));
  }

  function epigraphChildren() {
    const epi = config.epigraph;
    if (!epi) return [new Paragraph({})];
    // Accept either a string or { text, attribution }.
    const text = typeof epi === "string" ? epi : str(epi.text, "");
    const attribution = typeof epi === "string" ? "" : str(epi.attribution, "");
    const kids = text.split("\n").map((l) => noHyph(new Paragraph({
      spacing: { after: 60 }, alignment: AlignmentType.CENTER,
      children: inlineRuns(l, { font: T.FONT, size: 28, color: "222222", italics: true }),
    })));
    if (attribution) {
      // the em-dash prefix is a rendered character the source lint can never
      // see; under the (default-on) no-em-dashes voice rule it must not ship
      const attrPrefix = (config.voice && config.voice.no_em_dashes === false) ? "— " : "";
      kids.push(noHyph(new Paragraph({
        spacing: { before: 120, after: 200 }, alignment: AlignmentType.CENTER,
        children: inlineRuns(`${attrPrefix}${attribution}`, { font: T.FONT, size: 22, color: "555555", italics: true }),
      })));
    }
    return kids;
  }

  function readersNoteChildren() {
    const note = str(config.readers_note, "");
    const kids = [noHyph(new Paragraph({
      spacing: { before: 1200, after: 400 }, alignment: AlignmentType.CENTER,
      children: mkRuns({ text: str((config.strings || {}).readers_note_heading, "A NOTE TO THE READER"), font: T.FONT, size: 20, color: T.BODY_COLOR, characterSpacing: 40 }),
    }))];
    if (note) {
      for (const para of note.split("\n\n")) {
        kids.push(new Paragraph({
          spacing: { after: 160, line: T.BODY_LINE, lineRule: "atLeast" },
          indent: { firstLine: T.FIRST_INDENT },
          children: inlineRuns(para, { font: T.FONT, size: T.BODY_SIZE, color: T.BODY_COLOR }),
        }));
      }
    }
    return kids;
  }

  function blankChildren() {
    // TRULY empty — a "blank" page carrying even an invisible space run is the
    // pattern that drew a KDP "text outside margins" rejection (§3.5/§4).
    return [new Paragraph({})];
  }

  const CONTENT_BY_TYPE = {
    half_title: halfTitleChildren,
    title: titleChildren,
    copyright: copyrightChildren,
    dedication: dedicationChildren,
    epigraph: epigraphChildren,
    readers_note: readersNoteChildren,
    blank: blankChildren,
    // "contents" is handled by the dedicated TOC section built in the caller,
    // not here; if it appears in front_matter we emit a blank placeholder so the
    // section indexing for vAlign stays aligned 1:1 with front_matter[].
    contents: blankChildren,
  };

  fm.forEach((entry, idx) => {
    const type = entry && entry.type ? entry.type : "blank";
    const childrenFactory = CONTENT_BY_TYPE[type] || blankChildren;
    // First front-matter section has no NEXT_PAGE type (document starts here);
    // subsequent front-matter pages use NEXT_PAGE so each is its own page.
    const properties = idx === 0
      ? { page: { ...PAGE_COMMON, margin: { ...PAGE_COMMON.margin, footer: 0 } } }
      : { type: SectionType.NEXT_PAGE, page: { ...PAGE_COMMON, margin: { ...PAGE_COMMON.margin, footer: 0 } } };
    sections.push({
      properties,
      ...emptyHeadersFooters(),
      children: childrenFactory(),
    });
  });

  return sections;
}

// ============================================================
// MAIN
// ============================================================
async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    console.log(USAGE);
    return;
  }
  if (!args.format || !VALID_FORMATS.includes(args.format)) {
    console.error(`error: --format is required and must be one of: ${VALID_FORMATS.join(" | ")}`);
    console.error(`Run "node generate_book.js --help" for usage.`);
    process.exit(2);
  }
  const config = loadConfig(args.config);

  // The workspace root is the CONFIG's directory — the same convention the
  // engine and compositor use. The old kit-root/book_workspace/<slug> form
  // silently wrote into a DIFFERENT book's tree whenever the workspace dirname
  // and the slug diverged (e.g. a scratch copy carrying the original slug).
  const wsRoot = path.dirname(path.resolve(args.config));
  if (path.basename(wsRoot) !== config.slug) {
    console.warn(`[generate_book] NOTE: workspace dirname '${path.basename(wsRoot)}' != slug '${config.slug}'; using the config's parent as the workspace root`);
  }

  // The master is read first: whether the book carries East Asian text decides
  // how every run is built (resolveEastAsianContext).
  const srcPath = resolveSrc(config, args.src, wsRoot);
  const masterMd = fs.readFileSync(srcPath, "utf8");
  const ea = resolveEastAsianContext(config, masterMd);
  const cjkRuns = makeCjkRunFactory(ea);

  const T = resolveTypography(config);
  const buildInlineRuns = makeInlineBuilder(T, config.is_fiction === false, cjkRuns);

  // Page geometry from config.trim (default 6x9). Blurb page PDF = trim +
  // 0.125" W (outer-edge bleed only) + 0.25" H (0.125 top + 0.125 bottom) —
  // print_presets blurb_trade.page_bleed_model. All other formats: trim-size
  // pages. resolveMargins() compensates so the Blurb text block is identical.
  const trim = config.trim || { w: 6, h: 9 };
  const blurb = isBlurb(args.format);
  const pageWIn = num(trim.w, 6) + (blurb ? 0.125 : 0);
  const pageHIn = num(trim.h, 9) + (blurb ? 0.25 : 0);
  const PAGE_W = inToDxa(pageWIn);   // blurb 6x9 -> 6.125 * 1440 = 8820 DXA
  const PAGE_H = inToDxa(pageHIn);   // blurb 6x9 -> 9.25  * 1440 = 13320 DXA
  const margins = resolveMargins(config.interior || {}, args.format);

  // Footer distance 0.375 in from the TRIM edge (was 360 twips = 0.25 in, which
  // put the folio glyph box 0.24 in from the trim, inside KDP's 0.25 in band:
  // kdp_precheck live_area_kdp_band on every body page). The bottom margin still
  // sets the text block, which is unchanged. Blurb pages carry 0.125 in of
  // bottom bleed, so the same trim distance is 180 twips further from the edge.
  // Capped at bottom margin - 0.25 in (room for the folio line) so a config with
  // a tighter bottom margin never has its text block pushed up; never below the
  // historical 0.25 in. Every current profile gets the full 0.375 in.
  const footerIn = Math.max(0.25, Math.min(0.375 + (blurb ? 0.125 : 0), margins.bottom / 1440 - 0.25));
  const FOOTER_DXA = inToDxa(footerIn);
  // Header distance 0.3 in from the TRIM edge (N4, 2026-09-24; was 0). The
  // header is always empty, but Word still draws its paragraph mark, which sat
  // on the trim (y 0 to 13.7 pt on every recto and the front matter). Capped so
  // the empty header line (about 1.15 x the body size) ends above the top
  // margin and the text block never moves; Blurb adds its 0.125 in top bleed.
  const headerIn = Math.max(0, Math.min(0.3 + (blurb ? 0.125 : 0),
    margins.top / 1440 - 1.15 * (T.BODY_SIZE / 2) / 72));
  const HEADER_DXA = inToDxa(headerIn);
  const PAGE_COMMON = {
    size: { width: PAGE_W, height: PAGE_H },
    margin: {
      top: margins.top, bottom: margins.bottom,
      left: margins.gutter, right: margins.outside,
      header: HEADER_DXA, footer: FOOTER_DXA, gutter: 0,
    },
    mirror: true,
  };

  // Layout policy for this build (KIT2-PRINT): the text-block width sets the
  // label measure (quote indents 720 + 360).
  const interior = config.interior || {};
  const hyphenation = resolveHyphenation(interior);
  const L = {
    hyphenate: !!hyphenation,
    caption: resolveCaptionStyle(interior, T.BODY_SIZE / 2, T.BODY_LINE),
    labelMeasure: PAGE_W - margins.gutter - margins.outside - 720 - 360,
    // Opt-in (absent = 0, no keep flags): keeping a label whole trades a split
    // label for white space at the foot of the page it leaves, a per-book call
    // (a_human_still_signs' checklist cards would gain 6-9 line gaps).
    labelKeepMaxLines: Number.isInteger(interior.label_keep_max_lines) && interior.label_keep_max_lines >= 0
      ? interior.label_keep_max_lines : 0,
    labelCjkNobreakMax: Number.isInteger(interior.label_cjk_nobreak_max) ? interior.label_cjk_nobreak_max : 0,
  };
  const F = makeFactories(T, buildInlineRuns, cjkRuns, L);
  const noHyph = (p) => (L.hyphenate ? suppressAutoHyphens(p) : p);

  // ---- Header/footer factories ----
  // Page-number footers. House style (LESSONS_LEDGER §16.2): CENTERED at the
  // bottom of EVERY page, recto and verso alike — NOT the outer corner. The
  // legacy outer-corner style (recto RIGHT / verso LEFT) is still selectable via
  // interior.page_number_align='outer' (schema default 'center'); it relies on
  // the evenAndOddHeaders split that inject_mirror_margins.js injects so the
  // default (recto) and even (verso) footers render on the correct sides.
  const pnAlign = (config.interior && config.interior.page_number_align) === "outer" ? "outer" : "center";
  function pageNumberFooters() {
    const mk = (align) => new Footer({
      children: [new Paragraph({
        alignment: align,
        children: [new TextRun({ children: [PageNumber.CURRENT], font: T.FONT, size: 18, color: "888888" })],
      })],
    });
    if (pnAlign === "outer") {
      // Outer corner: recto (default) = RIGHT, verso (even) = LEFT.
      return { footers: { default: mk(AlignmentType.RIGHT), even: mk(AlignmentType.LEFT) } };
    }
    // Centered on both recto and verso (house default).
    return { footers: { default: mk(AlignmentType.CENTER), even: mk(AlignmentType.CENTER) } };
  }

  // §3.5: EVERY header-free section needs EXPLICIT empty Header AND Footer.
  // margin.header/footer=0 is the WRONG fix — inherited content still renders.
  function emptyHeadersFooters() {
    return {
      headers: { default: new Header({ children: [new Paragraph({})] }) },
      footers: {
        default: new Footer({ children: [new Paragraph({})] }),
        even: new Footer({ children: [new Paragraph({})] }),
      },
    };
  }

  // ---- Split the manuscript (read above) ----
  const unitNoun = (config.voice && config.voice.unit_noun) ? config.voice.unit_noun : "chapter";
  const unitLevel = unitNoun === "part" ? "##" : "#";
  const unitBodies = splitUnits(masterMd, unitLevel);
  // Chapter-opener art: unit ids bind to unit bodies BY POSITION (same rule
  // the EPUB builder enforces); a missing image file skips silently.
  const chapterArt = resolveChapterArt(config, wsRoot);
  const unitIdsForArt = (config.units || []).map((u) => (u && u.id) || "");
  const artParas = unitBodies.map((_, i) => chapterArtParagraph(chapterArt, unitIdsForArt[i], "generate_book"));
  const artCount = artParas.filter(Boolean).length;
  if (chapterArt && artCount > 0) {
    console.log(`[generate_book] chapter art: ${artCount} image(s) staged from ${chapterArt.dir}`);
  }
  // Mid-flow figure context: text-block width derived from the resolved
  // margins (universal across profiles — Blurb's page growth is margin-
  // compensated, so PAGE_W - gutter - outside is the same block everywhere).
  const figMaxH = num((config.interior || {}).figure_max_h_in, MIDFLOW_MAX_H_IN);
  const minPpi = num((config.interior || {}).min_image_ppi, 0);   // absent / null = no floor
  const midflowCtx = {
    wsRoot, widthIn: (PAGE_W - margins.gutter - margins.outside) / 1440, count: 0,
    maxHIn: figMaxH > 0 ? figMaxH : MIDFLOW_MAX_H_IN,
    minPpi: minPpi > 0 ? minPpi : 0,
  };
  // interior.part_title_break (S7): part units (config ids "part...", bound by
  // position like the chapter art; every unit when the unit noun is "part").
  const partTitleBreak = interior.part_title_break === true;
  const isPartUnit = (i) => unitNoun === "part" || /^part/i.test(unitIdsForArt[i] || "");
  const unitContents = unitBodies.map((md, i) => parseUnitMarkdown(md, unitLevel, F, /*sectionStartUnit=*/true,
    artParas[i], midflowCtx, { splitTitle: partTitleBreak && isPartUnit(i) }));

  // ---- Front matter sections (one per front_matter[] entry) ----
  const frontSections = buildFrontMatterSections(config, T, PAGE_COMMON, emptyHeadersFooters, buildInlineRuns, cjkRuns, L);

  // ---- TOC section (recto, no page numbers). Rendered once, after front
  // matter, regardless of whether a "contents" entry appears in front_matter[]
  // (that entry, if present, is a placeholder page for index alignment). ----
  const tocChildren = [
    noHyph(new Paragraph({
      spacing: { before: 1800, after: 600 }, alignment: AlignmentType.CENTER,
      children: cjkRuns({ text: str((config.strings || {}).contents_heading, "CONTENTS"), font: T.FONT, size: 22, color: T.BODY_COLOR, characterSpacing: 60 }),
    })),
    new TableOfContents(str((config.strings || {}).toc_title, "Table of Contents"), {
      hyperlink: true,
      headingStyleRange: "1-1",
      stylesWithLevels: [new StyleLevel("Heading1", 1)],
    }),
  ];

  const recto = (config.recto_strategy || "odd_page_sections");

  // Gate the whole CONTENTS/TOC section behind interior.include_toc (schema
  // default TRUE — omit only when a book deliberately ships without a printed
  // Contents). §16.3. When present, its entries are the title-case Heading-1
  // texts (see unitHeadingText) rendered by Word's auto-TOC dot-leader style.
  const includeToc = !(config.interior && config.interior.include_toc === false);

  // ---- Assemble sections ----
  const sections = [];
  // Front matter first (each its own one-page section).
  for (const s of frontSections) sections.push(s);

  // TOC on recto, empty headers/footers.
  if (includeToc) {
    sections.push({
      properties: {
        type: recto === "odd_page_sections" ? SectionType.ODD_PAGE : SectionType.NEXT_PAGE,
        page: { ...PAGE_COMMON, margin: { ...PAGE_COMMON.margin, footer: 0 } },
      },
      ...emptyHeadersFooters(),
      children: tocChildren,
    });
  }

  // First body unit — ODD_PAGE, page numbers start at 1.
  sections.push({
    properties: {
      type: recto === "odd_page_sections" ? SectionType.ODD_PAGE : SectionType.NEXT_PAGE,
      page: { ...PAGE_COMMON, pageNumbers: { start: 1 } },
    },
    ...pageNumberFooters(),
    children: unitContents[0] || [new Paragraph({})],
  });

  // Remaining units — ODD_PAGE, page numbers continue.
  for (let u = 1; u < unitContents.length; u++) {
    sections.push({
      properties: {
        type: recto === "odd_page_sections" ? SectionType.ODD_PAGE : SectionType.NEXT_PAGE,
        page: { ...PAGE_COMMON },
      },
      ...pageNumberFooters(),
      children: unitContents[u],
    });
  }

  // ABOUT THE AUTHOR back matter, from config.about_the_author. generate_kindle.js
  // and build_epub.py have always emitted this; the PRINT interior did not, so a
  // print/digital edition ended on the last line of the last chapter with no
  // author note at all. Its own recto section, page numbers continuing, so it
  // reads as real back matter rather than a tacked-on paragraph.
  // 2026-09-24: its paragraphs are built like body text: inline markup parsed
  // by buildInlineRuns (a *Title* printed as literal asterisks before) and
  // justified (it was the one ragged-right prose paragraph in the book).
  const aboutAuthor = typeof config.about_the_author === "string"
    ? config.about_the_author.trim() : "";
  if (aboutAuthor) {
    // Never hyphenated (interior.hyphenate): the author's own note.
    const aboutKids = [
      noHyph(new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 480, after: 360 },
        children: cjkRuns({
          text: str((config.strings || {}).about_author_heading, "ABOUT THE AUTHOR"), font: T.FONT, size: 22,
          color: T.BODY_COLOR, characterSpacing: 60,
        }),
      })),
    ];
    for (const para of aboutAuthor.split(/\n\s*\n/).map(s => s.trim()).filter(Boolean)) {
      aboutKids.push(noHyph(new Paragraph({
        spacing: { line: T.BODY_LINE, lineRule: "atLeast", after: 160 },
        alignment: AlignmentType.JUSTIFIED,
        children: buildInlineRuns(para, { font: T.FONT, size: T.BODY_SIZE, color: T.BODY_COLOR }),
      })));
    }
    sections.push({
      properties: {
        type: recto === "odd_page_sections" ? SectionType.ODD_PAGE : SectionType.NEXT_PAGE,
        page: { ...PAGE_COMMON },
      },
      ...pageNumberFooters(),
      children: aboutKids,
    });
  }

  // Trailing EVEN_PAGE blank — guarantees an even total page count (KDP ×2).
  // Truly-empty paragraph + explicit empty footers so KDP sees a blank page and
  // does NOT flag an inherited page number as "text outside margins" (§3.5).
  sections.push({
    properties: {
      type: SectionType.EVEN_PAGE,
      page: { ...PAGE_COMMON, margin: { ...PAGE_COMMON.margin, footer: 0 } },
    },
    ...emptyHeadersFooters(),
    children: [new Paragraph({})],
  });

  // ---- Build the document ----
  // CJK editions: tag the default run language East-Asian so Word's kinsoku
  // line-breaking engages (without it a line can START with 。，” — seen on the
  // first carlquist_zh render, 2026-08-12). No-op for non-zh configs.
  // w:val is the LATIN language, NOT the East-Asian one (2026-08-14: tagging it zh-CN
  // made Word classify ASCII as East Asian and render every Latin word from the eastAsia
  // font, silently voiding interior.body_font_latin — caught by reading a rendered page's
  // font names, invisible to every XML-level gate). eastAsia drives kinsoku; leave it zh-CN.
  // (zh books are unchanged; a ja/ko book gets its own East Asian default.)
  // 2026-09-24: a LATIN book that carries CJK text gets w:eastAsia only (its Latin
  // language untouched) as the document default, so kinsoku also holds across a
  // run boundary (an upright CJK run followed by an italic "; [Li ...]" run), plus
  // overflowPunct=0 (patchPackedDocx). Measured on across_borders: 13 bad line
  // starts -> 0, and only the 12 pages that held them reflow.
  const eaLang = ea.cjkBook ? { value: "en-US", eastAsia: ea.defaultEA } : undefined;
  const docLang = eaLang || (ea.latinWithCjk ? { eastAsia: ea.defaultEA } : undefined);
  // DOCX core properties: Word shows them (File > Info) and carries them into
  // the PDF it renders (Title / Author), which read "Un-named" and blank before.
  const coreProps = {};
  if (str(config.title, "")) coreProps.title = config.title;
  if (str(config.subtitle, "")) coreProps.subject = config.subtitle;
  if (str(config.author, "")) { coreProps.creator = config.author; coreProps.lastModifiedBy = config.author; }
  // Contents styles: Word builds TOC entries in the "toc N" styles. Undeclared,
  // Word instantiates its built-in ones, whose tab and paragraph-mark runs fell
  // back to the theme font (Aptos, embedded in the print PDF), and a wrapped
  // entry's turnover line sat flush left like a new entry. Declared here: the
  // book font, the built-in 5 pt space after, and a 0.25 in hanging turnover.
  // Right indent 0.4 in (S7, 2026-09-24): an entry's text wraps before the
  // page-number column. Word sets each entry's own right tab at the text-block
  // edge whatever the indent, so the numbers stay at the margin; without it a
  // long entry ("Part III: The All Asia Initiative and Archival Forensics")
  // filled the line and its leader and number dropped to a line of dots.
  const TOC_RIGHT_INDENT = 576;
  const tocStyle = (level) => ({
    id: `TOC${level}`, name: `toc ${level}`, basedOn: "Normal", next: "Normal",
    uiPriority: 39, unhideWhenUsed: true,
    run: { font: T.FONT },
    paragraph: { spacing: { after: 100 }, indent: { left: 360 * level, hanging: 360, right: TOC_RIGHT_INDENT } },
  });
  const doc = new Document({
    ...coreProps,
    features: { updateFields: true },
    styles: {
      default: {
        document: { run: { font: T.FONT, size: T.BODY_SIZE, color: T.BODY_COLOR, ...(docLang ? { language: docLang } : {}) } },
        heading1: {
          run: { font: T.FONT, size: 28, color: T.BODY_COLOR, ...(eaLang ? { language: eaLang } : {}) },
          paragraph: { alignment: AlignmentType.CENTER },
        },
      },
      paragraphStyles: [tocStyle(1), tocStyle(2)],
    },
    sections,
  });

  // ---- Write ----
  const outPath = resolveOutPath(config, args.format, args.out, wsRoot);
  const outDir = path.dirname(outPath);
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  const buf = await patchPackedDocx(await Packer.toBuffer(doc), {
    overflowPunctOff: ea.latinWithCjk, latinCjkSpacing: ea.latinWithCjk, hyphenation,
  });
  fs.writeFileSync(outPath, buf);

  // ---- Inline post-Packer injection: mirror margins + evenAndOddHeaders, then
  // front-matter vAlign (config-driven). (§3.4 / §3.6) ----
  if (args.inject) {
    await injectMirrorMargins(outPath);
    await injectValign(outPath, valignMapFromConfig(config));
  }

  // ---- Self-report banner ----
  const pageMultiple = PAGE_MULTIPLE[args.format] || 2;
  console.log(`\n=== BOOKSMITH print interior: ${args.format} ===`);
  console.log(`Source markdown : ${srcPath}`);
  console.log(`Output          : ${outPath}`);
  console.log(`Size            : ${(buf.length / 1024).toFixed(1)} KB`);
  console.log(`Trim            : ${num(trim.w, 6)}" x ${num(trim.h, 9)}"`);
  console.log(`Page            : ${pageWIn}" x ${pageHIn}" (${PAGE_W} x ${PAGE_H} DXA)` +
              (blurb ? "  [Blurb bleed model: +0.125 W outer edge, +0.25 H]" : ""));
  console.log(`Margins (DXA)   : top=${margins.top} bottom=${margins.bottom} gutter=${margins.gutter} outside=${margins.outside}`);
  console.log(`Margins (in)    : top=${(margins.top/1440).toFixed(3)} bottom=${(margins.bottom/1440).toFixed(3)} gutter=${(margins.gutter/1440).toFixed(3)} outside=${(margins.outside/1440).toFixed(3)}`);
  console.log(`Body            : ${T.BODY_SIZE/2}pt ${T.FONT_NAME}, leading ${T.BODY_LINE}, indent ${T.FIRST_INDENT} DXA, space after ${T.BODY_AFTER / 20}pt, color #${T.BODY_COLOR}`);
  console.log(`Folio footer    : ${FOOTER_DXA} DXA from the page edge (${(FOOTER_DXA / 1440).toFixed(3)} in)`);
  console.log(`Header distance : ${HEADER_DXA} DXA from the page edge (${(HEADER_DXA / 1440).toFixed(3)} in)`);
  console.log(`Hyphenation     : ` + (hyphenation
    ? `on (zone ${(hyphenation.zone / 1440).toFixed(2)} in, at most ${hyphenation.limit || "unlimited"} in a row, ` +
      `capitals ${hyphenation.caps ? "hyphenated" : "not hyphenated"}; headings, captions, labels, front matter, About exempt)`
    : "off (interior.hyphenate unset)"));
  console.log(`Captions        : ` + (L.caption
    ? `${L.caption.size / 2}pt, ${{ center: "centered", left: "left", both: "justified" }[L.caption.align] || L.caption.align}, no indent, ${L.caption.after / 20}pt after`
    : "body style (interior.caption unset)"));
  console.log(`Labels          : ` + (L.labelKeepMaxLines
    ? `quote runs kept on one page up to ${L.labelKeepMaxLines} lines (longer runs keep their ends)`
    : "no keep flags (interior.label_keep_max_lines unset)") +
    (L.labelCjkNobreakMax ? `; CJK words of ${L.labelCjkNobreakMax} characters or fewer never split` : ""));
  console.log(`Title lines     : ${resolveTitleLines(config) ? JSON.stringify(resolveTitleLines(config)) : "one run (title_lines unset)"}` +
    `  |  part openers: ${partTitleBreak ? "two lines at \": \"" : "one heading line"}`);
  console.log(`East Asian text : ` + (!ea.hasCjk ? "none"
    : ea.cjkBook ? `CJK-language book (default ${ea.defaultEA}); italic CJK set upright`
    : `embedded CJK: runs tagged w:eastAsia (${ea.defaultEA}; ja-JP kana, ko-KR hangul), upright in italic contexts, kinsoku on, hanging punctuation off`));
  console.log(`Unit noun       : ${unitNoun} (level "${unitLevel}")  |  units: ${unitContents.length}`);
  console.log(`Front-matter    : ${frontSections.length} section(s)  |  recto: ${recto}`);
  console.log(`Contents/TOC    : ${includeToc ? "included — title-case auto-TOC w/ dot leader (§16.3)" : "OMITTED (interior.include_toc=false)"}`);
  console.log(`Page numbers    : ${pnAlign === "outer" ? "OUTER (recto-right / verso-left)" : "centered (house style §16.2)"}`);
  console.log(`Sections total  : ${sections.length}`);
  console.log(`Mid-flow figures: ${midflowCtx.count} embedded` + (midflowCtx.count
    ? ` (grayscale _print siblings preferred; block-width / ${midflowCtx.maxHIn}in height caps; ` +
      (midflowCtx.minPpi
        ? `${midflowCtx.minPpi} ppi floor` + (midflowCtx.ppiLimited ? `: ${midflowCtx.ppiLimited} shrunk to reach it)` : ")")
        : "no ppi floor: interior.min_image_ppi unset)")
    : ""));
  console.log(`Page multiple   : must be x${pageMultiple}` + (pageMultiple === 4 ? " (pad in Python via fitz AFTER PDF conversion)" : " (trailing EVEN_PAGE handles it)"));
  console.log(`Mirror inject   : ${args.inject ? "done (mirrorMargins + evenAndOddHeaders + front-matter vAlign)" : "SKIPPED (--no-inject)"}`);
}

if (require.main === module) {
  main().catch((e) => {
    // Quiet, structured message for expected errors (missing --config, no
    // markdown source, bad format). Set BOOKSMITH_DEBUG=1 for the full stack.
    console.error(`error: ${e && e.message ? e.message : e}`);
    if (process.env.BOOKSMITH_DEBUG && e && e.stack) console.error(e.stack);
    process.exit(1);
  });
}

module.exports = {
  main, splitUnits, resolveMargins, resolveTypography, USAGE,
  // block-construct helpers (exported for the regression/smoke harness)
  isTableSeparator, looksLikeTableRow, splitTableRow, parseAligns, parseListItem,
  parseUnitMarkdown,
  // 2026-09-24 print QC helpers (pure; exercised by regression_fixtures.py)
  isFigureCaption, makeCjkRunFactory, resolveEastAsianContext, withOverflowPunctOff,
  // 2026-09-24 round 2 (KIT2-PRINT) helpers
  isQuoteLine, isItalicLine, isLabelNoteUnit, estimateLines, labelRunKeeps, joinShortCjk,
  resolveHyphenation, withSettingsChild, withDocDefaultPPrChild, withStylePPrChild,
  withPrintSettings, suppressAutoHyphens, resolveCaptionStyle, resolveTitleLines, splitPartTitle,
  mdAltText,
};

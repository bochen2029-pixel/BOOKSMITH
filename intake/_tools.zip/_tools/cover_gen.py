#!/usr/bin/env python3
r"""
cover_gen.py — AI cover-art generator for BOOKSMITH (ComfyUI via the hermes skill).

Generates FRONT-cover art from a Book-Bible-derived prompt. The composited
typography (title/author/spine) is added LATER by composite_cover.py — so the
HARD RULE enforced here is: NO title / author / lettering text in the image
prompt. The negative prompt always suppresses text/watermark/letters.

What it does:
  1. Reads machine paths from kit_env.json (cover_gen block): the hermes
     run_workflow.py, run_batch.py, workflows_dir, comfyui_server, comfyui_app,
     checkpoints_dir, default_checkpoint.
  2. Ensures the local ComfyUI daemon is up (`comfy launch --background` on :8188)
     unless it already answers /system_stats.
  3. Resolves the workflow graph (default sdxl_txt2img.json) and injects the
     requested checkpoint filename into the graph's CheckpointLoaderSimple node
     (the schema does NOT surface ckpt_name, so we patch the JSON directly).
  4. Shells to run_workflow.py with --args {prompt, negative_prompt, seed, steps}
     and --output-dir <cover_art>, parses its JSON, and returns the generated PNG
     path as JSON on stdout.
  5. run_batch subcommand: shells to run_batch.py --count N --randomize-seed for
     seed variations, returns all produced PNG paths as JSON.

I/O contract (single):
  python cover_gen.py \
    --prompt "<art prompt, NO title/author text>" \
    --negative "text, watermark, letters" \
    --workflow sdxl_txt2img.json \
    --seed -1 --steps 30 \
    --out cover_art/<slug>_src.png \
    [--config book_config.json]  [--kit-env kit_env.json]  [--no-launch]
  -> {"status":"success","png":"<abs path>","seed":<n>,"steps":<n>, ...}

I/O contract (batch):
  python cover_gen.py run_batch \
    --prompt "<art prompt>" --negative "..." --count 8 --steps 30 \
    --out-dir cover_art/ [--config ...] [--kit-env ...]
  -> {"status":"success","pngs":[...], "count":N}

SOURCE: a hermes-style ComfyUI runner skill (run_workflow.py, run_batch.py,
        workflows\sdxl_txt2img.json, flux_dev_txt2img.json) — every path is
        resolved via kit_env.cover_gen (historical provenance, not a runtime path).
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent

# COMMERCIAL-USE PROVENANCE: the shipped default checkpoint resolves to
# SDXL-base 1.0 (sd_xl_base_1.0.safetensors), released under the permissive
# CreativeML Open RAIL++-M license — generated art may be sold (e.g. KDP covers).
# Do NOT default this to FLUX.1-dev: its weights are NON-commercial. See
# docs/cover_pipeline.md for the full provenance/license note (fonts + art).
DEFAULT_NEGATIVE = "text, watermark, letters, title, signature, frame, border"

# Prompt-safety: tokens that signal the caller is asking the model to render
# words. These are rejected so a title/author string never gets painted in.
# NOTE: bare 'title'/'subtitle'/'author'/'text'/'word(s)' were removed — they
# collide with compositional idioms the kit's own shipped seeds use ("room for
# the title", "negative space for a title", "no text"). The remaining tokens are
# unambiguous requests to paint lettering. The config-driven check below (the
# book's literal title/author strings) stays as the real anti-baking guard.
TEXT_SIGNAL_TOKENS = (
    "byline", "lettering", "typography", "caption", "writing", "inscription",
    "signage", "book cover text", "cover text", "logo text", "nameplate",
)

# Negated / compositional phrases that must NOT trip the guard even though they
# contain a signal substring. Negated spans are stripped before scanning; the
# whitelist phrases suppress a flag on the surviving word 'title'.
_NEGATED_TEXT_SPANS = ("no text", "without text", "no lettering", "no title")
_TITLE_COMPOSITION_PHRASES = (
    "for a title", "for title placement", "title placement",
    "room for the title", "for the title", "quiet for title",
)

# Generic baked-lettering INTENT ("a banner reading WELCOME", "graffiti spelling
# FEAR") — arbitrary words are just as fatal to the no-text invariant as the
# book's own title, and the trimmed token list above cannot see them.
_LETTERING_INTENT = re.compile(
    r"\b(?:reading|that\s+says|saying|spelling|spells|inscribed\s+with|"
    r"emblazoned\s+with|stamped\s+with)\s+[\"'“‘A-Z0-9]"
    r"|\b(?:banner|sign|graffiti|neon|poster|billboard|label|headline|marquee)\s+"
    r"(?:reading|saying|with\s+the\s+words|that\s+says)\b",
    re.IGNORECASE)


# ============================================================
# kit_env + config loading
# ============================================================
def load_json(path: Path) -> dict:
    with path.open(encoding="utf-8") as f:
        return json.load(f)


def load_kit_env(path: str | None) -> dict:
    p = Path(path).expanduser() if path else (SCRIPT_DIR / "kit_env.json")
    if not p.exists():
        raise FileNotFoundError(f"kit_env.json not found: {p}")
    return load_json(p)


# ============================================================
# Prompt safety — reject title/author/lettering in the ART prompt
# ============================================================
def check_prompt_no_text(prompt: str, config: dict | None) -> list[str]:
    """Return a list of violations if the prompt asks for baked text.

    Flags generic text-signal tokens AND the book's own title/author strings
    (so the exact cover title can't be requested inside the art).
    """
    violations: list[str] = []
    low = prompt.lower()

    # Strip negated spans so "no text" / "no title" cannot trip the guard.
    for span in _NEGATED_TEXT_SPANS:
        low = low.replace(span, "")

    for tok in TEXT_SIGNAL_TOKENS:
        if tok in low:
            violations.append(f"prompt contains text-signal token {tok.strip()!r}")

    m = _LETTERING_INTENT.search(low)
    if m:
        violations.append(f"prompt requests baked lettering ({m.group(0).strip()!r})")

    if config:
        # If the prompt uses a compositional "…for the title" idiom, don't let a
        # book whose literal title happens to be that idiom's word false-fire.
        composition_ok = any(ph in low for ph in _TITLE_COMPOSITION_PHRASES)
        for key in ("title", "subtitle", "author"):
            val = (config.get(key) or "").strip()
            if val and len(val) >= 3 and val.lower() in low:
                if key == "title" and composition_ok and val.lower() in " ".join(_TITLE_COMPOSITION_PHRASES):
                    continue
                violations.append(f"prompt contains the book {key} {val!r} (would bake it as text)")

    return violations


def ensure_text_negatives(negative: str) -> str:
    """Guarantee the negative prompt suppresses text/watermark/letters."""
    neg = (negative or "").strip()
    if not neg:
        return DEFAULT_NEGATIVE
    low = neg.lower()
    needed = ["text", "watermark", "letters"]
    missing = [w for w in needed if w not in low]
    if missing:
        neg = neg.rstrip(", ") + ", " + ", ".join(missing)
    return neg


# ============================================================
# ComfyUI daemon lifecycle
# ============================================================
def server_up(server_url: str, timeout: float = 3.0) -> bool:
    """True if the ComfyUI server answers /system_stats."""
    url = server_url.rstrip("/") + "/system_stats"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return r.status == 200
    except (urllib.error.URLError, OSError, ValueError):
        return False


def _port_from_url(server_url: str) -> int:
    """Extract the port from http://host:port[/...] (default 8188)."""
    try:
        return int(server_url.rstrip("/").rsplit(":", 1)[1].split("/")[0])
    except (IndexError, ValueError):
        return 8188


def _resolve_comfy_launch(paths: dict) -> tuple:
    """Figure out how to launch a LOCAL ComfyUI (Desktop or portable) DIRECTLY
    via its own python + main.py, for when comfy-cli is not on PATH (the common
    case: ComfyUI Desktop installs no `comfy` shim). Returns
    (python, main_py, base_dir, extra_args); (None, None, base, []) if main.py
    cannot be located. Everything is derived from the kit_env.cover_gen fields
    already present (comfyui_app + checkpoints_dir), with optional explicit
    overrides: comfyui_python / comfyui_main / comfyui_base_dir /
    comfyui_launch_args."""
    cg = paths.get("_cover_gen_raw") or {}
    win = (os.name == "nt")

    # base directory = where models/ (and, on Desktop, .venv) live.
    base_dir = cg.get("comfyui_base_dir")
    if not base_dir and paths.get("checkpoints_dir"):
        # checkpoints_dir is <base>/models/checkpoints
        base_dir = str(Path(paths["checkpoints_dir"]).parent.parent)
    base_dir = str(Path(base_dir)) if base_dir else None

    # python: explicit override, else the venv beside the base dir, else this
    # interpreter as a last resort.
    py = cg.get("comfyui_python")
    if py and not Path(py).exists():
        py = None
    if not py and base_dir:
        cand = Path(base_dir) / ".venv" / ("Scripts/python.exe" if win else "bin/python")
        if cand.exists():
            py = str(cand)
    if not py:
        py = sys.executable

    # main.py: explicit override, else the Desktop layout under comfyui_app,
    # else a portable checkout at base_dir/main.py.
    main_py = cg.get("comfyui_main")
    if main_py and not Path(main_py).exists():
        main_py = None
    if not main_py:
        app = paths.get("comfyui_app")
        candidates = []
        if app:
            candidates += [Path(app) / "resources" / "ComfyUI" / "main.py",
                           Path(app) / "main.py"]
        if base_dir:
            candidates += [Path(base_dir) / "main.py"]
        for cand in candidates:
            if cand.exists():
                main_py = str(cand)
                break

    extra = cg.get("comfyui_launch_args") or []
    if isinstance(extra, str):
        extra = extra.split()
    return (py, main_py, base_dir, list(extra))


def launch_server(paths, comfy_bin: str = "comfy", wait_s: float = 150.0) -> bool:
    """Start a LOCAL ComfyUI and poll until it answers /system_stats.

    Two strategies, in order (so a fresh session never has to launch it by hand):
      1. comfy-cli:  `comfy launch --background`  (only if `comfy` is on PATH).
      2. Direct:     the ComfyUI Desktop/portable `main.py` via its own venv
                     python, derived from kit_env (comfyui_app + checkpoints_dir,
                     or explicit comfyui_python/comfyui_main/comfyui_base_dir).
    Returns True once the server answers; False only if BOTH strategies are
    unavailable or the server does not come up within `wait_s`.

    `paths` is the resolved cover_gen paths dict (a bare server-URL string is
    also accepted for backward compat, but then only strategy 1 is possible)."""
    is_dict = isinstance(paths, dict)
    server_url = paths["server"] if is_dict else paths
    if server_up(server_url):
        return True

    def _poll(seconds: float) -> bool:
        deadline = time.time() + seconds
        while time.time() < deadline:
            if server_up(server_url):
                return True
            time.sleep(2.0)
        return server_up(server_url)

    # Strategy 1: comfy-cli (daemonizes with --background).
    if shutil.which(comfy_bin) is not None:
        try:
            subprocess.run(
                [comfy_bin, "launch", "--background"],
                check=False, capture_output=True, text=True,
                encoding="utf-8", errors="replace", timeout=120,
            )
        except (subprocess.SubprocessError, OSError):
            pass
        if _poll(90.0):
            return True

    # Strategy 2: launch the local ComfyUI main.py directly. Needs the paths
    # dict (comfyui_app/checkpoints_dir or explicit launch keys).
    if not is_dict:
        return False
    py, main_py, base_dir, extra = _resolve_comfy_launch(paths)
    if not (py and main_py):
        return False
    port = _port_from_url(server_url)
    cmd = [py, main_py]
    if base_dir:
        cmd += ["--base-directory", base_dir]
    cmd += ["--listen", "127.0.0.1", "--port", str(port), "--disable-auto-launch"] + extra
    try:
        print(f"[cover_gen] comfy-cli absent; launching ComfyUI directly: "
              f"{py} {main_py} --base-directory {base_dir} --port {port} "
              f"{' '.join(extra)}".rstrip(), file=sys.stderr)
        creationflags = 0x00000008 if os.name == "nt" else 0  # DETACHED_PROCESS
        # close_fds=True on EVERY platform (2026-08-02). With close_fds=False on
        # Windows the detached server inherits ALL inheritable handles - not
        # just its stdio - including the WRITE ends of any pipes a CAPTURING
        # caller (engine.py run(), a driver script) attached to cover_gen
        # itself. The server outlives cover_gen, the pipe never sees EOF, and
        # the caller wedges forever in communicate() even after cover_gen
        # exits. Python >=3.7 supports close_fds=True together with stdio
        # redirection on Windows (stdio passes via STARTUPINFO, not handle
        # inheritance), so nothing is lost by closing the rest.
        subprocess.Popen(
            cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL, creationflags=creationflags,
            close_fds=True,
        )
    except (subprocess.SubprocessError, OSError) as exc:
        print(f"[cover_gen] direct ComfyUI launch failed: {exc}", file=sys.stderr)
        return False
    return _poll(wait_s)


_COMFY_PORT_CANDIDATES = ("http://127.0.0.1:8000", "http://127.0.0.1:8188")


def _adopt_live_server(paths: dict) -> None:
    """If the configured ComfyUI server is down, probe the two well-known local
    ports (:8000 desktop app, :8188 comfy-cli/portable) and adopt a live one.
    Configure-first-launch-later leaves a stale port in kit_env; a running
    desktop app must not be reported unreachable because of it."""
    if server_up(paths["server"]):
        return
    for cand in _COMFY_PORT_CANDIDATES:
        if cand != paths["server"] and server_up(cand):
            print(f"[cover_gen] configured server {paths['server']} down; using live {cand}",
                  file=sys.stderr)
            paths["server"] = cand
            return


# ============================================================
# Workflow resolution + checkpoint injection
# ============================================================
def resolve_workflow(workflow: str, workflows_dir: Path) -> Path:
    """Resolve a workflow name/path to an existing file.

    Accepts a bare filename (looked up under workflows_dir), a relative path,
    or an absolute path.
    """
    p = Path(workflow).expanduser()
    if p.is_absolute() and p.exists():
        return p
    # bare name or relative → try workflows_dir first, then CWD.
    cand = workflows_dir / workflow
    if cand.exists():
        return cand
    if p.exists():
        return p.resolve()
    raise FileNotFoundError(
        f"workflow not found: {workflow} (looked in {workflows_dir} and {Path.cwd()})"
    )


def patch_checkpoint(workflow_path: Path, checkpoint: str | None) -> Path:
    """Prepare the API-format graph for submission: STRIP non-node keys and
    optionally set the checkpoint, writing a temp copy.

    Community/skill workflow JSONs often carry a documentation key like
    '_comment' whose value is a string, not a node. ComfyUI's /prompt endpoint
    rejects the whole graph with "a node is missing the class_type property", so
    we keep ONLY real nodes (dict values carrying a class_type). We also set
    every CheckpointLoaderSimple.ckpt_name when a checkpoint is given (the schema
    does not surface ckpt_name as a param, so we patch the JSON directly).
    """
    graph = load_json(workflow_path)
    clean = {k: v for k, v in graph.items()
             if isinstance(v, dict) and "class_type" in v}
    dropped = [k for k in graph if k not in clean]
    if checkpoint:
        for node in clean.values():
            if node.get("class_type") == "CheckpointLoaderSimple":
                node.setdefault("inputs", {})["ckpt_name"] = checkpoint
    if not dropped and not checkpoint:
        return workflow_path
    tmp = Path(tempfile.mkdtemp(prefix="booksmith_wf_")) / workflow_path.name
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(clean, f)
    return tmp


# ============================================================
# run_workflow.py shell
# ============================================================
def _extract_png(run_json: dict) -> str | None:
    """Pull the first image file path out of run_workflow.py's success JSON.

    run_workflow emits {"status":"success","outputs":[{"file":..,"type":"image"|..}]}.
    Prefer image-typed entries; fall back to any file with an image suffix.
    """
    outputs = run_json.get("outputs") or []
    if isinstance(outputs, dict):
        # Defensive: some paths return the raw comfy outputs dict.
        outputs = [outputs]
    image_exts = (".png", ".jpg", ".jpeg", ".webp")
    # Pass 1: explicitly image-typed
    for o in outputs:
        if isinstance(o, dict) and o.get("type") == "image" and o.get("file"):
            return o["file"]
    # Pass 2: any file with an image extension
    for o in outputs:
        if isinstance(o, dict):
            f = o.get("file") or ""
            if f.lower().endswith(image_exts):
                return f
    return None


def run_single(run_workflow_py: Path, workflow_path: Path, args_obj: dict,
               output_dir: Path, host: str, timeout: int) -> dict:
    """Shell to run_workflow.py, return its parsed JSON (last JSON line on stdout)."""
    output_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable, str(run_workflow_py),
        "--workflow", str(workflow_path),
        "--args", json.dumps(args_obj),
        "--output-dir", str(output_dir),
        "--host", host,
    ]
    if timeout and timeout > 0:
        cmd += ["--timeout", str(timeout)]
    proc = subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace")
    return _parse_runner_json(proc)


def run_batch_shell(run_batch_py: Path, workflow_path: Path, args_obj: dict,
                    output_dir: Path, host: str, count: int, timeout: int) -> dict:
    """Shell to run_batch.py --count N --randomize-seed."""
    output_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable, str(run_batch_py),
        "--workflow", str(workflow_path),
        "--args", json.dumps(args_obj),
        "--count", str(count),
        "--randomize-seed",
        "--output-dir", str(output_dir),
        "--host", host,
    ]
    if timeout and timeout > 0:
        cmd += ["--timeout", str(timeout)]
    proc = subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace")
    return _parse_runner_json(proc)


def _parse_runner_json(proc: subprocess.CompletedProcess) -> dict:
    """Parse the JSON the runner emits on stdout. The runner uses emit_json for
    its final result; be tolerant of leading log lines by scanning for the last
    parseable JSON object in stdout, else the whole thing."""
    out = (proc.stdout or "").strip()
    # Try whole-stdout first.
    for candidate in (out, _last_json_blob(out)):
        if not candidate:
            continue
        try:
            data = json.loads(candidate)
            if isinstance(data, dict):
                return data
        except json.JSONDecodeError:
            continue
    return {
        "status": "error",
        "error": "could not parse runner JSON",
        "returncode": proc.returncode,
        "stdout_tail": out[-1000:],
        "stderr_tail": (proc.stderr or "")[-1000:],
    }


def _last_json_blob(text: str) -> str | None:
    """Return the substring from the last top-level '{' to the final '}'."""
    if not text:
        return None
    end = text.rfind("}")
    if end == -1:
        return None
    depth = 0
    for i in range(end, -1, -1):
        c = text[i]
        if c == "}":
            depth += 1
        elif c == "{":
            depth -= 1
            if depth == 0:
                return text[i:end + 1]
    return None


# ============================================================
# Provenance sidecar — bind INTENT to a recorded FACT
# ============================================================
# The single source of truth read by verify_build.py::check_cover_art_provenance
# (2026-07-31). book_config.cover.art declares HOW the cover is MEANT to be
# produced; this file records what ACTUALLY happened. A perceptual gate cannot
# tell genuine SDXL art from a tasteful hypergen placeholder — for months a
# silent hypergen fallback shipped placeholder covers on four books where the
# config said SDXL, and nothing went red. Recording the method, not judging the
# pixels, is what makes the miss visible. See docs/LESSONS_LEDGER.md 20.3.
def _comfy_version(server_url: str, timeout: float = 3.0):
    """Best-effort ComfyUI version from /system_stats (None if unavailable)."""
    url = server_url.rstrip("/") + "/system_stats"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8"))
        return (data.get("system") or {}).get("comfyui_version")
    except (urllib.error.URLError, OSError, ValueError, json.JSONDecodeError):
        return None


def _resolved_seed(server_url: str, prompt_id, fallback, timeout: float = 5.0):
    """The ACTUAL seed ComfyUI used, read back from /history/<prompt_id>.

    A `seed: -1` request expands to a real value server-side; the run_workflow
    runner does not echo it, so without this the winning cover could never be
    regenerated. Best-effort: returns `fallback` if history/the seed can't be
    read — provenance is never blocked on this optional lookup.
    """
    if not prompt_id:
        return fallback
    url = server_url.rstrip("/") + f"/history/{prompt_id}"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            hist = json.loads(r.read().decode("utf-8"))
    except (urllib.error.URLError, OSError, ValueError, json.JSONDecodeError):
        return fallback
    prompt = ((hist or {}).get(prompt_id) or {}).get("prompt")
    graph = prompt if isinstance(prompt, dict) else None
    if isinstance(prompt, list):                        # [num, id, graph, extra, ...]
        for el in prompt:
            if isinstance(el, dict) and any(
                    isinstance(v, dict) and "class_type" in v for v in el.values()):
                graph = el
                break
    if not isinstance(graph, dict):
        return fallback
    for node in graph.values():
        if isinstance(node, dict):
            ins = node.get("inputs") or {}
            for key in ("seed", "noise_seed"):
                v = ins.get(key)
                if isinstance(v, int) and not isinstance(v, bool):
                    return v
    return fallback


def _sha256_file(path: Path):
    """Streamed SHA-256 of a file (None if it cannot be read)."""
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


def _image_dims(path: Path):
    """'<w>x<h>' of an image via PIL (None if PIL missing or file unreadable)."""
    try:
        from PIL import Image
        with Image.open(path) as im:
            return f"{im.width}x{im.height}"
    except Exception:                                             # noqa: BLE001
        return None


def write_provenance(art_path, method: str, record: dict, recorded_by: str = None) -> Path:
    """Write `cover_art/<art-stem>.provenance.json` next to the generated art.

    `method` is the recorded fact (sdxl | hypergen | catalog | ...). `record` is
    an ordered dict of generation params (checkpoint/workflow/seed/…); None values
    are dropped. The file/sha256/dims of the actual art and a UTC timestamp are
    appended, so the sidecar always describes the bytes that shipped. This is the
    fact verify_build's provenance gate trusts, in place of judging the pixels.

    `recorded_by` names the producer that actually wrote the record; cover_pick.py
    reuses this helper and passes its own name, so a sidecar never misattributes
    itself (the record must not lie about who made it).
    """
    art_path = Path(art_path)
    sidecar = art_path.with_name(art_path.stem + ".provenance.json")
    payload = {"method": method}
    payload.update({k: v for k, v in record.items() if v is not None})
    payload["art_file"] = art_path.name
    payload["art_sha256"] = _sha256_file(art_path)
    payload["art_dims"] = _image_dims(art_path)
    payload["recorded_at"] = datetime.now(timezone.utc).isoformat()
    payload["recorded_by"] = recorded_by or Path(__file__).name
    sidecar.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
                       encoding="utf-8")
    return sidecar


# ============================================================
# High-level entry points
# ============================================================
def _resolve_cover_gen_paths(env: dict) -> dict:
    cg = env.get("cover_gen") or {}
    run_workflow = cg.get("run_workflow")
    workflows_dir = cg.get("workflows_dir")
    if not run_workflow or not workflows_dir:
        raise KeyError("kit_env.cover_gen must define run_workflow + workflows_dir")

    # Anchor non-absolute kit_env paths under the kit root (not the CWD), so a
    # relative workflows_dir/run_workflow (e.g. the vendored '_tools/…' defaults)
    # resolves the same from any working directory. Mirrors composite_cover.py's
    # FONTS_DIR anchoring. SCRIPT_DIR is _tools/; the kit root is its parent.
    def _anchor(p):
        if not p:
            return None
        pp = Path(p)
        return pp if pp.is_absolute() else (SCRIPT_DIR.parent / pp)

    run_workflow_p = _anchor(run_workflow)
    # run_batch.py sits next to run_workflow.py in the skill's scripts/ dir.
    run_batch_p = run_workflow_p.parent / "run_batch.py"
    return {
        "run_workflow": run_workflow_p,
        "run_batch": run_batch_p,
        "workflows_dir": _anchor(workflows_dir),
        "server": cg.get("comfyui_server", "http://127.0.0.1:8188"),
        "comfyui_app": cg.get("comfyui_app"),
        "checkpoints_dir": _anchor(cg.get("checkpoints_dir")),
        "default_checkpoint": cg.get("default_checkpoint", "sd_xl_base_1.0.safetensors"),
        "_cover_gen_raw": cg,  # raw block, for direct-launch param derivation
    }


def _default_checkpoint(config: dict | None, env_default: str) -> str:
    """Book config's cover.art.checkpoint wins over kit_env default."""
    if config:
        art = ((config.get("cover") or {}).get("art") or {})
        ck = art.get("checkpoint")
        if ck:
            return ck
    return env_default


def _default_workflow(config: dict | None, cli_workflow: str | None) -> str:
    if cli_workflow:
        return cli_workflow
    if config:
        art = ((config.get("cover") or {}).get("art") or {})
        wf = art.get("workflow")
        if wf:
            return wf
    return "sdxl_txt2img.json"


def _require_prompt(args) -> bool:
    """Emit an error + return False if --prompt was omitted (validated here
    rather than via argparse required=True — see build_parser note)."""
    if not (args.prompt and args.prompt.strip()):
        print(json.dumps({"status": "error", "error": "--prompt is required"}))
        return False
    return True


def _cover_gen_env_error(e: KeyError) -> int:
    """Structured status-error for a misconfigured kit_env.cover_gen (task 11)."""
    print(json.dumps({
        "status": "error",
        "error": str(e),
        "hint": "Fill kit_env.cover_gen.run_workflow + workflows_dir (the vendored "
                "defaults point at _tools/comfy_client.py + _tools/workflows), or "
                "skip AI art generation and place your own cover art in the book's "
                "cover_art/ folder — composite_cover.py and vision_verify.py still work.",
    }, indent=2))
    return 1


def _apply_art_defaults(args, config: dict | None) -> None:
    """Default any unset CLI knob from book_config.cover.art (task 10), so
    prompt_seed/negative_prompt/steps/seed in the config drive generation when
    the corresponding CLI flag is omitted (single source of knobs)."""
    art = ((config or {}).get("cover") or {}).get("art") or {}
    if not art:
        return
    if not args.prompt and art.get("prompt_seed"):
        args.prompt = art["prompt_seed"]
    if args.negative == DEFAULT_NEGATIVE and art.get("negative_prompt"):
        args.negative = art["negative_prompt"]
    if getattr(args, "steps", None) == 30 and "steps" in art:
        args.steps = art["steps"]
    if getattr(args, "seed", None) == -1 and "seed" in art:
        args.seed = art["seed"]


def do_single(args) -> int:
    env = load_kit_env(args.kit_env)
    config = load_json(Path(args.config)) if args.config else None
    _apply_art_defaults(args, config)
    if not _require_prompt(args):
        return 2
    try:
        paths = _resolve_cover_gen_paths(env)
    except KeyError as e:
        return _cover_gen_env_error(e)

    # ---- prompt safety ----
    violations = check_prompt_no_text(args.prompt, config)
    if violations:
        print(json.dumps({
            "status": "error",
            "error": "prompt requests baked text — cover art must contain NO title/author/lettering",
            "violations": violations,
        }, indent=2))
        return 2

    negative = ensure_text_negatives(args.negative)
    checkpoint = args.checkpoint or _default_checkpoint(config, paths["default_checkpoint"])
    workflow_name = _default_workflow(config, args.workflow)

    # ---- resolve workflow + inject checkpoint ----
    try:
        workflow_path = resolve_workflow(workflow_name, paths["workflows_dir"])
    except FileNotFoundError as e:
        print(json.dumps({"status": "error", "error": str(e)}))
        return 1
    effective_wf = patch_checkpoint(workflow_path, checkpoint)

    # ---- ensure server ----
    _adopt_live_server(paths)
    if not args.no_launch:
        if not launch_server(paths):  # pass the DICT so the Desktop-launch fallback (Strategy 2) is reachable
            print(json.dumps({
                "status": "error",
                "error": f"ComfyUI server not reachable at {paths['server']} and could not "
                         "auto-launch it (comfy-cli not on PATH). Start ComfyUI so it serves "
                         f"{paths['server']}, or install comfy-cli, or pass --no-launch once it "
                         "is running. Note: the vendored comfy_client.py is a CLIENT only and "
                         "cannot start a server.",
                "hint": f"A checkpoint must be present in {paths['checkpoints_dir']}.",
            }, indent=2))
            return 1
    elif not server_up(paths["server"]):
        print(json.dumps({
            "status": "error",
            "error": f"ComfyUI server not reachable at {paths['server']} (--no-launch set)",
        }))
        return 1

    # ---- run ----
    out_path = Path(args.out).expanduser()
    output_dir = out_path.parent if out_path.suffix else out_path
    args_obj = {
        "prompt": args.prompt,
        "negative_prompt": negative,
        "seed": args.seed,
        "steps": args.steps,
    }
    run_json = run_single(paths["run_workflow"], effective_wf, args_obj,
                          output_dir, paths["server"], args.timeout)

    if run_json.get("status") != "success":
        print(json.dumps({"status": "error", "error": "workflow run failed",
                          "runner": run_json}, indent=2))
        return 1

    png = _extract_png(run_json)
    if not png:
        print(json.dumps({"status": "error", "error": "no image in runner outputs",
                          "runner": run_json}, indent=2))
        return 1

    # ---- rename to the requested --out target if it names a file ----
    final_png = png
    if out_path.suffix:
        try:
            out_path.parent.mkdir(parents=True, exist_ok=True)
            if Path(png).suffix.lower() != out_path.suffix.lower():
                # a custom workflow may emit webp/jpeg: transcode instead of
                # lying about the byte format via the filename
                from PIL import Image
                Image.open(png).convert("RGB").save(out_path)
                Path(png).unlink(missing_ok=True)
            else:
                shutil.move(png, out_path)
            final_png = str(out_path.resolve())
        except Exception:
            final_png = png  # keep the runner's location if the move/transcode fails

    # ---- provenance sidecar (the SDXL FACT the verify_build gate trusts) ----
    # Written on SUCCESS only, so a failed run leaves no false proof. If the write
    # itself fails we WARN but keep status=success (the art is real): the missing
    # sidecar then trips check_cover_art_provenance downstream, which is the correct
    # loud failure, never a silent pass. See docs/LESSONS_LEDGER.md 20.3.
    # The ACTUAL seed ComfyUI used (a -1 request expands server-side) — read back
    # from /history so the winning cover stays reproducible instead of lost as -1.
    resolved_seed = run_json.get("seed")
    if not isinstance(resolved_seed, int) or resolved_seed == -1:
        resolved_seed = _resolved_seed(paths["server"], run_json.get("prompt_id"), args.seed)
    # Record the method that actually ran: a FLUX workflow must not be recorded
    # as "sdxl" (a hardcoded literal here once made every FLUX record a lie).
    gen_method = "flux" if "flux" in Path(workflow_path).name.lower() else "sdxl"
    provenance = None
    try:
        provenance = str(write_provenance(
            Path(final_png), gen_method, {
                "generator": "ComfyUI",
                "comfyui_version": _comfy_version(paths["server"]),
                "comfyui_server": paths["server"],
                "checkpoint": checkpoint,
                "workflow": Path(workflow_path).name,
                "steps": args.steps,
                # the RESOLVED seed regenerates this exact art; keep the request too
                "seed": resolved_seed,
                "seed_requested": args.seed,
                "prompt": args.prompt,
                "negative_prompt": negative,
                "prompt_id": run_json.get("prompt_id"),
            }))
    except OSError as exc:
        print(f"[cover_gen] WARNING: cover art generated but the provenance sidecar "
              f"could not be written ({exc}); verify_build will fail closed until it "
              f"exists", file=sys.stderr)

    # a dropped negative prompt voids the anti-baked-text backstop (FLUX has no
    # negative CLIPTextEncode) — that must be a loud caveat, not a buried note
    caveats = [w for w in (run_json.get("warnings") or [])
               if "negative" in str(w).lower() and "no " in str(w).lower()]
    for c in caveats:
        print(f"[cover_gen] CAVEAT: {c} — the text/watermark negative did NOT land; "
              f"rely on the perceptual gate", file=sys.stderr)
    print(json.dumps({
        "status": "success",
        "png": str(Path(final_png).resolve()),
        "provenance": provenance,
        "caveats": caveats,
        # the RESOLVED seed (a -1 request expands server-side); without it the
        # winning cover could never be regenerated
        "seed": resolved_seed,
        "steps": args.steps,
        "checkpoint": checkpoint,
        "workflow": str(workflow_path),
        "negative_prompt": negative,
        "prompt_id": run_json.get("prompt_id"),
    }, indent=2))
    return 0


def do_batch(args) -> int:
    env = load_kit_env(args.kit_env)
    config = load_json(Path(args.config)) if args.config else None
    _apply_art_defaults(args, config)
    if not _require_prompt(args):
        return 2
    try:
        paths = _resolve_cover_gen_paths(env)
    except KeyError as e:
        return _cover_gen_env_error(e)

    violations = check_prompt_no_text(args.prompt, config)
    if violations:
        print(json.dumps({
            "status": "error",
            "error": "prompt requests baked text — cover art must contain NO title/author/lettering",
            "violations": violations,
        }, indent=2))
        return 2

    negative = ensure_text_negatives(args.negative)
    checkpoint = args.checkpoint or _default_checkpoint(config, paths["default_checkpoint"])
    workflow_name = _default_workflow(config, args.workflow)

    try:
        workflow_path = resolve_workflow(workflow_name, paths["workflows_dir"])
    except FileNotFoundError as e:
        print(json.dumps({"status": "error", "error": str(e)}))
        return 1
    effective_wf = patch_checkpoint(workflow_path, checkpoint)

    _adopt_live_server(paths)
    if not args.no_launch:
        if not launch_server(paths):  # pass the DICT so the Desktop-launch fallback (Strategy 2) is reachable
            print(json.dumps({
                "status": "error",
                "error": f"ComfyUI server not reachable at {paths['server']} and could not "
                         "auto-launch it (comfy-cli not on PATH). Start ComfyUI so it serves "
                         f"{paths['server']}, or install comfy-cli, or pass --no-launch once it "
                         "is running. Note: the vendored comfy_client.py is a CLIENT only and "
                         "cannot start a server.",
            }, indent=2))
            return 1
    elif not server_up(paths["server"]):
        print(json.dumps({
            "status": "error",
            "error": f"ComfyUI server not reachable at {paths['server']} (--no-launch set)",
        }))
        return 1

    if not paths["run_batch"].exists():
        print(json.dumps({"status": "error",
                          "error": f"run_batch.py not found at {paths['run_batch']}"}))
        return 1

    output_dir = Path(args.out_dir).expanduser()
    # Base args for the batch; run_batch.py assigns a fresh seed per run.
    args_obj = {
        "prompt": args.prompt,
        "negative_prompt": negative,
        "steps": args.steps,
    }
    run_json = run_batch_shell(paths["run_batch"], effective_wf, args_obj,
                               output_dir, paths["server"], args.count, args.timeout)

    # run_batch.py aggregates per-run results; collect every image path we can find.
    pngs = _collect_batch_pngs(run_json)
    if not pngs:
        print(json.dumps({"status": "error", "error": "batch produced no images",
                          "runner": run_json}, indent=2))
        return 1

    # ---- provenance sidecars (batch) ----
    # Every produced image records how it was made, same as do_single. A
    # variations run that writes no record is exactly the producer-with-no-proof
    # gap check_cover_art_provenance exists to catch (LESSONS_LEDGER 20.3).
    gen_method = "flux" if "flux" in Path(workflow_path).name.lower() else "sdxl"
    seed_by_file = {}
    for key in ("runs", "results", "batch"):
        seq = run_json.get(key)
        if isinstance(seq, list):
            for entry in seq:
                if not isinstance(entry, dict):
                    continue
                outs = entry.get("outputs")
                if isinstance(outs, dict):
                    outs = [outs]
                for o in outs or []:
                    if isinstance(o, dict) and o.get("file"):
                        seed_by_file[str(Path(o["file"]).resolve())] = entry.get("seed")
    sidecar_paths = []
    for png in pngs:
        try:
            sidecar_paths.append(str(write_provenance(
                Path(png), gen_method, {
                    "generator": "ComfyUI",
                    "comfyui_server": paths["server"],
                    "checkpoint": checkpoint,
                    "workflow": Path(workflow_path).name,
                    "steps": args.steps,
                    "seed": seed_by_file.get(str(Path(png).resolve())),
                    "prompt": args.prompt,
                    "negative_prompt": negative,
                    "batch": True,
                })))
        except OSError as exc:
            print(f"[cover_gen] WARNING: batch art generated but a provenance "
                  f"sidecar could not be written for {png} ({exc}); verify_build "
                  f"will fail closed until it exists", file=sys.stderr)

    print(json.dumps({
        "status": "success",
        "pngs": pngs,
        "count": len(pngs),
        "provenance": sidecar_paths,
        "seeds": [r.get("seed") for r in (run_json.get("results")
                                          or run_json.get("runs") or [])
                  if isinstance(r, dict)],
        "checkpoint": checkpoint,
        "workflow": str(workflow_path),
        "negative_prompt": negative,
    }, indent=2))
    return 0


def _collect_batch_pngs(run_json: dict) -> list[str]:
    """Walk run_batch.py's aggregate JSON for every produced image path.

    run_batch emits a 'runs' (or 'results') list; each entry mirrors a
    run_workflow result with an 'outputs' list. Be tolerant of shape.
    """
    image_exts = (".png", ".jpg", ".jpeg", ".webp")
    found: list[str] = []

    def _harvest(outputs) -> None:
        if isinstance(outputs, dict):
            outputs = [outputs]
        if not isinstance(outputs, list):
            return
        for o in outputs:
            if isinstance(o, dict):
                f = o.get("file") or ""
                if f.lower().endswith(image_exts) and f not in found:
                    found.append(str(Path(f).resolve()))

    # Top-level outputs (single-shape) …
    _harvest(run_json.get("outputs"))
    # … and nested per-run lists.
    for key in ("runs", "results", "batch"):
        seq = run_json.get(key)
        if isinstance(seq, list):
            for entry in seq:
                if isinstance(entry, dict):
                    _harvest(entry.get("outputs"))
    return found


# ============================================================
# CLI
# ============================================================
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="BOOKSMITH AI cover-art generator (ComfyUI via the hermes skill). "
                    "NO title/author text is allowed in the art prompt.",
    )
    sub = p.add_subparsers(dest="command")

    # ---- shared options factory ----
    # NOTE: --prompt is deliberately NOT required at parse time. argparse routes
    # bare options to the PARENT parser, so a required parent --prompt would make
    # `cover_gen.py run_batch --prompt ...` fail (the subparser's --prompt hasn't
    # been consumed yet). Presence is validated in the command handlers instead.
    def add_common(sp, batch: bool):
        sp.add_argument("--prompt", default=None,
                        help="Art prompt (REQUIRED). MUST NOT request title/author/lettering text.")
        sp.add_argument("--negative", default=DEFAULT_NEGATIVE,
                        help="Negative prompt (text/watermark/letters are force-added).")
        sp.add_argument("--workflow", default=None,
                        help="Workflow name/path (default from config or sdxl_txt2img.json).")
        sp.add_argument("--checkpoint", default=None,
                        help="Checkpoint filename override (default from config/kit_env).")
        sp.add_argument("--steps", type=int, default=30, help="Sampler steps.")
        sp.add_argument("--config", default=None, help="book_config.json (title/author guard + defaults).")
        sp.add_argument("--kit-env", default=None, help="kit_env.json (machine paths).")
        sp.add_argument("--timeout", type=int, default=0, help="Runner timeout seconds (0=auto).")
        sp.add_argument("--no-launch", action="store_true",
                        help="Do not auto-launch ComfyUI; fail if the server is down.")

    # single (default command)
    add_common(p, batch=False)
    p.add_argument("--seed", type=int, default=-1, help="Seed (-1 = randomize).")
    p.add_argument("--out", default="cover_art/cover_src.png",
                   help="Output PNG path (or dir). File suffix => rename runner output to it.")

    # run_batch subcommand
    bp = sub.add_parser("run_batch", help="Generate N seed variations.")
    add_common(bp, batch=True)
    bp.add_argument("--count", type=int, default=8, help="Number of seed variations.")
    bp.add_argument("--out-dir", default="cover_art/", help="Directory for the variation PNGs.")

    return p


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command == "run_batch":
        return do_batch(args)
    return do_single(args)


if __name__ == "__main__":
    sys.exit(main())

// ============================================================
// generate_kindle.js — Reflowable Kindle DOCX generator (BOOKSMITH)
//
// PURPOSE: emit the reflowable ebook DOCX for direct KDP upload (NOT epub, NOT
// PDF). Strips every print concept (ledger §7.1): single section, uniform 1"
// margins (header:0 footer:0 gutter:0), NO page numbers / running headers /
// mirror margins / blank versos / forced rectos. Unit titles are styled
// HeadingLevel.HEADING_1 so Amazon builds its auto-TOC; the in-book CONTENTS
// page + TableOfContents field is OMITTED by default (§16.4) — set
// kindle_include_toc: true to embed one (which also arms updateFields).
//
// EVERYTHING per-book is read from book_config.json (title/subtitle/author,
// interior.body_font, voice.unit_noun, is_fiction, kdp_metadata for the About
// back matter). Reads the SAME version-pinned markdown as generate_book.js — the
// single fix for the Kindle-vs-print source-drift bug (§2.8).
//
// PORTED FROM: C:\BOOK\generate_kindle.js + C:\Claude-Titanic\generate_kindle.js.
//
// BAKED-IN LEDGER FIXES:
//   §3.3  parse order = backticks -> math -> bold -> italic
//   §7.1  single section, uniform 1" margins, no print furniture
//   §7.2  unit titles HeadingLevel.HEADING_1 + hyperlinked auto-TOC; updateFields
//   §7.3  math runs tagged "Cambria Math"; content parity (never page parity);
//         extended About-the-Author back matter
//   2026-09-24 ebook QC (across_borders): image alt text -> docPr; CJK runs
//         upright in italic contexts + East Asian w:lang; italic caption bound
//         to its figure (keepNext); a run of quote lines is ONE block (bare ">"
//         never prints); H1 text in real case (allCaps formatting); About the
//         Author is a Heading 1; core.xml title/creator from config; config
//         free text takes the body's inline markup. Guarded by
//         regression_fixtures.py (the ebook leg).
//   2026-09-24 final render QC round 2: quote (label) text in the body colour,
//         not a fixed #444444, so dark/sepia reading themes keep it readable
//         (regression_fixtures.py, the KIT2-OTHER leg).
//
// I/O:
//   node generate_kindle.js --config book_config.json [--src <master.md>] [--out <path.docx>]
//   reads outputs/markdown/<slug>_vN.md (latest) + book_config.json
//   writes outputs/kindle/<slug>_KINDLE.docx
// ============================================================

const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, AlignmentType, PageBreak,
  HeadingLevel, TableOfContents, StyleLevel, ImageRun,
  Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType,
} = require("docx");

const { latexToUnicode, fixProseSubscripts } = require("./latex_to_unicode.js");

const TOOLS_DIR = __dirname;
const REPO_ROOT = path.resolve(TOOLS_DIR, "..");

// ============================================================
// CLI + config
// ============================================================
function parseArgs(argv) {
  const args = { config: null, src: null, out: null, help: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--config") args.config = argv[++i];
    else if (a === "--src") args.src = argv[++i];
    else if (a === "--out") args.out = argv[++i];
    else if (a === "--help" || a === "-h") args.help = true;
  }
  return args;
}

const USAGE = `generate_kindle.js — BOOKSMITH reflowable Kindle DOCX generator

Usage:
  node generate_kindle.js --config <book_config.json> [options]

Required:
  --config <path>   book_config.json (per-book knobs; schema _tools/book_config.schema.json)

Options:
  --src <path>      version-pinned master markdown (default: latest outputs/markdown/<slug>_vN.md)
  --out <path>      output .docx path (default: book_workspace/<slug>/outputs/kindle/<slug>_KINDLE.docx)
  -h, --help        show this help and exit

Emits a single-section reflowable DOCX (no page numbers/headers/mirror). Reads the
SAME version-pinned markdown as generate_book.js. A manual CONTENTS page is OMITTED
by default (kindle_include_toc); Amazon auto-navs from Heading 1.`;

function loadConfig(configPath) {
  if (!configPath) throw new Error("--config <book_config.json> is required");
  const abs = path.isAbsolute(configPath) ? configPath : path.resolve(process.cwd(), configPath);
  return JSON.parse(fs.readFileSync(abs, "utf8"));
}

function num(v, d) { return (typeof v === "number" && !Number.isNaN(v)) ? v : d; }
function str(v, d) { return (typeof v === "string" && v.length) ? v : d; }

function resolveSrc(config, cliSrc, wsRoot) {
  if (cliSrc) return path.isAbsolute(cliSrc) ? cliSrc : path.resolve(process.cwd(), cliSrc);
  const slug = config.slug;
  const mdDir = path.join(wsRoot, "outputs", "markdown");
  if (!fs.existsSync(mdDir)) {
    throw new Error(`markdown source dir not found: ${mdDir} (run assemble_manuscript.py, or pass --src)`);
  }
  const re = new RegExp(`^${slug}_v(\\d+)\\.md$`);
  let best = null, bestN = -1;
  for (const name of fs.readdirSync(mdDir)) {
    const m = name.match(re);
    if (m) { const n = parseInt(m[1], 10); if (n > bestN) { bestN = n; best = name; } }
  }
  if (!best) throw new Error(`no ${slug}_vN.md found in ${mdDir}`);
  return path.join(mdDir, best);
}

function resolveOutPath(config, cliOut, wsRoot) {
  if (cliOut) return path.isAbsolute(cliOut) ? cliOut : path.resolve(process.cwd(), cliOut);
  const slug = config.slug;
  return path.join(wsRoot, "outputs", "kindle", `${slug}_KINDLE.docx`);
}

// ============================================================
// Kindle typography — pure black body, config font, 12pt-equivalent default.
// ============================================================
function resolveTypography(config) {
  const interior = config.interior || {};
  const bodyPt = num(interior.body_pt, 12);
  // CJK editions: interior.body_font_latin pairs a Latin face with a CJK body
  // face via split rFonts (ascii/hAnsi = Latin, eastAsia/cs = body). Absent the
  // key, FONT stays a plain string and output is byte-identical to before.
  const bodyName = str(interior.body_font, "Georgia");
  const latinName = str(interior.body_font_latin, "");
  return {
    FONT: latinName
      ? { ascii: latinName, hAnsi: latinName, eastAsia: bodyName, cs: bodyName }
      : bodyName,
    FONT_NAME: latinName ? `${latinName} + ${bodyName}` : bodyName,
    BODY_SIZE: bodyPt * 2,               // half-points
    BODY_LINE: num(interior.leading, 340),
    FIRST_INDENT: num(interior.first_line_indent, 360),
    BODY_COLOR: "000000",                // Kindle uses pure black (§3.2)
    ORNAMENT: str(interior.ornament_glyph, "✦"),
    // Config-driven glyph fonts (schema defaults match the historical literals,
    // so a sparse config is byte-identical to before).
    ORNAMENT_FONT: str(interior.ornament_font, "Segoe UI Symbol"),
    CODE_FONT: str(interior.code_font, "Consolas"),
    MATH_FONT: str(interior.math_font, "Cambria Math"),
    // East Asian language the document default already declares (zh configs;
    // see eaLang in main). CJK runs in another language carry their own.
    // Charter §13 (2026-09-28): zh-Hant/TW/HK/MO configs are tagged zh-TW, not zh-CN.
    DOC_EAST_ASIA: String(config.language || "").toLowerCase().startsWith("zh")
      ? ((/(hant|hk|-tw|-mo)/).test(String(config.language).toLowerCase()) ? "zh-TW" : "zh-CN")
      : null,
  };
}

// ============================================================
// CJK runs (Han, kana, Hangul, CJK punctuation, fullwidth forms, ...). CJK type
// has no italic, so a run in an italic context is split by script and its CJK
// segments are set upright (italics false; Latin keeps its italics). Each CJK
// segment also carries its East Asian language (ja-JP when it holds kana,
// ko-KR when it holds Hangul, else zh-CN) unless the document default already
// declares it. A run with no CJK, or one needing neither change, is emitted
// exactly as before. Shared punctuation (middle dot, dashes, ellipsis, curly
// quotes, tilde) BETWEEN two CJK characters belongs to the CJK run; beside
// Latin text it stays Latin. (Kept identical to build_epub.py CJK_RUN_RE.)
// ============================================================
const CJK_CHARS = "\\u1100-\\u11FF\\u2E80-\\u2FFF\\u3000-\\u303F\\u3040-\\u30FF\\u3100-\\u31FF\\u3200-\\u33FF" +
  "\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uA960-\\uA97F\\uAC00-\\uD7FF\\uF900-\\uFAFF\\uFE10-\\uFE1F\\uFE30-\\uFE6F" +
  "\\uFF00-\\uFFEF\\u{1AFF0}-\\u{1B16F}\\u{1F200}-\\u{1F2FF}\\u{20000}-\\u{3FFFF}";
const CJK_JOINERS = "\\u00B7\\u2013-\\u2015\\u2018\\u2019\\u201C\\u201D\\u2025-\\u2027~";
const CJK_SPLIT_RE = new RegExp(`([${CJK_CHARS}]+(?:[${CJK_JOINERS}]+[${CJK_CHARS}]+)*)`, "u");
const KANA_RE = /[\u{3040}-\u{30FF}\u{31F0}-\u{31FF}\u{FF66}-\u{FF9F}\u{1AFF0}-\u{1B16F}]/u;
const HANGUL_RE = /[\u{1100}-\u{11FF}\u{3130}-\u{318F}\u{A960}-\u{A97F}\u{AC00}-\u{D7FF}\u{FFA0}-\u{FFDC}]/u;

function cjkEastAsiaLang(seg, docEastAsia) {
  if (KANA_RE.test(seg)) return "ja-JP";
  if (HANGUL_RE.test(seg)) return "ko-KR";
  return docEastAsia || "zh-CN";
}

function cjkAwareRuns(opts, docEastAsia) {
  const parts = typeof opts.text === "string" ? opts.text.split(CJK_SPLIT_RE) : [];
  if (parts.length < 2) return [new TextRun(opts)];
  const italic = opts.italics === true;
  const needsSplit = italic || parts.some((p, k) => k % 2 === 1 && cjkEastAsiaLang(p, docEastAsia) !== docEastAsia);
  if (!needsSplit) return [new TextRun(opts)];
  const runs = [];
  parts.forEach((p, k) => {
    if (!p) return;
    if (k % 2 === 0) { runs.push(new TextRun({ ...opts, text: p })); return; }
    const ea = cjkEastAsiaLang(p, docEastAsia);
    runs.push(new TextRun({
      ...opts,
      text: p,
      ...(italic ? { italics: false } : {}),
      ...(ea !== docEastAsia ? { language: { eastAsia: ea } } : {}),
    }));
  });
  return runs;
}

// ============================================================
// Inline run builder — parse order backticks -> math -> bold -> italic (§3.3).
// Identical parser to the print generator (asymmetric parsers shipped literal
// backticks to Kindle, §3.3).
// ============================================================
function makeInlineBuilder(T, mathEnabled) {
  return function buildInlineRuns(text, baseOpts) {
    text = fixProseSubscripts(text);
    // Nested-emphasis degradation (identical to generate_book.js): bold-italic
    // renders bold.
    text = text.replace(/\*\*\*([^*]+)\*\*\*/g, "**$1**");
    const runs = [];
    const codeParts = text.split(/(`[^`]+`)/g);
    const isCodeSpan = (p) => p.startsWith("`") && p.endsWith("`") && p.length > 2;
    // Bold pairing ACROSS code/math spans (QC fix 2026-07-23, identical to
    // generate_book.js): even # of ** markers outside code -> toggle bold state
    // across the whole line so a bold span CONTAINING inline code renders
    // bold+code+bold instead of literal asterisks; odd count -> legacy pairing.
    let starMarkers = 0;
    for (const p of codeParts) {
      if (!isCodeSpan(p)) starMarkers += (p.match(/\*\*/g) || []).length;
    }
    const pairable = starMarkers > 0 && starMarkers % 2 === 0;
    let boldOn = false;
    const boldOpt = () => (boldOn ? { bold: true } : {});
    // Every run goes through cjkAwareRuns: CJK upright in italic contexts and
    // tagged with its East Asian language; non-CJK runs are unchanged.
    const pushRun = (opts) => { runs.push(...cjkAwareRuns(opts, T.DOC_EAST_ASIA)); };
    const emitItalicAware = (seg, extra) => {
      const italicParts = seg.split(/(\*[^*]+\*)/g);
      for (const part of italicParts) {
        if (part.startsWith("*") && part.endsWith("*") && part.length > 2) {
          pushRun({ ...baseOpts, ...extra, text: part.slice(1, -1), italics: true });
        } else if (part.length > 0) {
          pushRun({ ...baseOpts, ...extra, text: part });
        }
      }
    };
    for (const codePart of codeParts) {
      if (isCodeSpan(codePart)) {
        pushRun({ ...baseOpts, ...boldOpt(), text: codePart.slice(1, -1), font: T.CODE_FONT });
        continue;
      }
      if (codePart.length === 0) continue;
      // $..$ math parsing only for nonfiction (is_fiction:false) books, and a
      // currency pair ("$14.99 ... $24.99": digit-first, no \ ^ _) must stay
      // literal prose — otherwise the dollars are eaten and the span ships in
      // Cambria Math italic. (Kept identical to generate_book.js, §3.3.)
      const mathParts = mathEnabled ? codePart.split(/(\$[^$]+\$)/g) : [codePart];
      for (const mathPart of mathParts) {
        const inner = (mathEnabled && mathPart.startsWith("$") && mathPart.endsWith("$") && mathPart.length > 2)
          ? mathPart.slice(1, -1) : null;
        const currencyLike = inner !== null && /^\d/.test(inner) && !/[\\^_]/.test(inner);
        if (inner !== null && !currencyLike) {
          const expr = latexToUnicode(inner);
          pushRun({ ...baseOpts, ...boldOpt(), text: expr, font: T.MATH_FONT, italics: true });
          continue;
        }
        if (mathPart.length === 0) continue;
        if (pairable) {
          const toggleParts = mathPart.split("**");
          for (let i = 0; i < toggleParts.length; i++) {
            if (i > 0) boldOn = !boldOn;
            if (toggleParts[i].length > 0) emitItalicAware(toggleParts[i], boldOpt());
          }
          continue;
        }
        // Legacy pairing (unchanged behavior for zero/odd ** lines).
        const boldParts = mathPart.split(/(\*\*[^*]+\*\*)/g);
        for (const boldPart of boldParts) {
          if (boldPart.startsWith("**") && boldPart.endsWith("**") && boldPart.length > 4) {
            pushRun({ ...baseOpts, text: boldPart.slice(2, -2), bold: true });
            continue;
          }
          if (boldPart.length === 0) continue;
          emitItalicAware(boldPart, {});
        }
      }
    }
    return runs;
  };
}

function makeFactories(T, buildInlineRuns) {
  function createBodyParagraph(text) {
    const runs = buildInlineRuns(text, { font: T.FONT, size: T.BODY_SIZE, color: T.BODY_COLOR });
    return new Paragraph({
      spacing: { after: 160, line: T.BODY_LINE, lineRule: "atLeast" },
      indent: { firstLine: T.FIRST_INDENT },
      children: runs,
    });
  }
  // One line of a quote block. pos {first,last} places the line inside its
  // run of quote lines: the usual space before the first line and after the
  // last, tight spacing between lines, so a multi-line label reads as ONE
  // block. A single-line quote (first and last) keeps the historical spacing.
  // Quote text takes the BODY colour (2026-09-24, final render QC S12): Kindle's
  // dark and sepia themes remap body-coloured text, but the old fixed dark grey
  // #444444 could stay dark on a dark page. Grey is kept only for ornaments.
  function createBlockquote(text, pos) {
    const first = !pos || pos.first !== false;
    const last = !pos || pos.last !== false;
    const runs = buildInlineRuns(text, { font: T.FONT, size: T.BODY_SIZE - 2, color: T.BODY_COLOR, italics: true });
    return new Paragraph({
      spacing: { before: first ? 120 : 0, after: last ? 200 : 40, line: T.BODY_LINE, lineRule: "atLeast" },
      indent: { left: 720, right: 360 },
      children: runs,
    });
  }
  // Figure caption: the italic line directly below a mid-flow image, set as a
  // caption (centered, a size down, no first-line indent) close under its
  // figure; the image paragraph carries keepNext so the two never part.
  function createCaption(text) {
    return new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 0, after: 240, line: T.BODY_LINE, lineRule: "atLeast" },
      children: buildInlineRuns(text, { font: T.FONT, size: T.BODY_SIZE - 2, color: T.BODY_COLOR }),
    });
  }
  // Unit heading — Heading 1 for the Kindle auto-TOC (§7.2). PageBreak before
  // each unit is how Amazon detects chapter boundaries (§7.1). The title is
  // stored in its real case and DISPLAYED in capitals (allCaps), so the auto-TOC
  // Amazon builds from the Heading-1 text lists it as written, not uppercased.
  function createUnitHeading(title) {
    return [
      new Paragraph({ children: [new PageBreak()] }),
      new Paragraph({ spacing: { before: 1800, after: 300 } }),
      new Paragraph({
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 300, after: 400 },
        alignment: AlignmentType.CENTER,
        children: cjkAwareRuns({ text: title, allCaps: true, font: T.FONT, size: 32, color: T.BODY_COLOR, characterSpacing: 40 }, T.DOC_EAST_ASIA),
      }),
      new Paragraph({
        spacing: { before: 100, after: 500 },
        alignment: AlignmentType.CENTER,
        children: [new TextRun({ text: T.ORNAMENT, font: T.ORNAMENT_FONT, size: 22, color: "999999" })],
      }),
    ];
  }
  function createSubsectionHeading(title) {
    return new Paragraph({
      spacing: { before: 400, after: 200 },
      alignment: AlignmentType.LEFT,
      children: cjkAwareRuns({ text: title, font: T.FONT, size: 26, color: T.BODY_COLOR, bold: true }, T.DOC_EAST_ASIA),
    });
  }
  function createSectionBreak() {
    return new Paragraph({
      spacing: { before: 300, after: 300 },
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: `${T.ORNAMENT}  ${T.ORNAMENT}  ${T.ORNAMENT}`, font: T.ORNAMENT_FONT, size: 18, color: "BBBBBB" })],
    });
  }
  function createDisplayMath(expr) {
    return new Paragraph({
      spacing: { before: 240, after: 240 },
      alignment: AlignmentType.CENTER,
      children: cjkAwareRuns({ text: latexToUnicode(expr), font: T.MATH_FONT, size: 26, color: T.BODY_COLOR, italics: true }, T.DOC_EAST_ASIA),
    });
  }

  // ---- Fenced code block (```): one Paragraph per source line, monospace,
  // verbatim (NO inline parse, NO smart-quote substitution). Light gray shading
  // + a small left indent set it off; tight line spacing keeps it compact.
  // Blank code lines still emit a Paragraph so the listing spacing is preserved.
  function createCodeBlock(codeLines) {
    const size = Math.max(14, T.BODY_SIZE - 4);
    return codeLines.map((cl, i) => new Paragraph({
      shading: { type: ShadingType.CLEAR, color: "auto", fill: "F2F2F2" },
      spacing: { before: i === 0 ? 120 : 0, after: i === codeLines.length - 1 ? 120 : 0, line: 240, lineRule: "atLeast" },
      indent: { left: 240 },
      alignment: AlignmentType.LEFT,
      children: [new TextRun({ text: cl.length ? cl : " ", font: T.CODE_FONT, size, color: T.BODY_COLOR })],
    }));
  }

  // ---- Table (GFM pipe table): real Table/TableRow/TableCell with a bold
  // header row, thin borders, header shading, cell padding, the body font.
  // Cells hold inline-parsed runs (bold/italic/code/math reused).
  function createTable(rows, aligns) {
    const thin = { style: BorderStyle.SINGLE, size: 4, color: "999999" };
    const borders = { top: thin, bottom: thin, left: thin, right: thin,
                      insideHorizontal: thin, insideVertical: thin };
    const ncol = rows.reduce((m, r) => Math.max(m, r.length), 0);
    const alignFor = (c) => {
      const a = aligns && aligns[c];
      if (a === "center") return AlignmentType.CENTER;
      if (a === "right") return AlignmentType.RIGHT;
      return AlignmentType.LEFT;
    };
    const mkCell = (cellText, isHeader, colIdx) => {
      const runs = buildInlineRuns(cellText, {
        font: T.FONT, size: T.BODY_SIZE - 2, color: T.BODY_COLOR, bold: isHeader || undefined,
      });
      return new TableCell({
        margins: { top: 40, bottom: 40, left: 100, right: 100 },
        shading: isHeader ? { type: ShadingType.CLEAR, color: "auto", fill: "EDEDED" } : undefined,
        children: [new Paragraph({
          spacing: { after: 0, line: 240, lineRule: "atLeast" },
          alignment: alignFor(colIdx),
          children: runs.length ? runs : [new TextRun({ text: "", font: T.FONT, size: T.BODY_SIZE - 2 })],
        })],
      });
    };
    const tableRows = rows.map((cells, r) => {
      const padded = cells.slice();
      while (padded.length < ncol) padded.push("");
      return new TableRow({
        tableHeader: r === 0,
        children: padded.map((c, ci) => mkCell(c, r === 0, ci)),
      });
    });
    return new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      borders,
      rows: tableRows,
    });
  }

  // ---- List item: a hanging-indent Paragraph with a manual marker ("•  " for
  // bullets, "N.  " ordered). depth (0-based) nests via a deeper left indent.
  // Inline markup inside the item text is parsed.
  function createListItem(marker, itemText, depth) {
    const step = 360;
    const left = 360 + depth * step;
    const runs = [new TextRun({ text: marker, font: T.FONT, size: T.BODY_SIZE, color: T.BODY_COLOR })];
    for (const r of buildInlineRuns(itemText, { font: T.FONT, size: T.BODY_SIZE, color: T.BODY_COLOR })) runs.push(r);
    return new Paragraph({
      spacing: { after: 60, line: T.BODY_LINE, lineRule: "atLeast" },
      indent: { left, hanging: 240 },
      alignment: AlignmentType.LEFT,
      children: runs,
    });
  }

  return { createBodyParagraph, createBlockquote, createCaption, createUnitHeading, createSubsectionHeading, createSectionBreak, createDisplayMath, createCodeBlock, createTable, createListItem };
}

// ============================================================
// Chapter-opener art (OPTIONAL; kept identical in behavior to
// generate_book.js): interior.chapter_art {enabled, dir, width_in}; default
// dir cover_art/illustrations/live under the workspace; one <unit_id>.png per
// unit, injected after that unit's heading; missing dir/file = silent no-op.
// ============================================================
function pngDimensions(buf) {
  if (!buf || buf.length < 24) return null;
  if (buf[0] !== 0x89 || buf[1] !== 0x50 || buf[2] !== 0x4e || buf[3] !== 0x47) return null;
  return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) };
}

function resolveChapterArt(config, wsRoot) {
  const ca = (config.interior && config.interior.chapter_art) || {};
  if (ca.enabled === false) return null;
  const dir = path.resolve(wsRoot, ca.dir || path.join("cover_art", "illustrations", "live"));
  if (!fs.existsSync(dir)) return null;
  const widthIn = typeof ca.width_in === "number" && ca.width_in > 0 ? ca.width_in : 4.0;
  return { dir, widthIn };
}

function chapterArtParagraph(art, unitId, tag) {
  if (!art || !unitId) return null;
  const file = path.join(art.dir, `${unitId}.png`);
  if (!fs.existsSync(file)) return null;
  const data = fs.readFileSync(file);
  const dims = pngDimensions(data);
  if (!dims || !dims.w || !dims.h) {
    console.warn(`[${tag}] chapter art skipped (not a readable PNG): ${file}`);
    return null;
  }
  const wPx = Math.round(art.widthIn * 96);
  const hPx = Math.round(wPx * (dims.h / dims.w));
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 120, after: 360 },
    children: [new ImageRun({ type: "png", data, transformation: { width: wPx, height: hPx } })],
  });
}

// ============================================================
// Mid-flow images: a standalone markdown image line "![alt](relpath)" embeds
// the workspace-relative PNG/JPEG at that point in the flow (replica/photo
// books). Width = natural size at 150dpi, capped 5.0in; centered. A missing
// file or unreadable header is warned and SKIPPED — literal markdown must
// never reach the rendered artifact. generate_book.js embeds these too since
// 2026-07-27 (print prefers a grayscale "<name>_print.<ext>" sibling; this
// generator deliberately reads the color ORIGINAL); build_epub.py embeds them
// as <figure class="midflow">. The alt text becomes the image's description
// (docPr descr/title; name = the file name) for Kindle's screen reader, and an
// italic caption line directly below is bound to its figure (see parseMarkdown).
// ============================================================
const MD_IMAGE_RE = /^!\[([^\]]*)\]\(([^)\s]+)\)$/;

// Alt text is plain text: drop inline markup markers (as CommonMark does).
function mdAltText(raw) {
  return String(raw || "")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/\*([^*]+)\*/g, "$1")
    .replace(/\s+/g, " ")
    .trim();
}

// A caption line: one line wrapped in single-asterisk italics ("*...*"; a
// roman stretch inside, "*a maple,* Acer capillipes*, collected*", still counts).
function isCaptionLine(t) {
  return /^\*[^*\s](?:.*\S)?\*$/.test(t);
}

// A quote line: "> text", or a bare ">" (a paragraph break inside the quote).
function isQuoteLine(l) {
  const t = l.trim();
  return t === ">" || t.startsWith("> ");
}

function jpgDimensions(buf) {
  if (!buf || buf.length < 4 || buf[0] !== 0xff || buf[1] !== 0xd8) return null;
  let i = 2;
  while (i + 9 < buf.length) {
    if (buf[i] !== 0xff) { i++; continue; }
    const marker = buf[i + 1];
    if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { i += 2; continue; }
    const len = buf.readUInt16BE(i + 2);
    if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) {
      return { h: buf.readUInt16BE(i + 5), w: buf.readUInt16BE(i + 7) };
    }
    i += 2 + len;
  }
  return null;
}

function midflowImageParagraph(wsRoot, relPath, tag, alt = "", captioned = false) {
  const file = path.resolve(wsRoot, relPath);
  if (!fs.existsSync(file)) {
    console.warn(`[${tag}] mid-flow image missing, skipped: ${relPath}`);
    return null;
  }
  const data = fs.readFileSync(file);
  const ext = path.extname(file).toLowerCase();
  const isJpg = ext === ".jpg" || ext === ".jpeg";
  const dims = isJpg ? jpgDimensions(data) : pngDimensions(data);
  if (!dims || !dims.w || !dims.h) {
    console.warn(`[${tag}] mid-flow image unreadable (${ext}), skipped: ${relPath}`);
    return null;
  }
  const wIn = Math.min(5.0, dims.w / 150);
  const wPx = Math.round(wIn * 96);
  const hPx = Math.round(wPx * (dims.h / dims.w));
  console.log(`[${tag}] mid-flow image embedded: ${relPath} (${dims.w}x${dims.h})`);
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    ...(captioned ? { keepNext: true } : {}),
    spacing: { before: 240, after: captioned ? 120 : 240 },
    children: [new ImageRun({
      type: isJpg ? "jpg" : "png", data, transformation: { width: wPx, height: hPx },
      altText: { name: path.basename(file), title: alt, description: alt },
    })],
  });
}

// ============================================================
// Block-construct detection helpers (identical logic to generate_book.js;
// duplicated to keep each generator self-contained, the pattern the existing
// pngDimensions/resolveChapterArt helpers already follow). Pure + inert on
// prose: none fires on the 33 existing units.
// ============================================================
const FENCE_RE = /^\s*```/;
function isTableSeparator(line) {
  const t = line.trim();
  if (!t.includes("-")) return false;
  if (!/^\|?[\s:|-]+\|?$/.test(t)) return false;
  return t.includes("|") && /-/.test(t);
}
function looksLikeTableRow(line) {
  const t = line.trim();
  if (!t.includes("|")) return false;
  if (isTableSeparator(line)) return false;
  return true;
}
function splitTableRow(line) {
  let t = line.trim();
  const cells = [];
  let buf = "";
  for (let i = 0; i < t.length; i++) {
    const ch = t[i];
    if (ch === "\\" && t[i + 1] === "|") { buf += "|"; i++; continue; }
    if (ch === "|") { cells.push(buf); buf = ""; continue; }
    buf += ch;
  }
  cells.push(buf);
  if (cells.length && cells[0].trim() === "") cells.shift();
  if (cells.length && cells[cells.length - 1].trim() === "") cells.pop();
  return cells.map((c) => c.trim());
}
function parseAligns(sepLine) {
  return splitTableRow(sepLine).map((c) => {
    const s = c.trim();
    const l = s.startsWith(":"), r = s.endsWith(":");
    if (l && r) return "center";
    if (r) return "right";
    if (l) return "left";
    return null;
  });
}
function parseListItem(rawLine) {
  const m = rawLine.match(/^(\s*)([-*]|\d{1,9}[.)])\s+(.*)$/);
  if (!m) return null;
  const indent = m[1].replace(/\t/g, "  ");
  const token = m[2];
  const text = m[3];
  const ordered = /\d/.test(token);
  const depth = Math.floor(indent.length / 2);
  return { ordered, depth, marker: token, text };
}

// ============================================================
// Markdown -> paragraphs. Unit headings at the configured level become Heading 1.
// [IMAGE ...] blocks are consumed and skipped. Front-matter markdown before the
// first unit heading is ignored (front matter is rendered from config here).
// chapterArt, when non-null, is {paras: (Paragraph|null)[], idx: 0}: unit ids
// bound to headings BY POSITION; each unit heading consumes one slot.
// Three block constructs added (fenced code / pipe tables / lists); all inert on
// prose that uses none of them.
// ============================================================
function parseMarkdown(text, unitLevel, F, chapterArt, wsRoot) {
  const lines = text.split("\n");
  const paragraphs = [];
  let inDisplayMath = false;
  let displayMathBuffer = "";
  const isChapterLevel = unitLevel === "#";

  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    const line = raw.replace(/\s+$/, "");

    // Fenced code block (```): capture inner lines VERBATIM until the closing
    // fence (checked FIRST so "$$" / "# " / "| a |" inside a listing is never
    // interpreted). An unterminated fence renders what it captured to EOF.
    if (FENCE_RE.test(line)) {
      const codeLines = [];
      let j = i + 1;
      for (; j < lines.length; j++) {
        if (FENCE_RE.test(lines[j].replace(/\s+$/, ""))) break;
        codeLines.push(lines[j].replace(/\s+$/, ""));
      }
      if (j >= lines.length) {
        console.warn(`[generate_kindle] unterminated code fence opened at line ${i + 1}; rendered to EOF`);
      }
      for (const p of F.createCodeBlock(codeLines)) paragraphs.push(p);
      i = j;
      continue;
    }

    if (/^\[IMAGE[:\s\]]/.test(line.trim())) {
      // Well-formed image blocks only (see generate_book.js): anchored token,
      // closing "]" within a short window, never consume-to-EOF.
      let j = i;
      let closed = lines[j].trim().endsWith("]");
      while (!closed && j + 1 < lines.length && j - i < 10) {
        j++;
        closed = lines[j].trim().endsWith("]");
      }
      if (closed) { i = j; continue; }
      console.warn(`[generate_kindle] unclosed [IMAGE block at line ${i + 1} treated as prose`);
    }

    // Mid-flow markdown image line: embed (or skip with a warning; never literal).
    // An italic caption line directly below it (blank lines between allowed)
    // is bound to the figure: keepNext on the image, the line set as a caption.
    const mdImg = line.trim().match(MD_IMAGE_RE);
    if (mdImg) {
      let k = i + 1;
      while (k < lines.length && lines[k].trim() === "") k++;
      const cap = k < lines.length ? lines[k].trim() : "";
      const captioned = isCaptionLine(cap);
      const p = wsRoot ? midflowImageParagraph(wsRoot, mdImg[2], "generate_kindle", mdAltText(mdImg[1]), captioned) : null;
      if (p) {
        paragraphs.push(p);
        if (captioned) { paragraphs.push(F.createCaption(cap)); i = k; }
      }
      continue;
    }

    if (line.trim().startsWith("$$")) {
      if (!inDisplayMath) {
        const remainder = line.trim().replace(/^\$\$/, "");
        if (remainder.endsWith("$$")) {
          paragraphs.push(F.createDisplayMath(remainder.slice(0, -2).trim()));
        } else { inDisplayMath = true; displayMathBuffer = remainder; }
      } else {
        const remainder = line.trim().replace(/\$\$$/, "");
        displayMathBuffer += " " + remainder;
        paragraphs.push(F.createDisplayMath(displayMathBuffer.trim()));
        inDisplayMath = false; displayMathBuffer = "";
      }
      continue;
    }
    if (inDisplayMath) { displayMathBuffer += " " + line; continue; }

    if (line.trim() === "") continue;

    const isH1 = line.startsWith("# ") && !line.startsWith("## ");
    const isH2 = line.startsWith("## ") && !line.startsWith("### ");
    // H3-H6 all render as subsection headings (kept identical to generate_book.js).
    const isH3plus = /^#{3,6}\s/.test(line);

    if ((isChapterLevel && isH1) || (!isChapterLevel && isH2)) {
      paragraphs.push(...F.createUnitHeading(line.replace(/^#{1,2}\s+/, "").trim()));
      if (chapterArt) {
        const artPara = chapterArt.paras[chapterArt.idx++];
        if (artPara) paragraphs.push(artPara);
      }
      continue;
    }
    if (isChapterLevel && isH2) continue;
    if (!isChapterLevel && isH1) continue;
    if (isH3plus) { paragraphs.push(F.createSubsectionHeading(line.replace(/^#{1,6}\s+/, "").trim())); continue; }

    if (line.trim() === "---") { paragraphs.push(F.createSectionBreak()); continue; }
    // Quote block: a run of quote lines, including lines separated by blank
    // lines or by a bare ">", is ONE block (a multi-line label is written one
    // quote line per label line). A bare ">" is a paragraph break inside the
    // quote and never prints.
    if (isQuoteLine(line)) {
      const qTexts = [];
      let lastQ = i;
      for (let j = i; j < lines.length; j++) {
        const ql = lines[j].replace(/\s+$/, "");
        if (ql.trim() === "") continue;
        if (!isQuoteLine(ql)) break;
        lastQ = j;
        if (ql.trim() !== ">") qTexts.push(ql.trim().slice(2));
      }
      qTexts.forEach((q, k) => paragraphs.push(F.createBlockquote(q, { first: k === 0, last: k === qTexts.length - 1 })));
      i = lastQ;
      continue;
    }

    // GFM pipe table: header row + a separator row ("|---|:--:|"). Requiring the
    // separator keeps a lone prose line with a stray "|" from becoming a table.
    if (looksLikeTableRow(line) && (i + 1) < lines.length && isTableSeparator(lines[i + 1])) {
      const header = splitTableRow(line);
      const aligns = parseAligns(lines[i + 1]);
      const rows = [header];
      let j = i + 2;
      for (; j < lines.length; j++) {
        const bl = lines[j].replace(/\s+$/, "");
        if (bl.trim() === "" || !looksLikeTableRow(bl)) break;
        rows.push(splitTableRow(bl));
      }
      paragraphs.push(F.createTable(rows, aligns));
      i = j - 1;
      continue;
    }

    // Lists: consume a run of consecutive bullet / ordered items. Ordered items
    // are renumbered by sibling position (the source number is ignored). Detect
    // on the trailing-whitespace-stripped line so a CRLF master's "\r" never
    // blocks the match (the "$" anchor won't span a bare "\r").
    const li0 = parseListItem(line);
    if (li0) {
      let j = i;
      const counters = {};
      let prevDepth = -1;
      for (; j < lines.length; j++) {
        const li = parseListItem(lines[j].replace(/\s+$/, ""));
        if (!li) break;
        if (li.depth > prevDepth) counters[li.depth] = 1;
        for (const d of Object.keys(counters)) if (Number(d) > li.depth) delete counters[d];
        let marker;
        if (li.ordered) {
          const n = counters[li.depth] || 1;
          counters[li.depth] = n + 1;
          marker = `${n}.  `;
        } else {
          marker = "•  ";
        }
        paragraphs.push(F.createListItem(marker, li.text, li.depth));
        prevDepth = li.depth;
      }
      i = j - 1;
      continue;
    }

    paragraphs.push(F.createBodyParagraph(line));
  }
  return paragraphs;
}

// Strip everything before the first unit heading (front matter is config-driven).
function bodyFromFirstUnit(masterMd, unitLevel) {
  const lines = masterMd.split("\n");
  const isChapterLevel = unitLevel === "#";
  const headingRe = isChapterLevel ? /^#\s+(?!#)/ : /^##\s+(?!#)/;
  for (let i = 0; i < lines.length; i++) {
    if (headingRe.test(lines[i])) return lines.slice(i).join("\n");
  }
  return masterMd; // no unit heading found — emit whole thing
}

// ============================================================
// MAIN
// ============================================================
async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    console.log(USAGE);
    return;
  }
  const config = loadConfig(args.config);
  // workspace root = the config's directory (matches engine/compositor;
  // kept identical to generate_book.js)
  const wsRoot = path.dirname(path.resolve(args.config));
  if (path.basename(wsRoot) !== config.slug) {
    console.warn(`[generate_kindle] NOTE: workspace dirname '${path.basename(wsRoot)}' != slug '${config.slug}'; using the config's parent as the workspace root`);
  }
  const T = resolveTypography(config);
  const buildInlineRuns = makeInlineBuilder(T, config.is_fiction === false);
  const F = makeFactories(T, buildInlineRuns);

  const title = str(config.title, "");
  const subtitle = str(config.subtitle, "");
  const author = str(config.author, "");
  const isFiction = config.is_fiction === true;

  const children = [];
  // Plain config text (titles, copyright lines): CJK-aware runs, no markup.
  const plainRuns = (opts) => cjkAwareRuns(opts, T.DOC_EAST_ASIA);
  // Config free text (dedication, epigraph, attribution, reader's note, About
  // the Author) takes the SAME inline markup as the body (*italic*, **bold**,
  // `code`), so no literal asterisk reaches the page; an empty line keeps its
  // historical empty run.
  const configRuns = (text, opts) => {
    const runs = buildInlineRuns(text, opts);
    return runs.length ? runs : [new TextRun({ ...opts, text })];
  };

  // ---- Title page ----
  children.push(new Paragraph({
    spacing: { before: 3000, after: 80 }, alignment: AlignmentType.CENTER,
    children: plainRuns({ text: title.toUpperCase(), font: T.FONT, size: 36, color: T.BODY_COLOR, characterSpacing: 40 }),
  }));
  children.push(new Paragraph({
    spacing: { before: 300, after: 200 }, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: T.ORNAMENT, font: T.ORNAMENT_FONT, size: 20, color: "999999" })],
  }));
  if (subtitle) {
    children.push(new Paragraph({
      spacing: { before: 60, after: 300 }, alignment: AlignmentType.CENTER,
      children: plainRuns({ text: subtitle, font: T.FONT, size: 20, color: T.BODY_COLOR, italics: true }),
    }));
  }
  children.push(new Paragraph({
    spacing: { before: 600, after: 60 }, alignment: AlignmentType.CENTER,
    children: plainRuns({ text: author.toUpperCase(), font: T.FONT, size: 22, color: T.BODY_COLOR, characterSpacing: 60 }),
  }));

  // ---- Copyright ----
  children.push(new Paragraph({ children: [new PageBreak()] }));
  children.push(new Paragraph({ spacing: { before: 2800 } }));
  const copyrightLines = [];
  if (isFiction) {
    copyrightLines.push("This is a work of fiction. Names, characters, places, and incidents");
    copyrightLines.push("are the product of the author’s imagination or are used fictitiously.");
    copyrightLines.push("Historical persons appear as characters in a fictional narrative.");
    copyrightLines.push("Any resemblance to actual events or persons, living or dead, is coincidental.");
    copyrightLines.push("");
  }
  copyrightLines.push(str((config.strings || {}).copyright_line, `© 2026 ${author}. All rights reserved.`));
  copyrightLines.push("");
  copyrightLines.push(str((config.strings || {}).first_edition_line, "First edition"));
  for (const cl of copyrightLines) {
    if (cl === "") { children.push(new Paragraph({ spacing: { before: 120 } })); continue; }
    children.push(new Paragraph({
      spacing: { after: 40 }, alignment: AlignmentType.CENTER,
      children: plainRuns({ text: cl, font: T.FONT, size: 17, color: T.BODY_COLOR }),  // body color: fixed grey stays dim in Kindle dark mode
    }));
  }

  // ---- Dedication (config optional) ----
  const dedication = str(config.dedication, "");
  if (dedication) {
    children.push(new Paragraph({ children: [new PageBreak()] }));
    for (const l of dedication.split("\n")) {
      children.push(new Paragraph({
        spacing: { before: l === dedication.split("\n")[0] ? 3000 : 0, after: 120 }, alignment: AlignmentType.CENTER,
        children: configRuns(l, { font: T.FONT, size: T.BODY_SIZE, color: T.BODY_COLOR, italics: true }),
      }));
    }
  }

  // ---- Epigraph (config optional) ----
  if (config.epigraph) {
    const epi = config.epigraph;
    const epiText = typeof epi === "string" ? epi : str(epi.text, "");
    const epiAttr = typeof epi === "string" ? "" : str(epi.attribution, "");
    if (epiText) {
      children.push(new Paragraph({ children: [new PageBreak()] }));
      const epiLines = epiText.split("\n");
      epiLines.forEach((l, idx) => {
        children.push(new Paragraph({
          spacing: { before: idx === 0 ? 3000 : 0, after: 60 }, alignment: AlignmentType.CENTER,
          children: configRuns(l, { font: T.FONT, size: 20, color: T.BODY_COLOR, italics: true }),
        }));
      });
      if (epiAttr) {
        // same rendered-character rule as the print generator: no em-dash
        // prefix unless the voice contract explicitly allows em-dashes
        const attrPrefix = (config.voice && config.voice.no_em_dashes === false) ? "— " : "";
        children.push(new Paragraph({
          spacing: { before: 120, after: 200 }, alignment: AlignmentType.CENTER,
          children: configRuns(`${attrPrefix}${epiAttr}`, { font: T.FONT, size: 18, color: T.BODY_COLOR, italics: true }),
        }));
      }
    }
  }

  // ---- Reader's note (config.readers_note) — front-matter prose. Rendered here
  // so the ebook carries the same front matter as print/EPUB (else the Kindle
  // ships short of print and the word-count parity gate fails). §3.6 parity.
  const readersNote = str(config.readers_note, "");
  if (readersNote) {
    children.push(new Paragraph({ children: [new PageBreak()] }));
    children.push(new Paragraph({
      spacing: { before: 2000, after: 500 }, alignment: AlignmentType.CENTER,
      children: plainRuns({ text: str((config.strings || {}).readers_note_heading, "A NOTE TO THE READER"), font: T.FONT, size: 22, color: T.BODY_COLOR, characterSpacing: 60 }),
    }));
    for (const para of readersNote.split(/\n\s*\n/)) {
      const p = para.trim();
      if (!p) continue;
      children.push(new Paragraph({
        spacing: { after: 160 }, alignment: AlignmentType.LEFT,
        children: configRuns(p.replace(/\s*\n\s*/g, " "), { font: T.FONT, size: T.BODY_SIZE, color: T.BODY_COLOR }),
      }));
    }
  }

  // ---- Table of Contents (auto from Heading 1) — OMITTED by default (§16.4).
  // For Kindle / reflowable uploads Amazon builds navigation from the Heading-1
  // structure itself; a manual CONTENTS page + TableOfContents field is
  // redundant and, on some KDP upload paths, renders as a broken/blank screen
  // or a dead page-numbered list. Gate behind book_config.kindle_include_toc
  // (schema default FALSE — rely on Amazon's H1 auto-nav; set true only for an
  // upload path that wants an embedded TOC). Page numbers are ALWAYS absent
  // from Kindle (single section, header:0 footer:0). ----
  const includeToc = config.kindle_include_toc === true;
  if (includeToc) {
    children.push(new Paragraph({ children: [new PageBreak()] }));
    children.push(new Paragraph({
      spacing: { before: 2000, after: 600 }, alignment: AlignmentType.CENTER,
      children: plainRuns({ text: str((config.strings || {}).contents_heading, "CONTENTS"), font: T.FONT, size: 24, color: T.BODY_COLOR, characterSpacing: 60 }),
    }));
    children.push(new TableOfContents(str((config.strings || {}).toc_title, "Table of Contents"), {
      hyperlink: true,
      headingStyleRange: "1-1",
      stylesWithLevels: [new StyleLevel("Heading1", 1)],
    }));
  }

  // ---- Body ----
  const unitNoun = (config.voice && config.voice.unit_noun) ? config.voice.unit_noun : "chapter";
  const unitLevel = unitNoun === "part" ? "##" : "#";
  const srcPath = resolveSrc(config, args.src, wsRoot);
  const masterMd = fs.readFileSync(srcPath, "utf8");
  const body = bodyFromFirstUnit(masterMd, unitLevel);
  // Chapter-opener art: ids bind to unit headings by position (same rule as
  // generate_book.js and build_epub.py); missing files skip silently.
  const chapterArt = resolveChapterArt(config, wsRoot);
  const unitIdsForArt = (config.units || []).map((u) => (u && u.id) || "");
  const artParas = unitIdsForArt.map((id) => chapterArtParagraph(chapterArt, id, "generate_kindle"));
  const artCount = artParas.filter(Boolean).length;
  if (chapterArt && artCount > 0) {
    console.log(`[generate_kindle] chapter art: ${artCount} image(s) staged from ${chapterArt.dir}`);
  }
  children.push(...parseMarkdown(body, unitLevel, F, artCount > 0 ? { paras: artParas, idx: 0 } : null, wsRoot));

  // ---- About the Author (extended back matter, §7.3) ----
  // Sourced from config.about_the_author (free-text, paragraphs split on blank
  // lines) when present; falls back to a minimal factual bio built from author +
  // genre so the section always exists (helps discoverability). Its title is a
  // unit heading (page break + Heading 1 + ornament), so it is listed in
  // Amazon's auto-TOC like every other unit.
  children.push(...F.createUnitHeading(str((config.strings || {}).about_author_heading, "About the Author")));
  const aboutText = str(config.about_the_author, "");
  const aboutParas = aboutText
    ? aboutText.split(/\n\s*\n/)
    : [`${author} is the author of ${title}${subtitle ? ` (${subtitle})` : ""}.`];
  for (const para of aboutParas) {
    const runs = buildInlineRuns(para.replace(/\s*\n\s*/g, " ").trim(), { font: T.FONT, size: T.BODY_SIZE, color: T.BODY_COLOR });
    children.push(new Paragraph({
      spacing: { after: 200, line: T.BODY_LINE, lineRule: "atLeast" },
      indent: { firstLine: T.FIRST_INDENT },
      children: runs,
    }));
  }

  // ---- Document: single section, uniform 1" margins, no print furniture ----
  // CJK editions: East-Asian run language so downstream renderers apply CJK
  // line-breaking (kinsoku); no-op for non-zh configs.
  // w:val is the LATIN language, NOT the East-Asian one (2026-08-14: tagging it zh-CN
  // made Word classify ASCII as East Asian and render every Latin word from the eastAsia
  // font, silently voiding interior.body_font_latin — caught by reading a rendered page's
  // font names, invisible to every XML-level gate). eastAsia drives kinsoku; leave it zh-CN.
  const eaLang = T.DOC_EAST_ASIA
    ? { value: "en-US", eastAsia: T.DOC_EAST_ASIA }
    : undefined;
  const doc = new Document({
    // Core properties (docProps/core.xml): the book's own title/author, not the
    // docx library's "Un-named" defaults (Word File > Info, Explorer, KDP file).
    title: title || undefined,
    subject: subtitle || undefined,
    creator: author || undefined,
    lastModifiedBy: author || undefined,
    features: { updateFields: includeToc },   // only a TOC field needs on-open fill (§7.2); off by default (§16.4)
    styles: {
      default: {
        document: { run: { font: T.FONT, size: T.BODY_SIZE, color: T.BODY_COLOR, ...(eaLang ? { language: eaLang } : {}) } },
        heading1: {
          run: { font: T.FONT, size: 32, color: T.BODY_COLOR, ...(eaLang ? { language: eaLang } : {}) },
          paragraph: { alignment: AlignmentType.CENTER },
        },
      },
    },
    sections: [{
      properties: {
        page: {
          margin: { top: 1440, bottom: 1440, left: 1440, right: 1440, header: 0, footer: 0, gutter: 0 },
        },
      },
      children,
    }],
  });

  const outPath = resolveOutPath(config, args.out, wsRoot);
  const outDir = path.dirname(outPath);
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  const buf = await Packer.toBuffer(doc);
  fs.writeFileSync(outPath, buf);

  console.log(`\n=== BOOKSMITH Kindle DOCX ===`);
  console.log(`Source markdown : ${srcPath}`);
  console.log(`Output          : ${outPath}`);
  console.log(`Size            : ${(buf.length / 1024).toFixed(1)} KB`);
  console.log(`Body            : ${T.BODY_SIZE/2}pt ${T.FONT_NAME}, leading ${T.BODY_LINE}, color #${T.BODY_COLOR}`);
  console.log(`Unit noun       : ${unitNoun} (Heading 1 for auto-TOC)`);
  console.log(`Furniture       : single section, 1" margins, NO page numbers/headers/mirror/versos`);
  console.log(`TOC             : ${includeToc ? "manual CONTENTS + hyperlinked field (kindle_include_toc=true)" : "OMITTED by default — Amazon auto-navs from Heading 1 (§16.4)"}`);
}

if (require.main === module) {
  main().catch((e) => {
    // Quiet, structured message for expected errors (missing --config, no
    // markdown source). Set BOOKSMITH_DEBUG=1 for the full stack.
    console.error(`error: ${e && e.message ? e.message : e}`);
    if (process.env.BOOKSMITH_DEBUG && e && e.stack) console.error(e.stack);
    process.exit(1);
  });
}

module.exports = {
  main, parseMarkdown, bodyFromFirstUnit, USAGE,
  isTableSeparator, looksLikeTableRow, splitTableRow, parseAligns, parseListItem,
};
